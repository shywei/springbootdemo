(function($){
	
	$.extend({
		// 服务器刷新时间，服务器直接返回时间字符串，浏览器只需要显示
		// serverUrl 时间同步服务地址
		// interval 定期更新时间间隔 (毫秒)
		// callback 同步成功的更新函数
		serverClock: function(serverUrl, interval, callback){
	
			var timeSync = function(){ 
				$.ajax({
					type: 'get',
			        url: serverUrl + '?time=' +new Date(),
			        data: {},
			        dataType: 'json',
			        async: false,
			        success: function(data){
			        	if(data['message'] != null){
			        		callback(data['message']);
			        	}
			        },
			        error: function (msg) { 
			        } 
				});
			};
			
			setInterval(timeSync, interval); // 定期刷新时间
			timeSync();  // 第一次刷新时间
		},
		
		// 浏览器负责刷新时间，定时与服务器同步，从服务器获得一个毫秒表示的数字作为当前时间, 包括时区信息
		// serverUrl 时间同步服务地址
		// syncInterval 定期更新时间间隔
		// refreshInterval 本地时钟刷新间隔
		// format 时间显示格式
		// callback 同步成功的更新函数
		syncedLocalClock: function(serverUrl, syncInterval, refreshInterval, format, callback){
			
			var localClock = null; // 本地时钟
			
			// 获得当前的时间字符串
			var getTimeStr = function(time, timeZone, offset){
				var currentDate = new Date();
				currentDate.setTime(time + offset + currentDate.getTimezoneOffset()  * 60000);
				var timeStr = timeZone +"   "+ currentDate.format(format);
				return timeStr;
			};
			
			// 时间同步函数
			var timeSync = function(){ 
				// 同步开始时间
				var start = new Date().getTime();
				
				$.ajax({
					type: 'get',
			        url: serverUrl + '?time=' +new Date(),
			        data: {},
			        dataType: 'json',
			        async: false,
			        success: function(data){        	
			        	if(data['message'] != null && /^{.+}$/ .test(data['message'])){     		
			        		
			        		var zoneTime = eval("(" + data['message'] + ")");
			        		
			        		if(zoneTime.hasOwnProperty('zone') && zoneTime.hasOwnProperty('time')){
			        		
					        		// 同步完成时间
						        	var end = new Date().getTime();
						        	// 计算服务器同步时间到  客户端收到该时间的间隔
						        	var period = Math.ceil((end -start)/2);
						        	
						        	var timeZone = zoneTime.zone;
						        	// 获取用数字表示的当前时间
						        	var currentTime = period + (zoneTime.time - 0);
						        	
						        	var offset = zoneTime.offset;
						        	// 取消原来的定时器
						        	if(localClock){
						        		clearInterval(localClock);
						        	}
						            // 设置本地刷新的定时器
						        	localClock = setInterval(function(){
						        		// 当前时间定期更新
						        		currentTime += refreshInterval;
						        		// 显示当前时间
						        		callback(getTimeStr(currentTime, timeZone, offset));
						        		
						        	}, refreshInterval);
						        	// 第一次显示当前时间
						        	callback(getTimeStr(currentTime, timeZone, offset));      
			        		}
			        	}
			        },
			        error: function(msg) {	        	
			        } 
				});
			};
			
			setInterval(timeSync, syncInterval); // 定期更新时间
			timeSync(); // 第一次同步时间
		}
	});
	
	// 时间格式化扩展
	Date.prototype.format = function (fmt) {  
		
		var patterns = {
		        "M+": this.getMonth() + 1, //月份 
		        "d+": this.getDate(), //日 
		        "h+": this.getHours(), //小时 
		        "m+": this.getMinutes(), //分 
		        "s+": this.getSeconds()//秒 
		};
		
		if (/(y+)/.test(fmt)){
			fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
		}

		for (var p in patterns){	
			if (new RegExp("(" + p + ")").test(fmt)){
				fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (patterns[p]) : (("00" + patterns[p]).substr(("" + patterns[p]).length)));
			} 
		}
		return fmt;
	};	
	
})(jQuery);