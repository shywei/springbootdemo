var http = '';
//http = 'http://192.168.1.124:8080/ctr/';


//	离开用户名触发
$(".username input").blur(function(){
$(".username input")[0].validity.valueMissing;
});
//	离开密码触发
$(".pass input").blur(function(){
$(".pass input")[0].validity.valueMissing;
});

var codeIsOk = 0;
//用户信效验
$(".username input").blur(function(){
	var systemuserUserid = $(".username input").val();
	if(systemuserUserid.length<=0){
		$(".alert .useInfo").html("帐号不能为空!");
		$(".isOk").attr("value",0);
		return;
	}else{
		$(".alert .useInfo").html("");
	}
});
$(".pass input").blur(function(){
	var systemuserPass = $(".pass input").val();
	if(systemuserPass.length<=0){
		$(".alert .useInfo").html("密码不能为空!");
		$(".isOk").attr("value",0);
		return;
	}else{
		$(".alert .useInfo").html("");
	}
});
$(".verCodeOk").blur(function(){
	//验证码校验
	var inputCode = $(".verCodeOk").val();
//	console.log(inputCode,dataCode)
      if (inputCode.length <= 0) {
        $(".alert .useInfo").html("请输入验证码!");
        $(".isOk").attr("value",0);
        codeIsOk = 0;
        return
      }
      else if(inputCode != dataCode) {
        $(".alert .useInfo").html("验证码输入错误！");
        $(".isOk").attr("value",0);
        codeIsOk = 0;
        resCode(); //刷新验证码
     	return
      }	
      if(inputCode == dataCode){
      	$(".alert .useInfo").html("")
      } else{
      	codeIsOk = 0;
      	return
      }
      if($(".alert .useInfo").html()!=""){
      	codeIsOk = 0;
         return
      }
      codeIsOk = 1;
      $(".isOk").attr("value",1)
});
// 点击登录
function logBtn(){
	var systemuserUserid = $(".username input").val();//用户名
	var systemuserPass = $(".pass input").val();//密码
//	var cip = returnCitySN.cip;
//	var cityName = returnCitySN.cname;
	$.ajax({
		url:http + 'systemUser/login.do',
		type:'get',
		data:{
			loginName:systemuserUserid,
			password:systemuserPass
		},
		dataTpye:'json',
		success:function(data){
			console.log(data)
			if(data.code == 0){
				$(".alert .useInfo").html("用户名或密码错误！")
				return;
			}
			if(data.code == 1){
				var deptid=data.obj.deptid;//部门编号
				var userName = data.obj.userName;;// 用户名称
				var deptName = data.obj.deptName;//部门名称
				var roleid = data.obj.roleid;//roleid
				var sId = data.obj.id;//id

				sessionStorage.setItem("sName", userName);
				sessionStorage.setItem("sRoleId", roleid);
				sessionStorage.setItem("sUserDept", deptid);
				sessionStorage.setItem("sId", sId);
				sessionStorage.setItem("department", deptName);

			}
			window.location.href="newAdm.html";
		},error:function(data){
			console.log("请检查网络链接，稍后再试");
		}
	});
}
$(".login .btn").unbind("click").on("click",function(){
	$(".verCodeOk").blur();
	if($(".isOk").attr("value")==1&&codeIsOk==1){
		logBtn();
	}
});

var dataCode ;
//验证码
function resCode(){
$.ajax({
	url:http + 'systemUser/random.do',
		type:'get',
		data:'',
		dataTpye:'json',
		success:function(data){
			if(data.obj){
				dataCode =data.obj;
				$(".verCode").attr("value",data.obj);
			}else{
				$(".alert .useInfo").html("验证码错误!")
				return;
			}
		},error:function(data){
			console.log("验证码获取失败 请检查网络链接");
		}
});
};
resCode();
$(".verCode").on("click",function(){
	resCode();
});
//判断是否敲击了Enter键 
$(document).keydown(function(e){ 
    if(e.keyCode ==13){ 
    	$(".verCodeOk").blur();
    	if($(".isOk").attr("value")==1&&codeIsOk==1){
			logBtn();
		}
    } 
});
/*@gaoxujian
 * 页面加载完执行
 * 如果ctr_access_record总记录大于3万条，删除前2万条记录
 * */
//$().ready(function(){
//	$.ajax({
//		url:http+'deleteRecordInfo/deleteOverdueRecord.do',
//		type:'get',
//		dataTpye:'json',
//		success:function(data){
//			
//		},error:function(data){
//			
//		}
//	});
//});