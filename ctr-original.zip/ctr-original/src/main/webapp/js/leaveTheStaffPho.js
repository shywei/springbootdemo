//离队人员--查询--渲染表格循环显示所有图片的数据
function redershowAllPone($elem,data) {
    var phoneLen = data.obj.length
        trPhone = ''
    if(phoneLen === 0){//如果没有数据显示默认无数据图片
        trPhone+=`
        <div style="height: 100%; width: 100%;">
            <img src="img/dataloss.png" style=" margin-left: 600px;margin-top:100px">
        </div>
        `
    }else{
        for (var i = 0; i < phoneLen; i++) {
            var data_url = data.obj[i].photoUrl;
            //判断后端数据有没有人员图片，没有显示默认图片
            if (data.obj[i].photoUrl === null || data.obj[i].photoUrl === '') {
                var data_url = "img/moren.png"
            } else {
                data_url =data.message+data.obj[i].photoUrl;
            }
            trPhone += `

                    <li>

                  <span><img src="${data_url}"><div class="pic-click bg-click"></div></span>
                        <div class="all_phone_Name">
                           <p data-vnum=${data.obj[i].userid}> 编号:${data.obj[i].userid}</p>
                            <p data-state=${data.obj[i].reviseState} data-name=${data.obj[i].userName}>姓名:${data.obj[i].userName}</p>
                        </div>
                    </li>

            `
    }
}

    $elem.html(trPhone)
}

var sRoleId = sessionStorage["sRoleId"];
var sUserDept=sessionStorage["sUserDept"];
all_Phone();
//点击查询获取学员姓名 学员编号 调队时间 调队状态
$("#J_Query").click(function(){
    all_Phone();
    loadLtS();
});

//获取所有图片的数据
function all_Phone(page){
     page=page||"1"//当前页
    var rows = $("#sellc select option:selected").val()||"30";//每页显示数量
    var J_studentNa=$("#J_studentNa").val();                  //人员姓名
    var J_studentNum=$("#J_studentNum").val();                //人员编号
    var J_transTimes=$("#J_transTimes").val();                //调队时间
    var J_deptNum=$("#J_deptNum option:selected").val();      //状态
    $.ajax({
        url: http+"dropUserController/queryDropUserList",
        dataType:"JSON",
        type:"GET",
        data:{
            deptid:sUserDept,            //大队code
            roleid:sRoleId,            //角色id
            page:page,                  //当前页码
            rows:rows,                  //每页多少条
            userName:J_studentNa,           //姓名
            userid:J_studentNum,          //人员编号
            reviseTime:J_transTimes,            //调队时间
            reviseState:J_deptNum              //状态
            },
        success:function(data){
            console.log(data)
            console.log(rows)
        redershowAllPone($(".phone_List ul"), data)
            selectedImg();
            var dangqian=parseInt(data.objExt.currentPage)/1;//当前页码
            userstotal=data.objExt.totalCount;////一共多少条数据
             var rows=data.objExt.pageSize;//一页多少数据
             yeshu=Math.ceil(userstotal/rows);
             if(yeshu==0){
                 yeshu=1;
                    }

		    var html1='';
		    if(dangqian==1){
		        if(dangqian<=yeshu){
		            html1+=`<li class="ycolor">${dangqian}</li>`;
		        }
		        if(dangqian+1<=yeshu){
		            html1+=`<li>${dangqian+1}</li>`;
		        }
		        if(dangqian+2<=yeshu){
		            html1+=`<li>${dangqian+2}</li>`;
		        }
		        if(dangqian+3<=yeshu){
		            html1+=`<li>${dangqian+3}</li>`;
		        }
		        if(dangqian+4<=yeshu){
		            html1+=`<li>${dangqian+4}</li>`;
		        }
		    }else if(dangqian==2){
		        html1+=`<li>${dangqian-1}</li>`;
		        html1+=`<li class="ycolor">${dangqian}</li>`;
		
		        if(dangqian+1<=yeshu){
		            html1+=`<li>${dangqian+1}</li>`;
		        }
		        if(dangqian+2<=yeshu){
		            html1+=`<li>${dangqian+2}</li>`;
		        }
		        if(dangqian+3<=yeshu){
		            html1+=`<li>${dangqian+3}</li>`;
		        }
		    }else if(dangqian==yeshu&&dangqian>=5){
		        html1+=`
		            <li>${dangqian-4}</li>
		            <li>${dangqian-3}</li>
		            <li>${dangqian-2}</li>
		            <li >${dangqian-1}</li>
		            <li class="ycolor">${dangqian}</li>
		        `
		    }else if(dangqian==yeshu-1&&dangqian>=5){
		        html1+=`
		            <li>${dangqian-3}</li>
		            <li>${dangqian-2}</li>
		            <li>${dangqian-1}</li>
		            <li class="ycolor">${dangqian}</li>
		            <li>${dangqian+1}</li>
		        `
            }else{
                if(dangqian-2>0){
                    html1+=`<li>${dangqian-2}</li>`;
                }
                if(dangqian-1>0){
                    html1+=`<li>${dangqian-1}</li>`;
                }
                html1+=`<li class="ycolor">${dangqian}</li>`;
                if(dangqian<yeshu){
                    html1+=`<li>${dangqian+1}</li>`;
                }
                if(dangqian+1<yeshu){
                    html1+=`<li>${dangqian+2}</li>`;
                }
             }
        $("ul.yema1").html(html1);
        $(".look1 .allpeople1").html(userstotal);
        $(".look1 .nowpage1").html(dangqian);
        $(".look1 .allpage1").html(yeshu);

        //每一页显示多少条数据
    $(".footPage div#AllPhoto #sellc").change(function(){
        var W_number=$("#sellc select option:selected").val();
        var W_num=1;
        all_Phone(W_num,W_number)
        console.log(W_number)
    });
            //点击页面的跳转
    $(".jogger1 .yema1 li").each(function(i){
         $(".yema1 li").eq(i).unbind("click").on("click",function(){
               $(this).removeClass("ycolor");
                $(this).addClass("ycolor")
             var w_liNum = $(this).html();
                 all_Phone(w_liNum);
          })
    })
        //点击首页的跳转
    $(".jogger1").unbind("click").on("click",".firstpage1",function(){
        all_Phone(1);
    });
        //点击末页跳转
    $(".lastpage1").unbind("click").on('click',function(){
        all_Phone(yeshu);
    })
        //点击go跳转
    $(".jogger1").on("click"," .tiaozhuan1",function(){
        var Num = 0;
        if($(".jogger1 input").val()>yeshu){
            $(".jogger1 input").val(yeshu);
        }
        Num = $(".jogger1 input").val();
        $(".condition .jogger1 .tiaozhuan1").unbind("click");
                all_Phone(Num);
         });
         }
     })

    }
//离队人员选择选择图片
//selectedImg();
function selectedImg(){
        $(".phone_List").unbind('click').on("click", "ul li", function() {
            $(this).find(" .pic-click").toggleClass('bg-click').toggleClass('bg-clicked'); //点中的被选中
    })
}
//离队人员的列表撤回按钮事件
$("#J_withdraw").click(function(){
    //获取调队的状态
    var checkItem = $('.changedata tbody').find('.bg6');
    var statusDatas = [];
    var checkStatus = true;

    if (checkItem.size() === 0) {
        parent.$(".withdraw").fadeIn();
        parent.$(".baohu").fadeIn();
        parent.$(".smallkuang-header span").html("撤回人员");
    } else {
        checkItem.each(function (idx, value) {
            // alert( $(value).parent().parent().find("td[data-vnum]").attr('data-vnum'))
            var status = $(value).parent().parent().find("td[data-vnum]").attr('data-vnum')
            statusDatas.push(status);
            if (Number(status) !== 1) {
                checkStatus = false;
            }
        });
        if (checkStatus) {
            // alert("确定撤回该信息？")
            parent.$(".withdraw_reserve_btn").fadeIn();
            parent.$(".baohu").fadeIn();
            parent.$(".F_sure_withdraw").unbind('click').click(function(){
                //对确定按钮进行撤回
                var rollcallleaveNo = $('.changedata tbody').find('.bg6');
                var rollcallleavNum = []
                var rollcallName = []
                rollcallleaveNo.each(function (idx,value){
                     //alert($(value).parent().parent().find(".studentNumber").html())
                    var rollNum=$(value).parent().parent().find(".studentNumber").html();
                    rollcallleavNum.push(rollNum)
                    var rollName=$(value).parent().parent().find(".studentName").html();
                    rollcallName.push(rollName)
                })
                var concatStrNum = rollcallleavNum.join(',')
                var sUserName=rollcallName.join(',')
                $.ajax({
                    url:http+'ChangeReviseStateController/recallChangeDeptUser',
                    dataType:'JSON',
                    type:'GET',
                    data:{
                        ids:concatStrNum,
                        userNames:sUserName,
                        currentId:sessionStorage.sId
                    },
                    success:function(data){
                        loadLtS();
                        parent.$(".withdraw_reserve_btn").fadeOut();
                        parent.$(".baohu").fadeOut();

                    }
                })
            })

        }else{
            parent.$(".withdraw_serve").fadeIn();
            parent.$(".baohu").fadeIn();
        }
    }
    //获取选中的人员编号 按字符串,拼接
})


//离队人员图表撤回按钮事件
$("#J_withdrawChart").click(function(){
    //获取调队的状态
    var checkItem = $('.phone_List ul').find('.bg-clicked');
    var statusDatas = [];
    var checkStatus = true;
    if (checkItem.size() === 0) {
        // alert("请选择撤回的信息")
        parent.$(".smallkuang-header span").html("撤回人员");
        parent.$(".withdraw").fadeIn();
        parent.$(".baohu").fadeIn();
    } else {
        checkItem.each(function (idx, value) {
            var status = $(value).parent().parent().find(".all_phone_Name").children('p[data-state]').attr('data-state')
            statusDatas.push(status);
            if (Number(status) !== 1) {
                checkStatus = false;
            }
        });
        if (checkStatus) {
            // alert("确定撤回该信息？")
            parent.$(".withdraw_reserve_btn").fadeIn();
            parent.$(".baohu").fadeIn();
            parent.$(".F_sure_withdraw").unbind('click').click(function(){
                //对确定按钮进行撤回
                var rollcallleaveNo = $('.phone_List ul li').find('.bg-clicked');
                var rollcallleavNum = []
                var rollcallName=[]
                rollcallleaveNo.each(function (idx,value){
                    var rollNum=$(value).parent().parent().find(".all_phone_Name").children('p[data-vnum]').attr('data-vnum');
                    var rollName=$(value).parent().parent().find(".all_phone_Name").children('p[data-state]').attr('data-name');
                    rollcallName.push(rollName)
                    rollcallleavNum.push(rollNum)
                })
                var concatStrNum = rollcallleavNum.join(',')
                var sUserName=rollcallName.join(',')
                $.ajax({
                    url:http+'ChangeReviseStateController/recallChangeDeptUser',
                    dataType:'JSON',
                    type:'GET',
                    data:{
                        ids:concatStrNum,
                        userNames:sUserName,
                        currentId:sessionStorage.sId
                    },
                    success:function(data){
                        all_Phone();
                        parent.$(".withdraw_reserve_btn").fadeOut();
                        parent.$(".baohu").fadeOut();

                    }
                })
            })

        }else{
            parent.$(".withdraw_serve").fadeIn();
            parent.$(".baohu").fadeIn();
        }
    }
})

parent.$(".F_cancle_withdraw").unbind('click').click(function(){
    //alert(3333)
    parent.$(".withdraw_reserve_btn").fadeOut();
    parent.$(".baohu").fadeOut();

})
//点击del_time_消失
    parent.$(".del_time_").unbind('click').click(function(){
        parent.$(".withdraw_reserve_btn").fadeOut()
        parent.$(".baohu").fadeOut()
    })

