var http = "";

//http = "http://192.168.1.124:8080/ctr/";



if(!sessionStorage['sId']){
    location.href = 'Login.html';
}


var bianhao = 0;
var oldData007='';
var oldData009 = '';
var numcode = 0;
var isSetOver = true;

var sName = sessionStorage.getItem("sName");
//用户信息
var htmls=
    '<div  class="borderR"> <img src="img/people-new.png" alt=""/> <div class="uer"><p>你好,</p><span>'+sName+'</span></div>';
$(".asUer").html(htmls);
var recordDeptId=sessionStorage .sUserDept;

//请求后台
$.ajax({
    type: "POST",
    datatype: 'JSON',
    data: {recordDeptId: recordDeptId},
    url: http + "AttendPeopleRecordController/clearRecord.do",
    success: function (data) {
      console.log(data);
        if (data.code >= 0) {
            $("div.alert").fadeIn();
            $("div.alert div.alert_content").hide();
            $("div.alert div.people-rollcall").fadeIn();
            kaishi = new Date();
            kaishi = kaishi.toString().substr(16, 8);
            bianhao = 0;
            qingqiu();
        }
    }
})
var index=0;
function qingqiu() {
    if (!isSetOver) {
        return
    }
    setTimeout(qingqiu, 650);
    $.ajax({
        type: 'post',
        url: http + "AttendPeopleRecordController/prepareRecord.do",
        data: {recordDeptId: recordDeptId},
        datatype: 'JSONP',
        jsonp: 'callbacck',
        traditional: true,
        success: function (data) {
                       //设置初始计数器
            if(data.result.length==0){
                index++;
            }else{
                index=0;
            }
            console.log(index);
            if(index==3600){
                $(".baohu").fadeIn();
                $(".rollcallMessage").fadeIn();
                window.opener.parent.$(".baohu").fadeIn();
                window.opener.parent.$(".rollcallMessage").fadeIn();
                isSetOver = false;

            }
            //var data = data.result[0];
            var numdata = data;
            numcode += data.result.length;
            if (numcode === 0) {
                window.opener.parent.$(".rollcallMessage-foot-complete").css({
                    'opacity': 0.4
                });
                $(".rollcallMessage-foot-complete").css({
                    'opacity': 0.4
                });
                $("div.people-rollcall div.mainrollcall ul.btns li.wan").css({
                    'opacity': 0.4
                });
                $("div.people-rollcall div.mainrollcall ul.btns li.zan").css({
                    'opacity': 0.4
                });
                return;
            } else {
                $("div.people-rollcall div.mainrollcall ul.btns li.wan").css({
                    'opacity': 1
                });
                $("div.people-rollcall div.mainrollcall ul.btns li.zan").css({
                    'opacity': 1
                })
                window.opener.parent.$(".rollcallMessage-foot-complete").css({
                    'opacity': 1
                });
                $(".rollcallMessage-foot-complete").css({
                    'opacity': 1
                });
            }
            $("div.people-rollcall b.total").html(numdata.allnum);
            $("div.people-rollcall b.bingxiu").html(numdata.sickleavenum);
            $("div.people-rollcall b.qita").html(numdata.othernum);

            if (data.result.length <= 0) {
                return;
            }
            if (oldData007 == data.result[0].id) {
                return
            }

            oldData007 = data.result[0].id;
            showPhoto(data, numdata);
        }
    })
}
function showPhoto(data, numdata) {
    $("div.people-rollcall div.renyuan").html(data.result[0].deptName + "   编号" + data.result[0].userid + "      " + data.result[0].userName);
    if (data.result[0].photoUrl != null) {
        $("div.people-rollcall div.zhaopian img").attr("src", data.result[0].photoUrl);
    } else {
        $("div.people-rollcall div.zhaopian img").attr("src", "img/moren.png");
    }
    bianhao++;
    $("div.people-rollcall b.queqin").html((numdata.allnum - numdata.sickleavenum - numdata.othernum - bianhao));
    $("div.people-rollcall b.chugong").html(bianhao);
    $("div.people-rollcall div.zhaopian").animate({width: 0}, 250);
    $("div.people-rollcall div.zhaopian").animate({width: 280}, 250);
}
var kaishi;
var time;//定时器

//终止点名
function StopRollcall(){
    $.ajax({
        type: 'POST',
        data: {recordDeptId: recordDeptId},
        datatype: 'JSONP',
        jsonp: 'callback',
        url: http + 'AttendPeopleRecordController/shutdownRecord.do',
        traditional: true,
        success: function () {
        }
    })

    oldData007 = '';
    oldData009 = '';

    bianhao = 0;

    numcode = 0;
}
    $("div.people-rollcall div.mainrollcall ul.btns li.zhong").click(function () {
        window.close();
        window.opener.parent.$(".baohu").fadeOut();
        window.opener.parent.$(".rollcallMessage").fadeOut();
        StopRollcall();
    })


var zandate;
//暂停点名
$("div.people-rollcall div.mainrollcall ul.btns li.zan").click(function () {
    if ($(this).css("opacity") / 1 === 0.4) {
        return;
    }else{
        isSetOver = false;
        $(".people-rollcall").fadeOut();
        $(".pause").fadeIn();
        var zandate=new Date();
        var pauseDatetime=zandate.toString().substr(16,8);
        $.ajax({
            type: 'POST',
            data: {pauseDatetime:pauseDatetime,
                    recordDeptId : recordDeptId},
            dataType: 'JSON',
            url: http + 'AttendPeopleRecordController/pauseRecord.do',
            success: function (data) {
                console.log(data)

                var len=data.length;
                $("[name='pausebody']").empty();

                for(var i=0;i<len;i++){
                    $("[name='pausebody']").append(" <li><span>"+data[i].userName+"</span></li>");
                }
                console.log(len)
            }
        })
         qingqiu();
    $(".continiue button").click(function(){
        $(".people-rollcall").fadeIn();
        $(".pause").fadeOut();
        isSetOver = true;
        qingqiu();
    })

    }

//        if($(this).html()=="暂停点名"){
//            $(this).html("恢复点名");
//            isSetOver = false;
//            zandate=new Date();
//            zandate=zandate.toString().substr(16,8);
//        }else{
//            $(this).html("暂停点名");
////			$.ajax({
////				type:'POST',
////				datatype:'JSONP',
////				jsonp:'callback',
////				url:http+'AttendPeopleRecordController/pauseRecord.do',
////				data:{pauseDatetime:zandate,recordDeptId:sessionStorage['sUserDept']},
////				success:function(callback){}
////			})
//            isSetOver = true;
//            qingqiu();
//        }
})
//完成点名
function completeRollcall(){
    if ($("div.people-rollcall div.mainrollcall ul.btns li.zan").css("opacity") / 1 === 0.4) {
        return;
    }
    $(".rollcallMessage").hide();
    $(".baohu").show();
    $(".bar-1").show();
    isSetOver = false;
    oldData007 = '';
    oldData009 = '';

    numcode = 0;
    bianhao = 0;
    var endDate = new Date();
    endDate = endDate.toString().substr(16, 8);
    var kaishi = new Date();
    kaishi = kaishi.toString().substr(16, 8);
    var operationPersonnel=sessionStorage.sName;
    var depId=$("select[class='teamControlxiugai'] option:selected").val();
    //var operationIP=sessionStorage.logComIP;
    var depCode=sessionStorage.sUserDept;

    $.ajax({
        url: http + "AttendPeopleRecordController/commitRecord.do",
        type: 'POST',
        dataType: 'JSON',
        async: true,
        traditional: true,
        data: {
            depCode:depCode,
            //depId:depId,
            //operationIP:operationIP,
            operationPersonnel:operationPersonnel,
            recordDeptId: depCode,
            attendNum: $("div.people-rollcall b.chugong").html()||"",
            startDatetime: kaishi, endDatetime: endDate,
            absenseNum: $("div.people-rollcall b.queqin").html()||""
        },

        success: function (callback) {


            $(".end").show();
            $(".baohu").show();
            $(".end-body2").hide();
            $(".end-line ").hide();
            //$(".baohu").show();
            $(".bar-1").hide();
//          $(".end").show();
//          $(".baohu").show();
            $(".end-body ul").empty();
            console.log(callback);
            var len = callback.result.length;
            console.log(len);
            var h = "";
            if (len <= 0) {
                $(".end-body ul").hide();
                $(".end-line ").hide();
                $(".end-body2").show();
                //console.log(len);
                $(".end .footer").show();
                $("[name='end']").show();


            } else {

                $(".end-body ul").show();
                $(".end-line ").show();
                //$(".endbody").hide();
                $(".end .footer").show();
                $("[name='end']").show();

                $(".end-body2").hide();
                h += "<li><span class='wid-141' style='font-weight:bold '>学员编号</span> &nbsp <span class='wid-64' style='font-weight:bold '>学员姓名</span></li><li><span class='wid-141' style='font-weight:bold '>学员编号</span> &nbsp <span class='wid-64' style='font-weight:bold '>学员姓名</span></li>"

                for (var i = 0; i < len; i++) {
                    h += "<li><span class='wid-141'>" + callback.result[i].userid + "</span> &nbsp <span class='wid-64'>" + callback.result[i].userName + "</span></li>";

                }
                $("[name='endbody']").html(h)
            }
            $("[class='rollcallnum']").html(callback.rollcallnum);
            $("[class='attendnum']").html(callback.attendnum);
            $("[name='absensenum']").html(callback.absensenum);
//				console.log(callback.absensenum);
            $("div.alert div.alert_content").hide();
            $("div.alert div.people-rollcall").hide();
            $("div.alert div.end").show();
            $("div.people-rollcall div.renyuan").html("暂未有人录入");
            $("div.people-rollcall b.total").html("");
            $("div.people-rollcall b.bingxiu").html("");
            $("div.people-rollcall b.qita").html("");
            $("div.people-rollcall div.zhaopian img").attr("src", "img/no-people.png");
            $("div.people-rollcall b.chugong").html("");
            $("div.people-rollcall b.queqin").html("");
            //点名完成弹出框


        }

    })
}
    $("div.people-rollcall div.mainrollcall ul.btns li.wan").click(function () {
        completeRollcall();
    })
$("[name='end']").on("click", function () {
    $(".end").fadeOut();
    $(".baohu").fadeOut();
    if(sessionStorage['sRoleId']/1===2||sessionStorage['sRoleId']/1===1){
        window.opener.suosearch(2,"",1,$("div.rollcallbottom p select").val())
    }else if(sessionStorage['sRoleId']/1===3){
        window.opener. window.location.reload();
    }
    window.close();
    window.opener.parent.$(".baohu").fadeOut();
    window.opener.parent.$(".rollcallMessage").fadeOut();
    //刷新页面
    //var d = $("div.date input").val();
    //var j = sessionStorage['sUserDept'];
    //if (sessionStorage['sRoleId'] / 1 === 2 || sessionStorage['sRoleId'] / 1 === 1) {
    //    suosearch(2, d, 1, $("div.rollcallbottom p select").val())
    //} else if (sessionStorage['sRoleId'] / 1 === 3) {
    //    duisearch(3, d, j, 1, $("div.rollcallbottom p select").val());
    //}

    oldData007 = '';
    oldData009 = '';

    bianhao = 0;
    numcode = 0;
})
//弹出框完成点名
$(".rollcallMessage-foot-complete").on("click",function(){
    completeRollcall();
})
//弹出框终止点名
$(".rollcallMessage-foot-stop").on("click",function(){
    window.close();
    window.opener.parent.$(".baohu").fadeOut();
    window.opener.parent.$(".rollcallMessage").fadeOut();
    StopRollcall();
})



//关闭浏览器事件（暂时留着）
window.onbeforeunload = onbeforeunload_handler;
window.onunload = onunload_handler;
function onbeforeunload_handler(){
    $.ajax({
        type: 'POST',
        data: {recordDeptId: recordDeptId},
        datatype: 'JSONP',
        jsonp: 'callback',
        url: http + 'AttendPeopleRecordController/shutdownRecord.do',
        traditional: true,
        success: function () {
            if(sessionStorage['sRoleId']/1===2||sessionStorage['sRoleId']/1===1){
                window.opener.suosearch(2,"",1,$("div.rollcallbottom p select").val())
            }else if(sessionStorage['sRoleId']/1===3){
                window.opener.duisearch(3,"",sessionStorage['sUserDept'],1,$("div.rollcallbottom p select").val());
            }


            window.close();
            window.opener.parent.$(".baohu").fadeOut();
            window.opener.parent.$(".rollcallMessage").fadeOut();
        }
    })
    window.close();
    window.opener.parent.$(".baohu").fadeOut();
    window.opener.parent.$(".rollcallMessage").fadeOut();
}
function onunload_handler() {
    $.ajax({
        type: 'POST',
        data: {recordDeptId: recordDeptId},
        datatype: 'JSONP',
        jsonp: 'callback',
        url: http + 'AttendPeopleRecordController/shutdownRecord.do',
        traditional: true,
        success: function () {
            if(sessionStorage['sRoleId']/1===2||sessionStorage['sRoleId']/1===1){
                window.opener.suosearch(2,"",1,$("div.rollcallbottom p select").val())
            }else if(sessionStorage['sRoleId']/1===3){

                window.opener.duisearch(3,"",sessionStorage['sUserDept'],1,$("div.rollcallbottom p select").val());
            }

            window.close();
            window.opener.parent.$(".baohu").fadeOut();
            window.opener.parent.$(".rollcallMessage").fadeOut();
        }
    })
    window.opener.parent.$(".baohu").fadeOut();
    window.opener.parent.$(".rollcallMessage").fadeOut();
}

var scrollFunc=function(e){
	 e=e || window.event;
	 if(e.wheelDelta && event.ctrlKey){//IE/Opera/Chrome
	  event.returnValue=false;
	 }else if(e.detail){//Firefox
	  event.returnValue=false;
	 }
 }
 /*注册事件*/
 if(document.addEventListener){
 document.addEventListener('DOMMouseScroll',scrollFunc,false);
 }//W3C
 window.onmousewheel=document.onmousewheel=scrollFunc;//IE/Opera/Chrome/Safari