//异步加载单位名称lfz
//			$(function(){
//				$.ajax({
//					type:"get",
//					url:http + "queryDeptList.do",
////					data:{},
//					dataType:'json',
//					success:function(data){
//
//						var html = '';
//						$.each(data, function(i,v) {
//							html +="<option value='"+v.code+"'>"+v.department+"</option>";
//						});
//						$(".personnel .teamSelect").html("<option value='-1'>请选择大队</option>"+html);
//					}
//				});
//
//				$.ajax({
//					url:http + 'queryDeptList.do',
//					type:'GET',
//					datatype:'JSONP',
//					jsonp:'callback',
//					success:function(callback){
//						var data=JSON.parse(callback);
//
//							if(data.length===0){return}
//						var html="<option value='-1'>请选择</option>";
//						for(var i=0;i<data.length;i++){
//							if(data[i].department==="管理员"){continue;}
//							html+=" <option value='"+data[i].code+"'>"+data[i].department+"</option>"
//						}
//						$("div.changeview select.team").html(html);
//					}
//				})
//			})
//			var danwei=-1;
$("div.changeview select.team").change(function() {
	danwei = $(this).val();
})
var zhuangtai = -1;
//异步加载状态名称lfz
$(function() {
	$.ajax({
		url: http + 'userInfoListController/queryStateList',
		type: 'GET',
		datatype: 'JSONP',
		jsonp: 'callback',
		success: function(callback) {
			$(".theadview .view1").attr("class", "view1 bg1");
			if(callback.obj.length === 0) {
				return
			}
			var html = "<option value='-1'>请选择</option>";

			for(var i = 0; i < callback.obj.length; i++) {
				html += " <option value='" + callback.obj[i].stateid + "'>" + callback.obj[i].stateName + "</option>"
			}
			$("div.changeview select.zhuangtai").html(html);
			$("select.xiugai").html(html);
		}
	})
})
$("div.changeview select.zhuangtai").change(function() {
	zhuangtai = $(this).val();

})
var xiugai = -1;
$("select.xiugai").change(function() {
	xiugai = $(this).val();
})
$(".prompt .sp10").click(function() {
	var ids = $(".stnum").val();
	var userNames = $(".stnam").val();
	var stateid = $(".xiugai option:selected").val();
	var stateName = $(".xiugai option:selected").html();
	console.log(ids)
	$(".changehead .changetd").attr("class", "changetd bg5");

	var currentId = sessionStorage.sId;
	var depCode = sessionStorage.sUserDept;
	var operationIP = sessionStorage.logComIP;
	$.ajax({
		url: http + 'userInfoListController/updateUserState',
		type: 'POST',
		datatype: 'JSONP',
		data: {
			ids: ids,
			userNames: userNames,
			stateid: stateid,
			stateName: stateName,
			currentId: currentId
		},
		success: function(callback) {
			console.log(callback)
			if(callback.code >= 1) {
				$("div.condition div.prompt").fadeOut();
				$("div.baohu").fadeOut();
				//						$("div.condition div.prompt input").val('');
				rollcalluserId = $("iframe.crumbsCon")[0].contentWindow.$(".changeview .rollcalluserId").val();
				rollcalluserName = $("iframe.crumbsCon")[0].contentWindow.$(".changeview .rollcalluserName").val();
				$("iframe.crumbsCon")[0].contentWindow.loaded();
				$("iframe.crumbsCon")[0].contentWindow.loadStateMcrb(1);
			}

		}
	})
})


//点击复选框实现勾选效果
$(function() {
	$(".view1").addClass('bg1'); // 初始化时添加背景1
	//thead点击全选时，tbody全部选中
	$(".personnel").on("click", ".theadview .view1", function() {

		if($(".clonetrChild .view1").attr("class") == "view1 bg1") {
			$(".people-pic .view1").attr("class", "view1 bg2")

			$(".view1").attr("class", "view1 bg2")
			//						$(".tbodyview .bg2").parent().parent().css({ "backgroundColor": "#f2f9ff" })
		} else {
			$(".theadview .view1").attr("class", "view1 bg1");
			$(".clonetrChild .view1").attr("class", "view1 bg1");
			$(".people-pic .view1").attr("class", "view1 bg1")
			//						$(".tbodyview .bg1").parent().parent().css({ "backgroundColor": "white" })
		}
		//tbody点击时，单个选，当tbody全都点中时，触发thead
	});
	$(".personnel").on("click", ".tbodyview .view1", function() {
		var index = $(this).parent().parent().parent().index();
		//debugger;
		if($(".tbodyview  tr").eq(index).children().children().children().attr("class") == "view1 bg1") {
			$(".people-pic .view1").eq(index).attr("class", "view1 bg2")
			$(".tbodyview  tr").eq(index).children().children().children().attr("class", "view1 bg2")
		} else {
			$(".people-pic .view1").eq(index).attr("class", "view1 bg1")
			$(".tbodyview  tr").eq(index).children().children().children().attr("class", "view1 bg1")
			$(".theadview .view1").attr("class", "view1 bg1");
		}
		//$(this).toggleClass('bg1').toggleClass('bg2'); //点中的被选中
		//					for(var i = 0; i < $(".tbodyview .view1").size(); i++) {
		////						$(".tbodyview .bg2").eq(i).parent().parent().css({ "backgroundColor": "#f2f9ff" })
		//						if($(".tbodyview .view1").eq(i).attr("class") == "view1 bg2") {} else {
		//							$(".theadview .view1").attr("class", "view1 bg1");
		//							$(".people-pic .view1").eq(index).attr("class","view1 bg1")
		////							$(".tbodyview .bg1").parent().parent().css({ "backgroundColor": "white" })
		//							return;
		//						}
		//					};
		//					$(".view1").attr("class", "view1 bg2");
		//					$(".people-pic .view1").attr("class","view1 bg2")
	});
});

//点击获取是否有照片
$(function() {
	$(".select-pic").addClass('bg3'); // 初始化时添加背景3
	$(".personnel").on("click", ".select-pic", function() {
		if($(".select-pic").attr("class") == "select-pic bg3") {
			$(".select-pic").attr("class", "select-pic bg4")
		} else {
			$(".select-pic").attr("class", "select-pic bg3")
		}
	})
})

//点击上传照片
function photoClick() {
	$("#manyFiles").val('');
	$(".smallkuang4").fadeIn();
	$(".baohu").fadeIn();
	$("#upload").on("click", function() {
		console.log($("#manyFiles").val())
		if($("#manyFiles").val() == '') {
			$(".smallkuang9").slideDown();
			$(".baohu").fadeIn();
			$(".sp23").click(function() {
				$(".smallkuang9").fadeOut();
				$(".personnel .content .theadview .view1").attr("class", "view1 bg2");
			})
		} else {
			readFile();
		}

	});
	$(".smallkuang4 .sp10").click(function() {

		//			$(".personnel").on("click",".smallkuang4 .sp10",function(){
		$(".smallkuang4").fadeOut();
		$(".baohu").fadeOut();
	})
}
//图片单个上传
function readFile() {
	var formData = new FormData();
	for(var i = 0; i < $("#manyFiles")[0].files.length; i++) {
		var reader = new FileReader();
		reader.readAsDataURL($("#manyFiles")[0].files[i]);
		formData.append(i, $("#manyFiles")[0].files[i]);　　　
	}
	$.ajax({
		url: http + 'rollCallUserInfoController/springUpload.do',
		type: 'post',
		data: formData,
		contentType: false, //这个一定要写
		processData: false, //这个也一定要写，不然会报错
		dataType: 'json',
		success: function(data) {
			if(data == 0) {
				$(".smallkuang5").fadeIn();
				$(".baohu").fadeIn();
				$(".sp15").click(function() {
					$(".smallkuang4").fadeOut();
					$(".smallkuang5").fadeOut();
					$(".baohu").fadeOut();
					var rollcalluserId = $(".contentChild .rollcalluserId01").val();
					var isdrop = $(".personnel .content .isdrop option:selected").val();
					var rollcalluserName = $(".contentChild .rollcalluserName01").val();
					var rollcalluserCreatetime = $(".contentChild .rollcalluserCreatetime01").val();
					var rollcalluserDeletetime = $(".contentChild .rollcalluserDeletetime01").val();
					var rollcalluserPhoto = $(".select-pic").attr("class") == "select-pic bg3" ? 0 : 1;
					var selectPic = $(".personnel .selectPic option:selected").val();

					$(loading(1, $("div.footDiv div.jogger select").val(), isdrop, rollcalluserId, rollcalluserName, rollcalluserCreatetime, rollcalluserDeletetime, selectPic));
				})
			} else {
				$(".smallkuang6 p i").html(data.length);
				$(".smallkuang6").fadeIn();
				$(".namepic2").html(data);
				$(".baohu").fadeIn();
				$(".sp17").click(function() {
					$(".smallkuang4").hide();
					$(".smallkuang6").fadeOut();
					$(".baohu").fadeOut();
				})
			}
		},
		error: function(XMLHttpRequest, textStatus, errorThrown, data) {
			$(".namepic2").html(data);
			$(".smallkuang6").fadeIn();
			$(".baohu").fadeIn();
			$(".sp17").click(function() {
				$(".smallkuang6").fadeOut();
				$(".baohu").fadeOut();
				$(".smallkuang4").hide();
			})
		}
	});
}
$("#upload").on("click", function() {
	console.log($("#manyFiles").val())
	if($("#manyFiles").val() == '') {
		$(".smallkuang9").slideDown();
		$(".baohu").fadeIn();
		$(".sp23").click(function() {
			$(".smallkuang9").fadeOut();
			$(".personnel .content .theadview .view1").attr("class", "view1 bg2");
		})
	} else {
		readFile();
	}
});

//调用日历
$(".rollcalluserCreatetime").jeDate({
	format: "YYYY-MM-DD",
	isTime: false,
	maxDate: "2080-09-19 00:00:00"
})
$(".rollcalluserDeletetime").jeDate({
	format: "YYYY-MM-DD",
	isTime: false,
	skinCell: "jedateblue",
	minDate: "2016-09-19 00:00:00"
})
//驳回的人员
function Reject() {
	$(".smallkuang1>span").html("请选择需要驳回的人员！");

	$(".smallkuang1").fadeIn();
	$(".baohu").fadeIn();
	$(".sp5").click(function() {
		$(".smallkuang1").fadeOut();
		$(".baohu").fadeOut();
	})
	return false;
}

function RejectPeople() {
	$(".smallkuang").fadeIn();
	$(".baohu").fadeIn();
}

//删除学员
function delStudent(rollcalluserIdsZC) {
	//var rollcalluserIds = $(".tbodyview .stuId").attr("data-user");
	$(".baohu").fadeOut();
	$(".smallkuang").fadeOut();
	$(".sp3").click(function() {
		rollcalluserIdsZC = [];
		$(".smallkuang").fadeOut();
		$(".baohu").fadeOut();
		return;
	})
}
$(".sp3").click(function() {
	parent.$(".smallkuang").fadeOut();
	parent.$(".baohu").fadeOut();
})

function delStudent2() {
	$(".smallkuang1>span").html("请选择需要删除的学员！");
	$(".smallkuang1 .smallkuang-header span").html("删除学员");
	$(".smallkuang1").fadeIn();
	$(".baohu").fadeIn();
	$(".sp5").click(function() {
		$(".smallkuang1").fadeOut();
		$(".baohu").fadeOut();
	})
	return false;
}
$("[name='personnel-photobtn']").on("click", function() {
	$(".baohu").hide();
	$(".personnel-photo").fadeOut();
})

function delStudent3() {
	//console.log(rollcalluserIds)
	//console.log($("tbody .bg2").size())
	$(".smallkuang .smallkuang-header span").html("删除学员");
	$(".smallkuang").fadeIn();
	$(".baohu").fadeIn();
}
//查询结果
$(".personnel").on("click", ".search", function(event) {
	$(".theadview .view1").attr("class", "view1 bg1");
	//	日期验证
	if($(".rollcalluserDeletetime").val() != "" && $(".rollcalluserCreatetime").val() != "") {
		if($(".rollcalluserDeletetime").val() < $(".rollcalluserCreatetime").val()) {
			$(".adm .promptAlt .con .body p").html("起始时间不能大于结束时间");
			$(".promptAlt").fadeIn();
			return;
		}
	}
	var rollcalluserId = $(".contentChild .rollcalluserId01").val();
	var rollcalluserName = $(".contentChild .rollcalluserName01").val();
	var rollcalluserCreatetime = $(".contentChild .rollcalluserCreatetime01").val();
	var rollcalluserDeletetime = $(".contentChild .rollcalluserDeletetime01").val();
	var selectPic = $(".personnel .selectPic option:selected").val();

	loading(1, $("div.footDiv div.jogger select").val(), rollcalluserId, rollcalluserName, selectPic, rollcalluserCreatetime, rollcalluserDeletetime);

})
//分页效果实现
var userstotal; //总数据数量
var yeshu;
//人员管理
function loading(a, b, c, d, e, g, h) {
	if(a == 0) {
		a = 1;
	}
	c = c || '';
	d = d || '';
	e = e || "1";
	g = g || '';
	h = h || '';
	//var selectPic = $(".personnel .selectPic option:selected").val();
	//if(selectPic == -1){
	// 	selectPic = '';
	//}
	var teamSelect = $(".personnel .content .contentChild .teamSelect option:selected").val();
	if(teamSelect == -1) {
		teamSelect = '';
	}
	$.ajax({
		type: 'GET',
		datatype: 'JSONP',
		url: http + "userInfoListController/queryUserInfoList",
		data: {
			page: a,
			rows: b,
			userid: c,
			userName: d,
			states: e,
			createtime: g,
			deletetime: h,
			deptid: sessionStorage.sUserDept,
			roleid: sessionStorage.sRoleId
			//hasMetacarpalVein:selectPic
			//depId:sessionStorage['sUserDept']
		},
		success: function(data) {
			console.log(data)
			console.log(e)

			var html = '';
			//var data=null;
			//data=callback;
			//var picUrl=data.basePath;
			var len = data.obj.length;
			var pic = '';
			var url = '';
			if(len > 0) {
				for(var i = 0; i < len; i++) {

					//入队时间
					var t = new Date(data.obj[i].createtime / 1);
					t = t.toLocaleDateString(); //转换时间格式
					t = t.replace(/\//g, '-'); //将时间格式中'/'全部换成'-'
					//离队时间
					if(data.obj[i].deletetime) {
						var y = new Date(data.obj[i].deletetime / 1);
						y = y.toLocaleDateString(); //转换时间格式
						y = y.replace(/\//g, '-'); //将时间格式中'/'全部换成'-'
					} else {
						var y = null;
					}
					if(data.obj[i].photoUrl == null || data.obj[i].photoUrl == "") {
						url = 'img/moren.png'
					} else {
						url = data.message + data.obj[i].photoUrl;
					}
					var createtime;

					if(data.obj[i].createtime == "" || data.obj[i].createtime == null) {
						createtime = "--"
					} else {
						createtime = data.obj[i].createtime.substring(0, 10);
					}
					var deletetime;
					if(data.obj[i].deletetime == "" || data.obj[i].deletetime == null) {
						deletetime = "--"
					} else {
						deletetime = data.obj[i].deletetime.substring(0, 10);
					}
					pic += `
						<li ${data.obj[i].reviseState==1?'class="reviseStateRed "':''}>
							<div class="img-11">  <img src="${url}"/><div class="pic-click bg-click"> </div></div>

								<span class="mainpart1Id" ${data.obj[i].reviseState==1?'class="reviseStateRed"':''} data-wid="${data.obj[i].id}">编号: <p>${data.obj[i].userid}</p></span>
							<span class="mainpart1Name" ${data.obj[i].reviseState==1?'class="reviseStateRed"':''}>姓名: <p>${data.obj[i].userName}</p></span>
							</li>
                `
					html += `
						<tr  >
							<td class="clonetrChild" ><div><div class="view1 bg1" style="margin-left: 40%"></div></div></td>

							<td ${data.obj[i].reviseState==1?'class="reviseStateRed stuId"':'class=" stuId"'} class="stuId hand" onclick="showPhoto(${data.obj[i].userid})" data-user="${data.obj[i].id}" data="${data.obj[i].userId}" >${data.obj[i].userid}</td>
								<td ${data.obj[i].reviseState==1?'class="reviseStateRed stuName "':'class="stuName"'}  class="stuName hand"   onclick="showPhoto(${data.obj[i].userid})">${data.obj[i].userName}</td>
								<td class="stuName TdepName">${data.obj[i].roleName}</td>
								<td class="stuName TdepName">${data.obj[i].deptName}</td>
								<td class="startDate">${createtime}</td>
								<td class="endDate">${deletetime||"--"}</td>
								<td class="havepic">${data.obj[i].hasMetacarpalVein==0?"否":"是"}</td>
								<td class="havepic">${data.obj[i].hasDigitalVein==0?"否":"是"}</td>
								<td class="personnel-detail"><i onclick="AddView.showDetail(${data.obj[i].userid})">详情</i>&nbsp;|
								<i onclick="AddView.alertDetail(${data.obj[i].userid})">修改</i></td>
								</tr>
   						`
				}
			} else {
				html += `
					<div class="dataloss">
						<img src="img/dataloss.png" alt=""/>
							</div>
   						`
				pic += `
					<div class="dataloss">
						<img src="img/dataloss.png" alt=""/>
							</div>
                `
			}
			$(".tbodyview").html(html);
			$(".people-pic ul").html(pic);

			showPhoto = function(e) {
				parent.$(".baohu").fadeIn();
				parent.$(".personnel-photo").fadeIn();
				var id = e;
				//console.log(id);
				$.ajax({
					type: 'GET',
					dataType: 'JSON',
					url: http + "userInfoListController/queryUserInfoList",
					data: {
						userid: id
					},
					success: function(data) {
						var url = '';
						var html = '';
						parent.$("[class='personnel-photoname']").html(data.obj[0].userid);
						parent.$("[class='personnel-photoid']").html(data.obj[0].userName);
						if(data.obj[0].photoUrl == null || data.obj[0].photoUrl == "") {
							url = 'img/moren.png';
						} else {
							url = data.message + data.obj[0].photoUrl;
						}
						html = `
								<img src="${url}" alt=""/>
											`
						//点击确定
						parent.$("[class='personnel-photoimg']").html(html)

					}
				})
			}

			//动态生成分页
			var dangqian = parseInt(data.objExt.currentPage) / 1;
			//当前页码
			userstotal = data.objExt.totalCount; //一共多少条数据
			var rows = data.objExt.pageSize; //一页多少数据
			yeshu = Math.ceil(userstotal / rows);
			if(yeshu == 0) {
				yeshu = 1;
			}
			var html1 = '';
			if(dangqian == 1) {
				if(dangqian <= yeshu) {
					html1 += `<li class="ycolor">${dangqian}</li>`;
				}
				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
				if(dangqian + 4 <= yeshu) {
					html1 += `<li>${dangqian+4}</li>`;
				}
			} else if(dangqian == 2) {
				html1 += `<li>${dangqian-1}</li>`;
				html1 += `<li class="ycolor">${dangqian}</li>`;

				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
			} else if(dangqian == yeshu && dangqian >= 5) {
				html1 += `
						<li>${dangqian-4}</li>

						<li>${dangqian-3}</li>

						<li>${dangqian-2}</li>

						<li >${dangqian-1}</li>
						<li class="ycolor">${dangqian}</li>
						`
			} else if(dangqian == yeshu - 1 && dangqian >= 5) {
				html1 += `
						<li>${dangqian-3}</li>

						<li>${dangqian-2}</li>

						<li>${dangqian-1}</li>

						<li class="ycolor">${dangqian}</li>
						<li>${dangqian+1}</li>
						`
			} else {
				if(dangqian - 2 > 0) {
					html1 += `<li>${dangqian-2}</li>`;
				}
				if(dangqian - 1 > 0) {
					html1 += `<li>${dangqian-1}</li>`;
				}
				html1 += `<li class="ycolor">${dangqian}</li>`;
				if(dangqian < yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 1 < yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
			}
			$(".jogger ul.yema").html(html1);
			$(".look .allpeople").html(userstotal);
			$(".look .nowpage").html(dangqian);
			$(".look .allpage").html(yeshu);

		}
	})
}
$("div.jogger ul").on("click", "li", function(e) {
	var rollcalluserId = $(".contentChild .rollcalluserId01").val();
	var roleid = $(".role option:selected").val();
	var rollcalluserName = $(".contentChild .rollcalluserName01").val();
	var rollcalluserCreatetime = $(".contentChild .rollcalluserCreatetime01").val();
	var rollcalluserDeletetime = $(".contentChild .rollcalluserDeletetime01").val();
	var deptid = $(".whichTeam option:selected").val();
	var selectPic = $(".personnel .selectPic option:selected").val();
	$(".theadview .view1").attr("class", "view1 bg1");

	loading(e.target.innerHTML, $("div.footDiv div.jogger select").val(), rollcalluserId, rollcalluserName, selectPic, rollcalluserCreatetime, rollcalluserDeletetime);
	$("div.jogger ul li").removeClass("ycolor");
	$(this).addClass("ycolor");

});
//首页
$(".firstpage").click(function() {
	var page = $(".look .nowpage").html();
	if(page != 1) {
		var rollcalluserId = $(".contentChild .rollcalluserId01").val();
		var roleid = $(".role option:selected").val();
		var rollcalluserName = $(".contentChild .rollcalluserName01").val();
		var rollcalluserCreatetime = $(".contentChild .rollcalluserCreatetime01").val();
		var rollcalluserDeletetime = $(".contentChild .rollcalluserDeletetime01").val();
		var deptid = $(".whichTeam option:selected").val();
		var selectPic = $(".personnel .selectPic option:selected").val();
		$(".theadview .view1").attr("class", "view1 bg1");
		//var rollcalluserId = $(".contentChild .rollcalluserId01").val();
		//var rollcalluserName = $(".contentChild .rollcalluserName01").val();
		//var rollcalluserCreatetime = $(".contentChild .rollcalluserCreatetime01").val();
		//var rollcalluserDeletetime = $(".contentChild .rollcalluserDeletetime01").val();
		//var rollcalluserPhoto = $(".select-pic").attr("class") == "select-pic bg3" ? 0 : 1;
		loading(1, $("div.footDiv div.jogger select").val(), rollcalluserId, rollcalluserName, selectPic, rollcalluserCreatetime, rollcalluserDeletetime);
	}
})
//尾页
$(".lastpage").click(function(e) {
	var lastPage = $(".look .allpage").html();
	var page = $(".look .nowpage").html();
	e.preventDefault();
	if(page != lastPage) {

		var rollcalluserId = $(".contentChild .rollcalluserId01").val();
		var roleid = $(".role option:selected").val();
		var rollcalluserName = $(".contentChild .rollcalluserName01").val();
		var rollcalluserCreatetime = $(".contentChild .rollcalluserCreatetime01").val();
		var rollcalluserDeletetime = $(".contentChild .rollcalluserDeletetime01").val();
		var deptid = $(".whichTeam option:selected").val();
		var selectPic = $(".personnel .selectPic option:selected").val();
		$(".theadview .view1").attr("class", "view1 bg1");
		//var rollcalluserId = $(".contentChild .rollcalluserId01").val();
		//var rollcalluserName = $(".contentChild .rollcalluserName01").val();
		//var rollcalluserCreatetime = $(".contentChild .rollcalluserCreatetime01").val();
		//var rollcalluserDeletetime = $(".contentChild .rollcalluserDeletetime01").val();
		//var rollcalluserPhoto = $(".select-pic").attr("class") == "select-pic bg3" ? 0 : 1;
		loading(lastPage, $("div.footDiv div.jogger select").val(), rollcalluserId, rollcalluserName, selectPic, rollcalluserCreatetime, rollcalluserDeletetime);
	}
})

//点击跳转页面
$(".tiaozhuan").click(function(e) {
	var page = $(".look .nowpage").html();
	var lastPage = $(".look .allpage").html();
	var rollcalluserId = $(".contentChild .rollcalluserId01").val();
	var rollcalluserName = $(".contentChild .rollcalluserName01").val();
	var rollcalluserCreatetime = $(".contentChild .rollcalluserCreatetime01").val();
	var rollcalluserDeletetime = $(".contentChild .rollcalluserDeletetime01").val();
	var rollcalluserPhoto = $(".select-pic").attr("class") == "select-pic bg3" ? 0 : 1;
	console.log(lastPage)
	e.preventDefault();
	$(".theadview .view1").attr("class", "view1 bg1")
	var b = yeshu;
	var a = $("div.jogger input").val();
	//console.log(a,b)
	if(a != page) {
		$(".theadview .view1").attr("class", "view1 bg1")
		if (a / 1 > b / 1) {
			a = '';
			$("div.jogger input").val(lastPage);

			loading(lastPage, $("div.footDiv div.jogger select").val(), $(".isdrop option:selected").val(), rollcalluserId, rollcalluserName, rollcalluserCreatetime, rollcalluserDeletetime, rollcalluserPhoto);

			return;
		}
		if (a == '') {
			return;
		}
	}
})

//		$.ajax({
//       type:"GET",
//       url:http+ "rollCallUserInfoController/selectUserState.do",
////		 url:"data/data.json",
////       data:{"item.caller":"${item.caller}"},
//               //object是后台传过来的java list数据集合
//                 success:function(data){
//					   $(".changehead .changetd").attr("class", "changetd bg5");
//                      var html ="";
//                      var data=JSON.parse(data);
//                    //1,获取上面id为cloneTr的tr元素
//                      var tr = $(".changetr");
//						var result = data.result;
//                     $.each(result, function(index,item){
//                           //克隆tr，每次遍历都可以产生新的tr
//                             var changetr = tr.clone();
//                             var _index = index;
//                             //循环遍历cloneTr的每一个td元素，并赋值
//                             changetr.children("td").each(function(inner_index){
//                                    //根据索引为每一个td赋值
//                                          switch(inner_index){
//                                                case(0):
//                                                   $(this).html('<div class="changetd bg5"></div>');
//                                                   break;
//                                                case(1):
//                                                   $(this).html(item.id);
//                                                   break;
//                                                case(2):
//                                                   $(this).html(item.rollcalluserId);
//                                                   break;
//                                                case(3):
//                                                   $(this).html(item.rollcalluserName);
//                                                   break;
//                                                case(4):
//                                                   $(this).html(item.depName);
//                                                   break;
//                                                case(5):
//                                                   $(this).html(item.stataName);
//                                                   break;
//                              				  case(6):
//                                                   $(this).html(item.rollcalluserPhoto);
//                                                   break;
//                                         }//end switch
//                          });//end children.each
//                         //把克隆好的tr追加原来的tr后面
//                        	html +=tr;
////                         clonedTr.insertAfter(tr);
//                         changetr.insertBefore(tr);
//                      });//end $each
//	                    $(".changeTable").show();
//       }
//  });

//状态查询中，点击复选框实现勾选效果
$(function() {
	$(".changetd").addClass('bg5'); // 初始化时添加背景1
	//thead点击全选时，tbody全部选中
	$(".condition").on("click", ".changehead .changetd", function() {
		if($(".peoplechild .changetd").attr("class") == "changetd bg5") {
			$(".changetd").attr("class", "changetd bg6")
		} else {
			$(".changehead .changetd").attr("class", "changetd bg5")
			$(".peoplechild .changetd").attr("class", "changetd bg5")
		}
		//tbody点击时，单个选，当tbody全都点中时，触发thead
	});
	$(".condition").on("click", ".changebody .changetd", function() {
		$(this).toggleClass('bg5').toggleClass('bg6'); //点中的被选中
		for(var i = 0; i < $(".changebody .changetd").size(); i++) {
			if($(".changebody .changetd").eq(i).attr("class") == "changetd bg6") {} else {
				$(".changehead .changetd").attr("class", "changetd bg5")
				return;
			}
		}
		$(".changetd").attr("class", "changetd bg6")

	});

})

//状态查询，分页效果制作

//状态查询点击修改状态

//			点击小图标弹框消失
$(".prompt img").click(function() {
	$(".prompt").fadeOut();
	$(".baohu").fadeOut();
})
//点击弹出弹框
function chengBtn00() {


	$(".smallkuang7").fadeIn();
	$(".baohu").fadeIn();
};

function chengBtn01() {
	$(".smallkuang7").fadeOut();
	$(".baohu").fadeOut();
	$(".smallku").fadeOut();
	$(".chose_serve").fadeOut();
	$(".RejectBtn").fadeOut();
	$(".withdraw").fadeOut();
	$(".withdraw_serve").fadeOut();
};

function chengBtn00prompt() {
	$(".prompt").fadeIn();
	$(".baohu").fadeIn();
};

function chengBtn01prompt() {
	$(".prompt").fadeOut();
	$(".baohu").fadeOut();
};
$(".sp19").click(function() {
	chengBtn01();
});
$(".sp11").click(function() {
	chengBtn01();
	chengBtn01prompt();
});
//输入修改状态

//状态管理列表页面查询
//查询结果
//状态查询，分页效果制作
var userstotal1; //总数据数量
var yeshu1;

function loaded(m, n, o, p, q, r, s, t, u, v) {
	o = o || '0';
	p = p || '';
	q = q || '';
	r = r || '';
	s = s || '';
	t = t || '';
	u = u || sessionStorage.getItem("sUserDept");
	v = v || '';
	$.ajax({
		type: 'GET',
		datatype: 'JSONP',
		jsonp: 'callback',
		data: {
			roleid: sessionStorage.sRoleId,
			page: m,
			rows: n,
			userid: p,
			userName: q,
			stateid: s,
			deptid: u,
		},
		url: http + "userInfoListController/queryUserInfoList",
		success: function(callback) {
			$(".theadview .view1").attr("class", "view1 bg1");
			$(".changehead .changetd").attr("class", "changetd bg5");
			var html1 = '';
			//判断是否有数据,没有显示固定图片
			if(callback.obj.length == 0) {
				html1 = `
					<tr class="changetr">
	                	<td class="deviceid" colspan='8'><img src="img/dataloss.png" style="margin: 145px auto"></img></td>
	                </tr>
				`;
			} else {
				for(var x = 0; x < callback.obj.length; x++) {
					html1 += `
						<tr>
						<td class="peoplechild"><div class="changetd bg5"></div></td>
						<td class="peoplenum" data-wid="${callback.obj[x].id}">${callback.obj[x].userid}</td>
						<td class="peoplename">${callback.obj[x].userName}</td>
						<td class="peoplecompany">${callback.obj[x].deptName}</td>
						<td class="nowcurrent">${callback.obj[x].stateName}</td>
					</tr>
					`;
				}
			}
			$(".changebody").html(html1);
			//动态生成分页
			var dangqian = parseInt(callback.objExt.currentPage) / 1;//当前页码
			userstotal1 = callback.objExt.totalCount;                //一共多少条数据
			var rows = callback.objExt.pageSize;                     //一页多少数据
			yeshu1 = Math.ceil(userstotal1 / rows);                  //总页数
			if(yeshu1 == 0) {
				yeshu1 = 1;
			}
			var html1 = '';
			if(dangqian == 1) {
				if(dangqian <= yeshu1) {
					html1 += `<li class="ycolor">${dangqian}</li>`;
				}
				if(dangqian + 1 <= yeshu1) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu1) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu1) {
					html1 += `<li>${dangqian+3}</li>`;
				}
				if(dangqian + 4 <= yeshu1) {
					html1 += `<li>${dangqian+4}</li>`;
				}
			} else if(dangqian == 2) {
				html1 += `<li>${dangqian-1}</li>`;
				html1 += `<li class="ycolor">${dangqian}</li>`;
				if(dangqian + 1 <= yeshu1) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu1) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu1) {
					html1 += `<li>${dangqian+3}</li>`;
				}
			} else if(dangqian == yeshu1 && dangqian >= 5) {
				html1 += `
					<li>${dangqian-4}</li>
					<li>${dangqian-3}</li>
					<li>${dangqian-2}</li>
					<li >${dangqian-1}</li>
					<li class="ycolor">${dangqian}</li>
				`
			} else if(dangqian == yeshu1 - 1 && dangqian >= 5) {
				html1 += `
					<li>${dangqian-3}</li>
					<li>${dangqian-2}</li>
					<li>${dangqian-1}</li>
					<li class="ycolor">${dangqian}</li>
					<li>${dangqian+1}</li>
				`
			} else {
				if(dangqian - 2 > 0) {
					html1 += `<li>${dangqian-2}</li>`;
				}
				if(dangqian - 1 > 0) {
					html1 += `<li>${dangqian-1}</li>`;
				}
				html1 += `<li class="ycolor">${dangqian}</li>`;
				if(dangqian < yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 1 < yeshu1) {
					html1 += `<li>${dangqian+2}</li>`;
				}
			}
			//页码区显示数据
			$("ul.yema1").html(html1);
			$(".look1 .allpeople1").html(userstotal1);//总数据量
			$(".look1 .nowpage1").html(dangqian);     //当前数据页
			$(".look1 .allpage1").html(yeshu1);       //总页数

		}
	})
}
//状态管理 -- 点击页面列表显示数据
$("div.jogger1 ul").on("click", "li", function(e) {
	var yema = e.target.innerHTML;
	$(".changehead .changetd").attr("class", "changetd bg5");
	var rollcalluserId = $(".changeview .rollcalluserId").val();
	var rollcalluserName = $(".changeview .rollcalluserName").val();
	$(".theadview .view1").attr("class", "view1 bg1")
	if(zhuangtai == -1) {
		zhuangtai = ''
	};
	$.ajax({
		type: "POST",
		url: http + "userInfoListController/queryUserInfoList",
		data: {
			roleid: sessionStorage.sRoleId,
			userid: rollcalluserId,
			userName: rollcalluserName,
			stateid: zhuangtai,
			page: yema,
			rows: $("div.footDiv1 div.jogger1 select").val(),
			deptid: sessionStorage.getItem("sUserDept")
		},
		datatype: 'JSON',
		success: function(callback) {
			$(".changehead .changetd").attr("class", "changetd bg5");
			var html1 = "";
			if(callback.obj.length == 0) {
				html1 = `
					<tr class="changetr">
                    	<td class="deviceid" colspan='8'><img src="img/dataloss.png" style="margin: 145px auto"></img></td>
                    </tr>
				`;
			} else {
				for(var x = 0; x < callback.obj.length; x++) {
					html1 += `
						<tr>
						<td class="peoplechild"><div class="changetd bg5"></div></td>
						<td class="peoplenum" data-wid="${callback.obj[x].id}">${callback.obj[x].userid}</td>
						<td class="peoplename">${callback.obj[x].userName}</td>
						<td class="peoplecompany">${callback.obj[x].deptName}</td>
						<td class="nowcurrent">${callback.obj[x].stateName}</td>
					</tr>
					`
				}
			}
			$(".changebody").html(html1);
			var dangqian = callback.objExt.currentPage / 1;  //当前页码
			userstotal1 = callback.objExt.totalCount;        //一共多少条数据
			var rows = callback.objExt.pageSize / 1;         //一页多少数据
			var yeshu = Math.ceil(userstotal1 / rows);		 //总页数
			if(yeshu == 0) {
				yeshu = 1;
			}
			var html1 = '';
			if(dangqian == 1) {
				if(dangqian <= yeshu) {
					html1 += `<li class="ycolor">${dangqian}</li>`;
				}
				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
				if(dangqian + 4 <= yeshu) {
					html1 += `<li>${dangqian+4}</li>`;
				}
			} else if(dangqian == 2) {
				html1 += `<li>${dangqian-1}</li>`;
				html1 += `<li class="ycolor">${dangqian}</li>`;

				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
			} else if(dangqian == yeshu && dangqian >= 5) {
				html1 += `
					<li>${dangqian-4}</li>
					<li>${dangqian-3}</li>
					<li>${dangqian-2}</li>
					<li >${dangqian-1}</li>
					<li class="ycolor">${dangqian}</li>
				`
			} else if(dangqian == yeshu - 1 && dangqian >= 5) {
				html1 += `
					<li>${dangqian-3}</li>
					<li>${dangqian-2}</li>
					<li>${dangqian-1}</li>
					<li class="ycolor">${dangqian}</li>
					<li>${dangqian+1}</li>
				`
			} else {
				if(dangqian - 2 > 0) {
					html1 += `<li>${dangqian-2}</li>`;
				}
				if(dangqian - 1 > 0) {
					html1 += `<li>${dangqian-1}</li>`;
				}
				html1 += `<li class="ycolor">${dangqian}</li>`;
				if(dangqian < yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 1 < yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
			}
			//页码区显示数据
			$("ul.yema1").html(html1);
			$(".look1 .allpeople1").html(userstotal1);   //总数据量
			$(".look1 .nowpage1").html(dangqian);        //当前页
			$(".look1 .allpage1").html(yeshu);           //总页数
		},
		error: function(callback) {}
	})
})
//首页跳转按钮
$(".stateMatCrb .firstpage1").click(function() {
	var page = $(".look1 .nowpage1").html();
	if(page != 1) {
		$(".changehead .changetd").attr("class", "changetd bg5");
		var rollcalluserId = $(".changeview .rollcalluserId").val();
		var rollcalluserName = $(".changeview .rollcalluserName").val();
		if(zhuangtai == -1) {
			zhuangtai = ''
		};
		loaded(1, $("div.footDiv1 div.jogger1 select").val(),'', rollcalluserId, rollcalluserName, '', zhuangtai, '', '');
	}
})
//尾页跳转按钮
$(".stateMatCrb .lastpage1").click(function(e) {
	e.preventDefault();
	var lastPage = $(".look1 .allpage1").html();
	var page = $(".look1 .nowpage1").html();
	if(page != lastPage) {
		$(".changehead .changetd").attr("class", "changetd bg5");
		var rollcalluserId = $(".changeview .rollcalluserId").val();
		var rollcalluserName = $(".changeview .rollcalluserName").val();
		if(zhuangtai == -1) {
			zhuangtai = ''
		}
		loaded($(".look1 .allpage1").html(), $("div.footDiv1 div.jogger1 select").val(), '', rollcalluserId, rollcalluserName, '', zhuangtai, '', '');
	}
})

//点击跳转页面
$(".tiaozhuan1").click(function(e) {
	e.preventDefault();
	$(".changehead .changetd").attr("class", "changetd bg5");
	var b = yeshu1;
	var a = $("div.jogger1 input").val();
	var page = $(".look1 .nowpage1").html();
	if(a != page) {
		if(a / 1 > b / 1) {
			$(".smallkuang8").fadeIn();
			$(".baohu").fadeIn();
			$(".sp21").click(function() {
				$(".smallkuang8").fadeOut();
				$(".baohu").fadeOut();
				$("div.jogger1 input").val('');
			})
			return;
		}
		if(a == '') {
			return;
		}
		var rollcalluserId = $(".changeview .rollcalluserId").val();
		var rollcalluserName = $(".changeview .rollcalluserName").val();
		if(zhuangtai == -1) {
			zhuangtai = ''
		}
		if(danwei == -1) {
			danwei = ''
		}
		loaded(a, $("div.footDiv1 div.jogger1 select").val(), $(".zhuangtai option:selected").val(), rollcalluserId, rollcalluserName, '', zhuangtai, '', '', danwei);
	}
})

//点击小图标弹框消失
$(".prompt img").click(function() {
	$(".prompt").fadeOut();
	$(".baohu").fadeOut();
})
//点击弹出弹框
function chengBtn00() {
	$(".smallkuang7").fadeIn();
	$(".baohu").fadeIn();
};

function chengBtn01() {
	$(".smallkuang7").fadeOut();
	$(".baohu").fadeOut();
	$(".smallku").fadeOut();
	$(".chose_serve").fadeOut();
	$(".RejectBtn").fadeOut();
	$(".withdraw").fadeOut();
	$(".withdraw_serve").fadeOut();
};

function chengBtn00prompt() {
	$(".prompt").fadeIn();
	$(".baohu").fadeIn();
};

function chengBtn01prompt() {
	$(".prompt").fadeOut();
	$(".baohu").fadeOut();
};
$(".sp19").click(function() {
	chengBtn01();
});
$(".sp11").click(function() {
	chengBtn01();
	chengBtn01prompt();
});
//输入修改状态

//状态管理---查询--列表页面查询
//查询结果
$(".condition").on("click", ".search1", function(event) {
	$(".changehead .changetd").attr("class", "changetd bg5");
	$(".theadview .view1").attr("class", "view1 bg1")
	$("div.changedata table thead div").removeClass('bg6').addClass('bg5');
	var rollcalluserId = $(".changeview .rollcalluserId").val();
	var rollcalluserName = $(".changeview .rollcalluserName").val();
	if(zhuangtai == -1) {
		zhuangtai = ''
	};
	$.ajax({
		type: "POST",
		url: http + "userInfoListController/queryUserInfoList",
		data: {
			roleid: sessionStorage.sRoleId,
			userid: rollcalluserId,
			userName: rollcalluserName,
			stateid: zhuangtai,
			deptid: sessionStorage['sUserDept'],
			rows: $("div.footDiv1 div.jogger1 select").val()
		},
		datatype: 'JSON',
		success: function(callback) {
			$(".changehead .changetd").attr("class", "changetd bg5");
			var html1 = "";
			if(callback.obj.length == 0) {
				html1 = `
					<tr class="changetr">
                    	<td class="deviceid" colspan='8'><img src="img/dataloss.png" style="margin: 145px auto"></img></td>
                    </tr>
				`;
			} else {
				for(var x = 0; x < callback.obj.length; x++) {
					html1 += `
						<tr>
							<td class="peoplechild"><div class="changetd bg5"></div></td>
							<td class="peoplenum"  data-wid="${callback.obj[x].id}">${callback.obj[x].userid}</td>
							<td class="peoplename">${callback.obj[x].userName}</td>
							<td class="peoplecompany">${callback.obj[x].deptName}</td>
							<td class="nowcurrent">${callback.obj[x].stateName}</td>
						</tr>
					`
				}
			}
			$(".changebody").html(html1);
			var dangqian = callback.objExt.currentPage / 1;   //当前页码
			userstotal1 = callback.objExt.totalCount;         //一共多少条数据
			var rows = callback.objExt.pageSize / 1;          //一页多少数据
			var yeshu = Math.ceil(userstotal1 / rows);        //总页数
			if(yeshu == 0) {
				yeshu = 1;
			}
			var html1 = '';
			if(dangqian == 1) {
				if(dangqian <= yeshu) {
					html1 += `<li class="ycolor">${dangqian}</li>`;
				}
				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
				if(dangqian + 4 <= yeshu) {
					html1 += `<li>${dangqian+4}</li>`;
				}
			} else if(dangqian == 2) {
				html1 += `<li>${dangqian-1}</li>`;
				html1 += `<li class="ycolor">${dangqian}</li>`;

				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
			} else if(dangqian == yeshu && dangqian >= 5) {
				html1 += `
					<li>${dangqian-4}</li>
					<li>${dangqian-3}</li>
					<li>${dangqian-2}</li>
					<li >${dangqian-1}</li>
					<li class="ycolor">${dangqian}</li>
				`
			} else if(dangqian == yeshu - 1 && dangqian >= 5) {
				html1 += `
					<li>${dangqian-3}</li>
					<li>${dangqian-2}</li>
					<li>${dangqian-1}</li>
					<li class="ycolor">${dangqian}</li>
					<li>${dangqian+1}</li>
				`
			} else {
				if(dangqian - 2 > 0) {
					html1 += `<li>${dangqian-2}</li>`;
				}
				if(dangqian - 1 > 0) {
					html1 += `<li>${dangqian-1}</li>`;
				}
				html1 += `<li class="ycolor">${dangqian}</li>`;
				if(dangqian < yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 1 < yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
			}
			//页码区显示
			$("ul.yema1").html(html1);
			$(".look1 .allpeople1").html(userstotal1);   //总数据量
			$(".look1 .nowpage1").html(dangqian);        //当前页
			$(".look1 .allpage1").html(yeshu);           //总页数
		},
		error: function(callback) {}
	})
})