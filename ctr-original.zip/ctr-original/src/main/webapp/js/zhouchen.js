var http="";
//http = 'http://192.168.1.124:8080/ctr/';

//导出表格1
var newdate = new Date();
var seperator1 = "-";
var month = newdate.getMonth() + 1;
var strDate = newdate.getDate();
var suserDept = sessionStorage["sRoleId"];
var SSdeptId= sessionStorage["sUserDept"];
var sDeptment=sessionStorage['department'];
if(sDeptment==1){
    sDeptment=9;
}
var sRoleId = sessionStorage["sRoleId"];
if (month >= 1 && month <= 9) {
    month = "0" + month;
}
if (strDate >= 0 && strDate <= 9) {
    strDate = "0" + strDate;
}
var time = newdate.getFullYear() + seperator1 + month + seperator1 + strDate;
var date = $(".data1").val();
if (date == "") {
    date = time;
}
//console.log(time);
//导出表格1

//点击姓名和编号弹出人员照片


//人员数据统计
function showChart1() {
    var newdate = new Date();
    var seperator1 = "-";
    var month = newdate.getMonth() + 1;
    var strDate = newdate.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var time = newdate.getFullYear() + seperator1 + month + seperator1 + strDate

    var date = $(".data1").val();
    //console.log(date);
    if (date == "") {
        date = time;
    }
    //绘制柱状图
    $.ajax({
        url: http + "statistics/hasdeletedProportion.do",
        type: "get",
        data: {startTime: date,depId:SSdeptId,roleid:sessionStorage.sRoleId},
        dataType: 'json',
        success: function (data) {
//console.log(data);

            $(".list1-2").empty();
            $(".list1-2").append(" <tr style='display: none'><td>" + date + "</td><td>");
            var depName = [];
            var inuser = [];
            var deleted = [];
            var len = data.length;

            for (var i = 0; i < len; i++) {


                //if (suserDept == data[i].code) {
                //    console.log(data.length);
                $(".list1-2").append(" <tr><td>" + data[i].depName + "</td><td>" + data[i].inuser + "</td><td>" + data[i].deleted + "</td></tr>")
                inuser.push(data[i].inuser);
                deleted.push(data[i].deleted);
                depName.push(data[i].depName);
                //}
            }
            //console.log(inuser);
            //console.log(depName);

            $('#container1').highcharts({
                chart: {
                    type: 'column'
                },
                title: {
                    text: date + '人员数据柱状图'
                },

                loading: {

                    showDuration: 1000,                       //设置淡入效果持续时间

                    hideDuration: 1000                           //设置淡出效果持续时间

                },

                credits: {
                    enabled: false//不显示highCharts版权信息
                },
                xAxis: {
                    lineWidth: 1,
                    lineColor: "#777777",
                    tickWidth: 0,
                    gridLineColor:"#777777",
                    categories: depName,
                    crosshair: true
                },
                yAxis: {
                    lineWidth: 1,
                    lineColor: "#777777",
                    gridLineColor:"#777777",
                    min: 0,
                    title: {
                        text: '人数 (人)'
                    }

                },
                tooltip: {
                    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                    pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                    '<td style="padding:0"><b>{point.y:.1f} 人</b></td></tr>',
                    footerFormat: '</table>',
                    shared: true,
                    useHTML: true
                },
                plotOptions: {
                    column: {
                        pointPadding: 0.2,
                        borderWidth: 0
                    }
                },

                series: [{
                    name: '在队人数',
                    data: inuser

                }, {
                    name: '离队人数',
                    data: deleted
                }]
            });
        }

    });


}

//人员数据统计查询
function doSeacch() {
    var date = $(".data1").val();
    if (date == "") {
        alert("请选择时间！")
    } else {
        showChart1();
    }
}

//考勤数据统计
function showChart2() {

    var newdate = new Date();
    var seperator1 = "-";
    var month = newdate.getMonth() + 1;
    var strDate = newdate.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var time = newdate.getFullYear() + seperator1 + month + seperator1 + strDate;
    var date = $(".data1").val();
    if (date == "") {
        date = time;
    }
    $.ajax({
        url: http +"statistics/deptListByRole.do",
        type: "get",
        data: {code: sessionStorage.sRoleId, deptid: sessionStorage.sUserDept},
        dataType: 'json',
        success: function (data) {
//console.log(data)
            var len = data.obj.length;
            //if(sRoleId!="3"){
            var html = '';
            for(var k = 0; k < len; k++){
                html+='<li name="teamFather" data="teamFather1" value="'+data.obj[k].deptid+'">' +
                    '<a data-toggle="tab" href="#team'+k+1+'">'+data.obj[k].deptName+'</a> </li>';
                //$("[name='teamFather']").children().eq(k).html(data[k].department);
                $("[name='showChart']").eq(k).attr("value", data.obj[k].deptid);
                $("[class='histogram']").eq(k).attr("value", data.obj[k].deptid);
                $("#java>ul li").eq(k).attr("value", data.obj[k].deptid);

            }
            //console.log(html)
            $(" #java .teams").html(html);

            $("[name='teamFather']").eq(0).addClass("active");

            $("[data='teamFather1']").eq(0).click();



        }
    })
}
//showChart2();


$(function () {
    //弹出框叉号
    $(".smallkuang-header a").click(function(){
        $(this).parent().parent().fadeOut();
        $(".baohu").fadeOut();
        $(".baohu2").fadeOut();
        $(".alert").fadeOut();
        $(".adm .setAlert").fadeOut();
        $(".jstAlt").fadeOut();
        $(".jstSetAlt").fadeOut();
        $(".promptAlt").fadeOut();
        $(".promptAltDel").fadeOut();
        $(".promptAltJst").fadeOut();

    })


    $.ajax({
        url: http + "statistics/attendanceProportion.do",
        data: {code: SSdeptId},
        dataType: 'json',
        success: function (data) {
            //console.log(data);
            var len = data.length;
            //console.log(len);
            if (len > 0) {
                for (var k = 0; k < len; k++) {
                    //console.log(len)
                    var app = "<tr><td>" + data[k].endtime + "</td><td>" + data[k].allnum + "</td> <td>" + data[k].rollcallnum + "</td> <td>" + data[k].attendnum + "</td> <td>" + data[k].absensenum + "</td> <td>" + data[k].sickleavenum + "</td> <td>" + data[k].othernum + "</td> </tr>";
                    $("[name='dataList']").eq(0).append(app);
                }
            } else if (len == 0) {
                for (var i = 0; i < $(".sevenTeams>.tab-pane").size(); i++) {
                    $("[name='dataList']").eq(i).append("<tr style='text-align: center'><td colspan='7'>暂无数据</td></tr>")
                }

            }

        }
    })
    //console.log(startTime);
    var teamCode;
    var index = 0;
    //显示各大队的列表
    $("#java>ul li").click(function () {
        var teamFather = $("[name='teamFather']");
        var startTime = $("[name='endTime']").val();
        teamCode = $(this).val();
        var cli = $(this);
        //console.log(startTime);
        $.ajax({
            url: http + "statistics/attendanceProportion.do",
            data: {code: teamCode, startTime: startTime},
            dataType: 'json',
            success: function (data) {
                var newDate = new Date();
                var time = newDate.toLocaleString();
                time = time.replace(/\//g, '-').substring(0, 9);
                var len = data.length;
                if (startTime == "") {
                    startTime = time;
                }
                //console.log(teamFather.length);
                //console.log(cli.attr("data"));
                for (var j = 0; j < teamFather.length; j++) {
                    if (cli.attr("data") == teamFather.eq(j).attr("data")) {
                        index = j;
                        //console.log(index);
                    }
                }
                $("[name='dataList']").empty();

                $("[name='dataList']").eq(index).append(" <tr style='display: none'><td>" + startTime + "</td><td>")

                if (len > 0) {
                    for (var i = 0; i < len; i++) {
                        //console.log(index);
                        //console.log(app);
                        var app = "<tr><td>" + data[i].time + "</td><td>" + data[i].total + "</td> <td>" + data[i].rollcallNum + "</td> <td>" + data[i].attendNum + "</td> <td>" + data[i].absentNum + "</td> <td>" + data[i].sickNum + "</td> <td>" + data[i].otherNum + "</td> </tr>";
                        $("[name='dataList']").eq(index+1).append(app);
                    }

                } else if (len == 0) {
                    for (var i = 0; i < $(".sevenTeams>.tab-pane").size(); i++) {
                        $("[name='dataList']").eq(i).append("<tr style='text-align: center'><td colspan='7'>暂无数据</td></tr>")
                    }
                }
            }
        })
    })
    //查询事件
    function teamsSearchClick(oIndex){
        var teamFather = $("[name='teamFather']");
        var cli = $(".teams [class='actionON']");
        var depNAME = '';
        var teamcodeS = $(".actionON").attr("value");
        var startTime = $("[name='endTime']").val();
        var date = new Date();
        var seperator1 = "-";
        var seperator2 = ":";
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate;

        if (startTime == "") {
            startTime = currentdate;
        }
        //console.log(startTime)
        //console.log(currentdate);
        $.ajax({
            url: http + "statistics/attendanceProportion.do",
            data: {code: teamcodeS, startTime: startTime},
            dataType: 'json',
            success: function (data){
                //console.log(data)
                var len = data.length;
                //console.log(len)
                $("[name='dataList']").empty();
                if (len > 0) {
                    for (var k = 0; k < len; k++) {
                        var app = "<tr><td>" + data[k].endtime + "</td><td>" + data[k].allnum + "</td> <td>" + data[k].rollcallnum + "</td> <td>" + data[k].attendnum + "</td> <td>" + data[k].absensenum + "</td> <td>" + data[k].sickleavenum + "</td> <td>" + data[k].othernum + "</td> </tr>";
                        $("[name='dataList']").eq(oIndex).append(app);
                    }
                }
                if (len == 0) {
                    for (var i = 0; i < $(".sevenTeams>.tab-pane").size(); i++) {
                        $("[name='dataList']").eq(i).append("<tr style='text-align: center'><td colspan='7'>暂无数据</td></tr>")
                    }

                }


                //生成图表
                depNAME = $(".actionON").children().html();
                //console.log(depNAME);
                var time = [];
                var total = [];
                var rollcallNum = [];
                var attendNum = [];
                var absentNum = [];
                var sickNum = [];
                var otherNum = [];
                var len = data.length;
                for (var i = 0; i < len; i++) {
                    time.push(data[i].endtime.substring(11,16));
                    total.push(data[i].allnum);
                    rollcallNum.push(data[i].rollcallnum);
                    attendNum.push(data[i].attendNum);
                    absentNum.push(data[i].attendnum);
                    sickNum.push(data[i].sicknum);
//                  console.log(data[i].sickNum);
//                  console.log(sickNum);
                    otherNum.push(data[i].othernum)
                }

                //$(".histogram[value=" + teamCode1 + "]").append("<p>hahah </p>")

                $(".histogram[value=" + teamcodeS + "]").highcharts({
                    chart: {
                        type: 'column',
                        width: '1200'
                    },
                    title: {
                        text: startTime + ' ' + depNAME + '考勤数据柱状图'
                    },
                    credits: {
                        enabled: false//不显示highCharts版权信息
                    },
                    xAxis: {
                        lineWidth: 1,
                        lineColor: "#777777",
                        tickWidth: 0,
                        gridLineColor:"#777777",
                        categories: time,
                        crosshair: true
                    },
                    yAxis: {
                        lineWidth: 1,
                        lineColor: "#777777",
                        gridLineColor:"#777777",
                        min: 0,
                        title: {
                            text: '人数 (人)'
                        }

                    },
                    tooltip: {
                        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                        pointFormat: '<tr><td style="color:{series.color}.padding:0">{series.name}: </td>' +
                        '<td style="padding:0"><b>{point.y:.1f} 人</b></td></tr>',
                        footerFormat: '</table>',
                        shared: true,
                        useHTML: true
                    },

                    plotOptions: {
                        column: {
                            pointPadding: 0.2,
                            borderWidth: 0
                        }
                    },

                    series: [{
                        name: '总人数',
                        data: total
                    }, {
                        name: '应到人数',
                        data: rollcallNum
                    }, {
                        name: '实到人数',
                        data: attendNum
                    }, {
                        name: '缺席人数',
                        data: absentNum
                    }, {
                        name: '病假人数',
                        data: sickNum
                    }, {
                        name: '其他人数',
                        data: otherNum
                    }]
                });




            }
        });


    }

//查询各大队考勤
    $("[name='teamsSearch']").click(function () {
        var oIndex='';
        for (var j = 0; j < $("[name='teamFather']").length; j++) {
            if ($("[name='teamFather']").eq(j).attr("class")=="actionON active"||$("[name='teamFather']").eq(j).attr("class")=="actionON") {
                oIndex = j;
            }
        }
        teamsSearchClick(oIndex);
    });
    $("[data='teamFather1']").each(function(i){
        $("#java").eq(i).on("click","[data='teamFather1']",function(){
            $("[data='teamFather1']").removeClass("actionON");
            $(this).addClass("actionON");
            var oIndex='';
            for (var j = 0; j < $("[name='teamFather']").length; j++) {
                if ($("[name='teamFather']").eq(j).attr("class")=="actionON active"||$("[name='teamFather']").eq(j).attr("class")=="actionON") {
                    oIndex = j;
                }
            }
            teamsSearchClick(oIndex);
        })
    });

    //显示各大队的图表
    $("[name='showChart']").click(function () {
        var cli = $(this);
        var startTime = $("[name='endTime']").val();
        //var newDate = new Date();
        //var time = newDate.toLocaleString();
        //time = time.replace(/\//g, '-').substring(0, 9);
        var date = new Date();
        var seperator1 = "-";
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
        //console.log(currentdate);
        if (startTime == "") {
            startTime = currentdate;
        }
        //console.log(startTime)
        var teamCode1;
        teamCode1 = $(this).val();
        var depNAME = '';
        //console.log(teamCode1);
        $.ajax({
            url: http + "statistics/attendanceProportion.do",
            data: {code: teamCode1, startTime: startTime},
            dataType: 'json',
            success: function (data) {
                //console.log(data);
                depNAME = $(".teams>[class='active']").children().html();
                //console.log(data[1].deptName);
                //depNAME=data[0].deptName;
                var time = [];
                var total = [];
                var rollcallNum = [];
                var attendNum = [];
                var absentNum = [];
                var sickNum = [];
                var otherNum = [];
                var len = data.length;
                for (var i = 0; i < len; i++) {

                    time.push(data[i].endtime.substring(11,16));
                    //console.log(data[i].time);
                    total.push(data[i].allnum);
                    rollcallNum.push(data[i].rollcallnum);
                    attendNum.push(data[i].attendnum);
                    absentNum.push(data[i].absensenum);
                    sickNum.push(data[i].sickleavenum);
                    otherNum.push(data[i].othernum);
                }

                //$(".histogram[value=" + teamCode1 + "]").append("<p>hahah </p>")
                depNAME = $(".actionON").children().html();
                $(".histogram[value=" + teamCode1 + "]").highcharts({
                    chart: {
                        type: 'column',
                        width: '1200'
                    },
                    title: {
                        text: startTime + ' ' + depNAME + '考勤数据柱状图'
                    },
                    credits: {
                        enabled: false//不显示highCharts版权信息
                    },
                    xAxis: {
                        lineWidth: 1,
                        lineColor: "#777777",
                        tickWidth: 0,
                        gridLineColor:"#777777",
                        categories: time,
                        crosshair: true
                    },
                    yAxis: {
                        lineWidth: 1,
                        lineColor: "#777777",
                        gridLineColor:"#777777",
                        min: 0,
                        title: {
                            text: '人数 (人)'
                        }

                    },
                    tooltip: {
                        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                        pointFormat: '<tr><td style="color:{series.colors},padding:0">{series.name}: </td>' +
                        '<td style="padding:0"><b>{point.y:.1f} 人</b></td></tr>',
                        footerFormat: '</table>',
                        shared: true,
                        useHTML: true
                    },

                    plotOptions: {
                        column: {
                            pointPadding: 0.2,
                            borderWidth: 0
                        }
                    },

                    series: [{
                        name: '总人数',
                        data: total
                    }, {
                        name: '应到人数',
                        data: rollcallNum
                    }, {
                        name: '实到人数',
                        data: attendNum
                    }, {
                        name: '缺席人数',
                        data: absentNum
                    }, {
                        name: '病假人数',
                        data: sickNum
                    }, {
                        name: '其他人数',
                        data: otherNum
                    }]
                });

            }
        })

    })
});






$(function(){
    //选择指静脉仪器
    parent.$(".finger-machine-body ").on("click","ul li div",function(){
        $(".finger-machine-body ul li div").each(function(){
            $(".finger-machine-body ul li div").attr("class","bg1 view1 ")
        })
        $(this).removeClass("bg1").addClass("bg2");

        $(".finger-machine-foot-sure").css("background-color","#516CE1")

    })
    //选择指静脉仪器--取消
    $(".finger-machine-foot-close").click(function(){
        $(".finger-machine").fadeOut();
        $(".baohu").fadeOut();

    })

})

//采集指纹数据
function showFinger1(){
    $(".smallkuang11").fadeIn();
    $(".baohu").fadeIn();
    $(".sp4-1").html("请选择要采集数据的学员");
    $(".sp5").click(function(){
        $(".smallkuang11").fadeOut();
        $(".baohu").fadeOut();
    });
    return false;

}
function showFinger2(){
    $(".smallkuang11").fadeIn();
    $(".baohu").fadeIn();
    $(".sp4-1").html("采集数据只能选择一位学员");
    $(".sp5").click(function(){
        $(".smallkuang11").fadeOut();
        $(".baohu").fadeOut();
    });
    return false;
}

var timeShowFinger;
function showFinger() {
    $(".finger-machine-foot-sure").css("background-color", "lightgray")
    $(".smallkuang10-body>span").html("请放上手指进行采集").removeClass("red green");
    $("[name='firstF']").attr("class", "one gray");
    $("[name='secdentF']").attr("class", "one gray");
    $("[name='firstSpan']").attr("class", " grayspan");
    $("[name='secdentSpan']").attr("class", " grayspan");
    $(".baohu").fadeIn();
    $(".finger-machine").fadeIn();
    //后台导出指静脉仪器编号
    $.ajax({
        url: http + "collectFingerController/queryDriviceInfo",
        dataType: 'json',
        success: function (data) {
            var len = data.VDlist.length;
            var html = "";
            //console.log(data)
            for (var i = 0; i < len; i++) {
                html += "   <li> <div class='view1 bg1' data='" + data.VDlist[i].venaId + "'></div><span >" + data.VDlist[i].venaName + "</span> </li>"
            }
            $(".finger-machine-body ul").html(html)
        }
    })

    //确定选择仪器
    $(".finger-machine-foot-sure").click(function () {
        if ($(".finger-machine-foot-sure").css("background-color") == "lightgray") {
            return;
        } else {
            var whichVal = $(".finger-machine-body .bg2").attr("data");
            $(".smallkuang10").fadeIn();
            $(".finger-machine").fadeOut();

            $(".smallkuang10-foot-close").click(function () {
                var isSave = 0;
                $.ajax({
                    type: 'GET',
                    dataType: 'JSON',
                    url: http + "emptyFingerController/emptyFinger",
                    data: {isSave: isSave, userId: smallkuang11Id, mesID: whichVal},
                    success: function (data) {
                    }
                });

                $(".baohu").fadeOut();
                $(".smallkuang10").fadeOut();
            })
//每秒请求后台，是否录入成功
            var i = 1;

            function doQingqiu() {
                var whichVal = $(".finger-machine-body .bg2").attr("data");
                var smallkuang11Id = $("iframe.crumbsCon")[0].contentWindow.$("tbody .bg2").parent().parent().find(".stuId").attr("data-user");
                var userName = $("iframe.crumbsCon")[0].contentWindow.$("tbody .bg2").parent().parent().find(".stuName").html();
                var deptName = sessionStorage.department;
                $.ajax({
                    type: 'GET',
                    dataType: 'JSON',
                    url: http + collectFingerController/queryDriviceInfo,
                    data: {
                        userId: smallkuang11Id,
                        i: i,
                        mesID: whichVal,
                        deptName: deptName,
                        userName: userName,
                        isSave: 1
                    },
                    success: function (data) {
                        i = 2;
                        //console.log(data);
                        if (data == -1) {

                        } else if (data == 0) {
                            $(".smallkuang10-body>span").html("采集失败，请重新采集！").addClass("red");
                            $("[name='firstF']").attr("class", "one gray");
                            $("[name='secdentF']").attr("class", "one gray");
                            $("[name='firstSpan']").attr("class", " grayspan");
                            $("[name='secdentSpan']").attr("class", " grayspan");
                        } else if (data == 2) {
                            $(".smallkuang10-body>span").html("采集成功！请再次放手！").attr("class", "green");
                            $("[name='firstF']").attr("class", "one blue");
                            //$("[name='gray']").attr("class","one blue");
                            $("[name='firstSpan']").attr("class", "bluespan");
                        } else if (data == 1) {
                            $(".smallkuang10-body>span").html("指静脉采集成功！").attr("class", "green");
                            $("[name='firstF']").attr("class", "one blue");
                            $("[name='secdentF']").attr("class", "one blue");
                            $("[name='firstSpan']").attr("class", " bluespan");
                            $("[name='secdentSpan']").attr("class", " bluespan");
                            $(".smallkuang10-foot-sure").css("background-color", "516CE1");
                            $("[class='smallkuang10-foot-sure']").click(function () {
                                //ajax
                                var isSave = 1;
                                $.ajax({
                                    type: 'GET',
                                    dataType: 'JSON',
                                    url: http + "VenaController/inputFinger.do",
                                    data: {isSave: isSave, userId: smallkuang11Id, mesID: whichVal},
                                    success: function (data) {
                                    }
                                })
                                $(".baohu").fadeOut();
                                $(".smallkuang10").fadeOut();
                                //clearTimeout(time);
                            })
                            $(".smallkuang10-foot-close").click(function () {
                                var isSave = 0;
                                $.ajax({
                                    type: 'GET',
                                    dataType: 'JSON',
                                    url: http + "VenaController/inputFinger.do",
                                    data: {isSave: isSave, userId: smallkuang11Id, mesID: whichVal},
                                    success: function (data) {
                                    }
                                });

                                $(".baohu").fadeOut();
                                $(".smallkuang10").fadeOut();
                            })

                            clearTimeout(parent.timeShowFinger);
                        }


                    }

                })
            }

            timeShowFinger = setInterval(doQingqiu, 2500);
        }
    })
}

function showFinger3(){
    $(".baohu").fadeOut();
    $(".smallkuang10").fadeOut();
    //clearTimeout($("iframe.crumbsCon")[0].contentWindow.timeShowFinger);
}
$(".footClose").click(function(){
    parent.showFinger3();
    clearTimeout(parent.timeShowFinger);
});
function delFinger(){
    $(".smallkuang11").fadeIn();
    $(".baohu").fadeIn();
    $(".sp4-1").html("请选择要删除数据的学员");
    $(".sp5").click(function(){
        $(".smallkuang11").fadeOut();
        $(".baohu").fadeOut();
    });
    return false;
}
function delFinger1(){
    $(".smallkuang11").fadeIn();
    $(".baohu").fadeIn();
    $(".sp4-1").html("删除数据只能选择一位学员");
    $(".sp5").click(function(){
        $(".smallkuang11").fadeOut();
        $(".baohu").fadeOut();
    });
    return false;
}
function delFinger2(){
    $(".smallkuang12").fadeIn();
    $(".baohu").fadeIn();

}
function delFinger9(){
	//$(".adTxtC p")[0].click()
    var url=data.objExt;
    //console.log(url)
    var html=`
            <img src="${url}" data="${data.obj}"/>
           `;
    $("#photo img").remove();
    $("#photo").html(html);
	$(".baohu").fadeOut();

//	window.location.href ="newAdm.html"

}

function delFinger8(){

	$(".baohu").fadeIn();
	window.open("collectphotos.html","","height=700,width=900,top=100,left=400,toolbar=no,menubar=no,scrollbars=no,resizable=yes, location=no,status=no")
//	$(".collection").fadeIn();
//	var sName = sessionStorage.getItem("sName");
//	var smallkuang11Id = sessionStorage.getItem("smallkuang11Id");
//
//var smallkuang11Name = sessionStorage.getItem("smallkuang11Name");
//$(".gatheringInformation").html("编号"+smallkuang11Id+smallkuang11Name+	"照片正在采集中......")
//
////用户信息
//var htmls =
//	'<div class="uer">你好，<span>' + sName + '</span></div>';
//$(".asUer").html(htmls);
//
//var output = document.getElementById("output");
//var video = document.getElementById("video");
////debugger
//var canvas = document.getElementById("canvas");
//var context = canvas.getContext("2d");
////context.clearRect(0,0,canvas.width,canvas.height);
//
//navigator.getUserMedia = navigator.getUserMedia ||
//	navigator.webkitGetUserMedia ||
//	navigator.mozGetUserMedia ||
//	navigator.msGetUserMedia; //获取媒体对象（这里指摄像头）
//navigator.getUserMedia({
//	video: true
//}, gotStream, noStream); //参数1获取用户打开权限；参数二成功打开后调用，并传一个视频流对象，参数三打开失败后调用，传错误信息
//
//function gotStream(stream) {
//	video.src = URL.createObjectURL(stream);
//	video.onerror = function() {
//		stream.stop();
//	};
//	stream.onended = noStream;
//	video.onloadedmetadata = function() {
//		alert('摄像头成功打开！');
//	};
//}
//
//function noStream(err) {
//	alert(err);
//}
//
//document.getElementById("snap").addEventListener("click", function() {
//	$(this).unbind('click');
////	debugger
////	Uniqueness()
//
//	context.drawImage(video, 0, 0, 320, 380); //将获取视频绘制在画布上
//	var type = "png";
//	var img = canvas.toDataURL(type);//获取base64编码
//	imgdate = img.substr(22);//截取有用信息
////	console.log(imgdate)
////	output.innerText = imgdate;
//
//	$("#shangchuan").bind("click",function() {
//		$(this).unbind('click');
//
////		console.log(imgdate)
////debugger
//		 $.ajax({
//			type: "post",
//			url: http + "rollCallUserInfoController/generateImage.do",
//			dataType: "json",
//			data: {
//				imgStr: imgdate,
//				rollCallUserNo: smallkuang11Id
//			},
//			success: function(data) {
//				if(data == false){
//					$(".gatheringInformation").html("采集失败！")
//					$(".gatheringInformation").css("color","#FE610B")
//				}else{
////					debugger
//					$(".gatheringInformation").html("采集成功！")
//					$(".gatheringInformation").css("color","#FE610B")
//					delFinger9()
//				}
//			},
//			error: function(err) {
//				console.log(err)
//			}
//
//		});
////		request.abort();
//	})
//});

}


function delFingerl(){
    $(".smallkuang11").fadeIn();
    $(".baohu").fadeIn();
    $(".sp4-1").html("请选择要采集照片的学员");
    $(".sp5").click(function(){
        $(".smallkuang11").fadeOut();
        $(".baohu").fadeOut();
    });
    return false;
}
function delFinger6(){
    $(".smallkuang11").fadeIn();
    $(".baohu").fadeIn();
    $(".sp4-1").html("采集照片只能选择一位学员");
    $(".sp5").click(function(){
        $(".smallkuang11").fadeOut();
        $(".baohu").fadeOut();
    });
    return false;
}
$(function(){



//取消


//确定


    //删除指静脉

    //未选择学员

    //取消
    $("[name='smallkuang12-close']").click(function(){
        $(".smallkuang12").fadeOut();
        $(".baohu").fadeOut();
    })
    //确定
    $("[name='smallkuang12-sure']").click(function(){
        //ajax
        var isdelete=1;
        var whichVal=$("iframe.crumbsCon")[0].contentWindow.$("select[name='finger'] option:selected").val();
        var smallkuang11Id=$("iframe.crumbsCon")[0].contentWindow.$("tbody .bg2").parent().parent().find(".stuId").attr("data-user");
        //console.log(smallkuang11Id)
        $.ajax({
            type:'GET',
            dataType:'JSON',
            url:http+"VenaController/deleteFinger.do",
            data:{isDelete:isdelete,userId:smallkuang11Id,mesID:whichVal},
            success:function(data){}
        });

        $(".smallkuang12").fadeOut();
        $(".baohu").fadeOut();
    })

//所长页面
    function showBar(a){
        a=$("[name='deptChart'] option:selected").val()||"1";
        $(".welcome-left1-1").show();
        $(".welcome-left1-2").hide();
        $.ajax({
            url: http + "homePageController/homeAttence.do",
            data: {code:sessionStorage.sRoleId,deptid:a},
            dataType: 'json',
            success:function(data){

                var len=data.length;
                //console.log(len);
                var deptName;
                var absentNum;
                var attendNum;
                var otherNum;
                var rollcallNum;
                var sickNum;
                var time;
                var total;
                if(len>0){
                    for(var i=0;i<len;i++){
                        deptName=data[i].deptName;
                        absentNum=data[i].absensenum;
                        attendNum=data[i].attendnum;
                        otherNum=data[i].otherNum;
                        rollcallNum=data[i].rollcallnum;
                        sickNum=data[i].sickleavenum;
                        time=data[i].endtime;
                        total=data[i].allnum;
                        //console.log(time);
                        $(".welcome-left1-chart").highcharts({
                            chart: {
                                type: 'column'
                            },
                            title: {
                                text: deptName+"考勤数据",
                                align: 'center'
                            },
                            xAxis: {
                                lineWidth: 1,
                                lineColor: "blue",
                                tickWidth: 0,
                                gridLineColor:"blue",
                                categories: [time],
                                crosshair: true
                            },

                            credits: {
                                enabled: false//不显示highCharts版权信息
                            },
                            yAxis: {
                                lineWidth: 1,
                                lineColor: "blue",
                                tickWidth: 0,
                                //gridLineColor:"blue",
                                min: 0,
                                title: {
                                    text: '人数'
                                }
                            },
                            tooltip: {
                                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                                '<td style="padding:0"><b>{point.y:.1f} (人)</b></td></tr>',
                                footerFormat: '</table>',
                                //shared: true,
                                //useHTML: true
                            },
                            plotOptions: {
                                column: {
                                    pointPadding: 0.2,
                                    borderWidth: 0
                                }
                            },
                            series: [{
                                name: '总人数',
                                data: [total]
                            }, {
                                name: '应到人数',
                                data: [rollcallNum]
                            }, {
                                name: '实到人数',
                                data: [attendNum]
                            }, {
                                name: '缺席人数',
                                data: [absentNum]
                            },
                                {
                                    name: '病假人数',
                                    data: [sickNum]
                                },
                                {
                                    name: '其他人数',
                                    data: [otherNum]
                                }]
                        });
                    }
                }else{
                    var html;
                    $(".welcome-left1-chart").html('<img src="../img/dataloss.png" alt=""/>')
                }

            }
        })

    }
    //队长页面
    function showBar2(){
        $(".welcome-left1-2").show();
        $(".welcome-left1-1").hide();
        var deptid=sessionStorage.sUserDept;
        $.ajax({
            url: http + "homePageController/homeAttence.do",
            data: {code:suserDept,deptid:deptid},
            dataType: 'json',
            success:function(data){
                //console.log(data);
                var len=data.length;
                //console.log(len);
                var deptName;
                var absentNum;
                var attendNum;
                var otherNum;
                var rollcallNum;
                var sickNum;
                var time;
                var total;

                deptName=data[0].deptName;
                //console.log(deptName)
                absentNum=data[0].absensenum;
                attendNum=data[0].attendnum;
                otherNum=data[0].othernum;
                rollcallNum=data[0].rollcallnum;
                sickNum=data[0].sickleavenum;
                time=data[0].endtime.substring(0,16);
                total=data[0].allnum;
                //console.log(time);
                $(".welcome2-bar").highcharts({
                    chart: {
                        type: 'column'
                    },
                    title: {
                        text: deptName+"考勤数据",
                        align: 'center'
                    },
                    xAxis: {
                        lineWidth: 1,
                        lineColor: "#53c7e7",
                        tickWidth: 0,
                        gridLineColor:"#53c7e7",
                        categories: [time],
                        crosshair: true
                    },
                    credits: {
                        enabled: false//不显示highCharts版权信息
                    },
                    yAxis: {
                        lineWidth: 1,
                        lineColor: "#53c7e7",
                        tickWidth: 0,
                        //gridLineColor:"blue",
                        min: 0,
                        title: {
                            text: '人数'
                        }
                    },
                    tooltip: {
                        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                        '<td style="padding:0"><b>{point.y:.1f} (人)</b></td></tr>',
                        footerFormat: '</table>'
                        //shared: true,
                        //useHTML: true
                    },
                    plotOptions: {
                        column: {
                            pointPadding: 0.2,
                            borderWidth: 0
                        }
                    },
                    series: [{
                        name: '总人数',
                        data: [total]
                    }, {
                        name: '应到人数',
                        data: [rollcallNum]
                    }, {
                        name: '实到人数',
                        data: [attendNum]
                    }, {
                        name: '缺席人数',
                        data: [absentNum]
                    },
                        {
                            name: '病假人数',
                            data: [sickNum]
                        },
                        {
                            name: '其他人数',
                            data: [otherNum]
                        }]
                });
            }

        })
        //缺勤人员名单
        //console.log(deptid)
        //debugger;
        $.ajax({
            url: http + "homePageController/queqinList.do",
            data: {depId:deptid},
            dataType: 'json',
            success:function(data){
                //console.log(data);
                var state;
                var userName;
                var userNo;
                var len=data.length;
                //console.log(data)
                $(".welcome2-shuju table tbody").empty();
                for(var i=0;i<len;i++){
                    state=data[i].stateName;
                    userName=data[i].userName;
                    userNo=data[i].userid;
                    $(".welcome2-shuju table tbody").append("<tr> <td style='width: 33%'>"+userNo+"</td> <td style='width: 33%'>"+userName+"</td> <td style='width: 33%'>"+state+"</td> </tr>")
                }
            }
        })

    }
    if(suserDept!=1&&suserDept!=2){
        showBar2();
    }else{
        var code=$("[name='deptChart'] option:selected").val();
        showBar(code);

    }
//所长页面下拉框获取

    $(function(){
        if(suserDept!=1&&suserDept!=2){
            showBar2();
        }else{
            var code=$("[name='deptChart']").val();
            showBar(code);

        }
        $.ajax({
            url:http + "systemUser/queryDept.do",
            //data:{code:sessionStorage.sRoleId,deptid:sessionStorage.sUserDept},
            dataType: 'json',
            success:function(data){
//console.log(data)
                var len=data.obj.length;
                var html='';
                //code1=data[0].code;
                for(var i=0;i<len;i++){

                    html+='<option value="'+data.obj[i].deptid+'">'+data.obj[i].deptName+'</option>'
                }
                $("[name='deptChart']").html(html);
            }
        })
    })
    //所长页面下拉框
    $("[name='deptChart']").change(function(){
        var code=$(this).val();
        //console.log(code)
        showBar(code);
    });

    //面积图-在队
    function showZaidui(){
        $("#line1").addClass("buttonAction");
        $("#line2").addClass("buttonNoAction");
        $.ajax({
            url: http + "homePageController/yearlyInOrNotTeam.do",
            data: {code:suserDept,isDelected :0,deptid:sessionStorage.sUserDept},
            dataType: 'json',
            success: function (data) {
                var name;
                if(suserDept==1||suserDept==2){
                    name="所有大队";
                }else{
                    name=sDeptment;
                }
                var len=data.length;

                var sum=[];
                for(var i=0;i<len;i++){
                    sum.push(data[i].sum);
                }
                $('.welcome-left2-line1').highcharts({
                    chart: {
                        type: 'areaspline'
                    },
                    title: {
                        text: name+'在队人数'
                    },
                    legend: {
                        layout: 'vertical',
                        align: 'left',
                        verticalAlign: 'top',
                        x: 150,
                        y: 100,
                        floating: true,
                        borderWidth: 1,
                        backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
                    },
                    xAxis: {
                        lineColor: "#3cf",
                        categories: [
                            '一月',
                            '二月',
                            '三月',
                            '四月',
                            '五月',
                            '六月',
                            '七月',
                            '八月',
                            '九月',
                            '十月',
                            '十一月',
                            '十二月'
                        ]
                        //plotBands: [{ // visualize the weekend
                        //    from: 4.5,
                        //    to: 6.5,
                        //    color: 'rgba(68, 170, 213, .2)'
                        //}]
                    },
                    yAxis: {
                        lineWidth: 1,
                        lineColor: "#3cf",
                        title: {
                            text: '人数'
                        }
                    },
                    tooltip: {
                        shared: true,
                        valueSuffix: '人'
                    },
                    credits: {
                        enabled: false
                    },
                    plotOptions: {
                        areaspline: {
                            fillOpacity: 0.5
                        }
                    },
                    series: [{
                        name: name,
                        data: sum
                    }]
                });
            }

        })
    }
    showZaidui();
    //面积图-离队人数
    $("[name='welcome-left2-line2']").click(function(){
        $("#line1").attr("class","buttonNoAction");
        $("#line2").attr("class","buttonAction");
        $.ajax({
            url: http + "homePageController/yearlyInOrNotTeam.do",
            data: {code:suserDept,isDelected :1,deptid:sessionStorage.sUserDept},
            dataType: 'json',
            success: function (data) {
                console.log(data)
                var name;
                if(suserDept==1||suserDept==2){
                    name="所有大队";
                }else{
                    name=sDeptment;
                }
                var len=data.length;

                var sum=[];
                for(var i=0;i<len;i++){
                    sum.push(data[i].sum);
                }
                $('.welcome-left2-line2').highcharts({
                    chart: {
                        type: 'areaspline'
                    },
                    title: {
                        text: name+'离队人数'
                    },
                    legend: {
                        layout: 'vertical',
                        align: 'left',
                        verticalAlign: 'top',
                        x: 150,
                        y: 100,
                        floating: true,
                        borderWidth: 1,
                        backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
                    },
                    xAxis: {
                        lineWidth: 1,
                        lineColor: "#3cf",
                        tickWidth: 0,
                        //gridLineColor:"blue",
                        categories: [
                            '一月',
                            '二月',
                            '三月',
                            '四月',
                            '五月',
                            '六月',
                            '七月',
                            '八月',
                            '九月',
                            '十月',
                            '十一月',
                            '十二月'
                        ]
                        //plotBands: [{ // visualize the weekend
                        //    from: 4.5,
                        //    to: 6.5,
                        //    color: 'rgba(68, 170, 213, .2)'
                        //}]
                    },
                    yAxis: {
                        lineWidth: 1,
                        lineColor: "#3cf",
                        //gridLineColor:"blue",
                        min: 0,
                        title: {
                            text: '人数'
                        }
                    },
                    tooltip: {
                        shared: true,
                        valueSuffix: '人'
                    },
                    credits: {
                        enabled: false
                    },
                    plotOptions: {
                        areaspline: {
                            fillOpacity: 0.5
                        }
                    },
                    series: [{
                        name: name,
                        data: sum
                    }]
                });
            }

        });
        $(".welcome-left2-line2").fadeIn();
        $(".welcome-left2-line1").fadeOut();
    });
    $("[name='welcome-left2-line1']").click(function(){
        $("#line2").attr("class","buttonNoAction");
        $("#line1").attr("class","buttonAction");
        $(".welcome-left2-line1").fadeIn();
        $(".welcome-left2-line2").fadeOut();
        showZaidui();
    })

    //日历
    $('#ca').calendar({
        width: 240,
        height: 200,
        data: [
            {
                date: '2015/12/24',
                value: 'Christmas Eve'
            },
            {
                date: '2015/12/25',
                value: 'Merry Christmas'
            },
            {
                date: '2016/01/01',
                value: 'Happy New Year'
            }
        ],
        onSelected: function (view, date, data) {
            //console.log('view:' + view)
            //alert('date:' + date)
            //console.log('data:' + (data || 'None'));
        }
    });





});
//获取动态数据点名下拉框
//function teamControlxiugai(){
//    $.ajax({
//        url: http+"VenaDigitalController/selectMachine.do",
//        dataType: 'json',
//        success: function (data) {
//            var len=data.VDlist.length;
//
//            for(var i=0;i<len;i++){
//                $("[name='finger']").append("  <option value='"+data.VDlist[i].venaId+"'>"+data.VDlist[i].venaId+"号机器"+"</option>")
//            }
//
//        }
//    })
//}
//点击日历跳转

function cabaohu001(){
    var cla = "groupChoseCrb"
    var claName = "大队统计";
    sessionStorage.setItem("cla", cla);
    sessionStorage.setItem("claName", claName);
    cla = cla+".html";
    $(".adm .crumbsCon").attr("src",cla);
}

//右侧大队数据
function rightTem(){
    var deptid=sessionStorage.sUserDept;
    $.ajax({
        url: http + "homePageController/proportion.do",
        data: {code:suserDept,deptid:deptid},
        dataType: 'json',
        success: function (data) {
            console.log(data);
            if(suserDept!=2||suserDept!=1){
                $(".dadui").show();
                var total=data.attend.allnum;
                $("[class='shuju-total']").html(total);
                var attendNum=data.attend.attendnum;
                $("[class='shuju-attendNum']").html(attendNum);
                var absentNum=data.attend.absensenum;
                $("[class='shuju-absentNum']").html(absentNum);
                var sickNum=data.attend.sickleavenum;
                $("[class='shuju-sickNum']").html(sickNum);
                var rollcallNum=data.attend.rollcallnum;
                $("[class='shuju-rollcallNum']").html(rollcallNum);
                var otherNum=data.attend.othernum;
                $("[class='shuju-otherNum']").html(otherNum);
                //console.log(data);
            }else{
                $(".suozhang").show();
                var name;
                if(suserDept==2){
                    name="所有大队";
                }else{
                    name=sDeptment;
                }
//右侧大队数据
                depSum=data.depSum;
                $("[class='shuju-depSum']").html(depSum);
                total=data.attend.total;
                $("[class='shuju-total']").html(total);
                attendNum=data.attend.attendNum;
                $("[class='shuju-attendNum']").html(attendNum);
                absentNum=data.attend.absentNum+data.attend.sickNum+data.attend.otherNum;
                $("[class='shuju-absentNum']").html(absentNum);
            }

            //console.log(data);

            //右侧大队饼状图
            if(suserDept==1||suserDept==2){
                name="所有大队";
            }else{
                name=sDeptment;
            }
            var absentNum1=data.absentNum*1;
            var attendNum1=data.attendNum*1;
            var otherNum1=data.otherNum*1;
            var sickNum1=data.sickNum*1;
            console.log(absentNum1)
            console.log(attendNum1)
            console.log(otherNum1)
            console.log(sickNum1)


            $('.pieChart').highcharts({
                chart: {
                    plotBackgroundColor: null,
                    plotBorderWidth: null,
                    plotShadow: false
                },
                title: {
                    text: name+'出勤数据占比'
                },
                tooltip: {
                    headerFormat: '{series.name}<br>',
                    pointFormat: '{point.name}: <b>{point.percentage:.1f}%</b>'
                },
                credits: {
                    enabled: false//不显示highCharts版权信息
                },
                plotOptions: {
                    pie: {

                        allowPointSelect: true,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: false,
                            format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                            style: {
                                color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                            }
                        },
                        showInLegend: true
                    }
                },
                series: [{
                    type: 'pie',
                    name: name+'出勤数据',
                    data: [
                        {
                            name: '出勤',
                            y: attendNum1,
                            sliced: true,
                            selected: true
                        },
                        ['病假',sickNum1],
                        ['其他',otherNum1],
                        ['缺席',absentNum1]




                    ]
                }]
            });

        }
    })

}


//部门调度
function showTeamControl(){
    $(".smallkuang1 .sp4").html("请选择需要调度的学员！")
    $(".smallkuang1 .smallkuang-header span").html("部门调度")
    $(".smallkuang1").fadeIn();
    $(".baohu").fadeIn();
    $(".sp5").click(function(){
        $(".smallkuang1").fadeOut();
        $(".baohu").fadeOut();

    });
    return false;
}
function showTeamControl1(){
    $(".teamControl").fadeIn();
    $(".baohu").fadeIn();
    $.ajax({
        dataType:'JSON',
        type:'POST',
        url: http + "systemUser/queryDept.do",
        //data:{code:9},
        success:function(data){
            //console.log(data);
            var len=data.obj.length;
            $(".teamControlxiugai").empty();
            $(".teamControlxiugai").append(' <option value="-1">请选择</option>')
            for(var i=0;i<len;i++){
                $(".teamControlxiugai").append(' <option value="'+data.obj[i].deptid+'">'+data.obj[i].deptName+'</option>')
            }
            var code=sessionStorage.sUserDept;
            $("select[class='teamControlxiugai']").size();
            //for(var z=0;z<$("select[class='teamControlxiugai'] option").length;z++){
            //    if(code==1||code==9){
            //        $("select[class='teamControlxiugai'] option").eq(0).attr("selected",true)
            //    }else if($("select[class='teamControlxiugai'] option").eq(z).val()==code){
            //        $("select[class='teamControlxiugai'] option").eq(z).attr("selected",true)
            //    }
            //}
            //console.log($("select[class='teamControlxiugai'] option").length);
        }
    })
    $("[name='teamControlReturn']").click(function(){
        $(".teamControl").fadeOut();
        $(".baohu").fadeOut();
    })
}

//确认修改大队
function showTeamControl2(){
     $(".teamControl .teamControlSure").click(function () {
         $(".theadview .view1 ").attr("class","view1 bg1");
        var operationPersonnel=sessionStorage.sId;
        var depId=$(".teamControl .teamControlxiugai option:selected").val();
        var operationIP=sessionStorage.logComIP;
        var depCode=sessionStorage.sUserDept;
        var smallkuang11Id=$("[name='sIdHidden']").val();
         var fingerDevID=$(".teamControl .teamControlFinger option:selected").val();
        if(depId==-1){
            return false;
        }else{
            $(".teamControl .teamControl-message").html("");
            $.ajax({
                dataType:'JSON',
                type:'POST',
                url: http+ "ChangeReviseStateController/readyChangeDept",
                data:{ids:smallkuang11Id,reviseState:1,deptId:depId,currentId:operationPersonnel,fingerDevID:fingerDevID },
                success:function(data){
                    console.log(data)
                    if(data.code==-1){
                        $(".teamControl .teamControl-message").html(data.message);
                        return;
                    }else if(data.code==-3){
                    	$(".teamControl .teamControl-message").html(data.message);
                        return;
                    }else{
                        $(".teamControl").fadeOut();
                        $(".baohu").fadeOut();
                        var rollcalluserId =$(".contentChild .rollcalluserId01").val();
                        var isdrop = $(".personnel .content .isdrop option:selected").val();
                        var rollcalluserName =$(".contentChild .rollcalluserName01").val();
                        var rollcalluserCreatetime =$(".contentChild .rollcalluserCreatetime01").val();
                        var rollcalluserDeletetime =$(".contentChild .rollcalluserDeletetime01").val();
                        var rollcalluserPhoto =$(".select-pic").attr("class")=="select-pic bg3"?0:1;
                        var selectPic = parent.$(".personnel .selectPic option:selected").val();
                        $("iframe.crumbsCon")[0].contentWindow.loading(1,$("iframe.crumbsCon")[0].contentWindow.$("#sel-P option:selected").val(),rollcalluserId,rollcalluserName,1,rollcalluserCreatetime,rollcalluserDeletetime);

                    }

                }
            })
        }
    })

}
//    确定


//操作日志
var loginMax1;

function showPaging(a,b){
    var depCode=sessionStorage.sUserDept;
    var operationType=$(".operationType ").val();
    var c=$(".operationDateChoseCrb input.loginname").val();
    var d=$(".operationDateChoseCrb input.logindate").val();
    var e=$(".operationDateChoseCrb input.loginip").val();
    if(!c){c='';}
    if(!d){d='';}
    if(!e){e='';}
    $.ajax({
        dataType:'JSON',
        type:'POST',
        url: http + "operationLogController/getOperationLogList",
        data:{page:a,rows:b,operationPersonnel:c,operationTime:d,operationIP:e,depCode:depCode,operationType:operationType},
        jsonp:'callback',
        success:function(data){
            var dangqian=data.objExt.currentPage/1;
            var zongshu=data.objExt.totalCount/1;
            var yeshu=data.objExt.pageCount/1;
            if(yeshu==0){
                yeshu=1;
            }
            loginMax1=yeshu;
            $(".operationDateChoseCrb .mainpart tbody").empty();

            var len=data.obj.length;
            var html;
            if(data.obj.length>0){
                for(var i=0;i<len;i++){
                    var newTime = data.obj[i].operationTime;


                    //$(".operationDateChoseCrb .mainpart tbody").append("<tr><td>"+
                    //    data.result[i].operationTime+"</td><td>"+data.result[i].depName+
                    //    "</td><td>"+data.result[i].operationPersonnel+"</td><td>"+
                    //    data.result[i].operationContext+"</td><td>"+data.result[i].operationIP+"</td></tr>")
                    html+=`
                    <tr>
                        <td>${newTime}</td>
                        <td>${data.obj[i].deptName}</td>
                        <td>${data.obj[i].operationPersonnel}</td>
                        <td>${data.obj[i].operationContext}</td>
                        <td>${data.obj[i].operationIP}</td>
                        </tr>
				`
                }
            }else{
                html+=`
            <tr class="datalosslist">
                    <td colspan="5"><img src="img/dataloss.png" alt=""  /></td>

                    </tr>
				`
            }
            $("div.operationDateChoseCrb div.mainpart table tbody").html(html);

            $("div.operationDateChoseCrb div.pagers span.pagerstotal").html(zongshu);
            $("div.operationDateChoseCrb div.pagers span.dangqian").html(dangqian);
            $("div.operationDateChoseCrb div.pagers span.yeshu").html(yeshu);
            var html1='';
            if(dangqian==1){
                if(dangqian<=yeshu){
                    html1+=`<li class="clicked">${dangqian}</li>`;
                }
                if(dangqian+1<=yeshu){
                    html1+=`<li>${dangqian+1}</li>`;
                }
                if(dangqian+2<=yeshu){
                    html1+=`<li>${dangqian+2}</li>`;
                }
                if(dangqian+3<=yeshu){
                    html1+=`<li>${dangqian+3}</li>`;
                }
                if(dangqian+4<=yeshu){
                    html1+=`<li>${dangqian+4}</li>`;
                }
            }else if(dangqian==2){
                html1+=`<li>${dangqian-1}</li>`;
                html1+=`<li class="clicked">${dangqian}</li>`;

                if(dangqian+1<=yeshu){
                    html1+=`<li>${dangqian+1}</li>`;
                }
                if(dangqian+2<=yeshu){
                    html1+=`<li>${dangqian+2}</li>`;
                }
                if(dangqian+3<=yeshu){
                    html1+=`<li>${dangqian+3}</li>`;
                }
            }else if(dangqian==yeshu&&dangqian>=5){
                html1+=`
                <li>${dangqian-4}</li>

                    <li>${dangqian-3}</li>

                    <li>${dangqian-2}</li>

                    <li >${dangqian-1}</li>
                    <li class="clicked">${dangqian}</li>
						`
            }else if(dangqian==yeshu-1&&dangqian>=5){
                html1+=`
                <li>${dangqian-3}</li>

                    <li>${dangqian-2}</li>

                    <li>${dangqian-1}</li>

                    <li class="clicked">${dangqian}</li>
                        <li>${dangqian+1}</li>
						`
            }else{
                if(dangqian-2>0){
                    html1+=`<li>${dangqian-2}</li>`;
                }
                if(dangqian-1>0){
                    html1+=`<li>${dangqian-1}</li>`;
                }
                html1+=`<li class="clicked">${dangqian}</li>`;
                if(dangqian<yeshu){
                    html1+=`<li>${dangqian+1}</li>`;
                }
                if(dangqian+1<yeshu){
                    html1+=`<li>${dangqian+2}</li>`;
                }
            }
            $("div.operationDateChoseCrb div.pagers ul").html(html1);
        }
    })
}
showPaging(1,$("#operationDateChoseCrb div.pagers select").val());
$("#operationDateChoseCrb .pagers ul").on("click","li",function(e){
    showPaging(e.target.innerHTML,$("#operationDateChoseCrb div.pagers select").val());

})
$("#operationDateChoseCrb div.pagers a.tofirst").click(function(e){
    var page=$("#operationDateChoseCrb div.pagers span.dangqian").html();

    e.preventDefault();
    //console.log(e);
    if(page !=1){
        showPaging(1,$("#operationDateChoseCrb div.pagers select").val());
    }

})
$("#operationDateChoseCrb div.pagers a.toleast").click(function(e){
    e.preventDefault();
    var page=$("div#operationDateChoseCrb div.pagers span.dangqian").html();
    var lastPage=$("div#operationDateChoseCrb div.pagers span.yeshu").html();
    if(page !=lastPage ){
        showPaging(loginMax1,$("#operationDateChoseCrb div.pagers select").val());
    }

})
$("div#operationDateChoseCrb div.pagers a.go").click(function(e){
    e.preventDefault();
    var tar=$("#operationDateChoseCrb div.pagers input").val();
    var page=$("#operationDateChoseCrb div.pagers span.dangqian").html();
    if(page != tar) {
        if (tar == '') {
            return;
        }
        if (tar > loginMax1) {
            $("div.alert").fadeIn();
            $("div.alert_content").hide();
            $("div.tishi").show();
            $("div.tishi p").html("页码越界");
            return;
        }
        showPaging(tar, $("#operationDateChoseCrb div.pagers select").val());
    }
})
$("div#operationDateChoseCrb span.search").click(function(){
    showPaging(1,$("#operationDateChoseCrb div.pagers select").val());
})
$("div#operationDateChoseCrb div.pagers select").change(function(){
    showPaging(1,$("div#operationDateChoseCrb  div.pagers select").val())
    $("div#operationDateChoseCrb div.pagers input").val("");
})


//上传照片
$(".btn1").click(function(){
    $("#rrr img").remove();
    $(".personnel .content").hide();
    $(".personnel .up-photo").show();



});
$(".up-photo-return").click(function(){
    loading(1);
    $(".personnel .content").show();
    $(".personnel .up-photo").hide();

});


parent.$(".sp17").click(function(){
    $(".personnel .content").show();
    $(".personnel .up-photo").hide();
    $(".smallkuang6").fadeOut();
    $(".baohu").fadeOut();
});
parent.$(".sp15").click(function(){
    $(".personnel .content").show();
    $(".personnel .up-photo").hide();
    $(".smallkuang5").fadeOut();
    $(".baohu").fadeOut();
});

//接收人员

var loginMax2;

function showReceiveUser(a,b){
    var depCode=sessionStorage.sUserDept;
    var c=$(".ReceiveUserOn input.loginname").val();
    var d=$(".ReceiveUserOn input.logindate").val();
    var e=$(".ReceiveUserOn input.loginip").val();
    var f=$(".ReceiveUserOn select option:selected").val();


    if(!c){c='';}
    if(!d){d='';}
    if(!e){e='';}
    if(!f){f='1';}
    $.ajax({
        dataType:'JSON',
        type:'POST',
        url: http + "dropUserController/queryReceiveUserList",
        data:{page:a,rows:b,
            userName  :e,
            roleid:sRoleId,            //角色id
            userid :c,
            receiveTime:d,
            deptid:depCode,
            reviseState :f
        },
        success:function(data){

            var picUrl=data.message;
            var dangqian=data.objExt.currentPage/1;
            var zongshu=data.objExt.totalCount/1;
            var yeshu=data.objExt.pageCount/1;

            if(yeshu==0){
                yeshu=1;
            }

            loginMax2=yeshu;
            var html='';
            $(".ReceiveUserOn .mainpart tbody").empty();

            var len=data.obj.length;
            var html;
            var pic='';
            var url='';
            var reviseState;
            if(data.obj.length>0){
                for(var i=0;i<len;i++){

                    var reviseTime = data.obj[i].reviseTime;
                    var receiveTime=data.obj[i].receiveTime;
                    if(reviseTime==null||reviseTime==""){
                        reviseTime="--"
                    }
                    if(receiveTime==null||receiveTime==""){
                        receiveTime="--"
                    }

                    if(data.obj[i].reviseState==1){
                        reviseState="接收中";
                    }else if(data.obj[i].reviseState==2){
                        reviseState="已接收";

                    }else if(data.obj[i].reviseState==3){
                        reviseState="已驳回";

                    }else{
                        reviseState="数据有误";
                    }
                    if(data.obj[i].photoUrl==null||data.obj[i].photoUrl==""){
                        url='img/moren.png'
                    }else{
                        url=picUrl+data.obj[i].photoUrl
                    }
                    pic+=`
                <li>
                    <div class="img-11">  <img src="${url}"/><div class="pic-click bg-click"> </div></div>

                        <span class="mainpart1Id" data-num="${data.obj[i].reviseState}" data-id="${data.obj[i].userid}">编号: <p>${data.obj[i].userid}</p></span>
                    <span class="mainpart1Name">姓名: <p>${data.obj[i].userName}</p></span>
                    </li>
                `
                    var receiveTime="";


                    html+=`
                <tr>
                    <td ><div class="view1 bg1"></div></td>
                    <td class="rollcalluserNo" data-num=${data.obj[i].userid}>${data.obj[i].userid}</td>
                    <td>${data.obj[i].userName}</td>
                    <td>${reviseTime}</td>
                    <td>${data.obj[i].oldDeptName}</td>
                    <td>${data.obj[i].receiveDeptName}</td>
                    <td  data-status="${data.obj[i].reviseState}" ${data.obj[i].reviseState==3?'class="reviseState"':''} data="${data.obj[i].note}" value="${data.obj[i].reviseState}">${reviseState}</td>
                    <td>${data.obj[i].receiveTime==null?"--":data.obj[i].receiveTime }</td>
                     </tr>
				`
                }
            }else{
                html+=`
            <tr class="datalosslist">
                    <td colspan="8"><img src="img/dataloss.png" alt=""  /></td>

                    </tr>
				`
                pic+=`
            <div class="receiveP">
                <img src="img/dataloss.png" alt=""/>
                    </div>
                `
            }
            $("div.ReceiveUserOn div.mainpart1 ul").html(pic);
            $("div.ReceiveUserOn div.mainpart table tbody").html(html);
            $("div.ReceiveUserOn div.pagers span.pagerstotal").html(zongshu);
            $("div.ReceiveUserOn div.pagers span.dangqian").html(dangqian);
            $("div.ReceiveUserOn div.pagers span.yeshu").html(yeshu);

            checkAuto00();
            var html1='';
            if(dangqian==1){
                if(dangqian<=yeshu){
                    html1+=`<li class="clicked">${dangqian}</li>`;
                }
                if(dangqian+1<=yeshu){
                    html1+=`<li>${dangqian+1}</li>`;
                }
                if(dangqian+2<=yeshu){
                    html1+=`<li>${dangqian+2}</li>`;
                }
                if(dangqian+3<=yeshu){
                    html1+=`<li>${dangqian+3}</li>`;
                }
                if(dangqian+4<=yeshu){
                    html1+=`<li>${dangqian+4}</li>`;
                }
            }else if(dangqian==2){
                html1+=`<li>${dangqian-1}</li>`;
                html1+=`<li class="clicked">${dangqian}</li>`;

                if(dangqian+1<=yeshu){
                    html1+=`<li>${dangqian+1}</li>`;
                }
                if(dangqian+2<=yeshu){
                    html1+=`<li>${dangqian+2}</li>`;
                }
                if(dangqian+3<=yeshu){
                    html1+=`<li>${dangqian+3}</li>`;
                }
            }else if(dangqian==yeshu&&dangqian>=5){
                html1+=`
            <li>${dangqian-4}</li>

                <li>${dangqian-3}</li>

                <li>${dangqian-2}</li>

                <li >${dangqian-1}</li>
                <li class="clicked">${dangqian}</li>
						`
            }else if(dangqian==yeshu-1&&dangqian>=5){
                html1+=`
            <li>${dangqian-3}</li>

                <li>${dangqian-2}</li>

                <li>${dangqian-1}</li>

                <li class="clicked">${dangqian}</li>
                    <li>${dangqian+1}</li>
						`
            }else{
                if(dangqian-2>0){
                    html1+=`<li>${dangqian-2}</li>`;
                }
                if(dangqian-1>0){
                    html1+=`<li>${dangqian-1}</li>`;
                }
                html1+=`<li class="clicked">${dangqian}</li>`;
                if(dangqian<yeshu){
                    html1+=`<li>${dangqian+1}</li>`;
                }
                if(dangqian+1<yeshu){
                    html1+=`<li>${dangqian+2}</li>`;
                }
            }
            $(".ReceiveUserOn .pagers ul").html(html1);
        }
    })
}
showReceiveUser(1,$(".ReceiveUserOn div.pagers select").val());

$(".ReceiveUserOn .pagers ul").on("click","li",function(e){
    showReceiveUser(e.target.innerHTML,$(".ReceiveUserOn div.pagers select").val());

})
$(".ReceiveUserOn div.pagers a.tofirst").click(function(e){
    var page=$(".ReceiveUserOn div.pagers span.dangqian").html();
    e.preventDefault();
    if(page !=1){
        showReceiveUser(1,$(".ReceiveUserOn div.pagers select").val());
    }

})
$(".ReceiveUserOn div.pagers a.toleast").click(function(e){
    e.preventDefault();
    var page=$("div.ReceiveUserOn div.pagers span.dangqian").html();
    var lastPage=$("div.ReceiveUserOn div.pagers span.yeshu").html();
    if(page !=lastPage ){
        showReceiveUser(loginMax2,$(".ReceiveUserOn div.pagers select").val());
    }

})
$("div.ReceiveUserOn div.pagers a.go").click(function(e){
    e.preventDefault();

    var lastPage=$("div.ReceiveUserOn div.pagers span.yeshu").html();
    var tar=$(".ReceiveUserOn div.pagers input").val();
    var page=$(".ReceiveUserOn div.pagers span.dangqian").html();
var zong=$(".ReceiveUserOn div.pagers span.yeshu").html();
    console.log(lastPage)

    if(page != tar) {

        if (tar > zong) {
            showReceiveUser(lastPage, $(".ReceiveUserOn div.pagers select").val());
                $("div.pagers  input").val(lastPage);

            return;
        }
        if (tar == '') {
            return;
        }
    }
})
$("div.ReceiveUserOn span.search").click(function(){
    showReceiveUser(1,$(".ReceiveUserOn div.pagers select").val());
})
$("div.ReceiveUserOn div.pagers select").change(function(){
    showReceiveUser(1,$("div.ReceiveUserOn  div.pagers select option:selected").val())
    $("div.ReceiveUserOn div.pagers input").val("");
})












$(".ReceiveUserOn .view1").addClass('bg1'); // 初始化时添加背景1
//thead点击全选时，tbody全部选中
$(".ReceiveUserOn .mainpart").on("click", "thead .view1", function() {
    //debugger;
    if($(".ReceiveUserOn .mainpart thead .view1").attr("class") == "view1 bg1") {
        $(".ReceiveUserOn .mainpart .view1").attr("class", "view1 bg2");
    }
    else {
        $(".ReceiveUserOn thead .view1").attr("class", "view1 bg1");
        $(".ReceiveUserOn tbody .view1").attr("class", "view1 bg1");
    }
    //tbody点击时，单个选，当tbody全都点中时，触发thead
});
$(".ReceiveUserOn .mainpart").on("click", "tbody .view1", function() {
    $(this).toggleClass('bg1').toggleClass('bg2'); //点中的被选中
});





//判断全选
function checkAuto001(){
    if($("tbody .view1").size()==0){
        $("thead .view1").attr("class","view1 bg1");
        return;
    }
    if($("tbody .view1").size()==$("tbody .bg2").size()){
        $("thead .view1").attr("class","view1 bg2");
        return;
    }
    $("thead .view1").attr("class","view1 bg1");
}
$(".receiverPeople").hide();
$(".Reject").hide();

//接收人员图表切换
$(".ReceiveUserOn .changebar-tabOn").click(function(){
    $(".receiverPeople").show();
    $(".Reject").show();
    $(".receiverPeople1").hide();
    $(".Reject1").hide();
    $(".receiver").show();
    $(".receiver1").hide();
    if($(".changebar-tab").attr("class")=="changebar-tab tab-active"){
        return;
    }else{
        $(".changebar-tab").addClass("tab-active");
        $(".changebar-tab img").attr("src","img/tab1.png");
        $(".changebar-pic img").attr("src","img/pic1.png");
        $(".changebar-pic").attr("class","changebar-pic");
        var html='  <option value="5">5</option> <option value="10" selected="selected">10</option>';
        $(".pagers .sel select").html(html)
        $("#J_select").show();
        $(".mainpart1").hide();
        showReceiveUser(1,$(".ReceiveUserOn div.pagers select").val());
    }

})

$(".ReceiveUserOn .changebar-picOn").click(function(){
    $(".receiverPeople1").show();
    $(".Reject1").show();
    $(".receiverPeople").hide();
    $(".Reject").hide();
    $(".receiver1").show();
    $(".receiver").hide();
    if($(".changebar-pic").attr("class")=="changebar-tab tab-active"){
        return;
    }else{
        $(".changebar-pic").addClass("tab-active");
        $(".changebar-pic img").attr("src","img/pic2.png");
        $(".changebar-tab img").attr("src","img/tab2.png");
        $(".changebar-tab").attr("class","changebar-tab");
        var html=' <option value="10">10</option> <option value="20">20</option> <option value="30" selected="selected">30</option>';
        $(".pagers .sel select").html(html)
        $("#J_select").hide();
        $(".mainpart1").show();
        showReceiveUser(1,$(".ReceiveUserOn div.pagers select").val());

    }
})


//人员管理图表切换
$(".personnel  .changebar-tabOn1").click(function(){
    if($(".changebar-tab").attr("class")=="changebar-tab tab-active"){
        return;
    }else{
        $(".changebar-tab").addClass("tab-active");
        $(".changebar-tab img").attr("src","img/tab1.png");
        $(".changebar-pic img").attr("src","img/pic1.png");
        $(".changebar-pic").attr("class","changebar-pic");
        $(".people-list").show();
        $(".people-pic").hide();

        var html='  <option value="5">5</option> <option value="10" selected="selected">10</option>';
        $("#sel-P").html(html)
        var rollcalluserId = $(".contentChild .rollcalluserId01").val();
        var roleid = $(".role option:selected").val();
        var rollcalluserName = $(".contentChild .rollcalluserName01").val();
        var rollcalluserCreatetime = $(".contentChild .rollcalluserCreatetime01").val();
        var rollcalluserDeletetime = $(".contentChild .rollcalluserDeletetime01").val();
        var deptid = $(".whichTeam option:selected").val();
        var selectPic = $(".personnel .selectPic option:selected").val();
        $(".theadview .view1").attr("class", "view1 bg1");

        loading(1, $("div.footDiv div.jogger select").val(), rollcalluserId, rollcalluserName, selectPic, rollcalluserCreatetime, rollcalluserDeletetime);

    }

})
$(".personnel  .changebar-picOn2").click(function(){
    if($(".changebar-pic").attr("class")=="changebar-tab tab-active"){
        return;
    }else{
        $(".changebar-pic").addClass("tab-active");
        $(".changebar-pic img").attr("src","img/pic2.png");
        $(".changebar-tab img").attr("src","img/tab2.png");
        $(".changebar-tab").attr("class","changebar-tab");
        $(".people-list").hide();
        $(".people-pic").show();
        var rollcalluserId = $(".contentChild .rollcalluserId01").val();
        var roleid = $(".role option:selected").val();
        var rollcalluserName = $(".contentChild .rollcalluserName01").val();
        var rollcalluserCreatetime = $(".contentChild .rollcalluserCreatetime01").val();
        var rollcalluserDeletetime = $(".contentChild .rollcalluserDeletetime01").val();
        var deptid = $(".whichTeam option:selected").val();
        var selectPic = $(".personnel .selectPic option:selected").val();
        $(".theadview .view1").attr("class", "view1 bg1");

        var html=' <option value="10">10</option> <option value="20">20</option> <option value="30" selected="selected">30</option>';
        $("#sel-P").html(html)
        loading(1, $("div.footDiv div.jogger select").val(), rollcalluserId, rollcalluserName, selectPic, rollcalluserCreatetime, rollcalluserDeletetime);

    }
})

function checkAuto00(){
    if($("tbody .view1").size()==0){
        $("thead .view1").attr("class","view1 bg1");
        return;
    }
    if($("tbody .view1").size()==$("tbody .bg2").size()){
        $("thead .view1").attr("class","view1 bg2");
        return;
    }
    $("thead .view1").attr("class","view1 bg1");
}
//人员管理照片列表点击事件
$(".people-pic ").on("click","ul li",function(){
    $(this).find(" .pic-click").toggleClass('bg-click').toggleClass('bg-clicked'); //点中的被选中
    //var index=$(this).index()
    //if($(".people-pic .view1 ").eq(index).attr("class")=="view1 bg1"){
    //    $(".people-pic .view1").eq(index).attr("class","view1 bg2")
    //    $(".tbodyview .view1").eq(index).attr("class","view1 bg2")
    //    if($("tbody .view1").size()==$("tbody .bg2").size()){
    //        $("thead .view1").attr("class","view1 bg2");
    //
    //    }else{
    //        $("thead .view1").attr("class","view1 bg1");
    //    }
    //
    //}else{
    //    $(".people-pic .view1").eq(index).attr("class","view1 bg1")
    //    $(".tbodyview .view1").eq(index).attr("class","view1 bg1")
    //    if($("tbody .view1").size()==$("tbody .bg2").size()){
    //        $("thead .view1").attr("class","view1 bg2");
    //
    //    }else{
    //        $("thead .view1").attr("class","view1 bg1");
    //    }
    //}

})

//服务器注册

$(".buttonTrue").on("click",function(){
	var serverName = $("#serverName").val()
	var serverIP = $("#serverAddress").val()
//	var serverType =""
	var serverStatus =""
	var isSpare =""
	if($("#data").is(":checked") == true){
		serverType = 0
	}else{
		serverType = 1
	}
	if($("#available").is(":checked") == true){
		serverStatus = 0
	}else{
		serverStatus = 1
	}
	if($("#yes").is(":checked") == true){
		isSpare = 1
	}else{
		isSpare = 0
	}
	var recognitionAccuracy = $(".recognitionAccuracy option:selected").val()
	if($("#serverName").val() ==""){
		parent.$(".smallkuang-header span").html("服务器注册");
		parent.$(".condition .sp18").html("服务器名称不能为空！")
		parent.$(".condition .smallkuang7").fadeIn();
		parent.$(".baohu").fadeIn();
		return;
	}
	var Ipreg = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/
	if(!Ipreg.test(serverIP)){
		parent.$(".smallkuang1 .smallkuang-header span").html("服务器注册");
        parent.$(".smallkuang1").show();
        parent.$(".baohu2").show();
        parent.$(".smallkuang1 .sp4").html("请输入正确服务器地址");
        parent.$(".smallkuang1 .sel").click(function(){
            parent.$(".smallkuang1").fadeOut();
            parent.$(".baohu2").fadeOut();
        })
        return;
	}
 	$.ajax({
        dataType:'JSON',
        type:'get',
        url: http + "serverController/saveServer",
        data:{
        	serverName:serverName,
        	currentId:sessionStorage.sId,
        	serverIP:serverIP,
        	serverType:serverType,
        	isSpare:isSpare,
        	serverStatus:serverStatus,
        	identifyPrecision:recognitionAccuracy
        },
        success:function(data){
        	console.log(data)
        	if(data.code == 400){
        		$(".sMgAlert").fadeOut();
        		$("iframe.crumbsCon")[0].contentWindow.loadSmg();
        	}else if(data.code == -2){
        		parent.$(".smallkuang-header span").html("服务器添加");
				parent.$(".condition .sp18").html("同类型IP已存在！")
				parent.$(".condition .smallkuang7").fadeIn();
				parent.$(".baohu").fadeIn();
				return;
        	}else{
        		parent.$(".smallkuang-header span").html("服务器注册");
				parent.$(".condition .sp18").html("注册失败！")
				parent.$(".condition .smallkuang7").fadeIn();
				parent.$(".baohu").fadeIn();
				return;
        	}
        }
    })

})
$(".buttonFalse").on("click",function(){
	$(".sMgAlert").fadeOut();
})
$(".img1").on("click",function(){
	$(".sMgAlert").fadeOut();
})
//服务器修改
$(".buttonFalse1").on("click",function(){
	parent.$(".sMgAlert1").fadeOut();
})
$(".img2").on("click",function(){
	parent.$(".sMgAlert1").fadeOut();
})
//服务器修改信息显示
function shows(){
	var serverIP = sessionStorage.getItem("serverIP");
	var serverName = sessionStorage.getItem("serverName");
	var serverType = sessionStorage.getItem("serverType");
	var serverStatus = sessionStorage.getItem("serverStatus");
	var isSpare = sessionStorage.getItem("isSpare");
	//console.log(serverType)
	$("#serverName1").val(serverName)
	$("#serverIP1").val(serverIP)

	if(serverType == "数据服务器"){
		$("#data1").attr("checked",true)
	}else{
		$("#Contrast1").attr("checked",true)
	}
	if(serverStatus == "启用"){
		$("#available1").attr("checked",true)
	}else{
		$("#Unavailable1").attr("checked",true)
	}
	if(isSpare == "是"){
		$("#yes1").attr("checked",true)
	}else{
		$("#no1").attr("checked",true)
	}
}
$(".buttonTrue1").on("click",function(){
	var yeshu = sessionStorage.getItem("yeshu");
	var pageNumber = sessionStorage.getItem("pageNumber");
	var serverid = sessionStorage.getItem("serverid");
//	console.log(serverid)
	var serverName = $("#serverName1").val()
	var serverIP = $("#serverIP1").val()
//	var serverType =""
	var serverStatus =""
	var isSpare =""
	var Ipreg = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/
	if(!Ipreg.test(serverIP)){
		parent.$(".smallkuang1 .smallkuang-header span").html("服务器更新");
        parent.$(".smallkuang1").show();
        parent.$(".baohu2").show();
        parent.$(".smallkuang1 .sp4").html("请输入正确服务器地址");
        parent.$(".smallkuang1 .sel").click(function(){
            parent.$(".smallkuang1").fadeOut();
            parent.$(".baohu2").fadeOut();
        })
        return;
	}
	if($("#available1").is(":checked") == true){
		serverStatus = 0
	}else{
		serverStatus = 1
	}
	if($("#yes1").is(":checked") == true){
		isSpare = 1
	}else{
		isSpare = 0
	}
 	$.ajax({
        dataType:'JSON',
        type:'get',
        url: http + "serverController/saveServer",
//		url:"http://192.168.1.143:8080/ctr/serverController/saveServer",
        data:{
        	serverid:serverid,
        	serverName:serverName,
        	serverIP:serverIP,
        	serverType:0,
        	isSpare:isSpare,
        	serverStatus:serverStatus,
        	currentId:sessionStorage.sId,
        },
        success:function(data){
//      	console.log(data)
        	if(data.code == 500){
        		$(".sMgAlert1").fadeOut();
        		$("iframe.crumbsCon")[0].contentWindow.loadSmg(yeshu,pageNumber);
        	}else if(data.code == -2){
        		parent.$(".smallkuang-header span").html("服务器修改");
				parent.$(".condition .sp18").html("同类型IP已存在！")
				parent.$(".condition .smallkuang7").fadeIn();
				parent.$(".baohu").fadeIn();
				return;
        	}else if(data.code == -1){
        		parent.$(".smallkuang-header span").html("服务器修改");
				parent.$(".condition .sp18").html("设备已绑定不能修改！")
				parent.$(".condition .smallkuang7").fadeIn();
				parent.$(".baohu").fadeIn();
				return;
        	}else{
        		parent.$(".smallkuang-header span").html("服务器修改");
				parent.$(".condition .sp18").html("修改失败！")
				parent.$(".condition .smallkuang7").fadeIn();
				parent.$(".baohu").fadeIn();
				return;
        	}


        }
    })
})


//终端管理注册
AddView= {
    init: function () {
        //加载数据
        //this.terminalRegister();
        this. terminalRegisterClose();
        //this. terminalRegisterareaList();
        this. showterminalRegisterareaALL();

    },
    //所有下拉框获取
    showterminalRegisterareaALL:function(){
        this.terminalRegisterareaList(http+"device/areaList","#areaid");
        this.terminalRegisterareaapplicationModelName(http+"device/applicationModelList","#applicationModelName");
        this.terminalRegisterwebserverIP("#webserverIP",0);
        this.terminalRegisterwebserverIP("#standbyServerIP",0);
        this.terminalRegisterwebserverIP("#serverid",1);
    },
    //点击添加终端
//    terminalRegister:function(){
//        $(".register").on("click",function(){
//            parent.$(".terminalRegister .head span").html("添加终端");
//            parent.$(".baohu3").fadeIn();
//            parent.$(".terminalRegister").fadeIn();
//            parent.$(".terminalRegister input").val("");
//            parent.document.getElementById("deviceType").value = "-1";
//            parent.document.getElementById("pattern").value = "";
//            parent.document.getElementById("serverid").value = "";
//            parent.document.getElementById("standbyServerIP").value = "";
//            parent.document.getElementById("webserverIP").value = "";
//            parent.document.getElementById("areaid").value = "";
//            parent.document.getElementById("applicationModelName").value = "";
//            parent.document.getElementById("functionDescription").value = "";
//            //确定添加
//            parent.$(".terminalRegiste-foot-S").on("click",function(){
//                var id=parent.$("#deviceid").val();
//                var deviceid= parent.$("#deviceid").val();//设备编号
//                var deviceName=parent.$("#deviceName").val();//设备名称
//                var  deviceType=parent.$("#deviceType option:selected").val();//设备类型
//                var pattern=parent.$("#pattern option:selected").val();//模式 1：N 和1:1模式
//                var deviceIP=parent.$("#deviceIP").val();//设备IP
//                var devicePort=parent.$("#devicePort").val();//端口号var
//                var subnetmask=parent.$("#subnetmask").val();//子网掩码
//                var gateway=parent.$("#gateway").val();//网关
//                var password=parent.$("#password").val();//连接密码
//                var  serverid=parent.$("#serverid option:selected").val();//比对服务器编号
//                var standbyServerIP=parent.$("#standbyServerIP option:selected").html();//备用服务器IP
//                var webserverIP=parent.$("#webserverIP option:selected").html();//应用服务器IP
//                var  areaid=parent.$("#areaid option:selected").val();//区域编号
//                var applicationModel=parent.$("#applicationModelName option:selected").val();//应用模式名称
//                var functionDescription=parent.$("#functionDescription").val();//功能描述
//                var reg = /^[0-9]+.?[0-9]*$/;
//                if (!reg.test(deviceid)) {
//                    parent.$(".smallkuang1 .smallkuang-header span").html("添加终端");
//                    parent.$(".smallkuang1").show();
//                    parent.$(".baohu2").show();
//                    parent.$(".smallkuang1 .sp4").html("编号只能为数字");
//                    parent.$(".smallkuang1 .sel").click(function(){
//                        parent.$(".smallkuang1").fadeOut();
//                        parent.$(".baohu2").fadeOut();
//                    })
//                    return;
//                }
//                var operationPersonnel=sessionStorage.sName;
//                var deptid=sessionStorage.sUserDept;
//if(deviceid==""||deviceName==""||deviceType==""||pattern==""||deviceIP==""
//    ||devicePort==""||subnetmask==""||gateway==""||password==""||serverid==""
//    ||standbyServerIP==""||webserverIP==""||areaid==""||applicationModel==""||functionDescription==""){
//    parent.$(".smallkuang1 .smallkuang-header span").html("添加终端");
//    parent.$(".smallkuang1").show();
//    parent.$(".baohu2").show();
//    parent.$(".smallkuang1 .sp4").html("请填写完整信息！");
//    parent.$(".smallkuang1 .sel").click(function() {
//        parent.$(".smallkuang1").fadeOut();
//        parent.$(".baohu2").fadeOut();
//    })
//}else{
//        $.ajax({
//            dataType: 'JSON',
//            type: 'POST',
//            url: http+"device/insertDevice",
//            data:{
//                id:id,
//                deptid:deptid,
//                operationPersonnel:operationPersonnel,
//                deviceid: deviceid,
//                deviceName:deviceName,
//                deviceType:deviceType,
//                pattern:pattern,
//                deviceIP:deviceIP,
//                devicePort:devicePort,
//                subnetmask:subnetmask,
//                gateway:gateway,
//                password:password,
//                serverid:serverid,
//                standbyServerIP:standbyServerIP,
//                webserverIP:webserverIP,
//                areaid:areaid,
//                applicationModel:applicationModel
//
//            },
//            success: function (data) {
//                parent.$(".smallkuang1 .smallkuang-header span").html("添加终端");
//                parent.$(".smallkuang1").show();
//                parent.$(".baohu2").show();
//                if(data.code<0){
//                    parent.$(".smallkuang1 .sp4").html(data.message);
//                    parent.$(".smallkuang1 .sel").click(function(){
//                        parent.$(".smallkuang1").fadeOut();
//                        parent.$(".baohu2").fadeOut();
//                    })
//                }else{
//
//                    parent.$(".smallkuang1 .sp4").html(data.message);
//                    parent.$(".smallkuang1 .sel").click(function(){
//                        parent.$(".smallkuang1").fadeOut();
//                        parent.$(".baohu2").fadeOut();
//                        parent.$(".baohu3").fadeOut();
//                        parent.$(".terminalRegister").fadeOut();
//                        loadTmt(1,10);
//                    })
//
//                }
//            }
//        })
//    }
//
//            })
//        })
//    },
    //点击X号，和取消
    terminalRegisterClose:function(){
        $(".terminalRegiste-foot-C,.terminalRegister .head a").unbind("click").on("click",function(){
            $(".baohu3").fadeOut();
           	$(".terminalRegister").fadeOut();
           	$(".terminalFL input").attr("disabled",false);
		   	$(".terminalFL select").attr("disabled",false);
			$(".terminalRegister-message textarea").attr("disabled",false);
			$(".terminalRegiste-foot-S").fadeIn()
			$(".terminalRegiste-foot-C").fadeIn()
        })
    },
    //获取区域的下拉框封装
    terminalRegisterareaList:function(a,b){
        $.ajax({
            dataType:'JSON',
            type:'POST',
            url: a,
            success:function(data){
                var len=data.length;
                var html="<option value=''>"+"请选择区域"+"</option>";
                for(var i=0;i<len;i++){
                    html+="<option value='"+data[i].areaid+"'>"+data[i].areaName+"</option>"
                }
                $(b).html(html);
            }
        })
    },
    //获取类型的下拉框封装
    terminalRegisterareaapplicationModelName:function(a,b){
        $.ajax({
            dataType:'JSON',
            type:'POST',
            url: a,
            success:function(data){
                var len=data.length;
                var html="<option value=''>"+"请选择应用模式"+"</option>";
                for(var i=0;i<len;i++){
                    html+="<option value='"+data[i].applicationModel+"'>"+data[i].applicationModelName+"</option>"
                }
                $(b).html(html);
            }
        })
    },
    //获取应用和备用服务器的下拉框封装
    terminalRegisterwebserverIP:function(b,c){
        $.ajax({
            dataType:'JSON',
            type:'POST',
            url: http+"serverController/queryServerList",
            data:{terminalRegisterwebserverIP:0,
                serverType:c},
            success:function(data){
                var len=data.obj.length;
                var html="<option value=''>"+"请选择服务器"+"</option>";
                for(var i=0;i<len;i++){
                    html+="<option value='"+data.obj[i].serverid+"'>"+data.obj[i].serverIP+"</option>"
                }
                $(b).html(html);
            }
        })
    }



}
AddView.init();

//恢复人员
$(".recoveryPearson").on("click",function(){
    parent.$(".recoveryAlert .teamControl-message").html("");
    //取消
    parent.$(".recoveryAlert .teamControlReturn").on("click",function(){
        parent.$(".recoveryAlert").fadeOut();
        parent.$(".baohu").fadeOut();
    })
    parent.$(".recoveryAlert .teamControl-message").html("");
    parent.$(".recoveryAlert .smallkuang-header span").html("恢复人员");
    parent.$(".recoveryAlert .teamControl-Team p").html("选择所属大队");
    if ($(" .tbodyview .bg2").size() === 0&&$(".bg-clicked").size() == 0) {
        parent.$(".smallkuang1 .sp4").html("请选择需要恢复的学员！")
        parent.$(".smallkuang1 .smallkuang-header span").html("恢复人员");
        parent.$(".smallkuang1").fadeIn();
        parent.$(".baohu").fadeIn();
       parent.$(".sp5").click(function(){
           parent.$(".smallkuang1").fadeOut();
            parent.$(".baohu").fadeOut();
       });
    } else if($(" .tbodyview .bg2").size() > 1||$(".bg-clicked").size()>1) {
        parent.$(".smallkuang1 .sp4").html("只能选择单个学员！")
        parent.$(".smallkuang1").fadeIn();
        parent.$(".baohu").fadeIn();
        parent.$(".sp5").click(function(){
            parent.$(".smallkuang1").fadeOut();
            parent.$(".baohu").fadeOut();
        });
    }else{
        var smallkuang11Name = $(".tbodyview .bg2").eq(0).parent().parent().parent().find(".stuName").html()||$(".bg-clicked").eq(0).parent().parent().find(".mainpart1Name p").html();
        var smallkuang11Id = $(".tbodyview .bg2").eq(0).parent().parent().parent().find(".stuId ").attr("data-user")||$(".bg-clicked").eq(0).parent().parent().find(".mainpart1Id").attr("data-wid");
        var smallkuang11code = $(".tbodyview .bg2").eq(0).parent().parent().parent().find(".stuId ").html()||$(".bg-clicked").eq(0).parent().parent().find(".mainpart1Id p").html();


        parent.$(".recoveryAlert .stnum").val(smallkuang11code);
        parent.$("[name='sIdHidden']").val(smallkuang11Id);
        parent.$(".recoveryAlert .teamControlstnam").val(smallkuang11Name);
        parent.$(".recoveryAlert").fadeIn();
        parent.$(".baohu").fadeIn();
        var deptid=parent.$(".recoveryAlert .teamControlxiugai option:selected").val();

        $.ajax({
            dataType: 'JSON',
            type: 'POST',
            url: http + "systemUser/queryDept.do",
            //data:{code:9},
            success: function (data) {
                //console.log(data);
                var len = data.obj.length;
                parent.$(".teamControlxiugai").empty();
                parent.$(".teamControlxiugai").append(' <option value="-1">请选择</option>')
                for (var i = 0; i < len; i++) {
                    parent.$(".teamControlxiugai").append(' <option value="' + data.obj[i].deptid + '">' + data.obj[i].deptName + '</option>')
                }
            }
        })
        //确定按钮
        parent.$(".recoveryAlert .teamControlSure").on("click",function(){
            var deptid=parent.$(".recoveryAlert .teamControlxiugai option:selected").val();
            if(deptid==null||deptid==-1){
                parent.$(".recoveryAlert .teamControl-message").html("请选择大队!");
                return;
            }else{
                $.ajax({
                    dataType: 'JSON',
                    type: 'POST',
                    url: http + "userDelete/recoverUserInfo.do",
                    data:{id:smallkuang11Id,deptid:deptid,userid:sessionStorage.sId},
                    success: function (data) {
                        //console.log(data);
                        if(data.code<0){
                            parent.$(".recoveryAlert .teamControl-message").html("恢复人员失败!");
                            return;
                        }else{
                            parent.$(".recoveryAlert .teamControl-message").html("");
                            parent.$(".recoveryAlert").fadeOut();
                            parent.$(".baohu").fadeOut();
                            var rollcalluserId =$(".contentChild .rollcalluserId01").val();
                            var roleid=$(".role option:selected").val();
                            var rollcalluserName =$(".contentChild .rollcalluserName01").val();
                            var rollcalluserCreatetime =$(".contentChild .rollcalluserCreatetime01").val();
                            var rollcalluserDeletetime =$(".contentChild .rollcalluserDeletetime01").val();
                            var deptid=$(".whichTeam option:selected").val();
                            var selectPic = $(".personnel .selectPic option:selected").val();
                            $(".theadview .view1").attr("class", "view1 bg1");
                            loading(1,$("div.footDiv div.jogger select").val(),rollcalluserId,rollcalluserName,selectPic,rollcalluserCreatetime,rollcalluserDeletetime);

                        }


                    }
                })
            }

        })
    }

    })


$(".register").on("click",function(){
    parent.$(".terminalRegister .head span").html("添加终端");
    parent.$(".baohu3").fadeIn();
    parent.$(".terminalRegister").fadeIn();
    parent.$(".terminalRegister input").val("");
    parent.document.getElementById("deviceType").value = "-1";
    parent.document.getElementById("pattern").value = "";
    //parent.document.getElementById("serverid").value = "";
    parent.document.getElementById("standbyServerIP").value = "";
    parent.document.getElementById("webserverIP").value = "";
    parent.document.getElementById("areaid").value = "";
    parent.document.getElementById("applicationModelName").value = "";
    parent.document.getElementById("functionDescription").value = "";
    //确定添加
    parent.$(".terminalRegiste-foot-S").unbind("click").on("click",function(){
        //var id=parent.$("#deviceid").val();
        var deviceid= parent.$("#deviceid").val();//设备编号
        var deviceName=parent.$("#deviceName").val();//设备名称
        var  deviceType=parent.$("#deviceType option:selected").val();//设备类型
        var pattern=parent.$("#pattern option:selected").val();//模式 1：N 和1:1模式
        var deviceIP=parent.$("#deviceIP").val();//设备IP
        var devicePort=parent.$("#devicePort").val();//端口号var
        var subnetmask=parent.$("#subnetmask").val();//子网掩码
        var gateway=parent.$("#gateway").val();//网关
        var password=parent.$("#password").val();//连接密码
        var  serverid=parent.$("#serverid option:selected").val();//比对服务器编号
        var standbyServerIP=parent.$("#standbyServerIP option:selected").html();//备用服务器IP
        var webserverIP=parent.$("#webserverIP option:selected").html();//应用服务器IP
        var  areaid=parent.$("#areaid option:selected").val();//区域编号
        var applicationModel=parent.$("#applicationModelName option:selected").val();//应用模式名称
        var functionDescription=parent.$("#functionDescription").val();//功能描述
        var reg = /^[0-9]+.?[0-9]*$/;
        if (!reg.test(deviceid)) {
            parent.$(".smallkuang1 .smallkuang-header span").html("添加终端");
            parent.$(".smallkuang1").show();
            parent.$(".baohu2").show();
            parent.$(".smallkuang1 .sp4").html("编号只能为数字");
            parent.$(".smallkuang1 .sel").click(function(){

                parent.$(".smallkuang1").fadeOut();
                parent.$(".baohu2").fadeOut();
            })
            return;
        }
        var operationPersonnel=sessionStorage.sName;
        var deptid=sessionStorage.sUserDept;
        //debugger;
        if(deviceid==""||deviceName==""||deviceType==""||pattern==""||deviceIP==""
            ||devicePort==""||subnetmask==""||gateway==""||password==""
            ||standbyServerIP==""||webserverIP==""||areaid==""||applicationModel==""){
            parent.$(".smallkuang1 .smallkuang-header span").html("添加终端");
            parent.$(".smallkuang1").show();
            parent.$(".baohu2").show();
            parent.$(".smallkuang1 .sp4").html("请填写完整信息！");
            parent.$(".smallkuang1 .sel").unbind("click").click(function() {
                parent.$(".smallkuang1").fadeOut();
                parent.$(".baohu2").fadeOut();
            })
        }else{
            $.ajax({
                dataType: 'JSON',
                type: 'POST',
                url: http+"device/insertDevice",
                data:{
                    //id:id,
                    deptid:deptid,
                    operationPersonnel:operationPersonnel,
                    deviceid: deviceid,
                    deviceName:deviceName,
                    deviceType:deviceType,
                    pattern:pattern,
                    deviceIP:deviceIP,
                    devicePort:devicePort,
                    subnetmask:subnetmask,
                    gateway:gateway,
                    password:password,
                    serverid:serverid,
                    standbyServerIP:standbyServerIP,
                    webserverIP:webserverIP,
                    areaid:areaid,
                    applicationModel:applicationModel,
                    functionDescription:functionDescription

                },
                success: function (data) {
                    console.log(data)
                    parent.$(".smallkuang1 .smallkuang-header span").html("添加终端");
                    parent.$(".smallkuang1").show();
                    parent.$(".baohu2").show();
                    if(data.code<0){
                        parent.$(".smallkuang1 .sp4").html(data.message);
                        parent.$(".smallkuang1 .sel").unbind("click").click(function(){
                            parent.$(".smallkuang1").fadeOut();
                            parent.$(".baohu2").fadeOut();
                            return;
                        })
                    }else{
                        parent.$(".smallkuang1 .sp4").html(data.message);
                        parent.$(".smallkuang1 .sel").unbind("click").click(function(){
                            parent.$(".smallkuang1").fadeOut();
                            parent.$(".baohu2").fadeOut();
                            parent.$(".baohu3").fadeOut();
                            parent.$(".terminalRegister").fadeOut();
                            loadTmt(1,10);
                            return;
                        })

                    }
                }
            })
        }

    })
})

//无人点名父页面操作、终止点名
$(".rollcallMessage-foot-stop").on("click",function(){
    parent.$(".baohu").fadeOut();
    parent.$(".rollcallMessage").fadeOut();
    var rollcall=window.open("Rollcall.html","JavaScript");
    rollcall.close();
    var newWin=window.showModelDialog("Rollcall.html",window,'');
    newWin.close();
    //StopRollcall();
})
//无人点名父页面操作、完成点名
$(".rollcallMessage-foot-stop").on("click",function(){
    parent.$(".baohu").fadeOut();
    parent.$(".rollcallMessage").fadeOut();
    //StopRollcall();
})





$.fn.pageNumAuto = function(dataAll) {
	var e = this;
	var htmlPags = '' +
		'<div class="pubJogger">' +
		'<span class="pubSel">当前页' +
		'<select name="" id="">' +
		'   <option value="5">5</option>' +
		'  <option value="10" selected="selected">10</option>' +
		'</select>' +
		'条数据' +
		'</span>' +
		'<span class="pubLook">' +
		'共' +
		'<span class="pubAllRows">213213</span>' +
		'条&nbsp;当前为第' +
		'<span class="pubNowpage">123123</span>' +
		'页&nbsp;共' +
		'<span class="pubAllpage">123</span>' +
		'页' +
		'</span>' +
		'<b class="pubFirstpageWrap"><button class="pubFirstpage">首页</button></b>' +
		'<span class="pubYema">' +
		'<button  class="ycolor">1</button><button >2</button>' +
		'</span>' +
		'<b class="pubLastpageWrap"><button class="pubLastpage">末页</button></b>' +
		'<input type="text" onkeyup="this.value=this.value.replace(/[^\\d]/g,\'\') " />' +
		'<b class="pubSeachWrap"><button class="pubSeach">GO</button></b>' +
		'</div>';
	$(e).html(htmlPags)
	$(".pubJogger input").val("");
	var dataPage = dataAll.dataPage; //dataPage 当前页码
	var dataCount = dataAll.dataCount; //dataCount 一共多少条数据
	var pageNum = dataAll.pageNum; //pageNum 一页多少数据
	var fun = dataAll.fun; //fun 方法名

	$(".pubSel select").val(pageNum);
	//当前页码
	var currentPage = parseInt(dataPage) / 1;

	//一共多少条数据
	var allPageData = dataCount / 1;

	//一页多少数据
	var rows = pageNum / 1;

	PagesNum = Math.ceil(allPageData / rows);

	if(PagesNum == 0) { PagesNum = 1; }
	var htmlPage = '';
	if(currentPage == 1) {
		if(currentPage <= PagesNum) { htmlPage += '<button class="ycolor">' + (currentPage) + '</button>' };
		if(currentPage + 1 <= PagesNum) { htmlPage += '<button>' + (currentPage + 1) + '</button>' };
		if(currentPage + 2 <= PagesNum) { htmlPage += '<button>' + (currentPage + 2) + '</button>' };
		if(currentPage + 3 <= PagesNum) { htmlPage += '<button>' + (currentPage + 3) + '</button>' };
		if(currentPage + 4 <= PagesNum) { htmlPage += '<button>' + (currentPage + 4) + '</button>' };

	} else if(currentPage == 2) {
		htmlPage += '<button>' + (currentPage - 1) + '</button>';
		htmlPage += '<button class="ycolor">' + (currentPage) + '</button>'
		if(currentPage + 1 <= PagesNum) { htmlPage += '<button>' + (currentPage + 1) + '</button>' };
		if(currentPage + 2 <= PagesNum) { htmlPage += '<button>' + (currentPage + 2) + '</button>' };
		if(currentPage + 3 <= PagesNum) { htmlPage += '<button>' + (currentPage + 3) + '</button>' };

	} else if(currentPage == PagesNum - 1 && currentPage >= 4) {
		htmlPage +=
			'<button>' + (currentPage - 3) + '</button>' +
			'<button>' + (currentPage - 2) + '</button>' +
			'<button >' + (currentPage - 1) + '</button>' +
			'<button class="ycolor">' + (currentPage) + '</button>' +
			'<button>' + (currentPage + 1) + '</button>';

	} else if(currentPage == PagesNum && currentPage >= 5) {
		htmlPage += '<button>' + (currentPage - 4) + '</button>' +
			'<button>' + (currentPage - 3) + '</button>' +
			'<button>' + (currentPage - 2) + '</button>' +
			'<button >' + (currentPage - 1) + '</button>' +
			'<button class="ycolor">' + (currentPage) + '</button>';

	} else if(currentPage == PagesNum && currentPage >= 4) {
		htmlPage += '<button>' + (currentPage - 3) + '</button>' +
			'<button>' + (currentPage - 2) + '</button>' +
			'<button >' + (currentPage - 1) + '</button>' +
			'<button class="ycolor">' + (currentPage) + '</button>';

	} else {
		if(currentPage - 2 > 0) { htmlPage += '<button>' + (currentPage - 2) + '</button>' };
		if(currentPage - 1 > 0) { htmlPage += '<button >' + (currentPage - 1) + '</button>' };
		htmlPage += '<button class="ycolor">' + (currentPage) + '</button>';
		if(currentPage < PagesNum) { htmlPage += '<button>' + (currentPage + 1) + '</button>' };
		if(currentPage + 1 < PagesNum) { htmlPage += '<button>' + (currentPage + 2) + '</button>' };
	};

	$(".pubYema").html(htmlPage);
	$(".pubAllRows").html(allPageData);
	$(".pubNowpage").html(currentPage);
	$(".pubAllpage").html(PagesNum);
	//切换数据多少条
	$(".pubSel select").unbind("change").on("change", function() {
		var num = $(".pubSel select option:selected").val();
		var aNum = $(".condition .yema1 .ycolor").html();
		fun(aNum, num);
	});
	//点击页数跳转	
	$(".pubYema button").each(function(i) {
		$(e).eq(i).unbind("click").on("click", ".pubYema button", function() {
			$(this).removeClass("ycolor");
			$(this).addClass("ycolor")
			var liNum = $(this).html();
			console.log(liNum)
			fun(liNum);
		});
	});
	//点击首页跳转
	$(".pubFirstpageWrap").unbind("click").on("click", ".pubFirstpage", function() {
		fun(1);
	});
	//点击末页跳转
	$(".pubLastpageWrap").unbind("click").on("click", ".pubLastpage", function() {
		fun(PagesNum);
	});
	//点击go跳转
	$(".pubSeachWrap").unbind("click").on("click", ".pubSeach", function() {
		var Num = 0;
		if($(".pubJogger input").val() > PagesNum) {
			$(".pubJogger input").val(PagesNum);
		}
		Num = $(".pubJogger input").val();
		if($(".pubJogger input").val() == 0) { num = 1; }
		fun(Num);
	});
};




var scrollFunc=function(e){
	 e=e || window.event;
	 if(e.wheelDelta && event.ctrlKey){//IE/Opera/Chrome
	  event.returnValue=false;
	 }else if(e.detail){//Firefox
	  event.returnValue=false;
	 }
 }
 /*注册事件*/
 if(document.addEventListener){
 document.addEventListener('DOMMouseScroll',scrollFunc,false);
 }//W3C
 window.onmousewheel=document.onmousewheel=scrollFunc;//IE/Opera/Chrome/Safari


