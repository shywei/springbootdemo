var mesID;
AddView = {
    init: function () {
        //加载数据
        this.registerPearson();
        this.collectPeople();
        this.showSelect1();
        this.showSelect2();
        this.doFile_input();
        this.showSelect3();
        this.showSelectAll();
        this.onChangeteamControlFinger();
    },
    //各种下拉框获取
    showSelectAll: function () {
//加载列表页面大队下拉框
//        this.showSelect1(httpmacong+"systemUser/queryDept.do",".whichTeam");
//加载列表页面角色下拉框
        this.showSelect2(http + "userInfoSaveController/getRole", ".role");
//加载注册页面大队下拉框
        this.showSelect1(http + "systemUser/queryDept.do", "#deptid");
//加载注册页面角色下拉框
        this.showSelect2(http + "userInfoSaveController/getRole", "#roleid");
    },
    //学员注册按钮、取消、确定
    registerPearson: function () {
        $("[name='registerPearson']").on("click", function () {
            $(".finger-enter-M").show();
            $("#file_input1").show();
            $(".hand-enter-message-S").hide();
            $(".hand-enter-message-F").hide();
            $(".finger-enter-message-S").hide();
            $(".finger-enter-message-F").hide();
            $("#userid ").attr("disabled", false);

            $(".up-btn").show();
            $(".collect-btn").show();
            $(".finger-enter button").show();
            $("#verify").show();
            $(".credentials-num button").show();
            $(".credentials-num .red").show();
            $("#photo img").remove();
            $(".personnel-registerPearson input").val("");
            $(".finger-enter button").css({'opacity': 0.4})
            document.getElementById("gender").value = "-1";
            document.getElementById("roleid").value = "-1";
            document.getElementById("deptid").value = "-1";
            document.getElementById("isBalckList").value = "-1";
            document.getElementById("isMarried").value = "-1";
            document.getElementById("hasChild").value = "-1";
            $(".personnel").hide();
            $(".personnel-registerPearson").show();
            //学员注册取消
            $(".personnel-foot-C").on("click", function () {
                $(".personnel").show();
                $(".personnel-registerPearson").hide();

            })

            //学员信息注册确定
            $(".personnel-foot-S").unbind("click").on("click", function () {

                var hasMetacarpalVein;

                if ($("#veinData").val() == "" || $("#veinData").val() == null) {
                    hasMetacarpalVein = 0;
                } else {
                    hasMetacarpalVein = 1;
                }
                var createid = sessionStorage.sUid;
                var photoUrl = $("#photo img").attr("data");					//照片地址
                var userid = $("#userid").val();							//编号
                var gender = $("#gender option:selected").val();								//性别
                var userName = $("#userName").val();			//姓名
                var roleid = $("#roleid").val();									//角色
                var deptid = $("#deptid option:selected").val();									//部门
                var isBalckList = $("#isBalckList").val();							//是否黑名单
                var createtime = $("#createtime").val();//入队时间
                var deptName=$("#deptid option:selected").html();
                var deletetime = $("#deletetime").val();							//离队时间
                //var hasMetacarpalVein=$("#userid").val();			//是否录入掌静脉
                var veinData = $("#veinData").val();					//掌静脉信息
                //var hasDigitalVein=$("#userid").val();					//是否录入指静脉
                //var digitalVein=$("#userid").val();						//指静脉信息
                var dormitoryNum = $("#dormitoryNum").val();			//宿舍
                var bedNum = $("#bedNum").val();							//床号
                var placeOrigin = $("#placeOrigin").val();							//籍贯
                var nationalities = $("#nationalities").val();									//民族
                var isMarried = $("#isMarried option:selected").val();									//婚否
                var hasChild = $("#hasChild option:selected").val();									//生育状况
                var birthday = $("#birthday").val();						//出生日期
                var politicalStatus = $("#politicalStatus").val();				  				//政治面貌
                var cardType = $("#cardType option:selected").val();			  							//证件类型
                var cardNum = $("#cardNum").val();					//证件号码
                var beginEffectiveDate = $("#beginEffectiveDate").val();		//证件有效期(起)
                var endEffectiveDate = $("#endEffectiveDate").val();		//证件有效期(止)
                var contact = $("#contact").val();									//联系人
                var contactNum = $("#contactNum").val();				//联系人号码
                var residenceAdress = $("#residenceAdress").val();	//户口所在地址
                var address = $("#address").val();   //现居住地
                //填写信息不完整
                var reg = /^[0-9]+.?[0-9]*$/;
                if (!reg.test(userid)) {
                    parent.$(".smallkuang1 .smallkuang-header span").html("人员注册");
                    parent.$(".smallkuang1 .sp4").html("编号只能为数字！");
                    parent.$(".smallkuang1").show();
                    parent.$(".baohu").show();
                    parent.$(".smallkuang1 .sel").unbind("click").click(function () {
                        parent.$(".smallkuang1").fadeOut();
                        parent.$(".baohu").fadeOut();
                    })
                    return;
                }
                if ($("#photo img").size() == 0 || userName == "" || roleid == "-1" || deptid == "-1" || gender == "-1" || userid == "") {
                    parent.$(".smallkuang1 .smallkuang-header span").html("人员注册");
                    parent.$(".smallkuang1 .sp4").html("请填写完整信息！");
                    parent.$(".smallkuang1").show();
                    parent.$(".baohu").show();
                    parent.$(".smallkuang1 .sel").unbind("click").click(function () {
                        parent.$(".smallkuang1").fadeOut();
                        parent.$(".baohu").fadeOut();
                    })
                    return;
                }
                if ($("#createtime").val() != "" && $("#deletetime").val() != "") {
                    if ($("#deletetime").val() < $("#createtime").val()) {
                        parent.$(".smallkuang1 .smallkuang-header span").html("人员注册");
                        parent.$(".smallkuang1 .sp4").html("入队时间不可小于离队时间！");
                        parent.$(".smallkuang1").show();
                        parent.$(".baohu").show();
                        parent.$(".smallkuang1 .sel").unbind("click").click(function () {
                            parent.$(".smallkuang1").fadeOut();
                            parent.$(".baohu").fadeOut();
                        })
                        return;
                    }
                }
                if ($("#beginEffectiveDate").val() != "" && $("#endEffectiveDate").val() != "") {
                    if ($("#endEffectiveDate").val() < $("#beginEffectiveDate").val()) {
                        parent.$(".smallkuang1 .smallkuang-header span").html("人员注册");
                        parent.$(".smallkuang1 .sp4").html("证件起始时间不可大于结束时间！");
                        parent.$(".smallkuang1").show();
                        parent.$(".baohu").show();
                        parent.$(".smallkuang1 .sel").unbind("click").click(function () {
                            parent.$(".smallkuang1").fadeOut();
                            parent.$(".baohu").fadeOut();
                        })
                        return;
                    }
                }
                var deptid1 = sessionStorage.sUserDept;
                var userName1 = sessionStorage.sName;
                $.ajax({
                    url: http + 'userInfoSaveController/saveUserInfo',
                    dataType: "json",
                    type: 'POST',
                    data: {
                        //createid:createid,
                        photoUrl: photoUrl,
                        userid: userid,
                        gender: gender,
                        userName: userName,
                        roleid: roleid,
                        deptid: deptid,
                        isBalckList: isBalckList,
                        createtime: createtime,
                        deletetime: deletetime,
                        hasMetacarpalVein: hasMetacarpalVein,
                        veinData: veinData,
                        //hasDigitalVein:hasDigitalVein,
                        //digitalVein:digitalVein,
                        dormitoryNum: dormitoryNum,
                        bedNum: bedNum,
                        placeOrigin: placeOrigin,
                        nationalities: nationalities,
                        isMarried: isMarried,
                        hasChild: hasChild,
                        birthday: birthday,
                        politicalStatus: politicalStatus,
                        cardType: cardType,
                        cardNum: cardNum,
                        beginEffectiveDate: beginEffectiveDate,
                        endEffectiveDate: endEffectiveDate,
                        contact: contact,
                        contactNum: contactNum,
                        residenceAdress: residenceAdress,
                        address: address,
                        deptid1: deptid1,
                        userName1: userName1
                    },
                    success: function (data) {
                        console.log(data)
                        console.log(deletetime)
                        var rollcalluserId = $(".contentChild .rollcalluserId01").val();
                        var roleid = $(".role option:selected").val();
                        var rollcalluserName = $(".contentChild .rollcalluserName01").val();
                        var rollcalluserCreatetime = $(".contentChild .rollcalluserCreatetime01").val();
                        var rollcalluserDeletetime = $(".contentChild .rollcalluserDeletetime01").val();
                        var deptid = $(".whichTeam option:selected").val();
                        var selectPic = $(".personnel .selectPic option:selected").val();
                        $(".theadview .view1").attr("class", "view1 bg1");


                        //无指静脉的版本
                        //·······························································
                        parent.$(".smallkuang1 .smallkuang-header span").html("人员注册");
                        parent.$(".smallkuang1 .sp4").html(data.message);
                        parent.$(".smallkuang1").show();
                        parent.$(".baohu").show();
                        if (data.code < 0) {
                            parent.$(".smallkuang1 .sel").unbind("click").click(function () {
                                parent.$(".smallkuang1").fadeOut();
                                parent.$(".baohu").fadeOut();
                            })
                        } else {
                            parent.$(".smallkuang1 .sel").unbind("click").click(function () {
                                parent.$(".smallkuang1").fadeOut();
                                parent.$(".baohu").fadeOut();
                                $(".personnel").show();
                                $(".personnel-registerPearson").hide();

                            })
                        }
                        //·······························································
                        //有指静脉的版本
                        //if (data.code < 0) {
                        //    parent.$(".smallkuang1 .smallkuang-header span").html("人员注册");
                        //    parent.$(".smallkuang1 .sp4").html(data.message);
                        //    parent.$(".smallkuang1").show();
                        //    parent.$(".baohu").show();
                        //    parent.$(".smallkuang1 .sel").click(function () {
                        //        parent.$(".smallkuang1").fadeOut();
                        //        parent.$(".baohu").fadeOut();
                        //    })
                        //} else {
                        //    parent.$(".fingerCC").fadeIn();
                        //    parent.$(".baohu").show();
                        //    //取消按钮
                        //    parent.$(".fingerCC-F").unbind("click").on("click",function(){
                        //        parent.$(".fingerCC").fadeOut();
                        //        parent.$(".baohu").fadeOut();
                        //        parent.$(".baohu").fadeOut();
                        //        $(".personnel").show();
                        //        $(".personnel-registerPearson").hide();
                        //
                        //        loading(1, $("div.footDiv div.jogger select").val(), rollcalluserId, rollcalluserName, selectPic, rollcalluserCreatetime, rollcalluserDeletetime);
                        //    })
                        //    //采集按钮
                        //    parent.$(".fingerCC-S").unbind("click").on("click",function(){
                        //        parent.$(".fingerCC").fadeOut();
                        //        AddView.dofingerCollect(data.obj, userName, deptName);
                        //        //保存
                        //        parent.$("[class='smallkuang10-foot-sure']").unbind("click").click(function () {
                        //            //ajax
                        //            var isSave = 1;
                        //            if ($(this).css("opacity") / 1 === 0.4) {
                        //                return;
                        //            }
                        //            var fingerDeviceid;
                        //            var digitalVein;
                        //            $.ajax({
                        //                type: 'GET',
                        //                dataType: 'JSON',
                        //                url: http + "collectFingerController/isSave",
                        //                data: {isSave: 1, userId: data.obj, mesID: mesID},
                        //                success: function (data) {
                        //                    parent.$(".baohu").fadeOut();
                        //                    $(".personnel").show();
                        //                    $(".personnel-registerPearson").hide();
                        //                    parent.$(".smallkuang10").fadeOut();
                        //                    loading(1, $("div.footDiv div.jogger select").val(), rollcalluserId, rollcalluserName, selectPic, rollcalluserCreatetime, rollcalluserDeletetime);
                        //                    clearInterval(timeShowFinger);
                        //                    //$.ajax({
                        //                    //    type: 'GET',
                        //                    //    dataType: 'JSON',
                        //                    //    url: http + "userInfoSaveController/registerFingerVein",
                        //                    //    data: {fingerDeviceid: fingerDeviceid, userid	: a, digitalVein: digitalVein},
                        //                    //    success: function (data) {
                        //                    //        console.log(fingerDeviceid)
                        //                    //        console.log(digitalVein)
                        //                    //        console.log(a)
                        //                    //
                        //                    //
                        //                    //    }
                        //                    //})
                        //                }
                        //            })
                        //
                        //
                        //        })
                        //        //取消
                        //        parent.$(".smallkuang10-foot-close").unbind("click").on("click",function () {
                        //            $.ajax({
                        //                type: 'GET',
                        //                dataType: 'JSON',
                        //                url: http + "collectFingerController/isSave",
                        //                data: {isSave: 0, userId: data.obj, mesID: mesID},
                        //                success: function (data) {
                        //                    console.log(data);
                        //                    console.log(mesID);
                        //                    parent.$(".baohu").fadeOut();
                        //                    $(".personnel").show();
                        //                    $(".personnel-registerPearson").hide();
                        //                    parent.$(".smallkuang10").fadeOut();
                        //                    loading(1, $("div.footDiv div.jogger select").val(), rollcalluserId, rollcalluserName, selectPic, rollcalluserCreatetime, rollcalluserDeletetime);
                        //
                        //                }
                        //            });
                        //            clearInterval(timeShowFinger);
                        //
                        //        })
                        //        $(".personnel").show();
                        //        $(".personnel-registerPearson").hide();
                        //    })
                        //    //点击差号
                        //    parent.$(".fingerCC .head a").unbind("click").on("click",function(){
                        //        parent.$(".fingerCC").fadeOut();
                        //        parent.$(".baohu").fadeOut();
                        //        loading(1, $("div.footDiv div.jogger select").val(), rollcalluserId, rollcalluserName, selectPic, rollcalluserCreatetime, rollcalluserDeletetime);
                        //    })
                        //}
                    }
                });


            })

        })
    },
    //人像采集
    collectPeople: function () {
        $(".collect-btn").on("click", function () {
            sessionStorage.setItem("sUid", sessionStorage.sUid);
            parent.delFinger8();
        });
    },
    //大队下拉框获取函数
    showSelect1: function (a, b) {
        $.ajax({
            dataType: 'JSON',
            type: 'POST',
            url: a,
            success: function (data) {
                var len = data.obj.length;
                var html = "<option value='-1'>" + "请选择大队" + "</option>";
                for (var i = 0; i < len; i++) {
                    html += "<option value='" + data.obj[i].deptid + "'>" + data.obj[i].deptName + "</option>"
                }
                $(b).html(html);
            }
        })
    },
    //角色下拉框获取函数
    showSelect2: function (a, b) {
        $.ajax({
            dataType: 'JSON',
            type: 'POST',
            url: a,
            success: function (data) {
                var len = data.obj.results.length;
                var html = "<option value='-1'>" + "请选择" + "</option>";
                for (var i = 0; i < len; i++) {
                    html += "<option value='" + data.obj.results[i].roleid + "'>" + data.obj.results[i].roleName + "</option>"
                }
                $(b).html(html);
            }
        })
    },
    //人员列表详情
    showDetail: function (e) {
        //所有按钮不可见
        $("#file_input1").hide();
        $(".finger-enter-M").hide();
        $(".finger-enter-message-S").hide();
        $(".finger-enter-message-F").hide();
        $(".finger-enter button").hide();
        $(".hand-enter-message-S").hide();
        $(".hand-enter-message-F").hide();
        $(".up-btn").hide();
        $(".collect-btn").hide();
        $("#verify").hide();
        $(".credentials-num button").hide();
        $(".credentials-num .red").hide();
        var id = e;
        $(".personnel").hide();
        $(".personnel-registerPearson").show();
        //学员详情取消
        $(".personnel-foot-C").on("click", function () {
            $(".personnel").show();
            $(".personnel-registerPearson").hide();
            $(".hand-enter-message-S").hide();
            $(".hand-enter-message-F").hide();
            $(".personnel-registerPearson input").attr("disabled", false);
            $(".personnel-registerPearson select").attr("disabled", false);
        })
        $(".personnel-foot-S").unbind("click").on("click", function () {
            $(".personnel").show();
            $(".personnel-registerPearson").hide();
            $(".hand-enter-message-S").hide();
            $(".hand-enter-message-F").hide();
            $(".personnel-registerPearson input").attr("disabled", false);
            $(".personnel-registerPearson select").attr("disabled", false);
        })
        $.ajax({
            dataType: 'JSON',
            type: 'POST',
            data: {id: id},
            url: http + 'userInfoListController/queryUserInfoList',
            success: function (data) {
                console.log(data)
                console.log(typeof (data.obj[0].createtime))
                //点击添加和修改加载数据
                function showPerson() {
                    //加载图片
                    var url = data.message + data.obj[0].photoUrl;
                    var html = ' <img src="' + url + '" data="' + data.obj + '"/>'
                    $("#photo img").remove();
                    $("#photo").html(html);
                    console.log(data.obj[0].hasMetacarpalVein)
                    if (data.obj[0].hasMetacarpalVein == 0) {
                        $(".hand-enter-message-F").show();
                    } else if (data.obj[0].hasMetacarpalVein == 1) {
                        $(".hand-enter-message-S").show();
                    }
                    if (data.obj[0].hasDigitalVein == 0 || data.obj[0].hasDigitalVein == null) {
                        $(".finger-enter-message-F").show();
                    } else if (data.obj[0].hasDigitalVein == 1) {
                        $(".finger-enter-message-S").show();
                    }

                    document.getElementById("gender").value = data.obj[0].gender || "-1";
                    document.getElementById("roleid").value = data.obj[0].roleid || "-1";
                    document.getElementById("deptid").value = data.obj[0].deptid || "-1";
                    document.getElementById("isBalckList").value = data.obj[0].isBalckList || "-1";
                    document.getElementById("isMarried").value = data.obj[0].isMarried || "-1";
                    document.getElementById("hasChild").value = data.obj[0].hasChild || "-1";
                    document.getElementById("cardType").value = data.obj[0].cardType || "-1";
                    var createtime;
                    var deletetime;
                    if(data.obj[0].createtime==null){
                        createtime="";
                    }else{
                        createtime=data.obj[0].createtime.substring(0,10);
                    }
                    if(data.obj[0].deletetime==null){
                        deletetime="";
                    }else{
                        deletetime=data.obj[0].deletetime.substring(0,10);
                    }



                    $("#userid").val(data.obj[0].userid);							//编号
                    $("#userName").val(data.obj[0].userName);			//姓名
                    //$("#roleid").val(data.obj[0].roleid);									//角色
                    $("#createtime").val(createtime);			//入队时间
                    $("#deletetime").val(deletetime);							//离队时间
                    //var hasMetacarpalVein=$("#userid").val();//是否录入掌静脉
                    //$("#gender").val(data.obj[0].gender);
                    $("#veinData").val(data.obj[0].metacarpalVein);					//掌静脉信息
                    //var hasDigitalVein=$("#userid").val();					//是否录入指静脉
                    //var digitalVein=$("#userid").val();						//指静脉信息
                    $("#dormitoryNum").val(data.obj[0].dormitoryNum);			//宿舍
                    $("#bedNum").val(data.obj[0].bedNum);							//床号
                    $("#placeOrigin").val(data.obj[0].placeOrigin);							//籍贯
                    $("#nationalities").val(data.obj[0].nationalities);									//民族
                    $("#birthday").val(data.obj[0].birthday);						//出生日期
                    $("#politicalStatus").val(data.obj[0].politicalStatus);				  				//政治面貌
                    $("#cardNum").val(data.obj[0].cardNum);					//证件号码
                    $("#beginEffectiveDate").val(data.obj[0].beginEffectiveDate);		//证件有效期(起)
                    $("#endEffectiveDate").val(data.obj[0].endEffectiveDate);		//证件有效期(止)
                    $("#contact").val(data.obj[0].contact);									//联系人
                    $("#contactNum").val(data.obj[0].contactNum);				//联系人号码
                    $("#residenceAdress").val(data.obj[0].residenceAdress);	//户口所在地址
                    $("#address").val(data.obj[0].address);   //现居住地
                }

                //禁用所有下拉框和input
                $(".personnel-registerPearson input").attr("disabled", "disabled");
                $(".personnel-registerPearson select").attr("disabled", "disabled");
                showPerson();


            }
        })
        //确定按钮

    },
    //人员列表修改
    alertDetail: function (e) {
        var id = e;
        var userid;
        var userName;
        var deptName;
        $(".finger-enter-message-S").hide();
        $(".finger-enter-message-F").hide();
        $(".finger-enter button").css({'opacity': 1})
        $(".personnel").hide();
        $(".finger-enter button").show();
        $(".finger-enter-M").hide();
        $(".personnel-registerPearson").show();
        $("#file_input1").show();
        $(".hand-enter-message-S").hide();
        $(".hand-enter-message-F").hide();
        $(".up-btn").show();
        $(".collect-btn").show();
        $("#verify").show();
        $(".credentials-num button").show();
        $(".credentials-num .red").show();

var id1=0;
        $.ajax({
            dataType: 'JSON',
            type: 'POST',
            data: {id: id},
            url: http + 'userInfoListController/queryUserInfoList',
            success: function (data) {
                //console.log(data)
                //console.log(data.obj[0].gender)
                //console.log(data.obj[0].roleid)
                //console.log(data.obj[0].deptid)
                //console.log(data.obj[0].isBalckList)
                //console.log(data.obj[0].isMarried)
                //console.log(data.obj[0].hasChild)
                id1=data.obj[0].id;
                function showPerson() {
                    //加载图片
                    var url = data.message + data.obj[0].photoUrl;
                    var html = ' <img src="' + url + '" data="' + data.obj[0].photoUrl + '"/>'
                    $("#photo img").remove();
                    $("#photo").html(html);
                    userid = data.obj[0].userid;
                    userName = data.obj[0].userName;
                    deptName = data.obj[0].deptName;
                    //点击录入指静脉
                    $(".finger-enter button").unbind("click").on("click", function () {
                        if ($(this).css("opacity") / 1 === 0.4) {
                            return;
                        }

                        AddView.dofingerCollect(id1, userName, deptName);
                        //保存
                        parent.$("[class='smallkuang10-foot-sure']").unbind("click").click(function () {
                            //ajax
                            var isSave = 1;
                            if ($(this).css("opacity") / 1 === 0.4) {
                                return;
                            }
                            var fingerDeviceid;
                            var digitalVein;
                            $.ajax({
                                type: 'GET',
                                dataType: 'JSON',
                                url: http + "collectFingerController/isSave",
                                data: {isSave: 1, userId: id1, mesID: mesID},
                                success: function (data) {
                                    console.log(data)
                                    parent.$(".baohu").fadeOut();
                                    $(".finger-enter-message-S").show();
                                    $(".finger-enter-message-F").hide();
                                    parent.$(".smallkuang10").fadeOut();
                                    loading(1, $("div.footDiv div.jogger select").val());
                                    clearInterval(timeShowFinger);
                                    //$.ajax({
                                    //    type: 'GET',
                                    //    dataType: 'JSON',
                                    //    url: http + "userInfoSaveController/registerFingerVein",
                                    //    data: {fingerDeviceid: fingerDeviceid, userid	: a, digitalVein: digitalVein},
                                    //    success: function (data) {
                                    //        console.log(fingerDeviceid)
                                    //        console.log(digitalVein)
                                    //        console.log(a)
                                    //
                                    //
                                    //    }
                                    //})
                                }
                            })


                        })
                        //取消
                        parent.$(".smallkuang10-foot-close").unbind("click").on("click",function () {
                            console.log(156)
                            $.ajax({
                                type: 'GET',
                                dataType: 'JSON',
                                url: http + "collectFingerController/isSave",
                                data: {isSave: 0, userId: id1, mesID: mesID},
                                success: function (data) {
                                    console.log(data);
                                    console.log(mesID);
                                    parent.$(".baohu").fadeOut();

                                    parent.$(".smallkuang10").fadeOut();
                                    loading(1, $("div.footDiv div.jogger select").val());

                                }
                            });
                            clearInterval(timeShowFinger);

                        })
                        if (data.obj[0].hasDigitalVein == 0 || data.obj[0].hasDigitalVein == null) {
                            $(".finger-enter-message-F").show();
                            $(".finger-enter-message-S").hide();
                        } else if (data.obj[0].hasDigitalVein == 1) {
                            $(".finger-enter-message-S").show();
                            $(".finger-enter-message-F").hide();
                        }
                    })
                    document.getElementById("gender").value = data.obj[0].gender || "-1";
                    document.getElementById("roleid").value = data.obj[0].roleid || "-1";
                    document.getElementById("deptid").value = data.obj[0].deptid || "-1";
                    document.getElementById("isBalckList").value = data.obj[0].isBalckList || "-1";
                    document.getElementById("isMarried").value = data.obj[0].isMarried || "-1";
                    document.getElementById("hasChild").value = data.obj[0].hasChild || "-1";
                    document.getElementById("cardType").value = data.obj[0].cardType || "-1";

                    if(data.obj[0].createtime==null){
                        createtime="";
                    }else{
                        createtime=data.obj[0].createtime.substring(0,10);
                    }
                    if(data.obj[0].deletetime==null){
                        deletetime="";
                    }else{
                        deletetime=data.obj[0].deletetime.substring(0,10);
                    }
                    $("#userid").val(data.obj[0].userid);							//编号
                    $("#userName").val(data.obj[0].userName);			//姓名
                    $("#roleid").val(data.obj[0].roleid);									//角色
                    $("#createtime").val(createtime);			//入队时间
                    $("#deletetime").val(deletetime);							//离队时间
                    var hasMetacarpalVein = data.obj[0].hasMetacarpalVein;			//是否录入掌静脉
                    $("#veinData").val(data.obj[0].metacarpalVein);					//掌静脉信息
                    if (data.obj[0].hasMetacarpalVein == 0) {
                        $(".hand-enter-message-F").show();
                    } else if (data.obj[0].hasMetacarpalVein == 1) {
                        $(".hand-enter-message-S").show();
                    }
                    if (data.obj[0].hasDigitalVein == 0 || data.obj[0].hasDigitalVein == null) {
                        $(".finger-enter-message-F").show();
                    } else if (data.obj[0].hasDigitalVein == 1) {
                        $(".finger-enter-message-S").show();
                    }
                    //var digitalVein=$("#userid").val();						//指静脉信息
                    $("#dormitoryNum").val(data.obj[0].dormitoryNum);			//宿舍
                    $("#bedNum").val(data.obj[0].bedNum);							//床号
                    $("#placeOrigin").val(data.obj[0].placeOrigin);							//籍贯
                    $("#nationalities").val(data.obj[0].nationalities);									//民族
                    $("#birthday").val(data.obj[0].birthday);						//出生日期
                    $("#politicalStatus").val(data.obj[0].politicalStatus);				  				//政治面貌
                    $("#cardNum").val(data.obj[0].cardNum);					//证件号码
                    $("#beginEffectiveDate").val(data.obj[0].beginEffectiveDate);		//证件有效期(起)
                    $("#endEffectiveDate").val(data.obj[0].endEffectiveDate);		//证件有效期(止)
                    $("#contact").val(data.obj[0].contact);									//联系人
                    $("#contactNum").val(data.obj[0].contactNum);				//联系人号码
                    $("#residenceAdress").val(data.obj[0].residenceAdress);	//户口所在地址
                    $("#address").val(data.obj[0].address);   //现居住地
                    $("#userid").attr("disabled", "disabled");
                }
                showPerson();
            }
        });
        //学员修改取消
        $(".personnel-foot-C").on("click", function () {
            $(".personnel").show();
            $(".personnel-registerPearson").hide();
            $(".hand-enter-message-S").hide();
            $(".hand-enter-message-F").hide();
        })
        //学员信息修改确定
        $(".personnel-foot-S").unbind("click").on("click", function () {
            var createid = sessionStorage.sUid;
            var photoUrl = $("#photo img").attr("data");					//照片地址
            var userid = $("#userid").val();							//编号
            var gender = $("#gender option:selected").val();								//性别
            var userName = $("#userName").val();			//姓名
            var roleid = $("#roleid").val();									//角色
            var deptid = $("#deptid option:selected").val();									//部门
            var isBalckList = $("#isBalckList").val();							//是否黑名单
            var createtime = $("#createtime").val();			//入队时间
            var deletetime = $("#deletetime").val();							//离队时间
            //var hasMetacarpalVein=$("#userid").val();			//是否录入掌静脉
            var veinData = $("#veinData").val();					//掌静脉信息
            //var hasDigitalVein=$("#userid").val();					//是否录入指静脉
            //var digitalVein=$("#userid").val();						//指静脉信息
            var dormitoryNum = $("#dormitoryNum").val();			//宿舍
            var bedNum = $("#bedNum").val();							//床号
            var placeOrigin = $("#placeOrigin").val();							//籍贯
            var nationalities = $("#nationalities").val();									//民族
            var isMarried = $("#isMarried option:selected").val();									//婚否
            var hasChild = $("#hasChild option:selected").val();									//生育状况
            var birthday = $("#birthday").val();						//出生日期
            var politicalStatus = $("#politicalStatus").val();				  				//政治面貌
            var cardType = $("#cardType option:selected").val();			  							//证件类型
            var cardNum = $("#cardNum").val();					//证件号码
            var beginEffectiveDate = $("#beginEffectiveDate").val();		//证件有效期(起)
            var endEffectiveDate = $("#endEffectiveDate").val();		//证件有效期(止)
            var contact = $("#contact").val();									//联系人
            var contactNum = $("#contactNum").val();				//联系人号码
            var residenceAdress = $("#residenceAdress").val();	//户口所在地址
            var address = $("#address").val();   //现居住地
            //填写信息不完整

            if ($("#photo img").size() == 0 || userName == "" || roleid == "" || deptid == "" || gender == "" || userid == "") {
                parent.$(".smallkuang1 .smallkuang-header span").html("人员注册");
                parent.$(".smallkuang1 .sp4").html("请填写完整信息！");
                parent.$(".smallkuang1").show();
                parent.$(".baohu").show();
                parent.$(".smallkuang1 .sel").unbind("click").click(function () {
                    parent.$(".smallkuang1").fadeOut();
                    parent.$(".baohu").fadeOut();
                })
            } else {
                $.ajax({
                    url: http + 'userInfoSaveController/saveUserInfo',
                    dataType: "json",
                    type: 'POST',
                    data: {
                        id: id1,
                        //createid:createid,
                        photoUrl: photoUrl,
                        userid: userid,
                        gender: gender,
                        userName: userName,
                        roleid: roleid,
                        deptid: deptid,
                        isBalckList: isBalckList,
                        createtime: createtime,
                        deletetime: deletetime,
                        //hasMetacarpalVein:hasMetacarpalVein,
                        veinData: veinData,
                        //hasDigitalVein:hasDigitalVein,
                        //digitalVein:digitalVein,
                        dormitoryNum: dormitoryNum,
                        bedNum: bedNum,
                        placeOrigin: placeOrigin,
                        nationalities: nationalities,
                        isMarried: isMarried,
                        hasChild: hasChild,
                        birthday: birthday,
                        politicalStatus: politicalStatus,
                        cardType: cardType,
                        cardNum: cardNum,
                        beginEffectiveDate: beginEffectiveDate,
                        endEffectiveDate: endEffectiveDate,
                        contact: contact,
                        contactNum: contactNum,
                        residenceAdress: residenceAdress,
                        address: address,
                        deptid1: sessionStorage.sUserDept,
                        userName1: sessionStorage.sName
                    },
                    success: function (data) {
//console.log(id)
//                        console.log(userid)
                        parent.$(".smallkuang1 .smallkuang-header span").html("人员注册");
                        parent.$(".smallkuang1 .sp4").html(data.message);
                        parent.$(".smallkuang1").show();
                        parent.$(".baohu").show();
                        if (data.code < 0) {
                            parent.$(".smallkuang1 .sel").unbind("click").click(function () {
                                parent.$(".smallkuang1").fadeOut();
                                parent.$(".baohu").fadeOut();
                            })
                        } else {
                            parent.$(".smallkuang1 .sel").unbind("click").click(function () {
                                parent.$(".smallkuang1").fadeOut();
                                parent.$(".baohu").fadeOut();
                                $(".personnel").show();
                                $(".personnel-registerPearson").hide();

                            })
                        }
                        var rollcalluserId = $(".contentChild .rollcalluserId01").val();
                        var roleid = $(".role option:selected").val();
                        var rollcalluserName = $(".contentChild .rollcalluserName01").val();
                        var rollcalluserCreatetime = $(".contentChild .rollcalluserCreatetime01").val();
                        var rollcalluserDeletetime = $(".contentChild .rollcalluserDeletetime01").val();
                        var deptid = $(".whichTeam option:selected").val();
                        var selectPic = $(".personnel .selectPic option:selected").val();
                        $(".theadview .view1").attr("class", "view1 bg1");
                        //loading(1,10);
                        loading(1, $("div.footDiv div.jogger select").val(), rollcalluserId, rollcalluserName, selectPic, rollcalluserCreatetime, rollcalluserDeletetime);

                    }
                });
            }

        })

    },
    //注册页面点击上传照片
    doFile_input: function () {
        $("#file_input1").on("change", function () {
            var formData = new FormData();
            formData.append("file", $("#file_input1")[0].files[0]);
            formData.append("userid", sessionStorage.sId);
            var file = this.files[0]; //获取file对象
            //判断file的类型是不是图片类型。
            if (!/image\/\w+/.test(file.type)) {
                alert("请确保文件为图像类型！");
                return false;
            }
            console.log(formData)
            $.ajax({
                url: http + "userInfoSaveController/uploadImg",
                type: "POST",
                cache: false,
                data: formData,
                dataType: "json",
                processData: false,  // 告诉jQuery不要去处理发送的数据
                contentType: false,  // 告诉jQuery不要去设置Content-Type请求头
                success: function (data) {
                    console.log(formData)
                    console.log(data)
                    var url = data.objExt+"?id="+Math.random();
                    console.log(url)
                    var html = ' <img src="' + url + '" data="' + data.obj + '"/>'

                    $("#photo img").remove();
                    $("#photo").html(html);


                }
            });
        })

    },
    //证件类型下拉框
    showSelect3: function () {
        $.ajax({
            dataType: 'JSON',
            type: 'POST',
            url: http + "userInfoSaveController/getCardType",
            success: function (data) {
                var len = data.obj.results.length;
                var html = "<option value='-1'>" + "请选择" + "</option>";
                for (var i = 0; i < len; i++) {
                    html += "<option value='" + data.obj.results[i].dataValue + "'>" + data.obj.results[i].dataKey + "</option>"
                }
                $("#cardType").html(html);
            }
        })
    },
    //指静脉录入封装函数
    dofingerCollect: function (a, b, c) {
        var i = 1;
        parent.$("[class='smallkuang10-foot-sure']").css({
            'opacity': 0.4
        })
        parent.$(".finger-machine-foot-sure").css("background-color", "lightgray")
        parent.$(".smallkuang10-body>span").html("请放上手指进行采集").removeClass("red green");
        parent.$("[name='firstF']").attr("class", "one gray");
        parent.$("[name='secdentF']").attr("class", "one gray");
        parent.$("[name='firstSpan']").attr("class", " grayspan");
        parent.$("[name='secdentSpan']").attr("class", " grayspan");
        parent.$(".baohu").fadeIn();
        parent.$(".finger-machine").fadeIn();
        //后台导出指静脉仪器编号

        $.ajax({
            url: http + "collectFingerController/queryDriviceInfo",
            dataType: 'json',
            data:{deptName:c},
            success: function (data) {
                //console.log(data)
                //console.log(c)

                var len = data.obj.length;
                var html = "";
                console.log(data)
                for (var i = 0; i < len; i++) {
                    html += "   <li> <div class='view1 bg1' data='" + data.obj[i].id + "'></div><span >" + data.obj[i].driviceName + "</span> </li>"
                }
                parent.$(".finger-machine-body ul").html(html)
            }
        })
        //确定选择仪器

        parent.$(".finger-machine-foot-sure").unbind("click").click(function () {
            if (parent.$(".finger-machine-foot-sure").css("background-color") === "rgb(211, 211, 211)") {
                return false;
            } else {

                 mesID = parent.$(".finger-machine-body .bg2").attr("data");
                parent.$(".smallkuang10").fadeIn();
                parent.$(".finger-machine").fadeOut();
                //采集取消按钮
              $(".smallkuang10-foot-close").unbind("click").on("click",function () {
                    console.log(225)
                    var isSave = 0;
                    $.ajax({
                        type: 'GET',
                        dataType: 'JSON',
                        url: http + "emptyFingerController/emptyFinger",
                        data: {isSave: isSave, userId: a, mesID: mesID},
                        success: function (data) {
                        }
                    });
                  var rollcalluserId = $(".contentChild .rollcalluserId01").val();
                  var roleid = $(".role option:selected").val();
                  var rollcalluserName = $(".contentChild .rollcalluserName01").val();
                  var rollcalluserCreatetime = $(".contentChild .rollcalluserCreatetime01").val();
                  var rollcalluserDeletetime = $(".contentChild .rollcalluserDeletetime01").val();
                  var deptid = $(".whichTeam option:selected").val();
                  var selectPic = $(".personnel .selectPic option:selected").val();
                    parent.$(".baohu").fadeOut();
                    parent.$(".smallkuang10").fadeOut();
                  loading(1, $("div.footDiv div.jogger select").val(), rollcalluserId, rollcalluserName, selectPic, rollcalluserCreatetime, rollcalluserDeletetime);

              })
//每秒请求后台，是否录入成功
//                console.log(i)
//                console.log(a)
//                console.log(b)
//                console.log(c)
//                console.log(mesID)
//                console.log(123123)
                    $.ajax({
                                type: 'GET',
                                dataType: 'JSON',
                                url: http + "collectFingerController/firstCollectFinger",
                                data: {
                                    userId: a,
                                    mesID: mesID,
                                    deptName: c,
                                    userName: b
                                    //isSave: 1
                                },
                                success: function (data) {
                                    console.log(123123)
                                    console.log(data)
                                }
                    })
                function doQingqiu() {
                    //console.log(963963)
                    $.ajax({
                            type: 'GET',
                            dataType: 'JSON',
                            url: http + "collectFingerController/nextCollectFinger",
                            success: function (data) {
                                console.log(data);
                                console.log(48548956)
                                if (data.message == -1) {
                                } else if (data == 0) {
                                    parent.$(".smallkuang10-body>span").html("采集失败，请重新采集！").addClass("red");
                                    parent.$("[name='firstF']").attr("class", "one gray");
                                    parent.$("[name='secdentF']").attr("class", "one gray");
                                    parent.$("[name='firstSpan']").attr("class", " grayspan");
                                    parent.$("[name='secdentSpan']").attr("class", " grayspan");
                                } else if (data.message == 2) {
                                    //console.log(123465)
                                    parent.$(".smallkuang10-body>span").html("采集成功！请再次放手！").attr("class", "green");
                                    parent.$("[name='firstF']").attr("class", "one blue");
                                    //$("[name='gray']").attr("class","one blue");
                                    parent.$("[name='firstSpan']").attr("class", "bluespan");
                                } else if (data.message == 1) {
                                    parent.$(".smallkuang10-body>span").html("指静脉采集成功！").attr("class", "green");
                                    parent.$("[name='firstF']").attr("class", "one blue");
                                    parent.$("[name='secdentF']").attr("class", "one blue");
                                    parent.$("[name='firstSpan']").attr("class", " bluespan");
                                    parent.$("[name='secdentSpan']").attr("class", " bluespan");
                                    parent.$(".smallkuang10-foot-sure").css({
                                        'opacity': 1
                                    });
                                    clearInterval(timeShowFinger);
                                }
                            }
                        })
                    }
                var timeShowFinger = setInterval(doQingqiu, 1500);


            }
        })
    },
    //部门调度指静脉设备下拉框onchange
    onChangeteamControlFinger:function(){
        parent.$(".teamControlxiugai").change(function(){
            $.ajax({
                url: http + "fingerDriviceController/queryDriviceListCanBeUsed",
                dataType: 'json',
                data:{
                    status:0,
                    driviceState:0,
                    deptID:$(this).val()
                },
                success: function (data) {
                    var len=data.length;
                    var html='<option value="-1">请选择大队</option>';
                    for(var i=0;i<len;i++){
                        html+='<option value="'+data[i].id+'">'+data[i].driviceName+'</option>'
                    }
                    parent.$(".teamControlFinger").html(html)
                        console.log(data)
                }
            })

        })
    }

};
AddView.init();


