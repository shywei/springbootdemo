var getAllDistrictUrl =  http + 'getAllDistrict.do';//权限侧边栏
var AllotSystemAuthorityUrl =  http + 'AllotSystemAuthority.do';//权限类别详情
var queryAuthorityBySystemuserIdUrl =  http + 'getAuthorityByCode.do';//权限类别详情
var subAuthorityUrl = http + 'updateSystemUserAuthority.do';//权限修改提交


var jstDistData={
	init:function(){
		this.upDataJstDist()
		this.loadData()
		this.addEvent()
	},
	addEvent:function(){
		//侧边栏
		var e  = this;
		var useCode;//用户的code
		var useCodeTit;
		$(".jstDist").unbind("click").on("click",".jstUlP",function(){
			$(".jstDist .disCon .right").hide();
			$(".jstDist .jstLiW").removeAttr("style");
			$(".jstDist .jstLiW").slideUp(500);
			$(".jstDist .jstLiW02").slideUp(500);
			$(".jstDist .jstLiW03").slideUp(500);
			$(".jstDist .jstLiW04").slideUp(500);
			$(this).next().stop(true).slideToggle(500);
			console.log()
//			if($(this).next().html()==''){
				console.log('``````1`````````')
				useCode = $(this).attr("data-code");
				console.log(useCode)
				useCodeTit = $(this).html();
				e.AllotSystemAuthority(useCode,useCodeTit);
				$(".jstDist .disCon .right").fadeIn();
//			}else{
//				e.hideDeit()
//			}
		});
		
		
		$(".jstDist").on("click",".jstUlP02",function(){
			$(".jstDist .disCon .right").hide();
			$(".jstDist .jstLiW02").removeAttr("style");
			$(".jstDist .jstLiW02").slideUp(500);
			$(".jstDist .jstLiW03").slideUp(500);
			$(".jstDist .jstLiW04").slideUp(500);
			$(this).next().stop(true).slideToggle(500);
//			if($(this).next().html()==''){
				console.log('``````2`````````')
				useCode = $(this).attr("data-code");
				useCodeTit = $(this).html();
				e.AllotSystemAuthority(useCode,useCodeTit);
				$(".jstDist .disCon .right").fadeIn();
//			}else{
//				e.hideDeit()
//			}
		});
		
		
		$(".jstDist").on("click",".jstUlP03",function(){
			$(".jstDist .disCon .right").hide();
			$(".jstDist .jstLiW03").removeAttr("style");
			$(".jstDist .jstLiW03").slideUp(500);
			$(".jstDist .jstLiW04").slideUp(500);
			$(this).next().stop(true).slideToggle(500);
//			if($(this).next().html()==''){
				console.log('``````3`````````')
				useCode = $(this).attr("data-code");
				useCodeTit = $(this).html();
				e.AllotSystemAuthority(useCode,useCodeTit);
				$(".jstDist .disCon .right").fadeIn();
//			}else{
//				e.hideDeit()
//			}
		});
		
		
		$(".jstDist").on("click",".jstUlP04",function(){
			$(".jstDist .disCon .right").hide();
//			if($(this).next().html()==''){
				console.log('``````4`````````')
				useCode = $(this).attr("data-code");
				useCodeTit = $(this).html();
				e.AllotSystemAuthority(useCode,useCodeTit);
				$(".jstDist .disCon .right").fadeIn();
//			}else{
//				e.hideDeit()
//			}
		});
		
		
		
		parent.$(".promptAltJst").unbind("click").on("click",".promptAltJstNO",function(){
			e.AllotSystemAuthority(useCode,useCodeTit);
			parent.$(".promptAltJst").fadeOut();
		});
		
		parent.$(".promptAltJst .con").unbind("click").on("click",".promptAltJstOK",function(){
			parent.$(".promptAltJst").fadeOut();
			e.subAuthority(useCode,useCodeTit);
		});
		
		
	},
	subAuthority:function(useCode,useCodeTit){
		var e  =this; 
		var idsW ='';
		for(var i = 0 ; i<$(".jstDist .disCon .jstRtxts .jstRtxtOn").size();i++){
			if(i==0){
				idsW += $(".jstRtxtOn").eq(i).find("img").attr("data-menuuseid");
			}else{
				idsW += ','+$(".jstRtxtOn").eq(i).find("img").attr("data-menuuseid");
			}
		}
		var data={}
		data.code= useCode
		data.ids= idsW
		pubQ.ajaxAuto(subAuthorityUrl,data,
			function(data){
				e.selectRoleId(useCode,useCodeTit);//权限人员左侧菜单
				parent.selectUserLeft();//刷新左侧栏
			
		},function(d){
			alert('网络链接失败！！请检查网络链接')
		});
	},
	upDataJstDist:function(data){
		data = data||{};
		if(!data){data.code='';};
		pubQ.ajaxAuto(getAllDistrictUrl,data,
			function(data){
			data= JSON.parse(data)
			console.log(data)
			var html = '';
			var htmlTit = '';
			htmlTit = '<div class="jstUl jstUlTit"><div class="jstUlP00">'+data.districtTitle+'</div><div class="jstLiW"></div></div>';
			
			for(var i = 0 ; i<data.deptList.length; i++){
				if(data.deptList[i].level==1){
					html+='<div class="jstUl">'
						+'	<div class="jstUlP" data-code="'+data.deptList[i].code+'" >'+data.deptList[i].department+'</div>'
						+'	<div class="jstLiW">';
							for(var j = 0 ;j < data.deptList.length; j++){
								if(data.deptList[i].code == data.deptList[j].superCode && data.deptList[j].level==2){
									html+=  '<div class="jstLi">'
												+'	<div class="jstUlP02" data-code="'+data.deptList[j].code+'">'+data.deptList[j].department+'</div>'
												+'	<div class="jstLiW02">';
												
													for(var n = 0 ;n < data.deptList.length; n++){
														if(data.deptList[j].code == data.deptList[n].superCode && data.deptList[n].level==3){	
															html+='<div class="jstLi02" >'
																	+'	<div class="jstUlP03" data-code="'+data.deptList[n].code+'">'+data.deptList[n].department+'</div>'
																	+'	<div class="jstLiW03">';
																
																
																	for(var k = 0 ;k < data.deptList.length; k++){
																		if(data.deptList[n].code == data.deptList[k].superCode && data.deptList[k].level==4){
																			html+='<div class="jstLi02">'
																					+'	<div class="jstUlP04" data-code="'+data.deptList[k].code+'">'+data.deptList[k].department+'</div>'
																					+'	<div class="jstLiW04">'
																					+'</div>'
																				+'  </div>'
																		};
																	};	
																	
																	
																html+='</div>'
																+'</div>';
														};
													};	
												html+='</div>'
											+'</div>';
								};
							};
						html+='</div>'
						+'</div>';
				}
			}
			$(".jstDist .disCon .left").html(htmlTit+html);

			
		});
	},
	hideDeit:function(num){
		$(".jstDist .disCon .right").html("")
		$(".jstDist .disCon .right").hide();
	},
	AllotSystemAuthority:function(useCode,regionName){
		var e = this;
		regionName = regionName||'请先选择地区';
		regionName+='权限分配信息'
		pubQ.ajaxAuto(AllotSystemAuthorityUrl,{},
			function(data){
			data= JSON.parse(data)
			var html = '';
			for(var i =0 ; i<data.length;i++){

				html += `
			<div class="jstRtits">
					<div class="jstRtit">${data[i].menuName}</div>
					<div class="jstRtxts">`;
				for(var j=0 ; j<data[i].userAuthorityList.length;j++){
					html +=`<div class="jstRtxt">
						<img class="" data-menuUseId="${data[i].userAuthorityList[j].authorityId}" src="../../img/checkbox.png"/><span>${data[i].userAuthorityList[j].authorityName}</span></div>`;
				}
				html +=	`<div class="claer"></div>
					</div>
					</div>`;
			}
			$(".jstDist .disCon .right").html('<div class="jstTopTit">'+regionName+'</div>'+html + '<div class="jstRtxtBtn"><botton class="jstRtxtBtn00 jstRtxtBtnOK">确定</botton></div>');

			
			e.selectRoleId(useCode);


			//人员管理 check切换
			$(".jstDist .disCon .jstRtxts .jstRtxt img").each(function(i){
				$(".jstRtxt img").eq(i).unbind("click").on("click",function(){
					console.log($(this).attr("src"));
						
					if($(this).attr("src")=="../../img/checkbox.png"){
						$(this).parent().addClass("jstRtxtOn")
						$(this).attr("src","../../img/checkbox2.png");
					}else{
						$(this).parent().removeClass("jstRtxtOn")
						$(this).attr("src","../../img/checkbox.png");
					};
				});
			});
			
		},function(d){
			alert('网络链接失败！！请检查网络链接')
		})
	},
	selectRoleId:function(code){
		var data={};
		data.code=code;
		pubQ.ajaxAuto(queryAuthorityBySystemuserIdUrl,data,
			function(data){
				var data = JSON.parse(data);
				console.log(data);
	//			$(".jstDist .disCon .right .jstRtxt").find("img").attr("src","img/checkbox.png");
				var html = '';
				for(var i = 0 ; i< data.length ; i++){
					for(var j = 0 ;j <$(".jstDist .disCon .jstRtxts .jstRtxt").size() ; j++){
						if($(".jstDist .disCon .jstRtxts .jstRtxt img").eq(j).attr("data-menuuseid")==data[i].authorityId){
							$(".jstDist .disCon .jstRtxts .jstRtxt").eq(j).addClass("jstRtxtOn");
							$(".jstDist .disCon .jstRtxts .jstRtxt img").eq(j).attr("src","../../img/checkbox2.png");
						};
					}
	
				};
			},function(d){
			alert('网络链接失败！！请检查网络链接')
		})
	},
	loadData:function(){
		
	},
	initDist:function(){
		
	}
};
jstDistData.init();

