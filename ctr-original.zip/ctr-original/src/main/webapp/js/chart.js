function showChart2(){
    Highcharts.setOptions({
        lang: {
            printChart: "打印图表",
            downloadJPEG: "下载JPEG 图片",
            downloadPDF: "下载PDF文档",
            downloadPNG: "下载PNG 图片",
            downloadSVG: "下载SVG 矢量图",
            exportButtonTitle: "导出图片"
        }
    });
    $('#container2').highcharts({
        chart: {
            animation: {
                duration: 5000,
                easing: 'easeOutBounce'
            },
            type: 'column'
        },
        title: {
            text: '月平均降雨量'
        },
        subtitle: {
            text: '数据'
        },
        loading: {

            showDuration: 1000,                       //设置淡入效果持续时间

            hideDuration: 1000                           //设置淡出效果持续时间

        },

        credits: {
            enabled:false//不显示highCharts版权信息
        },
        xAxis: {
            categories: [
                '一月',
                '二月',
                '三月',
                '四月',
                '五月',
                '六月',
                '七月',
                '八月',
                '九月',
                '十月',
                '十一月',
                '十二月'
            ],
            crosshair: true
        },
        yAxis: {
            min: 0,
            title: {
                text: '降雨量 (mm)'
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        exporting: {
            //enabled:true,默认为可用，当设置为false时，图表的打印及导出功能失效
            buttons: {    //配置按钮选项
                printButton: {    //配置打印按钮
                    width: 50,
                    symbolSize: 20,
                    borderWidth: 2,
                    borderRadius: 5,
                    hoverBorderColor: 'red',
                    height: 50, symbolX: 25,
                    symbolY: 15,
                    x: -200,
                    y: 20
                },
                exportButton: {    //配置导出按钮
                    width: 80,
                    symbolSize: 20,
                    borderWidth: 2,
                    borderRadius: 0,
                    hoverBorderColor: 'red',
                    height: 80,
                    symbolX: 25,
                    symbolY: 15,
                    x: -150,
                    y: 20
                }
            },
            filename: '52wulian.org',//导出的文件名
            type: 'image/png',//导出的文件类型
            width: 800    //导出的文件宽度
        },
        series: [{
            name: '东京',
            data: [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4]
        } ]
    });

};
$(function(){
    //$('.container').highcharts({
    //    chart: {
    //        animation: {
    //            duration: 5000,
    //            easing: 'easeOutBounce'
    //        },
    //        type: 'column'
    //    },
    //    title: {
    //        text: '月平均降雨量'
    //    },
    //    subtitle: {
    //        text: '数据'
    //    },
    //    loading: {
    //
    //        showDuration: 1000,                       //设置淡入效果持续时间
    //
    //        hideDuration: 1000                           //设置淡出效果持续时间
    //
    //    },
    //
    //    credits: {
    //        enabled:false//不显示highCharts版权信息
    //    },
    //    xAxis: {
    //        categories: [
    //            '一月',
    //            '二月',
    //            '三月',
    //            '四月',
    //            '五月',
    //            '六月',
    //            '七月',
    //            '八月',
    //            '九月',
    //            '十月',
    //            '十一月',
    //            '十二月'
    //        ],
    //        crosshair: true
    //    },
    //    yAxis: {
    //        min: 0,
    //        title: {
    //            text: '降雨量 (mm)'
    //        }
    //    },
    //    tooltip: {
    //        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
    //        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
    //        '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
    //        footerFormat: '</table>',
    //        shared: true,
    //        useHTML: true
    //    },
    //    plotOptions: {
    //        column: {
    //            pointPadding: 0.2,
    //            borderWidth: 0
    //        }
    //    },
    //    exporting: {
    //        //enabled:true,默认为可用，当设置为false时，图表的打印及导出功能失效
    //        buttons: {    //配置按钮选项
    //            printButton: {    //配置打印按钮
    //                width: 50,
    //                symbolSize: 20,
    //                borderWidth: 2,
    //                borderRadius: 5,
    //                hoverBorderColor: 'red',
    //                height: 50, symbolX: 25,
    //                symbolY: 15,
    //                x: -200,
    //                y: 20
    //            },
    //            exportButton: {    //配置导出按钮
    //                width: 80,
    //                symbolSize: 20,
    //                borderWidth: 2,
    //                borderRadius: 0,
    //                hoverBorderColor: 'red',
    //                height: 80,
    //                symbolX: 25,
    //                symbolY: 15,
    //                x: -150,
    //                y: 20
    //            }
    //        },
    //        filename: '52wulian.org',//导出的文件名
    //        type: 'image/png',//导出的文件类型
    //        width: 800    //导出的文件宽度
    //    },
    //    series: [{
    //        name: '东京',
    //        data: [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4]
    //    } ]
    //});

})
