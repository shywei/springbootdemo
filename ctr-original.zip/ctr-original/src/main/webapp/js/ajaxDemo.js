//document.write(returnCitySN["cip"]+','+returnCitySN["cname"]);
//var returnCitySN = {"cip": "49.74.243.121", "cid": "320100", "cname": "江苏省南京市"};
//'http://192.168.1.15:8080' //zheng 端口/
var http = '';
//   http = 'http://192.168.1.35:8080/OnePalm/';
   
function ajaxAuto(http,oUrl,oType,oData,oDataType,fn){
		console.log(http + oUrl," 类型 "+oType," 数据 "+oData," 数据类型 "+oDataType)
		var data ;
		$.ajax({
			url : http + oUrl,
			type : oType,
			data : oData,
			dataTpye : oDataType,
			beforeSend:function(){
				console.log("bef")
			},
			success : function(oSdata){			
				fn(oSdata);
						
			},complete:function(){
				console.log("com")
			}
		});
		console.log(data)
		
}


// ajax({
//      url: "./TestXHR.aspx",              //请求地址
//      type: "POST",                       //请求方式
//      data: { name: "super", age: 20 },        //请求参数
//      dataType: "json",
//      success: function (response, xml) {
//          // 此处放成功后执行的代码
//      },
//      fail: function (status) {
//          // 此处放失败后执行的代码
//      }
//  });

    function ajax(options) {
        options = options || {};
        options.type = (options.type || "GET").toUpperCase();
        options.dataType = options.dataType || "json";
        var params = formatParams(options.data);

        //创建 - 非IE6 - 第一步
        if (window.XMLHttpRequest) {
            var xhr = new XMLHttpRequest();
        } else { //IE6及其以下版本浏览器
            var xhr = new ActiveXObject('Microsoft.XMLHTTP');
        }

        //接收 - 第三步
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4) {
                var status = xhr.status;
                if (status >= 200 && status < 300) {
                    options.success && options.success(xhr.responseText, xhr.responseXML);
                } else {
                    options.fail && options.fail(status);
                }
            }
        }

        //连接 和 发送 - 第二步
        if (options.type == "GET") {
            xhr.open("GET", options.url + "?" + params, true);
            xhr.send(null);
        } else if (options.type == "POST") {
            xhr.open("POST", options.url, true);
            //设置表单提交时的内容类型
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.send(params);
        }
    }
    //格式化参数
    function formatParams(data) {
        var arr = [];
        for (var name in data) {
            arr.push(encodeURIComponent(name) + "=" + encodeURIComponent(data[name]));
        }
        arr.push(("v=" + Math.random()).replace(".",""));
        return arr.join("&");
    }