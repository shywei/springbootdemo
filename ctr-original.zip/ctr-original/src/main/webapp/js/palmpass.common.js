(function($){

/*
 * combox联动的js
 *  
 * @param requestUrl 	服务器url
 * @param requestData    请求的json数据
 * @param comboxId: 要动态加载的combox的html id
 * @param resultProperty 与comobx的选择内容相关的属性
 * {
 *  	resultName: ajax响应中内容列表字段的名字
 *  	descField: 要选择的对象显示的字段
 *      valueField: 要显示的对象的值的字段
 *  }
 * @param initOption  combox中初始的选项，与结果无关
 */
comboxDynamicLoad = function(requestUrl, requestData,  comboxId, resultProperty, initOption){
	
	$.ajax({
		type: 'post',
		url: requestUrl,
		data:  requestData,
		dataType: 'json',
		success : function(data) {	
			
			var combox = $("#"+comboxId);
			var wrapper = combox.parents("div.combox:first");	
			
			var html = "";
        	var items = data[resultProperty.resultName];
        	if(items != null){
        		if(initOption){
        			html += '<option value="'+ initOption.code +'">'+ initOption.desc +'</option>';
        		}
        		for(var i = 0; i < items.length; i++){
        			html += '<option value="'+ items[i][resultProperty.valueField] +'">'+ items[i][resultProperty.descField] +'</option>';
        		}
        		combox.html(html).insertAfter(wrapper);
        		wrapper.remove();
    			combox.trigger("change").combox();			        	
        	}  
		},
		error : function(msg) {
				alert(msg);
		}
	});	
};

uniqueCheckDeviceName = function(inputId, errMsgParent, errMsgId, triggerOnload){
	checkDeviceProperty(inputId, errMsgParent, errMsgId, 
			"device/deviceNameQuery.ajax", 
			"deviceName", 
			"DEVICE_NAME_EXISTS", triggerOnload);
};

uniqueCheckDeviceId = function(inputId, errMsgParent, errMsgId, triggerOnload){
	
	checkDeviceProperty(inputId, errMsgParent, errMsgId, 
			"device/deviceIdQuery.ajax", 
		     "deviceId", 
			"DEVICE_NO_EXISTS", triggerOnload);
};

uniqueCheckDeviceIp = function(inputId, errMsgParent, errMsgId, triggerOnload){
	
	checkDeviceProperty(inputId, errMsgParent, errMsgId, 
			"device/deviceIpQuery.ajax", 
		    "deviceIp", 
			"DEVICE_IP_EXISTS", triggerOnload);
};

loadDeviceModelByType = function(deviceTypeId, deviceModelId, triggerOnload){

	$('#' + deviceTypeId).change(function() {
		var deviceType = $(this).val();
		var resultProperty = {
			resultName: "deviceModels",
			descField: "desc",
			valueField: "code"
		};
		comboxDynamicLoad("device/getDeviceModel.ajax", {deviceType: deviceType}, deviceModelId, resultProperty, null);		
	});	
	
	if(triggerOnload){
		$('#' + deviceTypeId).trigger("change");
	}
}

uniqueCheckDevicePropertyCallback = function(checkUrl, requestData, errorMsg, callback){
	
	$.ajax({
	       type: 'post',
	       url: checkUrl,
	       data: requestData,
	       dataType: 'json',
	       async: false,
	       success: function(data) {
	       	if(data['deviceIdInfo'] !== "null") {
	       		alertMsg.error(errorMsg);
	       	} 
	       	else{
	       		if(callback){
	       			callback();
	       		}
	       	}
	       },
	       error: function (msg) { 
	           alert(msg); 
	       } 
	  	 });		
	
};

/* 
 * 设备搜索页面添加或编辑成功后重新进行搜索
 * 
 */
deviceSearchAjaxDone = function(json){
    if(json != null && json.statusCode === "200"){
  	  DWZ.ajaxDone(json);
  	  $.pdialog.closeCurrent(); 
  	  $('#BTN-SEARCH-DEVICE').trigger("click");
    } else{
  	  DWZ.ajaxDone(json);
  	  $.pdialog.closeCurrent(); 
    }
}

/*
 * 检测设备的属性是否唯一的通用模式
 *   
 */
var checkDeviceProperty = function(inputId, errMsgParent, errMsgId, checkUrl, requestField, errMsgContent, triggerOnload){
	
	$('#'+ errMsgParent).hide();
	
	$('#' + inputId).change(function(){
		var requestData = {};
		requestData[requestField] = $(this).val();
		 $.ajax({
		        type: 'post',
		        url: checkUrl,
		        data: requestData,
		        dataType: 'json',
		        async: false,
		        success: function(data) {
		        	if(data['deviceIdInfo'] !== "null") {
		        		$("#"+errMsgParent).show();
		        		$('#'+errMsgId).html($.i18n.prop(errMsgContent,requestData[requestField]));
		        		$("#"+inputId).val("");		
		        	} else{	 
		        		$("#"+errMsgParent).hide();
		         		$('#'+errMsgId).html("");
		        	}
		        },
		        error: function (msg) { 
		            alert(msg); 
		        } 
		   	 });				 
	});
	
	if(triggerOnload){
		$("#"+inputId).trigger('change');
	}
};

/*
 * 检查是否安装了flash
 * 返回值 result {f: , v: }
 * f:0 表示未安装flash
 *   1 表示安装了flash
 * v:如果安装了flash,返回具体版本号  
 */
$.flash = {
	flashChecker : function () {  

			var hasFlash = 0; //是否安装了flash  
			var flashVersion = 0; //flash版本  

			if (document.all) {
				try {
					var swf = new ActiveXObject('ShockwaveFlash.ShockwaveFlash');
					if (swf) {
						hasFlash = 1;
						VSwf = swf.GetVariable("$version");
						flashVersion = parseInt(VSwf.split(" ")[1].split(",")[0]);
					}
				}
				catch(e){	
				}
			} else {
				try {
					if (navigator.plugins && navigator.plugins.length > 0) {
						var swf = navigator.plugins["Shockwave Flash"];
						if (swf) {
							hasFlash = 1;
							var words = swf.description.split(" ");
							for (var i = 0; i < words.length; ++i) {
								if (isNaN(parseInt(words[i])))
									continue;
								flashVersion = parseInt(words[i]);
							}
						}
					}
				}
				catch(e){
				}
			}
			return {
				f : hasFlash,
				v : flashVersion
			};
	}
};
})(jQuery);