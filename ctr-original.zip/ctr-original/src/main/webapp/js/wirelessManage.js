function W_readerTable($elem, data){
    //日期格式化
    var dayformat = function(str){
        var date = new Date(str);
        var year = date.getFullYear();
        var month = date.getMonth()+1;
        var day = date.getDate();
        var str = ""+year+"-"+month+"-"+day;
        return str;
    }
    var len=data.result.length,
        trhtml=''
    if(len>0){
        for( var i=0;i<len;i++){
            trhtml+=`
                <tr>
                    <td>
                        <img class="check_img" src="img/checkbox.png">
                    </td>
                    <td class="select_ID">${data.result[i].id}</td>
                    <td class="data_wifi_name">${data.result[i].name}</td>
                    <td class="data_wifi_pwd">${data.result[i].pwd}</td>
                    <td>${dayformat(data.result[i].createDate)}</td>
                    <td>${dayformat(data.result[i].modifyDate)}</td>
                    <td>
                      <span  class="change_Click" onclick="change_wifi(${data.result[i].id},'${data.result[i].name}','${data.result[i].pwd}')">修改 </span>
                      <!--<span  class="change_Click" onclick="change_wifi(${data.result[i].id},'${data.result[i].name}')">修改 </span>-->
                    </td>
                </tr>
                `

        }
    }else{
        trhtml = '<tr><td colspan="7">暂无数据</td></tr>';
    }
    $elem.html(trhtml);
}


//点击查询获取的数据
$(".click_Query").click(function(){
    all_table()
})
//all_table();

function all_table(page){
    page=page || 1;
    var wifiName=$(".wireless_input").val();
    //var rows=$("div.jogger select").val();
    var rows = $(".sel select option:selected").val() || 10;
    //console.log(rows)
    //var pageNow = $(".ycolor").html()==''?'1':$(".ycolor").html();
    $.ajax({
        url:http+"venaWifiInfoController/queryWifiInfoByName.do",
        type:"GET",
        dataType:"JSON",
        data:{
            name: wifiName,
            page: page,
            rows: rows
        },
        success:function(data){
            //console.log(data.result[0].createDate);
            W_readerTable($(".w_table"), data);
            //selectAll();
            //调用点击删除后的选中的class
            text_color();

            var dangqian=parseInt(data.page)/1;
            //当前页码
            userstotal=data.count;//一共多少条数据
            var rows=data.rows;//一页多少数据
            yeshu=Math.ceil(userstotal/rows);
            if(yeshu==0){
                yeshu=1;
            }

            var html1='';
            if(dangqian==1){
                if(dangqian<=yeshu){
                    html1+=`<li class="ycolor">${dangqian}</li>`;
                }
                if(dangqian+1<=yeshu){
                    html1+=`<li>${dangqian+1}</li>`;
                }
                if(dangqian+2<=yeshu){
                    html1+=`<li>${dangqian+2}</li>`;
                }
                if(dangqian+3<=yeshu){
                    html1+=`<li>${dangqian+3}</li>`;
                }
                if(dangqian+4<=yeshu){
                    html1+=`<li>${dangqian+4}</li>`;
                }
            }else if(dangqian==2){
                html1+=`<li>${dangqian-1}</li>`;
                html1+=`<li class="ycolor">${dangqian}</li>`;

                if(dangqian+1<=yeshu){
                    html1+=`<li>${dangqian+1}</li>`;
                }
                if(dangqian+2<=yeshu){
                    html1+=`<li>${dangqian+2}</li>`;
                }
                if(dangqian+3<=yeshu){
                    html1+=`<li>${dangqian+3}</li>`;
                }
            }else if(dangqian==yeshu&&dangqian>=5){
                html1+=`
						<li>${dangqian-4}</li>

						<li>${dangqian-3}</li>

						<li>${dangqian-2}</li>

						<li >${dangqian-1}</li>
						<li class="ycolor">${dangqian}</li>
						`
            }else if(dangqian==yeshu-1&&dangqian>=5){
                html1+=`
						<li>${dangqian-3}</li>

						<li>${dangqian-2}</li>

						<li>${dangqian-1}</li>

						<li class="ycolor">${dangqian}</li>
						<li>${dangqian+1}</li>
						`
            }else{
                if(dangqian-2>0){
                    html1+=`<li>${dangqian-2}</li>`;
                }
                if(dangqian-1>0){
                    html1+=`<li>${dangqian-1}</li>`;
                }
                html1+=`<li class="ycolor">${dangqian}</li>`;
                if(dangqian<yeshu){
                    html1+=`<li>${dangqian+1}</li>`;
                }
                if(dangqian+1<yeshu){
                    html1+=`<li>${dangqian+2}</li>`;
                }
            }
            $("ul.yema").html(html1);
            $(".look .allpeople").html(userstotal);
            $(".look .nowpage").html(dangqian);
            $(".look .allpage").html(yeshu);

            //每一页显示多少条数据
            $("div#jogger select").change(function(){
                var W_number=$(".sel select option:selected").val();
                var W_num=$(".content .yema .ycolor").html();
                all_table(W_num,W_number)
            });
            //点击页面的跳转
            $(".content .yema li").each(function(i){
                $(".content").eq(i).unbind("click").on("click",".yema li",function(){
                    $(this).removeClass("ycolor");
                    $(this).addClass("ycolor")
                    var w_liNum = $(this).html();
                    all_table(w_liNum);
                });
            });
            //点击首页的跳转
            $(".jogger").unbind("click").on("click",".firstpage",function(){
                all_table(1);
            });
            //点击末页跳转
            $(".lastpage").unbind("click").on('click',function(){
                all_table(yeshu);
            })
            //点击go跳转
            $(".jogger").on("click"," .tiaozhuan",function(){
                //alert(1111)
                var Num = 0;
                if($(".jogger input").val()>yeshu){
                    $(".jogger input").val(yeshu);
                }
                Num = $(".jogger input").val();
                $(".condition .jogger .tiaozhuan").unbind("click");
                all_table(Num);
            });
        }
    })
}

//点击添加wifi账号
$(".add_wireless").click(function(){
    parent.$(".add").fadeIn();
     parent.$(".baohu").fadeIn();

    parent.$(".add_wifi_prompt").html('');
    parent.$("#J_wifi_name").val('');
    parent. $("#J_wifi_Pwd").val('');
    parent.$("#J_sure_pwd").val('');

    //点击添加wifi账号确定按钮
    var check_wifi=false;
    //验证添加的wifi账号密码
    function test_wifi(){

        var J_wifi_name=parent.$("#J_wifi_name").val();
        var J_wifi_Pwd=parent.$("#J_wifi_Pwd").val();
        var J_sure_pwd=parent. $("#J_sure_pwd").val();
        //alert(parent.$("#J_wifi_name").val());
        console.log(J_wifi_name)
        console.log(J_wifi_Pwd)
        console.log(J_sure_pwd)

        if(J_wifi_name ===''){
            parent.$(".add_wifi_prompt").html("添加的账号不能为空");
            return;
        }
        if(J_wifi_Pwd === '' || J_sure_pwd === ''){
            parent.$(".add_wifi_prompt").html("连接的密码不能为空");
            return;
        }
        if(J_wifi_Pwd===(/^\d{8,}$/) || J_sure_pwd === (/^\d{8,}$/)){
            parent. $(".add_wifi_prompt").html("密码至少8位数");
            return;
        }
        if(J_wifi_Pwd !== J_sure_pwd){
           parent.$(".add_wifi_prompt").html("两次输入的密码不一样");
            return;
        }

        check_wifi = true;
        J_sure_wifi();
    }

   parent.$("#J_add_wifi_sure").unbind('click').click(function(){
       //alert("success");
        test_wifi();
    });

    //添加wifi的确定按钮
    function J_sure_wifi(){
        var J_wifi_name=parent.$("#J_wifi_name").val();
        var J_wifi_Pwd=parent.$("#J_wifi_Pwd").val();
        var J_sure_pwd=parent. $("#J_sure_pwd").val();
        $.ajax({
            url:http+"venaWifiInfoController/insertWifiInfo.do",
            type:"GET",
            dataType:"JSON",
            data:{
                name:J_wifi_name,
                pwd: J_wifi_Pwd
            },
            success:function(data){
               parent.$(".add").fadeOut();
                parent.$(".baohu").fadeOut();
                all_table();
            }
        });
    }

    //添加wifi里面的取消按钮
    parent.$(".close_Wifi").click(function(){
        parent.$(".baohu").fadeOut();
        parent.$(".add").fadeOut();
    });
});

//封装显示全部的方法
function text_color(){
    if ($('#select_all').hasClass('on')) {
        $("#select_all").removeClass('on').attr('src', 'img/checkbox.png');
    }

    //点击过后文本框变色
    $("#select_all").unbind('click').on('click', function(){
        if (!$(this).hasClass('on')) {
            $(this).addClass('on');
            $(this).attr('src', 'img/checkbox2.png');

            $('.check_img').addClass('on').attr('src','img/checkbox2.png');
        } else {
            $(this).removeClass('on');
            $(this).attr('src', 'img/checkbox.png');
            $("#select_all").removeClass('on');
            $('.check_img').removeClass('on').attr('src','img/checkbox.png');
        }
    });

// 点击单选
    $('.check_img').unbind('click').on('click', function(){
        if (!$(this).hasClass('on')) {
            $(this).addClass('on').attr('src','img/checkbox2.png');
            var isSelectAll = true;
            $('.check_img').each(function(idx, value){
                if (!$(value).hasClass('on')) {
                    isSelectAll = false;
                }
            });

            if (isSelectAll) {
                $("#select_all").addClass('on').attr('src','img/checkbox2.png');
            }
        } else {
            $(this).removeClass('on').attr('src','img/checkbox.png');

            $("#select_all").removeClass('on').attr('src','img/checkbox.png');
        }
    });

}


//点击删除按钮
$(".click_Del").click(function(){
    var isSelect = false;
    $('.check_img').each(function(idx, value){
        if ($(value).hasClass('on')) {
            isSelect = true;
        }
    });
    if(!isSelect) {
       parent.$(".wifi_del_sure").fadeIn();
        parent. $(".baohu").fadeIn();
    }else{
       parent. $(".wifi_del_btn").fadeIn();
        parent.$(".baohu").fadeIn();
        var checkImgs = $('.check_img');
        var delSelectIds = [];
        $.each(checkImgs, function(idx, item){
            if ($(item).hasClass('on')) {
                var checkId = $(item).parent().next().text();
                delSelectIds.push(checkId);
            }
        });

        //点击删除按钮弹框的确定按钮
       parent.$(".F_sure").unbind('click').click(function(){
            $.ajax({
                url:http+"venaWifiInfoController/deleteWifiInfo.do",
                dataType:"JSON",
                type:"GET",
                data:{
                    ids: delSelectIds.join(',')
                },
                success:function(data){
                    console.log(data);
                    parent.$(".wifi_del_btn").fadeOut();
                    parent.$(".baohu").fadeOut();
                    all_table();
                    if( data == ',' || data == ''){
                        parent.$(".smallkuang-header span").html("删除wifi");
                        parent.$(".condition .sp18").html("操作成功")
                        parent.$(".condition .smallkuang7").fadeIn();
                        parent.$(".baohu").fadeIn();
                        return;
                    }
                    parent.$(".smallkuang-header span").html("删除wifi");
                    parent.$(".condition .sp18").html('wifi编号' + (data||'').slice(0,data.length-1) + '操作失败');
                    parent.$(".condition .smallkuang7").fadeIn();
                    parent.$(".baohu").fadeIn();
                    return;
                    all_table();
                },
                error:function(data){
                    parent.$(".smallkuang-header span").html("操作失败");
                    parent.$(".condition .sp18").html('请检查网络连接')
                    parent.$(".condition .smallkuang7").fadeIn();
                    parent.$(".baohu").fadeIn();
                }
            });
        });

       parent.$(".F_cancle").click(function(){
            parent.$(".wifi_del_btn").fadeOut();
            parent.$(".baohu").fadeOut();
        });
        parent.$(".del_time_").click(function(){
           parent. $(".wifi_del_btn").fadeOut();
            parent.$(".baohu").fadeOut();
        });

    }

});
//取消的弹框未选择
$(".D_Time").click(function(){
    $(".wifi_del_sure").fadeOut();
    parent.$(".baohu").fadeOut();
})
$(".wifi_sure").click(function(){
    $(".wifi_del_sure").fadeOut();
    parent.$(".baohu").fadeOut();
})



//点击修改的按钮
change_wifi = function(a,b,c) {
    parent.$(".Change_wifi_prompt").html("");
    parent.$("#J_sureChange_pwd").val("")

    parent.$(".change_prompt").fadeIn();
   parent.$(".baohu").fadeIn();
    var change_Id = a;
    var change_Name = b;
    var change_pwd = c;
    parent.$("#J_wifiChange_name").val(change_Name);
    parent.$("#J_wifiCahnge_Pwd").val(change_pwd);

   parent.$(".sure_Wifi").click(function () {
       parent. $(".Change_wifi_prompt").html('');

        var change_Name = parent.$("#J_wifiChange_name").val();
        var J_wifiCahnge_Pwd =parent.$("#J_wifiCahnge_Pwd").val();
        var J_sureChange_pwd = parent.$("#J_sureChange_pwd").val();
        console.log(change_Name);
        console.log(J_wifiCahnge_Pwd);
        console.log(J_sureChange_pwd);

        if (change_Name === '') {
           parent. $(".Change_wifi_prompt").html("修改的账号不能为空");
            return;
        }
        if (J_wifiCahnge_Pwd === '' || J_sureChange_pwd === '') {
            parent. $(".Change_wifi_prompt").html("密码不能为空")
            return;
        }
        if (J_wifiCahnge_Pwd !== J_sureChange_pwd) {
            parent. $(".Change_wifi_prompt").html("两次输入的密码不一致")
            return;
        }
        $.ajax({
            url: http + "venaWifiInfoController/updateWifiInfo.do",
            type: "GET",
            dataType: "JSON",
            data: {
                id: change_Id,
                name: change_Name,
                pwd: J_wifiCahnge_Pwd
            },
            success: function (data) {
                parent.$(".change_prompt").fadeOut();
                parent.$(".baohu").fadeOut();
                all_table();
            }
        })

    })
    //点击修改的取消里面的取消按钮
    parent.$(".close_Wifi").click(function () {
        parent.$(".change_prompt").fadeOut();
        parent.$(".baohu").fadeOut();
    })
}
