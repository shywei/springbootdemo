var http = "";
//http = 'http://192.168.1.121:8080/ctr/';
 window.onbeforeunload=function(){
 	window.opener.$(".baohu").fadeOut();
 }

var video = document.getElementById("video");
var canvas = document.getElementById("canvas");
var context = canvas.getContext("2d");

navigator.getUserMedia = navigator.getUserMedia ||
	navigator.webkitGetUserMedia ||
	navigator.mozGetUserMedia ||
	navigator.msGetUserMedia; //获取媒体对象（这里指摄像头）
navigator.getUserMedia({
	video: true
}, gotStream, noStream); //参数1获取用户打开权限；参数二成功打开后调用，并传一个视频流对象，参数三打开失败后调用，传错误信息

function gotStream(stream) {
	video.src = URL.createObjectURL(stream);
	video.onerror = function() {
		stream.stop();
	};
	stream.onended = noStream;
	video.onloadedmetadata = function() {
		//alert('摄像头成功打开！');
	};
}

function noStream(err) {
	alert(err);
}

document.getElementById("snap").addEventListener("click", function() {
//	debugger
//	Uniqueness()
	context.drawImage(video, 0, 0, 320, 380); //将获取视频绘制在画布上
	var type = "png";
	var img = canvas.toDataURL(type);//获取base64编码
	imgdate = img.substr(22);//截取有用信息
//	output.innerText = imgdate;

	$("#shangchuan").click(function() {
		window.opener.$("iframe.crumbsCon")[0].contentWindow.$("#photo").html('');
		var haha = Math.floor(Math.random()*1000);
		$.ajax({
			type: "post",
			url: http + "userInfoSaveController/photograph",
			dataType: "json",
			data: {
				photo: imgdate,
				userid:sessionStorage.sId,
				haha:haha
			},
			cache:false,
			success: function(data) {
				window.opener.console.log(data)
				window.opener.console.log(haha)

				if(data.obj == null){
					$(".gatheringInformation").html("采集失败！")
					$(".gatheringInformation").css("color","#FE610B")
				}else{
					$(".gatheringInformation").html("采集成功！")
					$(".gatheringInformation").css("color","#FE610B")
					//window.opener.delFinger9();
					var url=data.objExt;
					console.log(url)
					var html=' <img src="'+url+'" data="'+data.obj+'"/>'
					window.opener.$("iframe.crumbsCon")[0].contentWindow.$("#photo img").remove();
					window.opener.$("iframe.crumbsCon")[0].contentWindow.$("#photo").html(html);
					window.opener.$(".baohu").fadeOut();
					window.close()
				}
			},
			error: function(err) {
				console.log(err)
			}
		});

	})
});


