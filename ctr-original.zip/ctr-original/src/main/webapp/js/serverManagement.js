
$(function(){
	loadSmg()
	
	$(".changetd").addClass('bg5'); // 初始化时添加背景1
				//thead点击全选时，tbody全部选中
	$(".changedata").on("click", ".changehead .changetd", function() {
		if($("thead .changetd").attr("class") == "changetd bg5") {
			$(".changetd").attr("class", "changetd bg6");
		} else {
			$("thead .changetd").attr("class", "changetd bg5");
			$("tbody .changetd").attr("class", "changetd bg5");
		}
		//tbody点击时，单个选，当tbody全都点中时，触发thead
	});
	$(".changedata").on("click", ".changebody .changetd", function() {
		$(this).toggleClass('bg5').toggleClass('bg6'); //点中的被选中
		checkAuto00();
	});

});


//服务器管理--查询--列表详情显示
$(".search1").on("click",function(){
	loadSmg();
});
//初始化注册表
function emptying(){
	parent.$("#serverAddress").val("")
	parent.$("#serverName").val("")
	parent.$("#data").attr("checked",false)
	parent.$("#Contrast").attr("checked",false)
	parent.$("#available").attr("checked",true)
	parent.$("#yes").attr("checked",true)
//	parent.$(".application").hide()
	parent.$(".duibi").hide()
}
//服务器注册
$(".changebtnAdd").on('click',function(){
	//判断角色是否是超级管理员
	if(sessionStorage.sId == 1){//是超级管理员
		//弹出框显示
		parent.$(".sMgAlert").fadeIn();
		parent.$(".xian").show()
		//改变服务器注册弹出框大小
		parent.$(".con").height(415)
		//判断选中的是哪个服务器类型
		parent.$(":radio").click(function(){
			//选中应用服务器单选框
			if($(this).val() ==1){
				//服务器状态和是否备用显示
				parent.$(".application").show()
				//识别精度隐藏
				parent.$(".duibi").hide()
			}
			//选中对比服务器
			if($(this).val() ==2){
				//识别精度显示
				parent.$(".duibi").show()
				//服务器状态和是否备用隐藏
//				parent.$(".application").hide()
			}
		})
	}else{//不是超级管理员
		//弹出框显示
		parent.$(".sMgAlert").fadeIn();
		//服务器类型隐藏
		parent.$(".xian").hide()
		//改变弹出框大小
		parent.$(".con").height(370)
	}
	//服务器注册窗口初始化
	emptying()
		
});

//服务器修改
$(".modify").on('click',function(){	
	var yeshu = $(".ycolor").html()
	var pageNumber = $("#pageNumber option:selected").val()
	var serverid=$("tbody .bg6").parent().attr("data");//设备id
	var serverIP=$("tbody .bg6").parent().parent().find(".serverAddress").html();//服务器名称
	var serverName=$("tbody .bg6").parent().parent().find(".deviceNumber").html();//服务器地址
	var serverStatus = $("tbody .bg6").parent().parent().find(".serverStatus").html()//服务器状态
	var serverType = $("tbody .bg6").parent().parent().find(".serverType").html()//服务器类型
	var isSpare= $("tbody .bg6").parent().parent().find(".isSpare").html()//是否可用
	sessionStorage.setItem("yeshu", yeshu);
	sessionStorage.setItem("pageNumber", pageNumber);
	sessionStorage.setItem("serverid", serverid);
	sessionStorage.setItem("serverIP", serverIP);
	sessionStorage.setItem("serverName", serverName);
	sessionStorage.setItem("serverStatus", serverStatus);
	sessionStorage.setItem("serverType", serverType);
	sessionStorage.setItem("isSpare", isSpare);
	//获取选中要修改服务器的个数
	var len = $("td.deviceid .changetd.bg6").length
	if(len == 0){
		parent.$(".smallkuang-header span").html("服务器修改");
		parent.$(".condition .sp18").html("请选择要修改的服务器")
		parent.$(".condition .smallkuang7").fadeIn();
		parent.$(".baohu").fadeIn();
		return;
	}else if(len >1){
		parent.$(".smallkuang-header span").html("服务器修改");
		parent.$(".condition .sp18").html("只能修改一个服务器!")
		parent.$(".condition .smallkuang7").fadeIn();
		parent.$(".baohu").fadeIn();
		return;
	}else{
		parent.$(".sMgAlert1").fadeIn();
		parent.shows()
	}
		
});




//点击删除
$(".changebtnDel").on('click',function(){	
	//获取服务器id
	var serverid=$("tbody .bg6").parent().attr("data");
	//获取服务器IP地址
    var serverIP=$("tbody .bg6").parent().parent().find(".serverAddress").html();
    //获取要删除服务器的个数
	var idsNum  = $("tbody .bg6").size();
	//获取的个数为0
	var sId = sessionStorage.sId;
	
	if(!idsNum){
		parent.$(".smallkuang-header span").html("删除服务器");
		parent.$(".condition .sp18").html("请选择要删除的服务器地址")
		parent.$(".condition .smallkuang7").fadeIn();
		parent.$(".baohu").fadeIn();
		return;
	}else if(idsNum>1){//获取的个数为多个
		parent.$(".smallkuang-header span").html("删除服务器");
		parent.$(".condition .sp18").html("只能删除一个服务器！")
		parent.$(".condition .smallkuang7").fadeIn();
		parent.$(".baohu").fadeIn();
		return
	}else{
		
		parent.$(".smallkuang13").fadeIn();
		parent.$(".baohu").fadeIn();
		parent.$("#no13").on("click",function(){
			parent.$(".smallkuang13").fadeOut();
		});
		parent.$("#ok13").on("click",function(){
			parent.$(".smallkuang13").fadeOut();
			parent.$(".baohu").fadeOut();
			
			$.ajax({
				type:'get',
				url:http + 'serverController/delServer',
				data:{
					serverid:serverid,               //服务器id
					serverIP:serverIP,				 //服务器IP地址
					currentId: sId    //账号ID
				},
				dataType:'json',
				success:function(data){
					if(data.code == 1){
						parent.$(".smallkuang-header span").html("删除服务器");
						parent.$(".condition .sp18").html("删除成功！")
						parent.$(".condition .smallkuang7").fadeIn();
						parent.$(".baohu").fadeIn();
						loadSmg()
					}else if(data.code == -1){
						parent.$(".smallkuang-header span").html("删除服务器");
						parent.$(".condition .sp18").html("该服务器已绑定不可删除！")
						parent.$(".condition .smallkuang7").fadeIn();
						parent.$(".baohu").fadeIn();
						return
					}else{
						parent.$(".smallkuang-header span").html("删除服务器");
						parent.$(".condition .sp18").html("操作失败！")
						parent.$(".condition .smallkuang7").fadeIn();
						parent.$(".baohu").fadeIn();
						return
					}
				}
			});
		});
	}
});

//查询列表
function loadSmg(page){
	//初始化所有的选中状态为未选中
	$("thead .changetd").attr("class", "changetd bg5")
	//当前页
	page = page||'1';
	//显示条数
	row = $(".sel select option:selected").val()||'10';
	$.ajax({
		url:http+'serverController/queryServerList',
		data:{
			page:page,//当前页
			rows:row,//显示条数
			serverName:$(".changeview .server").val()||'',//服务器名称
			serverIP:$(".changeview .serverAddress").val()||'',//服务器地址
			serverStatus:$(".serverStatus option:selected").val()||'',//服务器状态
			serverType:0,                          
			s:1
		},
		type:'get',
		dataStype:'json',
		success:function(data){
			//没有数据
			if(data.obj.length == 0){
				var html = '';
				html=`
					<tr class="changetr">
                    	<td class="deviceid" colspan='9'><img src="img/dataloss.png"></img></td>
                    </tr>
				`;
			}else{//有数据
				var html='';
				var len = data.obj.length
				for(i = 0;i<len;i++){
					if(data.obj[i].serverStatus == 0){
						serverStatus = '启用'
					}else{
						serverStatus = '停用'
					}
					if(data.obj[i].serverType == 0){
						serverType = '应用服务器'
					}else{
						serverType = '对比服务器'
					}
					if(data.obj[i].isSpare == 0){
						isSpare = '否'
					}else{
						isSpare = '是'
					}
					//截取创建时间长度
					if(data.obj[i].createtime != null){
						var createtime = data.obj[i].createtime.slice(0,19)
					}else{
						var createtime =""
					}
					//截取修改时间长度
					if(data.obj[i].modifytime != null){
						var modifytime = data.obj[i].modifytime.slice(0,19)
					}else{
						var modifytime =""
					}
					html += `
						<tr class="changetr">
	                    	<td class="deviceid" data="${data.obj[i].serverid}"><div class="changetd bg5"></div></td>
	                        <td class="deviceNumber">${data.obj[i].serverName}</td>
	                        <td class="serverAddress">${data.obj[i].serverIP}</td>
	                        <td class="serverStatus">${serverStatus}</td>
	                        <td class="serverType">${serverType}</td>
	                        <td class="isSpare">${isSpare}</td>
	                        <td class="creationTime">${createtime}</td>
	                        <td class="modifyTime">${modifytime}</td>
	                    </tr>
					`;	
				}
			}
			$(".changebody").html(html);
			
			var dangqian=parseInt(data.objExt.currentPage)/1; //当前页码
			var userstotal=data.objExt.totalCount;            //一共多少条数据
			var rows=data.objExt.pageSize;                    //一页多少数据
			yeshu=Math.ceil(userstotal/rows);                 //总页数
			if(yeshu==0){
				yeshu=1;
			}
			var html1='';
			if(dangqian==1){
				if(dangqian<=yeshu){
					html1+=`<li class="ycolor">${dangqian}</li>`;
				}
				if(dangqian+1<=yeshu){
					html1+=`<li>${dangqian+1}</li>`;
				}
				if(dangqian+2<=yeshu){
					html1+=`<li>${dangqian+2}</li>`;
				}
				if(dangqian+3<=yeshu){
					html1+=`<li>${dangqian+3}</li>`;
				}
				if(dangqian+4<=yeshu){
					html1+=`<li>${dangqian+4}</li>`;
				}
			}else if(dangqian==2){
					html1+=`<li>${dangqian-1}</li>`;
					html1+=`<li class="ycolor">${dangqian}</li>`;

				if(dangqian+1<=yeshu){
					html1+=`<li>${dangqian+1}</li>`;
				}
				if(dangqian+2<=yeshu){
					html1+=`<li>${dangqian+2}</li>`;
				}
				if(dangqian+3<=yeshu){
					html1+=`<li>${dangqian+3}</li>`;
				}
			}else if(dangqian==yeshu&&dangqian>=5){
				html1+=`
				<li>${dangqian-4}</li>

				<li>${dangqian-3}</li>

				<li>${dangqian-2}</li>

				<li >${dangqian-1}</li>
				<li class="ycolor">${dangqian}</li>
				`
			}else if(dangqian==yeshu-1&&dangqian>=5){
				html1+=`
				<li>${dangqian-3}</li>

				<li>${dangqian-2}</li>

				<li>${dangqian-1}</li>

				<li class="ycolor">${dangqian}</li>
				<li>${dangqian+1}</li>
				`
			}else{
				if(dangqian-2>0){
					html1+=`<li>${dangqian-2}</li>`;
				}
				if(dangqian-1>0){
					html1+=`<li>${dangqian-1}</li>`;
				}
				html1+=`<li class="ycolor">${dangqian}</li>`;
				if(dangqian<yeshu){
					html1+=`<li>${dangqian+1}</li>`;
				}
				if(dangqian+1<yeshu){
					html1+=`<li>${dangqian+2}</li>`;
				}
			}
			//分页区显示
			$("ul.yema1").html(html1);
			$(".look1 .allpeople1").html(userstotal);     //总数据量
			$(".look1 .nowpage1").html(dangqian);         //当前页数
			$(".look1 .allpage1").html(yeshu);            //总页数
			//切换数据多少条
			$(".sel select").on("change",function(){
				var num = $(".sel select option:selected").val();
				var aNum = 1
				loadSmg(aNum,num);
			});
			//点击页数跳转	
			$(".condition .yema1 li").each(function(i){
				$(".condition").eq(i).unbind("click").on("click",".yema1 li",function(){
					$(this).removeClass("ycolor");
					$(this).addClass("ycolor")
					var liNum = $(this).html();
					loadSmg(liNum);
				});	
			});
			//点击首页跳转
			$(".crumbsCon").unbind("click").on("click",".firstpage1",function(){
					loadSmg(1);
			});	
			//点击末页跳转
			$(".stateMatCrb").unbind("click").on("click",".lastpage1",function(){
					loadSmg(yeshu);
			});	
			//点击go跳转
			$(".condition").on("click",".jogger1 .tiaozhuan1",function(){
					var Num = 0;
					if($(".jogger1 input").val()>yeshu){
						$(".jogger1 input").val(yeshu);
					}
					Num = $(".jogger1 input").val();
					$(".condition .jogger1 .tiaozhuan1").unbind("click");
					loadSmg(Num);
			});	
		}
	});
}