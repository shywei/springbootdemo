var http = '';
var locations = [];
locations=(window.location+'').split('/')
//locations[2]="192.168.1.124:8080";
//locations[3]="ctr";
http = locations[0]+'//'+locations[2]+'/'+locations[3]+'/';
console.log(locations)
console.log(http)
var httpUrl = '';
httpUrl = http;
//httpUrl = 'http://127.0.0.1:8020/ctr/';


if(!sessionStorage['sId']) {
	location.href = 'Login.html';
}

$.fn.pageNumAuto = function(dataAll) {
	var e = this;
	var htmlPags = '' +
		'<div class="pubJogger">' +
		'<span class="pubSel">当前页' +
		'<select name="" id="">' +
		'   <option value="5">5</option>' +
		'  <option value="10" selected="selected">10</option>' +
		'</select>' +
		'条数据' +
		'</span>' +
		'<span class="pubLook">' +
		'共' +
		'<span class="pubAllRows">213213</span>' +
		'条&nbsp;当前为第' +
		'<span class="pubNowpage">123123</span>' +
		'页&nbsp;共' +
		'<span class="pubAllpage">123</span>' +
		'页' +
		'</span>' +
		'<b class="pubFirstpageWrap"><button class="pubFirstpage">首页</button></b>' +
		'<span class="pubYema">' +
		'<button  class="ycolor">1</button><button >2</button>' +
		'</span>' +
		'<b class="pubLastpageWrap"><button class="pubLastpage">末页</button></b>' +
		'<input type="text" onkeyup="this.value=this.value.replace(/[^\\d]/g,\'\') " />' +
		'<b class="pubSeachWrap"><button class="pubSeach">GO</button></b>' +
		'</div>';
	$(e).html(htmlPags)
	$(".pubJogger input").val("");
	var dataPage = dataAll.dataPage; //dataPage 当前页码
	var dataCount = dataAll.dataCount; //dataCount 一共多少条数据
	var pageNum = dataAll.pageNum; //pageNum 一页多少数据
	var fun = dataAll.fun; //fun 方法名

	$(".pubSel select").val(pageNum);
	//当前页码
	var currentPage = parseInt(dataPage) / 1;

	//一共多少条数据
	var allPageData = dataCount / 1;

	//一页多少数据
	var rows = pageNum / 1;

	PagesNum = Math.ceil(allPageData / rows);

	if(PagesNum == 0) { PagesNum = 1; }
	var htmlPage = '';
	if(currentPage == 1) {
		if(currentPage <= PagesNum) { htmlPage += '<button class="ycolor">' + (currentPage) + '</button>' };
		if(currentPage + 1 <= PagesNum) { htmlPage += '<button>' + (currentPage + 1) + '</button>' };
		if(currentPage + 2 <= PagesNum) { htmlPage += '<button>' + (currentPage + 2) + '</button>' };
		if(currentPage + 3 <= PagesNum) { htmlPage += '<button>' + (currentPage + 3) + '</button>' };
		if(currentPage + 4 <= PagesNum) { htmlPage += '<button>' + (currentPage + 4) + '</button>' };

	} else if(currentPage == 2) {
		htmlPage += '<button>' + (currentPage - 1) + '</button>';
		htmlPage += '<button class="ycolor">' + (currentPage) + '</button>'
		if(currentPage + 1 <= PagesNum) { htmlPage += '<button>' + (currentPage + 1) + '</button>' };
		if(currentPage + 2 <= PagesNum) { htmlPage += '<button>' + (currentPage + 2) + '</button>' };
		if(currentPage + 3 <= PagesNum) { htmlPage += '<button>' + (currentPage + 3) + '</button>' };

	} else if(currentPage == PagesNum - 1 && currentPage >= 4) {
		htmlPage +=
			'<button>' + (currentPage - 3) + '</button>' +
			'<button>' + (currentPage - 2) + '</button>' +
			'<button >' + (currentPage - 1) + '</button>' +
			'<button class="ycolor">' + (currentPage) + '</button>' +
			'<button>' + (currentPage + 1) + '</button>';

	} else if(currentPage == PagesNum && currentPage >= 5) {
		htmlPage += '<button>' + (currentPage - 4) + '</button>' +
			'<button>' + (currentPage - 3) + '</button>' +
			'<button>' + (currentPage - 2) + '</button>' +
			'<button >' + (currentPage - 1) + '</button>' +
			'<button class="ycolor">' + (currentPage) + '</button>';

	} else if(currentPage == PagesNum && currentPage >= 4) {
		htmlPage += '<button>' + (currentPage - 3) + '</button>' +
			'<button>' + (currentPage - 2) + '</button>' +
			'<button >' + (currentPage - 1) + '</button>' +
			'<button class="ycolor">' + (currentPage) + '</button>';

	} else {
		if(currentPage - 2 > 0) { htmlPage += '<button>' + (currentPage - 2) + '</button>' };
		if(currentPage - 1 > 0) { htmlPage += '<button >' + (currentPage - 1) + '</button>' };
		htmlPage += '<button class="ycolor">' + (currentPage) + '</button>';
		if(currentPage < PagesNum) { htmlPage += '<button>' + (currentPage + 1) + '</button>' };
		if(currentPage + 1 < PagesNum) { htmlPage += '<button>' + (currentPage + 2) + '</button>' };
	};

	$(".pubYema").html(htmlPage);
	$(".pubAllRows").html(allPageData);
	$(".pubNowpage").html(currentPage);
	$(".pubAllpage").html(PagesNum);
	//切换数据多少条
	$(".pubSel select").unbind("change").on("change", function() {
		var num = $(".pubSel select option:selected").val();
		var aNum = $(".condition .yema1 .ycolor").html();
		fun(aNum, num);
	});
	//点击页数跳转	
	$(".pubYema button").each(function(i) {
		$(e).eq(i).unbind("click").on("click", ".pubYema button", function() {
			$(this).removeClass("ycolor");
			$(this).addClass("ycolor")
			var liNum = $(this).html();
			console.log(liNum)
			fun(liNum);
		});
	});
	//点击首页跳转
	$(".pubFirstpageWrap").unbind("click").on("click", ".pubFirstpage", function() {
		fun(1);
	});
	//点击末页跳转
	$(".pubLastpageWrap").unbind("click").on("click", ".pubLastpage", function() {
		fun(PagesNum);
	});
	//点击go跳转
	$(".pubSeachWrap").unbind("click").on("click", ".pubSeach", function() {
		var Num = 0;
		if($(".pubJogger input").val() > PagesNum) {
			$(".pubJogger input").val(PagesNum);
		}
		Num = $(".pubJogger input").val();
		if($(".pubJogger input").val() == 0) { num = 1; }
		fun(Num);
	});
};

var pubQ = pubQ || {};

pubQ.checkAuto = function() {
	if($("tbody .checked").size() == 0) {
		$("thead .check").removeClass("checked");
		return;
	}
	if($("tbody .check").size() == $("tbody .checked").size()) {
		$("thead .check").addClass("checked");
		return;
	}
	$("thead .check").removeClass("checked");
}
//div 模拟check点击事件
//thead点击全选时，tbody全部选中
pubQ.tableCheck = function() {
	$(".pubTabelSty").on("click", "thead .check", function() {
		if($("thead .checked").size() == 0) {
			$("thead .check").addClass("checked");
			$("body .check").addClass("checked");
			return;
		}
		$("thead .check").removeClass("checked");
		$("tbody .check").removeClass("checked");
	});
	$(".pubTabelSty").on("click", "tbody .check", function() {
		if($(this).hasClass("checked")) {
			$(this).removeClass("checked");
		} else {
			$(this).addClass("checked");
		}
		pubQ.checkAuto();
	});
}

pubQ.htmlNullAuto = function(num, className, html) {
	num = num || 0;
	html = html || '<img src="../../img/dataloss.png">';
	var htmlNull = '';
	htmlNull = '<tr><td class="htmlNull" colspan=' + num + '>' + html + '</td></tr>';
	$(className).html(htmlNull);
}

pubQ.alertTrue = function(content, title) {
	data.content = content || '请选择';
//	console.log(content)
	title = title || '请选择';
	$.dialog({
		id: "isTrue",
		width: 320,
		height: 100,
		title: title,
		content: "url:" + httpUrl + "page/deviceMent/alertTrue.html",
		data: data,
		max: false,
		min: false,
		lock: true,
		ok: function() {

		}
	});
}

//ajax获取
pubQ.ajaxAuto = function(oHttp, oData, fn, oType, oDataType) {
	//	console.log(oHttp + oUrl," 类型 "+oType," 数据 "+oData," 数据类型 "+oDataType)
	$.ajax({
		url: oHttp,
		type: oType || 'get',
		data: oData || '',
		dataTpye: oDataType || 'json',
		success: function(oSdata) {
			return fn(oSdata);
		}
	});
};

function tableHead(data) {
	if(!data) { return; };
	var htmlHead = '';
	htmlHead+='<tr>';
	$.each(data, function(i, oColumns) {
		var thAlign = oColumns.thAlign || 'center';
		var width = oColumns.width || '';
		htmlHead += '<td width="'+width+'" align="'+thAlign+'">' + oColumns.text + '</td>';
	});
	htmlHead+='</tr>';
	return htmlHead;
};

$.fn.tableAuto = function(data) {
	//	if (typeof options == 'string') {
	//      var method = $.fn.endTable.methods[options];
	//      if (method) {
	//          return method(this, param);
	//      }
	//  } else {
	//      opt = $.extend({}, defaults, options);
	//  }
	var eThis = this;

	if(!$(this).attr("id")) {
		var className = '.' + $(this).attr("class");
	} else {
		var className = '#' + $(this).attr("id");
	};

	var classNameHead = className + ' thead';
	var classNameBody = className + ' tbody';

	data.url;
	data.pager;
	data.data;
	data.loadEvent;
	data.columns;
	data.hNull;

	data.emptyMsg || '没有符合条件的数据~';
	data.err || '请检查网络链接~';

	var hNull = data.hNull || '--';

	var htmlBody = '';
	
	$.ajax({
		type: 'get',
		url: data.url,
		data: data.data,
		dataType: 'json',
		success: function(d) {
			tableHead(data.columns);
			for(key in d) {
				if(d[key]) {
					if(d[key] instanceof Array) {
						if(d[key].length==0){ var isOk=true; };
						$.each(d[key], function(i, vData) {
							console.log('`````````````````');
							if( vData ){
								htmlBody += '<tr>';
								$.each(data.columns, function(n, oColumns) {
									for(key in vData) {
										if(key == oColumns.name) {
											var align = oColumns.align || 'center';
											var width = oColumns.width || '';
											if(oColumns.renderer) {
												htmlBody += '<td width="'+width+'" align="'+align+'">' + oColumns.renderer(vData, vData[key]) + '</td>';
											} else {
												htmlBody += '<td width="'+width+'" align="'+align+'">' + (vData[key] || hNull) + '</td>';
											};
										};
									};
								});
								htmlBody += '</tr>';
							};
						});
					};
				};
			};

			$(classNameHead).html(tableHead(data.columns));
			$(classNameBody).html(htmlBody);
			
			if( isOk && data.columns.length != 0 ) {
				pubQ.htmlNullAuto(data.columns.length, classNameBody, data.emptyMsg);
			};
				
			if(!data.pager) { return; };
//			console.log(data.pager);
			data.pager.renderer(d);
			//分页          	 	
//			var dataAll = {};
//			dataAll.dataPage = d.objExt.currentPage; //当前页码
//			dataAll.dataCount = d.objExt.totalCount; //一共多少条数据
//			dataAll.pageNum = d.objExt.pageSize; //一页多少数据
//			dataAll.fun = DataView.loadData; //fun 方法名
//			$(data.pager.className).pageNumAuto(dataAll);
		}, 
		error: function(d) {
			$(classNameHead).html(tableHead(data.columns));
			if(data.columns.length) {
				pubQ.htmlNullAuto(data.columns.length, classNameBody, data.emptyMsg);
			};
			//      	alert('网络异常,请检查网络链接');

		}
	});
}
	

//$(".pubTabelSty").tableAuto({
//	url: gridDataUrl,
//  data: data,
//  emptyMsg: '<img src="../../img/dataloss.png">',
//  //width: "700px",
//  //loadEvent: function (data) {
//  //},
//  pager:{
//  	className:'.pubPageSty',
//  	renderer:function(d){
//  		//分页          	 	
//			var dataAll = {};
//			dataAll.dataPage = d.objExt.currentPage; //当前页码
//			dataAll.dataCount = d.objExt.totalCount; //一共多少条数据
//			dataAll.pageNum = d.objExt.pageSize; //一页多少数据
//			dataAll.fun = DataView.loadData; //fun 方法名
//			$(".pubPageSty").pageNumAuto(dataAll);
//  	}
//  },
//  columns: [
//      {
//          name: "id",
//          text: '<div class="check" data-value></div>',
//          width: "4%",
//          thAlign: "center",
//          align: "center",
//          renderer: function (row, val) {
//              var html = '<div class="check" data-value='+val+'></div>';
//              return html
//          }
//      },
//      {
//          name: "driviceName",
//          text: '设备名称',
//          thAlign: "center",
//          align: "center"
//      },
//      {
//          name: "status",
//          text: '在线状态',
//          thAlign: "center",
//          align: "center",
//          renderer:function(row,val){
//          	var html = val==0?"在线":"离线";
//          	return html;
//          }
//      },
//  ]
//});

//静止鼠标滑轮缩放
pubQ.scrollFunAuto={
	inti:function(){
		this.addEvent();
	},
	scrollFunc:function(e){
		 e=e || window.event;
		 if(e.wheelDelta && event.ctrlKey){//IE/Opera/Chrome
		  event.returnValue=false;
		 }else if(e.detail){//Firefox
		  event.returnValue=false;
	 	}
 	},
	addEvent:function(){
		// 注册事件
		var e =this;
		if(document.addEventListener){
		document.addEventListener('DOMMouseScroll',e.scrollFunc,false);
		};
		//W3C
		window.onmousewheel=document.onmousewheel=e.scrollFunc;//IE/Opera/Chrome/Safari
	}
};
pubQ.scrollFunAuto.inti();

