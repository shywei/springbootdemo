$(function () {
    loadTmt()
    $(".changetd").addClass('bg5'); // 初始化时添加背景1
    //thead点击全选时，tbody全部选中
    $(".changedata").on("click", ".changehead .changetd", function () {
        if ($("thead .changetd").attr("class") == "changetd bg5") {
            $(".changetd").attr("class", "changetd bg6");
        } else {
            $("thead .changetd").attr("class", "changetd bg5");
            $("tbody .changetd").attr("class", "changetd bg5");
        }
        //tbody点击时，单个选，当tbody全都点中时，触发thead
    });
    $(".changedata").on("click", ".changebody .changetd", function () {
        $(this).toggleClass('bg5').toggleClass('bg6'); //点中的被选中
        checkAuto00();
    });

});

$(function () {
    loadSmg()
    //	debugger
    $(".changetd1").addClass('bg3'); // 初始化时添加背景1
    //thead点击全选时，tbody全部选中
    $(".changedata1").on("click", ".changehead1 .changetd1", function () {
        if ($("thead .changetd1").attr("class") == "changetd1 bg3") {
            $(".changetd1").attr("class", "changetd1 bg4");
        } else {
            $("thead .changetd1").attr("class", "changetd1 bg3");
            $("tbody .changetd1").attr("class", "changetd1 bg3");
        }
        //tbody点击时，单个选，当tbody全都点中时，触发thead
    });
    $(".changedata1").on("click", ".changebody1 .changetd1", function () {
        $(this).toggleClass('bg3').toggleClass('bg4'); //点中的被选中
        checkAuto00();
    });

});
//点击列表/信息转换

//终端列表
$(".contentSelection .terminal").each(function (i) {
    $(".contentSelection .terminal").eq(i).on("click", function () {

        $(".contentSelection .terminal").eq(i).css("color", "#6080ed")
        $(".subject").eq(i).css("display", "block")
        $(".contentSelection .terminal").eq(!i).css("color", "black")
        $(".subject").eq(!i).css("display", "none")
        loadTmt();
        loadSmg();
    })
});
$(".contentSelection .terminal:eq(0)").click()
//点击查询
$(".search").on("click", function () {
    loadTmt();
});
//点击删除
$(".remove").on('click', function () {
    var userid = sessionStorage.getItem("sId")
    var serverid = $("tbody .bg6").parent().attr("data");
    var serverIP = $("tbody .bg6").parent().parent().find(".serverAddress").html();
    var idsNum = $("tbody .bg6").size();
    //	console.log(userid)
    var ids = ""
    //	debugger
    if (idsNum == 0) {
        ids = ""
    } else {
        $("tbody .bg6").each(function (i) {
            var id = $("tbody .bg6").eq(i).parent().attr("data");
            ids += "," + id
        })
    }
    ids = ids.slice(1, ids.length)
    if (!idsNum) {
        parent.$(".smallkuang-header span").html("删除服务器");
        parent.$(".condition .sp18").html("请选择要删除的终端地址")
        parent.$(".condition .smallkuang7").fadeIn();
        parent.$(".baohu").fadeIn();
        return;
    } else {
        $.ajax({
            type: 'get',
            url: http + 'device/deleteDevice.do',
//			url: "http://192.168.1.178:8080/ctr/device/deleteDevice.do",
            data: {
                ids: ids,
                userid: userid
            },
            dataType: 'json',
            success: function (data) {
                console.log(data)
                if (data.code == 1) {
                    parent.$(".smallkuang-header span").html("删除终端");
                    parent.$(".condition .sp18").html("删除成功！")
                    parent.$(".condition .smallkuang7").fadeIn();
                    parent.$(".baohu").fadeIn();
                    loadTmt()
                } else {
                    parent.$(".smallkuang-header span").html("删除服务器");
                    parent.$(".condition .sp18").html("操作失败！")
                    parent.$(".condition .smallkuang7").fadeIn();
                    parent.$(".baohu").fadeIn();
                    return
                }
            }
        })
    }

});

//终端修改

$(".modify").on("click", function () {
    var idsNum = $("tbody .bg6").size();
        parent.$(".smallkuang-header span").html("终端更新");
        parent.$(".terminalRegister .head span").html("终端更新");
    if (!idsNum) {
        parent.$(".condition .sp18").html("请选择要更新的终端！")
        parent.$(".condition .smallkuang7").fadeIn();
        parent.$(".baohu").fadeIn();
        return;
    } else if (idsNum > 1) {
        parent.$(".condition .sp18").html("只能更新一个终端！")
        parent.$(".condition .smallkuang7").fadeIn();
        parent.$(".baohu").fadeIn();
        return
    } else {
        var id = $("tbody .bg6").parent().attr("data");
        sessionStorage.setItem("serverid", id);
        parent.$(".terminalRegister").fadeIn();
        parent.$(".baohu3").fadeIn();
        updateDisplay()
        parent.$(".terminalRegiste-foot-S").unbind("click").on("click", function () {
            var deviceid = parent.$("#deviceid").val()//编号
            var gateway = parent.$("#gateway").val()//网关
            var areaid = parent.$("#areaid option:selected").val()//区域
            var deviceName = parent.$("#deviceName").val()//名称
            var devicePort = parent.$("#devicePort").val()//端口号
            var passWord = parent.$("#password").val()//链接密码
            var serverid = parent.$("#serverid option:selected").val()//对比服务器
            var webserverIP = parent.$("#webserverIP option:selected").html()//应用服务器
            var standbyServerIP = parent.$("#standbyServerIP option:selected").html()//备用服务器
            var deviceType = parent.$("#deviceType option:selected").val()//类型
            var deviceIP = parent.$("#deviceIP").val()//终端IP
            var pattern = parent.$("#pattern option:selected").val()//模式
            var subnetmask = parent.$("#subnetmask").val()//子网掩码
            var applicationModel = parent.$("#applicationModelName option:selected").val()//应用模式
            var functionDescription = parent.$("#functionDescription").val()//备注
            var reg = /^[0-9]+.?[0-9]*$/;
            if (!reg.test(deviceid)) {
                parent.$(".smallkuang1 .smallkuang-header span").html("终端更新");
                parent.$(".smallkuang1").show();
                parent.$(".baohu2").show();
                parent.$(".smallkuang1 .sp4").html("编号只能为数字");
                parent.$(".smallkuang1 .sel").click(function () {
                    parent.$(".smallkuang1").fadeOut();
                    parent.$(".baohu2").fadeOut();
                })
                return;
            }
            var Ipreg = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/
            if (!Ipreg.test(deviceIP)) {
                parent.$(".smallkuang1").show();
                parent.$(".baohu2").show();
                parent.$(".smallkuang1 .sp4").html("请输入正确终端IP");
                parent.$(".smallkuang1 .sel").click(function () {
                    parent.$(".smallkuang1").fadeOut();
                    parent.$(".baohu2").fadeOut();
                })
                return;
            }
//			console.log(applicationModel)
            $.ajax({
                dataType: 'JSON',
                type: 'get',
                url: http + "device/updateDevice",
//				url:"http://192.168.1.178:8080/ctr/device/updateDevice",
                data: {
                    id: id,
                    deviceid: deviceid,
                    gateway: gateway,
                    areaid: areaid,
                    deviceName: deviceName,
                    devicePort: devicePort,
                    password: passWord,
                    serverid: serverid,
                    webserverIP: webserverIP,
                    standbyServerIP: standbyServerIP,
                    deviceType: deviceType,
                    deviceIP: deviceIP,
                    pattern: pattern,
                    subnetmask: subnetmask,
                    applicationModel: applicationModel,
                    operationPersonnel: sessionStorage.sName,
                    deptid: sessionStorage.sUserDept
                },
                success: function (data) {
                    console.log(serverid)
                    parent.$(".smallkuang1 .sp4").html(data.message);
                    parent.$(".smallkuang1").show();
                    parent.$(".baohu2").show();
                    if (data.code < 0) {
                        parent.$(".smallkuang1 .sel").unbind("click").click(function () {
                            parent.$(".smallkuang1").fadeOut();
                            parent.$(".baohu2").fadeOut();
                        })
                    } else {
                        parent.$(".smallkuang1 .sel").unbind("click").click(function () {
                            parent.$(".smallkuang1").fadeOut();
                            parent.$(".baohu2").fadeOut();
                            parent.$(".baohu3").fadeOut();
                            parent.$(".terminalRegister").fadeOut();
                            loadTmt();
                        })

                    }


                }
            })
        })


    }

});

//终端更新
function updateDisplay() {
    var serverid = sessionStorage.getItem("serverid")
    $.ajax({
        dataType: 'JSON',
        type: 'get',
        url: http + "device/singleDevice",
//		url:"http://192.168.1.178:8080/ctr/device/singleDevice",
        data: {
            id: serverid
        },
        success: function (data) {
            parent.$("#deviceid").val(data.obj.deviceid)//编号
            parent.$("#deviceName").val(data.obj.deviceName)//名称
            parent.$("#areaid option[value=" + data.obj.areaid + "]").attr("selected", true)//区域
            parent.$("#devicePort").val(data.obj.devicePort)//端口号
            parent.$("#subnetmask").val(data.obj.subnetmask)//子网掩码
            parent.$("#deviceIP").val(data.obj.deviceIP)//终端IP
            parent.$("#gateway").val(data.obj.gateway)//网关
            parent.$("#password").val(data.obj.password)//链接密码
            parent.$("#serverid option[value=" + data.obj.serverid + "]").attr("selected", true)//对比服务器
            parent.$("#deviceType option[value=" + data.obj.deviceType + "]").attr("selected", true)//类型
            parent.$("#pattern option[value=" + data.obj.pattern + "]").attr("selected", true)//模式
            for (var i = 0; i < parent.$("#webserverIP option").length; i++) {
                if (parent.$("#webserverIP option").eq(i).html() == data.obj.webserverIP) {
                    parent.$("#webserverIP option").eq(i).attr("selected", true)
                }
            }//webserverIP应用
            for (var i = 0; i < parent.$("#standbyServerIP option").length; i++) {
                if (parent.$("#standbyServerIP option").eq(i).html() == data.obj.standbyServerIP) {
                    parent.$("#standbyServerIP option").eq(i).attr("selected", true)
                }
            }//standbyServerIP备用
            parent.$("#applicationModelName option[value=" + data.obj.applicationModel + "]").attr("selected", true)//类型
            parent.$("#functionDescription").val(data.obj.functionDescription)
        }
    })
}


//查询列表
function loadTmt(page) {
    $("thead .changetd").attr("class", "changetd bg5")
    page = page || '1';
    row = $(".sel select option:selected").val() || '10';

    $.ajax({
        url: http + 'device/queryDevice.do',
//		url: "http://192.168.1.178:8080/ctr/device/queryDevice.do",
        data: {
            pageNo: page,
            pageSize: row,
            deviceName: $(".terminalName").val(),
            deviceIP: $(".ipAdress").val()
        },
        type: 'get',
        dataStype: 'json',
        success: function (data) {
            console.log(data)
            if (data.obj.results.length == 0) {
                var html = '';
                html = `
					<tr class="changetr">
	                    	<td class="deviceid" colspan='9'><img src="img/dataloss.png"></img></td>
	                    </tr>
				`;
            } else {
                var html = '';
                var len = data.obj.results.length
                for (i = 0; i < len; i++) {
                    if (data.obj.results[i].deviceType == 1) {
                        deviceType = '考勤机'
                    } else {
                        deviceType = '一体机'
                    }
                    if (data.obj.results[i].createtime != null) {
                        var createtime = data.obj.results[i].createtime.slice(0, 19)
                    } else {
                        var createtime = ""
                    }
                    if (data.obj.results[i].modifytime != null) {
                        var modifytime = data.obj.results[i].modifytime.slice(0, 19)
                    } else {
                        var modifytime = ""
                    }

                    html += `
					<tr class="changetr">
                    	<td class="deviceid" data="${data.obj.results[i].deviceid}"><div class="changetd bg5"></div></td>
                        <td class="deviceNumber">${data.obj.results[i].deviceName}</td>
                        <td class="serverType">${deviceType}</td>
                        <td class="serverAddress">${data.obj.results[i].deviceIP}</td>
                        <td class="serverStatus">${data.obj.results[i].devicePort}</td>
                        <td class="serverid">${data.message}</td>
                        <td class="isSpare">${data.obj.results[i].areaName}</td>
                        <td class="creationTime">${createtime}</td>
                        <td class="modifyTime">${modifytime}</td>
                    </tr>
				`;
                }
            }
            $(".changebody").html(html);

            var dangqian = parseInt(data.obj.page.currentPage) / 1; //当前页码
            var userstotal = data.obj.page.totalCount; //一共多少条数据
            var rows = data.obj.page.pageSize; //一页多少数据
            var yeshu = Math.ceil(userstotal / rows);
            if (yeshu == 0) {
                yeshu = 1;
            }
            var html1 = '';
            if (dangqian == 1) {
                if (dangqian <= yeshu) {
                    html1 += `<li class="ycolor">${dangqian}</li>`;
                }
                if (dangqian + 1 <= yeshu) {
                    html1 += `<li>${dangqian + 1}</li>`;
                }
                if (dangqian + 2 <= yeshu) {
                    html1 += `<li>${dangqian + 2}</li>`;
                }
                if (dangqian + 3 <= yeshu) {
                    html1 += `<li>${dangqian + 3}</li>`;
                }
                if (dangqian + 4 <= yeshu) {
                    html1 += `<li>${dangqian + 4}</li>`;
                }
            } else if (dangqian == 2) {
                html1 += `<li>${dangqian - 1}</li>`;
                html1 += `<li class="ycolor">${dangqian}</li>`;

                if (dangqian + 1 <= yeshu) {
                    html1 += `<li>${dangqian + 1}</li>`;
                }
                if (dangqian + 2 <= yeshu) {
                    html1 += `<li>${dangqian + 2}</li>`;
                }
                if (dangqian + 3 <= yeshu) {
                    html1 += `<li>${dangqian + 3}</li>`;
                }
            } else if (dangqian == yeshu && dangqian >= 5) {
                html1 += `
				<li>${dangqian - 4}</li>

				<li>${dangqian - 3}</li>

				<li>${dangqian - 2}</li>

				<li >${dangqian - 1}</li>
				<li class="ycolor">${dangqian}</li>
				`
            } else if (dangqian == yeshu - 1 && dangqian >= 5) {
                html1 += `
				<li>${dangqian - 3}</li>

				<li>${dangqian - 2}</li>

				<li>${dangqian - 1}</li>

				<li class="ycolor">${dangqian}</li>
				<li>${dangqian + 1}</li>
				`
            } else {
                if (dangqian - 2 > 0) {
                    html1 += `<li>${dangqian - 2}</li>`;
                }
                if (dangqian - 1 > 0) {
                    html1 += `<li>${dangqian - 1}</li>`;
                }
                html1 += `<li class="ycolor">${dangqian}</li>`;
                if (dangqian < yeshu) {
                    html1 += `<li>${dangqian + 1}</li>`;
                }
                if (dangqian + 1 < yeshu) {
                    html1 += `<li>${dangqian + 2}</li>`;
                }
            }
            $("ul.yema").html(html1);
            $(".look .allpeople").html(userstotal);
            $(".look .nowpage").html(dangqian);
            $(".look .allpage").html(yeshu);

            //切换数据多少条
            $(".sel select").unbind("change").on("change", function () {
                var num = $(".sel select option:selected").val();
                var aNum = 1;
                loadTmt(aNum, num);
            });

            //点击页数跳转
            $(".terminalList .yema li").each(function (i) {
                $(".terminalList .yema li").on("click", function () {
                    $(this).removeClass("ycolor");
                    $(this).addClass("ycolor")
                    var liNum = $(this).html();
                    loadTmt(liNum);
                });
            });

            //点击首页跳转
            $(".terminalList .firstpage").on("click", function () {
                loadTmt(1);
            });

            //点击末页跳转
            $(".terminalList").unbind("click").on("click", ".lastpage", function () {
                loadTmt(yeshu);
            });

            //点击go跳转
            $(".terminalList").on("click", ".jogger .tiaozhuan", function () {
                var Num = 0;
                if ($(".jogger input").val() > yeshu) {
                    $(".jogger input").val(yeshu);
                }
                Num = $(".terminalList .jogger input").val();
                $(".terminalList .jogger .tiaozhuan").unbind("click");
                loadTmt(Num);
            });
        }
    });
}


//终端状态

//终端状态查询列表
function loadSmg(page) {
    $("thead .changetd").attr("class", "changetd bg3")
    page = page || '1';
    row = $(".sel1 select option:selected").val() || '10';
    $.ajax({
        url: http + 'device/quertDeviceStateList',
//		url: "http://192.168.1.178:8080/ctr/device/quertDeviceStateList",
        data: {
            page: page,
            rows: row,
            deviceName: $(".terminalName1").val(),
            deviceIP: $(".operationResult1").val()
        },
        type: 'get',
        dataStype: 'json',
        success: function (data) {
//			console.log(data)
            if (data.obj.length == 0) {
                var html = '';
                html = `
					<tr class="changetr1">
	                    	<td class="deviceid1" colspan='9'><img src="img/dataloss.png"></img></td>
	                    </tr>
				`;
            } else {
                var html = '';
                var len = data.obj.length
                for (i = 0; i < len; i++) {
                    if (data.obj[i].connectionStatus == 1) {
                        connectionStatus = '连接丢失'
                    } else {
                        connectionStatus = '连接正常'
                    }
                    if (data.obj[i].deviceType == 1) {
                        deviceType = '考勤机'
                    } else {
                        deviceType = '一体机'
                    }
                    if (data.obj[i].modifytime != null) {
                        var modifytime1 = data.obj[i].modifytime.slice(0, 19)
                    } else {
                        var modifytime1 = ""
                    }

                    html += `
					<tr class="changetr1">
                    	<td class="deviceid1" data="${data.obj[i].deviceid}"><div class="changetd1 bg3"></div></td>
                        <td class="deviceNumber1">${data.obj[i].deviceName}</td>
                        <td class="deviceType1">${deviceType}</td>
                        <td class="deviceIP1">${data.obj[i].deviceIP}</td>
                        <td class="operatorType1">${data.obj[i].operatorType}</td>
                        <td class="operatorResult1">${data.obj[i].operatorResult}</td>
                        <td class="modifyTime1">${modifytime1}</td>
                        <td class="connectionStatus">${connectionStatus}</td>
                        <td class="operation1" onclick="details(${data.obj[i].deviceid})">详情</td>
                    </tr>
				`;
                }
            }
            $(".changebody1").html(html);

            var dangqian = parseInt(data.objExt.currentPage) / 1; //当前页码
            var userstotal = data.objExt.totalCount; //一共多少条数据
            var rows = data.objExt.pageSize; //一页多少数据
            var yeshu = Math.ceil(userstotal / rows);
            if (yeshu == 0) {
                yeshu = 1;
            }
            var html1 = '';
            if (dangqian == 1) {
                if (dangqian <= yeshu) {
                    html1 += `<li class="ycolor1">${dangqian}</li>`;
                }
                if (dangqian + 1 <= yeshu) {
                    html1 += `<li>${dangqian + 1}</li>`;
                }
                if (dangqian + 2 <= yeshu) {
                    html1 += `<li>${dangqian + 2}</li>`;
                }
                if (dangqian + 3 <= yeshu) {
                    html1 += `<li>${dangqian + 3}</li>`;
                }
                if (dangqian + 4 <= yeshu) {
                    html1 += `<li>${dangqian + 4}</li>`;
                }
            } else if (dangqian == 2) {
                html1 += `<li>${dangqian - 1}</li>`;
                html1 += `<li class="ycolor1">${dangqian}</li>`;

                if (dangqian + 1 <= yeshu) {
                    html1 += `<li>${dangqian + 1}</li>`;
                }
                if (dangqian + 2 <= yeshu) {
                    html1 += `<li>${dangqian + 2}</li>`;
                }
                if (dangqian + 3 <= yeshu) {
                    html1 += `<li>${dangqian + 3}</li>`;
                }
            } else if (dangqian == yeshu && dangqian >= 5) {
                html1 += `
				<li>${dangqian - 4}</li>

				<li>${dangqian - 3}</li>

				<li>${dangqian - 2}</li>

				<li >${dangqian - 1}</li>
				<li class="ycolor1">${dangqian}</li>
				`
            } else if (dangqian == yeshu - 1 && dangqian >= 5) {
                html1 += `
				<li>${dangqian - 3}</li>

				<li>${dangqian - 2}</li>

				<li>${dangqian - 1}</li>

				<li class="ycolor1">${dangqian}</li>
				<li>${dangqian + 1}</li>
				`
            } else {
                if (dangqian - 2 > 0) {
                    html1 += `<li>${dangqian - 2}</li>`;
                }
                if (dangqian - 1 > 0) {
                    html1 += `<li>${dangqian - 1}</li>`;
                }
                html1 += `<li class="ycolor1">${dangqian}</li>`;
                if (dangqian < yeshu) {
                    html1 += `<li>${dangqian + 1}</li>`;
                }
                if (dangqian + 1 < yeshu) {
                    html1 += `<li>${dangqian + 2}</li>`;
                }
            }
            $("ul.yema1").html(html1);
            $(".look1 .allpeople1").html(userstotal);
            $(".look1 .nowpage1").html(dangqian);
            $(".look1 .allpage1").html(yeshu);

            //切换数据多少条
            $(".terminalList1 .sel1 select").unbind("change").on("change", function () {
                var num = $(".sel1 select option:selected").val();
                var aNum = $(".terminalList1 .yema1 .ycolor1").html();
                loadSmg(aNum, num);
            });

            //点击页数跳转
            $(".terminalList1 .yema1 li").each(function (i) {
                $(".terminalList1 .yema1 li").on("click", function () {
                    $(this).removeClass("ycolor1");
                    $(this).addClass("ycolor1")
                    var liNum = $(this).html();
                    loadSmg(liNum);
                });
            });

            //点击首页跳转
            $(".terminalList1 .firstpage1").on("click", function () {
                loadSmg(1);
            });

            //点击末页跳转
            $(".terminalList1").unbind("click").on("click", ".lastpage1", function () {
                loadSmg(yeshu);
            });

            //点击go跳转
            $(".terminalList1").on("click", ".jogger1 .tiaozhuan1", function () {
                var Num = 0;
                if ($(".jogger1 input").val() > yeshu) {
                    $(".jogger1 input").val(yeshu);
                }
                Num = $(".terminalList1 .jogger1 input").val();
                $(".terminalList1 .jogger1 .tiaozhuan1").unbind("click");
                loadSmg(Num);
            });
        }
    });
}
$(".search1").on("click", function () {
    loadSmg();
});
//时间同步
$(".modify1").on("click", function () {
    var userid = sessionStorage.getItem("sId")
    var serverid = $("tbody .bg4").parent().attr("data");
    var idsNum = $("tbody .bg4").size();
    if (!idsNum) {
        parent.$(".smallkuang-header span").html("时间同步");
        parent.$(".condition .sp18").html("请选择要同步的终端！")
        parent.$(".condition .smallkuang7").fadeIn();
        parent.$(".baohu").fadeIn();
        return;
    } else if (idsNum > 1) {
        parent.$(".smallkuang-header span").html("时间同步");
        parent.$(".condition .sp18").html("只能同步一个终端！")
        parent.$(".condition .smallkuang7").fadeIn();
        parent.$(".baohu").fadeIn();
        return
    } else {
        $.ajax({
            url: http + 'device/setDeviceTime.do',
//			url: "http://192.168.1.178:8080/ctr/device/setDeviceTime.do",
            data: {
                id: serverid,
                userid: userid
            },
            type: 'get',
            dataStype: 'json',
            success: function (data) {
//				console.log(data)
                if (data.code == 1) {
                    parent.$(".smallkuang-header span").html("时间同步");
                    parent.$(".condition .sp18").html("同步成功！")
                    parent.$(".condition .smallkuang7").fadeIn();
                    parent.$(".baohu").fadeIn();
                    loadSmg();
                } else {
                    parent.$(".smallkuang-header span").html("时间同步");
                    parent.$(".condition .sp18").html("同步失败！")
                    parent.$(".condition .smallkuang7").fadeIn();
                    parent.$(".baohu").fadeIn();
                    return
                }
            }
        })
    }
});

//终端重启
$(".remove1").on("click", function () {
    var userid = sessionStorage.getItem("sId")
    var serverid = $("tbody .bg4").parent().attr("data");
    var idsNum = $("tbody .bg4").size();
    if (!idsNum) {
        parent.$(".smallkuang-header span").html("终端重启");
        parent.$(".condition .sp18").html("请选择要重启的终端！")
        parent.$(".condition .smallkuang7").fadeIn();
        parent.$(".baohu").fadeIn();
        return;
    } else if (idsNum > 1) {
        parent.$(".smallkuang-header span").html("终端重启");
        parent.$(".condition .sp18").html("只能重启一个终端！")
        parent.$(".condition .smallkuang7").fadeIn();
        parent.$(".baohu").fadeIn();
        return
    } else {
        $.ajax({
            url: http + 'device/restartDevice.do',
//			url: "http://192.168.1.178:8080/ctr/device/restartDevice.do",
            data: {
                id: serverid,
                userid: userid
            },
            type: 'get',
            dataStype: 'json',
            success: function (data) {
//				console.log(data)
                if (data.code == 1) {
                    parent.$(".smallkuang-header span").html("终端重启");
                    parent.$(".condition .sp18").html("重启成功！")
                    parent.$(".condition .smallkuang7").fadeIn();
                    parent.$(".baohu").fadeIn();
                    loadSmg();
                } else {
                    parent.$(".smallkuang-header span").html("终端重启");
                    parent.$(".condition .sp18").html("重启失败！")
                    parent.$(".condition .smallkuang7").fadeIn();
                    parent.$(".baohu").fadeIn();
                    return
                }
            }
        })
    }
});

//
function details(e) {
    sessionStorage.setItem("serverid", e);
    //禁用所有下拉框和input
    parent.$(".terminalFL input").attr("disabled", "disabled");
    parent.$(".terminalFL select").attr("disabled", "disabled");
    parent.$(".terminalRegister-message textarea").attr("disabled", "disabled");
    parent.$(".terminalRegiste-foot-S").hide()
    parent.$(".terminalRegiste-foot-C").hide()
    parent.$(".terminalRegister").fadeIn();
    parent.$(".baohu3").fadeIn();
    updateDisplay()

}

//终端信息远程开门
$(".openDoor").unbind("click").on("click", function () {

    var userid = sessionStorage.getItem("sId")
    var serverid = $("tbody .bg4").parent().attr("data");
    var idsNum = $("tbody .bg4").size();
    if (!idsNum) {
        parent.$(".smallkuang-header span").html("远程开门");
        parent.$(".condition .sp18").html("请选择终端！")
        parent.$(".condition .smallkuang7").fadeIn();
        parent.$(".baohu").fadeIn();
        return;
    } else if (idsNum > 1) {
        parent.$(".smallkuang-header span").html("远程开门");
        parent.$(".condition .sp18").html("只能选择一个终端！")
        parent.$(".condition .smallkuang7").fadeIn();
        parent.$(".baohu").fadeIn();
        return
    } else {
        $.ajax({
            url: http + 'openDoorController/remoteOpenDoor',
            data: {
                id: serverid,
                userid: userid
            },
            type: 'get',
            dataStype: 'json',
            success: function (data) {

                parent.$(".smallkuang-header span").html("远程开门");
                parent.$(".condition .sp18").html(data.message)
                parent.$(".condition .smallkuang7").fadeIn();
                parent.$(".baohu").fadeIn();
            }
        })
    }


})

//终端查看信息
$(".lookM").unbind("click").on("click", function (){
    var userid = sessionStorage.getItem("sId")
    var serverid = $("tbody .bg4").parent().attr("data");
    var idsNum = $("tbody .bg4").size();
    if (!idsNum) {
        parent.$(".smallkuang-header span").html("查看信息");
        parent.$(".condition .sp18").html("请选择终端！")
        parent.$(".condition .smallkuang7").fadeIn();
        parent.$(".baohu").fadeIn();
        return;
    } else if (idsNum > 1) {
        parent.$(".smallkuang-header span").html("查看信息");
        parent.$(".condition .sp18").html("只能选择一个终端！")
        parent.$(".condition .smallkuang7").fadeIn();
        parent.$(".baohu").fadeIn();
        return
    } else {
        $.ajax({
            dataType: 'JSON',
            type: 'get',
            url: http + "device/singleDevice",
            data: {
                id: serverid
            },
            success: function (data) {
                console.log(data)
                var remoteIP=data.obj.deviceIP
                var port=data.obj.devicePort;
                var confirmNum=data.obj.deviceid
                var confirmType=data.obj.deviceType
                var confirmModel=0;
                var confirmPasswd=data.obj.password;
                $.ajax({
                    url: http + 'userInfoSaveController/getTerminalInfo',
                    data: {
                        remoteIP:remoteIP,
                        port:port,
                        confirmNum:confirmNum,
                        confirmType:confirmType,
                        confirmModel:0,
                        confirmPasswd:confirmPasswd
                    },
                    type: 'get',
                    dataStype: 'json',
                    success: function (data) {
                        console.log(remoteIP)
                        console.log(port)
                        console.log(confirmNum)
                        console.log(confirmType)
                        console.log(confirmPasswd)
                        loadSmg();
                    }
                })
            }
        })
   }
})

//终端状态
$(".terminaState").unbind("click").on("click", function (){
    var userid = sessionStorage.getItem("sId")
    var serverid = $("tbody .bg4").parent().attr("data");
    var idsNum = $("tbody .bg4").size();
    if (!idsNum) {
        parent.$(".smallkuang-header span").html("终端状态");
        parent.$(".condition .sp18").html("请选择终端！")
        parent.$(".condition .smallkuang7").fadeIn();
        parent.$(".baohu").fadeIn();
        return;
    } else if (idsNum > 1) {
        parent.$(".smallkuang-header span").html("终端状态");
        parent.$(".condition .sp18").html("只能选择一个终端！")
        parent.$(".condition .smallkuang7").fadeIn();
        parent.$(".baohu").fadeIn();
        return
    } else {
        $.ajax({
            dataType: 'JSON',
            type: 'get',
            url: http + "getDeviceStateController/getDeviceState",
            data: {
                currentId: userid,
                confirmNum:serverid

            },
            success: function (data) {
                console.log(data)
                parent.$(".smallkuang-header span").html("终端状态");
                parent.$(".condition .sp18").html(data.message)
                parent.$(".condition .smallkuang7").fadeIn();
                parent.$(".baohu").fadeIn();

            }
        })



    }
})