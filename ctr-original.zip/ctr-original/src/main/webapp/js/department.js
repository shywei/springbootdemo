/**
 * Created by Super-Man on 2017/8/28.
 */
var http="";
 //http = "http://192.168.1.124:8080/ctr/";

if (!sessionStorage['sId']) {
    location.href = 'Login.html';
}
AddView = {
    init: function () {
        //加载数据
        this.doDepartmentSelect();
        this.doDepartmentSearch();
        this.DepartmentSearch();
        this.doAddDepartment();
        this.doCloseDepartment();
        this.doHide();
    },
    //事件公共方法
    DepartmentSearch: function (a, b, c, d) {
        if (!c) {
            c = '';
        }
        if (!d) {
            d = '';
        }
        $.ajax({
            dataType: 'JSON',
            type: 'POST',
            url: http + "departmentController/queryDeptList",
            data: {page: a, rows: b, deptName: c, superDeptName: d, single: -1},
            jsonp: 'callback',
            success: function (data) {
                console.log(data)
                var dangqian = data.objExt.currentPage / 1;
                var zongshu = data.objExt.totalCount / 1;
                var yeshu = data.objExt.pageCount / 1;
                if (yeshu == 0) {
                    yeshu = 1;
                }
                var loginMax1 = yeshu;
                $(".operationDateChoseCrb .mainpart tbody").empty();

                var len = data.obj.length;
                var html = '';

                if (data.obj.length > 0) {
                    for (var i = 0; i < len; i++) {
                        var superDeptName = data.obj[i].superDeptName || "--";
                        var createtime = data.obj[i].createtime || "--";
                        var modifytime = data.obj[i].modifytime || "--";
                        html += ' <tr> <td>' + data.obj[i].deptid + '</td> <td class="deptNameAjax">' + data.obj[i].deptName + '</td><td>' + superDeptName + '</td> <td>' + createtime + '</td> <td>' + modifytime + '</td> <td class="department-detail"><i onclick="AddView.alertDetail(' + data.obj[i].deptid + ')">修改</i>&nbsp;| <i onclick="AddView.deleteDetail(' + data.obj[i].deptid + ')">删除</i></td> </tr>'
                    }
                } else {
                    html += ' <tr class="datalosslist"> <td colspan="6"><img src="img/dataloss.png" alt=""  /></td> </tr> '
                }
                $(".departmentContain table tbody").html(html);
                $(".jogger span.allpeople").html(zongshu);
                $(".jogger span.nowpage").html(dangqian);
                $(".jogger span.allpage").html(yeshu);
                var html1 = '';
                if (dangqian == 1) {
                    if (dangqian <= yeshu) {
                        html1 += `<li class="ycolor">${dangqian}</li>`;
                    }
                    if (dangqian + 1 <= yeshu) {
                        html1 += `<li>${dangqian + 1}</li>`;
                    }
                    if (dangqian + 2 <= yeshu) {
                        html1 += `<li>${dangqian + 2}</li>`;
                    }
                    if (dangqian + 3 <= yeshu) {
                        html1 += `<li>${dangqian + 3}</li>`;
                    }
                    if (dangqian + 4 <= yeshu) {
                        html1 += `<li>${dangqian + 4}</li>`;
                    }
                } else if (dangqian == 2) {
                    html1 += `<li>${dangqian - 1}</li>`;
                    html1 += `<li class="ycolor">${dangqian}</li>`;

                    if (dangqian + 1 <= yeshu) {
                        html1 += `<li>${dangqian + 1}</li>`;
                    }
                    if (dangqian + 2 <= yeshu) {
                        html1 += `<li>${dangqian + 2}</li>`;
                    }
                    if (dangqian + 3 <= yeshu) {
                        html1 += `<li>${dangqian + 3}</li>`;
                    }
                } else if (dangqian == yeshu && dangqian >= 5) {
                    html1 += `
                <li>${dangqian - 4}</li>

                    <li>${dangqian - 3}</li>

                    <li>${dangqian - 2}</li>

                    <li >${dangqian - 1}</li>
                    <li class="ycolor">${dangqian}</li>
						`
                } else if (dangqian == yeshu - 1 && dangqian >= 5) {
                    html1 += `
                <li>${dangqian - 3}</li>

                    <li>${dangqian - 2}</li>

                    <li>${dangqian - 1}</li>

                    <li class="ycolor">${dangqian}</li>
                        <li>${dangqian + 1}</li>
						`
                } else {
                    if (dangqian - 2 > 0) {
                        html1 += `<li>${dangqian - 2}</li>`;
                    }
                    if (dangqian - 1 > 0) {
                        html1 += `<li>${dangqian - 1}</li>`;
                    }
                    html1 += `<li class="ycolor">${dangqian}</li>`;
                    if (dangqian < yeshu) {
                        html1 += `<li>${dangqian + 1}</li>`;
                    }
                    if (dangqian + 1 < yeshu) {
                        html1 += `<li>${dangqian + 2}</li>`;
                    }
                }
                $(".yema ").html(html1);
                //分页点击查询
                $(".yema li").on("click", function (e) {
                    var deptName = $(".deptName").val();
                    var superDeptName = $(".superDeptName").val();
                    var pageSize = $("#sel-P").val();
                    AddView.DepartmentSearch(e.target.innerHTML, pageSize, deptName, superDeptName);
                    $(".yema li").removeClass("ycolor");
                    $(this).addClass("ycolor");
                })
                //点击首页
                $(".firstpage").click(function () {
                    var page = $(".look .nowpage").html();
                    if (page != 1) {
                        var deptName = $(".deptName").val();
                        var superDeptName = $(".superDeptName").val();
                        var pageSize = $("#sel-P").val();
                        AddView.DepartmentSearch(1, pageSize, deptName, superDeptName);
                    }
                })
                //点击末页
                $(".lastpage").click(function (e) {
                    var lastPage = $(".look .allpage").html();
                    var page = $(".look .nowpage").html();
                    if (page != lastPage) {
                        var deptName = $(".deptName").val();
                        var superDeptName = $(".superDeptName").val();
                        var pageSize = $("#sel-P").val();
                        //var
                        AddView.DepartmentSearch(lastPage, pageSize, deptName, superDeptName);
                    }
                })
                //分页onchange事件
                $("#sel-P").change(function () {
                    //var num = $("div.footDiv div.jogger select").val();
                    var deptName = $(".deptName").val();
                    var superDeptName = $(".superDeptName").val();
                    var pageSize = $("#sel-P").val();
                    AddView.DepartmentSearch(1, pageSize, deptName, superDeptName);
                    $("div.jogger input").val("");
                    $("div.jogger1 input").val("");
                })
                //输入页数跳转
                $(".tiaozhuan").click(function (e) {
                    var page = $(".look .nowpage").html();
                    e.preventDefault();
                    var b = yeshu;
                    var lastpage=$(".allpage").html()
                    var a = $("div.jogger input").val();
                    if (a != page) {
                        if (a / 1 > b / 1) {

                            $("div.jogger input").val(lastpage);
                            AddView.DepartmentSearch(lastpage, pageSize, deptName, superDeptName);
                            return;
                        }
                        if (a == '') {
                            return;
                        }
                        var deptName = $(".deptName").val();
                        var superDeptName = $(".superDeptName").val();
                        var pageSize = $("#sel-P").val();


                    }
                })
            }
        });
    },
    //列表查询
    doDepartmentSearch: function () {
        $(".toppart .search").on("click", function () {
            var deptName = $(".deptName").val();
            var superDeptName = $(".superDeptName").val();
            var pageSize = $("#sel-P").val();
            AddView.DepartmentSearch(1, pageSize, deptName, superDeptName);
        });

    },
    //弹出框点击差号
    doHide: function () {
        parent.$(".head a").unbind("click").on("click", function () {
            parent.$("#department").fadeOut();
            parent.$(".baohu").fadeOut();
        });
    },
    //部门下拉框获取
    doDepartmentSelect: function () {
        $.ajax({
            dataType: 'JSON',
            type: 'POST',
            url: http + "departmentController/queryDeptList",
            success: function (data) {
                var len = data.obj.length;
                var html = '<option value="">请选择</option>';
                for (var i = 0; i < len; i++) {
                    html += '<option value="' + data.obj[i].deptid + '">' + data.obj[i].deptName + '</option>'
                }
                parent.$(".superDepartmentS").html(html);
            }
        })
        function alertDetail(e) {
            parent.$(".departmentContain>span").html("");
            parent.$("#department").fadeIn();
            parent.$(".baohu").fadeIn();
            var currentId = sessionStorage.sId;
            var deptName = parent.$(".departmentContain .department-deptName").val();
            var superid = parent.$(".superDepartmentS option:selected").val();
            $.ajax({
                dataType: 'JSON',
                type: 'POST',
                url: http + "departmentController/queryDeptList",
                data: {deptid: e},
                success: function (data) {
                    console.log(data);
                    parent.$(".departmentContain .department-deptName").val(data.obj[0].deptName);
                    document.getElementById("superDepartmentS").value = data.obj[0].deptid || "";
                }
            })
        }
    },
    //点击添加部门
    doAddDepartment: function () {
        $(".addDepartment").on("click", function () {
            parent.$(".departmentContain>span").html("");
            parent.$("#department .head span").html("添加部门");
            parent.$(".departmentContain .department-deptName").val("");
            parent.$("#department").fadeIn();
            parent.$(".baohu").fadeIn();
            //确定添加
            parent.$(".department-S").unbind("click").on("click", function () {
                var currentId = sessionStorage.sId;
                var deptName = parent.$(".departmentContain .department-deptName").val();
                var superid = parent.$(".superDepartmentS option:selected").val();
                if (deptName == "") {
                    parent.$(".departmentContain>span").html("请填写部门名称！");
                    return;
                } else {
                    $.ajax({
                        url: http + "departmentController/saveDept",
                        dataType: 'JSON',
                        type: 'POST',
                        data: {currentId: currentId, deptName: deptName, superid: superid},
                        success: function (data) {
                            console.log(data)
                            if (data.code <= 0) {
                                parent.$(".departmentContain>span").html(data.message);
                                return;
                                return;

                            } else {
                                parent.$("#department").fadeOut();
                                parent.$(".baohu").fadeOut();
                                AddView.DepartmentSearch(1, 10);
                            }
                        }
                    })
                }

            })

        })
    },
    //修改
    alertDetail: function (e) {
        parent.$(".departmentContain>span").html("");
        parent.$("#department .head span").html("修改部门");
        parent.$("#department").fadeIn();
        parent.$(".baohu").fadeIn();
        AddView.doCloseDepartment();
        AddView.doHide();
        $.ajax({
            dataType: 'JSON',
            type: 'POST',
            url: http + "departmentController/queryDeptList",
            data: {deptid: e},
            success: function (data) {
                parent.$(".departmentContain .department-deptName").val(data.obj[0].deptName);
                parent.document.getElementById("superDepartmentS").value = data.obj[0].superid || "";
            }
        })
        //确定修改
        parent.$(".department-S").unbind("click").on("click", function () {
            var currentId = sessionStorage.sId;
            var deptName = parent.$(".departmentContain .department-deptName").val();
            var superid = parent.$(".superDepartmentS option:selected").val();
            var deptid = e;
            if (deptName == "") {
                parent.$(".departmentContain>span").html("请填写部门名称！");
                return;
            } else {
                $.ajax({
                    url: http + "departmentController/saveDept",
                    dataType: 'JSON',
                    type: 'POST',
                    data: {currentId: currentId, deptName: deptName, superid: superid, deptid: deptid},
                    success: function (data) {
                        if (data.code <= 0) {
                            parent.$(".departmentContain>span").html(data.message);
                            return;
                            return;

                        } else {
                            parent.$("#department").fadeOut();
                            parent.$(".baohu").fadeOut();
                            AddView.DepartmentSearch(1, 10);
                        }
                    }
                })
            }

        })
    },
    //删除
    deleteDetail: function (e) {
        parent.$(".smallkuang1 .sel").show();
        parent.$(".smallkuang1 .smallkuang-header a").show();
        parent.$(".smallkuang1 .sp99").html(" ");
        parent.$(".smallkuang1 .smallkuang-header span").html("删除部门");
        parent.$(".smallkuang1").fadeIn();
        parent.$(".baohu").fadeIn();
        parent.$(".smallkuang1 .sp4").html("确定删除此部门？");
        parent.$(".smallkuang1 .sel").unbind("click").click(function () {
            var currentId = sessionStorage.sId;
            $.ajax({
                dataType: 'JSON',
                type: 'POST',
                url: http + "departmentController/delDept",
                data: {deptid: e, currentId: currentId},
                success: function (data) {
                    var mun = 5;
                    parent.$(".smallkuang1 .sel").hide();
                    parent.$(".smallkuang1 .smallkuang-header a").hide();

                    parent.$(".smallkuang1 .sp4").html(data.message+"("+mun+"后自动关闭)");
                    var int= setInterval(function () {
                        mun--;
                        parent.$(".smallkuang1 .sp4").html(data.message+"("+mun+"后自动关闭)");
                       if (mun == 1) {
                           clearInterval(int)
                           parent.$(".smallkuang1").fadeOut();
                           parent.$(".baohu").fadeOut();
                           AddView.DepartmentSearch(1, 10);
                           mun = 5;
                       }
                   }, 1000);
                }
            })
        })
    },
    //取消按钮（添加修改）
    doCloseDepartment: function () {
        parent.$(".department-C").unbind("click").on("click", function () {
            parent.$("#department").fadeOut();
            parent.$(".baohu").fadeOut();
        });
    }
}
AddView.init();
AddView.doCloseDepartment();
AddView.doHide();


var scrollFunc=function(e){
	 e=e || window.event;
	 if(e.wheelDelta && event.ctrlKey){//IE/Opera/Chrome
	  event.returnValue=false;
	 }else if(e.detail){//Firefox
	  event.returnValue=false;
	 }
 }
 /*注册事件*/
 if(document.addEventListener){
 document.addEventListener('DOMMouseScroll',scrollFunc,false);
 }//W3C
 window.onmousewheel=document.onmousewheel=scrollFunc;//IE/Opera/Chrome/Safari