if (!sessionStorage['sId']) {
    location.href = 'Login.html';
}
AddView = {
    init: function () {
        //加载数据
        this.doSeacch();
        this.showAllteam();
        this.showData();
        this.showChartList();
        this.doExcel();
        this. doAlldoExcel();
        this.groupChoseCrbClick();
        this.doParsonSeacch();
    },
    //出勤、人员数据点击切换事件
    groupChoseCrbClick: function () {
        $(".groupChoseCrbContain").eq(0).show();
        $(".groupChoseCrb ul li").on("click", function () {
            //css样式
            $(".groupChoseCrb ul li").removeClass("blue");
            $(this).addClass("blue");
            //AddView.doPerson()
            //div显示、隐藏
            var index = $(".groupChoseCrb ul li").index(this);
            $(".groupChoseCrbContain").hide();
            $(".groupChoseCrbContain").eq(index).show();
        })
    },
    //获取所有大队、点击事件
    showAllteam: function () {
        $.ajax({
            url: http + "statistics/deptListByRole.do",
            type: "get",
            data: {code: sessionStorage.sRoleId, deptid: sessionStorage.sUserDept},
            dataType: 'json',
            success: function (data) {
                var len = data.obj.length;
                var html = '';
                for (var k = 0; k < len; k++) {
                    html += '  <li class="allTeamBlue" data="' + data.obj[k].deptid + '">' + data.obj[k].deptName + '</li>'
                }
                $(".groupChoseCrbContain ul").html(html);
                //各大队点击事件
                $(".allTeam ul li").eq(0).addClass("allTeamBlue2");
                AddView.doSeacch();
                deptNAME = $(".allTeam .allTeamBlue2").html();
                $(".allTeam ul li").on("click",function(){
                    //css样式
                    $(".allTeam ul li").removeClass("allTeamBlue2");
                    $(this).addClass("allTeamBlue2");
                    AddView.doSeacch();
                    deptNAME = $(".allTeam .allTeamBlue2").html();
                })

            }
        })
    },
    //日期控件
    showData: function () {
        $(".rollcalluserCreatetime").jeDate({
            format: "YYYY-MM-DD",
            isTime: true,
            skinCell: "jedateblue",
            minDate: "2016-09-19 00:00:00"
        });
    },
    //各大队考勤数据查询
    doSeacch: function () {
        function teamsSearchClick(){
            var newdate = new Date();
            var seperator1 = "-";
            var month = newdate.getMonth() + 1;
            var strDate = newdate.getDate();
            if (month >= 1 && month <= 9) {
                month = "0" + month;
            }
            if (strDate >= 0 && strDate <= 9) {
                strDate = "0" + strDate;
            }
            var time = newdate.getFullYear() + seperator1 + month + seperator1 + strDate

            var date = $(".rollcalluserCreatetime").val();

            if (date == "") {
                date = time;
            }
            var teamcodeS = $(".allTeamBlue2").attr("data");
            $.ajax({
                url: http + "statistics/attendanceProportion.do",
                data: {code: teamcodeS, startTime: date},
                dataType: 'json',
                success: function (data){
                    var len = data.length;
                    var app="";
                    $("[class='allTeamContain-list'] tbody").empty();
                    if (len > 0) {
                        for (var k = 0; k < len; k++) {
                             app+= "<tr><td>" + data[k].endtime + "</td><td>" + data[k].allnum + "</td> <td>" + data[k].rollcallnum + "</td> <td>" + data[k].attendnum + "</td> <td>" + data[k].absensenum + "</td> <td>" + data[k].sickleavenum + "</td> <td>" + data[k].othernum + "</td> </tr>";

                        }
                    }
                    if (len == 0) {
                        app="<tr style='text-align: center'><td colspan='7'>暂无数据</td></tr>"

                    }
                    $(".allTeamContain-list tbody").html(app);
                    //生成图表
                    var depNAME = $(".allTeamBlue2").html();
                    //console.log(depNAME);
                    var time = [];
                    var total = [];
                    var rollcallNum = [];
                    var attendNum = [];
                    var absentNum = [];
                    var sickNum = [];
                    var otherNum = [];
                    var len = data.length;
                    for (var i = 0; i < len; i++) {
                        time.push(data[i].endtime.substring(11,16));
                        total.push(data[i].allnum);
                        rollcallNum.push(data[i].rollcallnum);
                        attendNum.push(data[i].attendnum);
                        absentNum.push(data[i].absensenum);
                        sickNum.push(data[i].sickleavenum);
                        otherNum.push(data[i].othernum)
                    }
                    $(".allTeamContain-chart").highcharts({
                        chart: {
                            type: 'column',
                            width: '900'
                        },
                        title: {
                            text: date + ' ' + depNAME + '考勤数据柱状图'
                        },
                        credits: {
                            enabled: false//不显示highCharts版权信息
                        },
                        xAxis: {
                            lineWidth: 1,
                            lineColor: "#53c7e7",
                            tickWidth: 0,
                            gridLineColor:"#e6e6e6",
                            categories: time,
                            crosshair: true
                        },
                        yAxis: {
                            lineWidth: 1,
                            lineColor: "#53c7e7",
                            gridLineColor:"#e6e6e6",
                            min: 0,
                            title: {
                                text: '人数 (人)'
                            }

                        },
                        tooltip: {
                            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                            pointFormat: '<tr><td style="color:{series.color}.padding:0">{series.name}: </td>' +
                            '<td style="padding:0"><b>{point.y:.1f} 人</b></td></tr>',
                            footerFormat: '</table>',
                            shared: true,
                            useHTML: true
                        },

                        plotOptions: {
                            column: {
                                pointPadding: 0.2,
                                borderWidth: 0
                            }
                        },

                        series: [{
                            name: '总人数',
                            data: total
                        }, {
                            name: '应到人数',
                            data: rollcallNum
                        }, {
                            name: '实到人数',
                            data: attendNum
                        }, {
                            name: '缺席人数',
                            data: absentNum
                        }, {
                            name: '病假人数',
                            data: sickNum
                        }, {
                            name: '其他人数',
                            data: otherNum
                        }]
                    });
                }
            });


        }
        teamsSearchClick();
    },
    //考勤数据图表切换
    showChartList:function(){
        $("  .changebar-tabOn1").click(function(){
            if($(".changebar-tab").attr("class")=="changebar-tab tab-active"){
                return;
            }else{
                $(".changebar-tab").addClass("tab-active");
                $(".changebar-tab img").attr("src","img/tab1.png");
                $(".changebar-pic img").attr("src","img/pic1.png");
                $(".changebar-pic").attr("class","changebar-pic");
                $(".allTeamContain-list").show();
                $(".allTeamContain-chart").hide();
            }

        })
        $("  .changebar-picOn2").click(function(){
            if($(".changebar-pic").attr("class")=="changebar-tab tab-active"){
                return;
            }else{
                $(".changebar-pic").addClass("tab-active");
                $(".changebar-pic img").attr("src","img/pic2.png");
                $(".changebar-tab img").attr("src","img/tab2.png");
                $(".changebar-tab").attr("class","changebar-tab");
                $(".allTeamContain-list").hide();
                $(".allTeamContain-chart").show();
            }
        })
},
    //人员数据统计查询事件
    doParsonSeacch: function () {
        function doPerson(){
            var newdate = new Date();
            var seperator1 = "-";
            var month = newdate.getMonth() + 1;
            var strDate = newdate.getDate();
            if (month >= 1 && month <= 9) {
                month = "0" + month;
            }
            if (strDate >= 0 && strDate <= 9) {
                strDate = "0" + strDate;
            }
            var time = newdate.getFullYear() + seperator1 + month + seperator1 + strDate

            var date = $(".groupChoseCrbContainTop .rollcalluserCreatetime").val();
            //console.log(date);
            if (date == "") {
                date = time;
            }
            //绘制柱状图
            $.ajax({
                url: http + "statistics/hasdeletedProportion.do",
                type: "get",
                data: {startTime: date, depId: sessionStorage.sUserDept, roleid: sessionStorage.sRoleId},
                dataType: 'json',
                success: function (data) {
                    console.log(data)
                    $(".groupChoseCrbContain-list tbody").empty();
                    var depName = [];
                    var inuser = [];
                    var deleted = [];
                    var len = data.length;
                    var html='';
                    for (var i = 0; i < len; i++) {
                        html+=" <tr><td>" + data[i].depName + "</td><td>" + data[i].inuser + "</td><td>" + data[i].deleted + "</td></tr>";
                        inuser.push(data[i].inuser);
                        deleted.push(data[i].deleted);
                        depName.push(data[i].depName);
                    }
                    $(".groupChoseCrbContain-list tbody").html(html)
                    $('.groupChoseCrbContain-chart').highcharts({
                        chart: {
                            type: 'column'
                        },
                        title: {
                            text: date + '人员数据柱状图'
                        },
                        loading: {
                            showDuration: 1000,                       //设置淡入效果持续时间
                            hideDuration: 1000                           //设置淡出效果持续时间

                        },
                        credits: {
                            enabled: false//不显示highCharts版权信息
                        },
                        xAxis: {
                            lineWidth: 1,
                            lineColor: "#777777",
                            tickWidth: 0,
                            gridLineColor: "#777777",
                            categories: depName,
                            crosshair: true
                        },
                        yAxis: {
                            lineWidth: 1,
                            lineColor: "#777777",
                            gridLineColor: "#777777",
                            min: 0,
                            title: {
                                text: '人数 (人)'
                            }
                        },
                        tooltip: {
                            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                            '<td style="padding:0"><b>{point.y:.1f} 人</b></td></tr>',
                            footerFormat: '</table>',
                            shared: true,
                            useHTML: true
                        },
                        plotOptions: {
                            column: {
                                pointPadding: 0.2,
                                borderWidth: 0
                            }
                        },
                        series: [{
                            name: '在队人数',
                            data: inuser

                        }, {
                            name: '离队人数',
                            data: deleted
                        }]
                    });
                }
            });
        }
        doPerson();


    },
    //导出Excel函数封装
    doExcel:function(a,b){
        $(a).click(function () {
            if(sessionStorage.sRoleId==1||sessionStorage.sRoleId==2){
                deptNAME="所有大队";
            }
            var date;
            var newdate = new Date();
            var time = newdate.toLocaleString();
            time = time.replace(/\//g, '-').substring(0, 9);
            if ($(".rollcalluserCreatetime").val() == "") {
                date = time;
            } else {
                date = $(".rollcalluserCreatetime").val();
            }
            //导出
            $(b).tableExport({type:"excel",escape:"false",fileName: date +""+deptNAME+ "人员数据统计"});
        });
    },
    //导出函数调用
    doAlldoExcel:function(){
        //数据统计导出表格
        this.doExcel(".allTeamContain-list .DoExcel",".allTeamContain-list table");
        this.doExcel(".groupChoseCrbContain-list .DoExcel",".groupChoseCrbContain-list table");
    }
}
AddView.init();



