$("#personPhoto").click(function(){
	if ($(".bg2").size() === 0) {
        parent.delFingerl();
        //选择多名学员
    } else if ($(".bg2").size() > 1) {
        parent.delFinger6();
    } else {
		var smallkuang11Id=$("tbody .bg2").parent().parent().find(".stuId").attr("data-user");
		var smallkuang11Name=$("tbody .bg2").parent().parent().find(".stuName").html();
//		console.log(smallkuang11Id)
		sessionStorage.setItem("smallkuang11Id", smallkuang11Id);
		sessionStorage.setItem("smallkuang11Name", smallkuang11Name);
		window.open("collectphotos.html","_blank")
    }
})

function delFingerl(){
    $(".smallkuang11").fadeIn();
    $(".baohu").fadeIn();
    $(".sp4-1").html("请选择要采集照片的学员");
    $(".sp5").click(function(){
        $(".smallkuang11").fadeOut();
        $(".baohu").fadeOut();
    });
    return false;
}
function delFinger6(){
    $(".smallkuang11").fadeIn();
    $(".baohu").fadeIn();
    $(".sp4-1").html("采集照片只能选择一位学员");
    $(".sp5").click(function(){
        $(".smallkuang11").fadeOut();
        $(".baohu").fadeOut();
    });
    return false;
}
