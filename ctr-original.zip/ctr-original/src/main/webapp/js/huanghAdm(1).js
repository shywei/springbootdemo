/**若用户未登录，则跳转到登录页面（产品列表页）**/
if(!sessionStorage['sId']) {
	location.href = 'Login.html';
}


var pageSize = 10;
var sName = sessionStorage.getItem("sName"); // 姓名
var sUid = sessionStorage.getItem("sUid"); //帐号
var sPass = sessionStorage.getItem("sPass"); //密码
var sId = sessionStorage.getItem("sId"); //id
var sUserDept = sessionStorage.getItem("sUserDept"); //大队 的部门
var department = sessionStorage.getItem("department"); //大队名称
var sRoleId = sessionStorage.getItem("sRoleId"); //大队名称
//判断是否是管理员
if(sUid != "admin") {
	$(".isAdm").hide();
} else {
	$(".isAdm").show();
}
//用户信息
var html =' <div  class="borderR"> <img src="img/people-new.png" alt=""/> <div class="uer"><p>你好,</p><span>'+sName+'</span></div> </div> <div class="borderR"> <img src="img/change_new.png" alt=""/> <div class="position">修改密码</div> </div> <div> <img src="img/exit-new.png" alt=""/> <div class="exit">退出</div> </div>'
$(".asUer").html(html);
selectUserLeft(); //用户侧边栏
//侧边栏----菜单显示
function selectUserLeft() {
	var useId = sId;
	$.ajax({
		url: http + 'userAuthorityController/getMenuById',
		type: 'get',
		data: {
			id: useId
		},
		dataTpye: 'json',
		success: function(data) {
			var html = '';
			for(var i = 0; i < data.obj.results.length; i++) {
				html += `
				<div class="adTxt adTxt01">
					<p class="top"><img class="pic6" />${data.obj.results[i].menuName}</p>
					<div class="adTxtC" readonly>${selectUserLeftId(data.obj.results[i].menuid)} </div>
				</div>
				`;
			}
			$(".adTxtWrap").html(html);
			$(".pic6").each(function(i) {
				console.log("name:"+data.obj.results[i].menuName+"  id:"+data.obj.results[i].menuid);
				$(".pic6").eq(i).attr("src", "img/" + data.obj.results[i].menuid + ".png");
			});
			$(".adTxt .adTxtC").slideUp(500);
		},
		error: function(data) {}
	});
}

//父权限对应的id
function selectUserLeftId(fatherId) {
	var roleId = sessionStorage.getItem("sRoleId");
	var fatherId = fatherId;
	var htmlPtxt = '';
	$.ajax({
		url: http + 'userAuthorityController/getModelByMenuIdAndId',
		type: 'get',
		data: {
			id: sId,
			menuid: fatherId
		},
		dataTpye: 'json',
		async: false,
		success: function(data) {
			var html = '';
			for(var i = 0; i < data.obj.results.length; i++) {
				html += `
					<p><img class="pic5" /><span data-span="${data.obj.results[i].modelUrl}">${data.obj.results[i].modelName}</span></p>
				`
			}
			htmlPtxt = html;
		},
		error: function(data) {}
	});
	return htmlPtxt;
}
//左侧边栏展开收起
$(".asideL").unbind("click").on("click", ".adTxt .top", function() {
	$(".adTxt .adTxtC").slideUp(500);
	$(this).next().stop(true).slideToggle(500);
	if($(this).parent().find(".adTxtC").is(':visible')) {
		$(".adTxt .top").find(".pic4").attr("src", "img/plus.png");
		$(this).parent().find(".pic4").attr("src", "img/plus2.png");
	} else {
		$(this).parent().find(".pic4").attr("src", "img/plus.png");
	}
	//获取左侧栏标签p的class
	var pLen = $(".adTxtC p").size();
	for(var i = 0; i < pLen; i++) {
		$(".adTxtC p").eq(i).unbind("click").on("click", function() {
			$(".adTxtC p").removeClass("on");
			$(this).addClass("on");
			var cla = $(this).attr("class");
			var dataUrl = $(this).find("span").attr("data-span");
			//面包屑
			var html = '';
			for(var n = 0; n < $(".titW").size(); n++) {
				if($(this).find("span").html() == $(".titW .text").eq(n).html()) {
					var claUrl = $(".titW .text").eq(n).parent().attr("data-url");
					$(".titW .text").eq(n).parent().siblings().removeClass("on");
					$(".titW .text").eq(n).parent().addClass("on");
					if(claUrl == "undefined") {
						return
					};
					autoCbCon();
					return;
				}
			};
			html = '<div class="titW ' + cla + ' on" data-url="' + dataUrl + '" ><span class="text">' + $(this).find("span").html() + '</span><span class="close">&times;</span></div>'
			$(".crumbs .titW").removeClass("on");
			$(".crumbs").append(html);
			cbClik();
			autoCbCon();
		});
	};
});
//面包屑点击事件
function cbClik() {
	$(".crumbs .titW").each(function(i) {
		$(".crumbs .titW").eq(i).unbind("click").on("click", function() {
			$(".crumbs .titW").removeClass("on");
			$(this).addClass("on");
			var dataUrl;
			autoCbCon();
		});
	});
};
//添加面包屑 打开相应的内容
function autoCbCon() {
	var cla = $(".crumbs .on").attr("data-url");
	var claName = $(".crumbs .on").find(".text").html();
	if(cla == "undefined") {
		return
	};
	sessionStorage.setItem("cla", cla);
	sessionStorage.setItem("claName", claName);
	//页面跳转
	$(".adm .crumbsCon .frame").attr("src", cla);

};
//关闭面包屑
$(".crumbs").on("click", ".close", function() {
	$(this).parent().remove();
	var index = $(".titW").size();
	$(".titW").eq(index - 1).addClass("on");
	autoCbCon();
});

//修改密码校验
var pwdCheck = false;
var oldCheck = false;
$(".pass01").blur(function() {
	var oldPwd = $(".pass01").val();
	var newPwd = $(".pass02").val();
	var rePwd = $(".pass03").val();
	var sId = sessionStorage.getItem("sId");
	$(".adm .setAlert .top").html("");
	if(oldPwd == '') {
		pwdCheck = false;
		$(".adm .setAlert .top").html("原密码不能为空");
	} else {
		$(".adm .setAlert .top").html("");
		$.ajax({
			type: "get",
			url: http + "systemUser/ checkPwd.do",
			data: {
				id: sId,
				password: oldPwd
			},
			dataType: 'json',
			success: function(data) {
				if(data.code != 1) {
					$(".adm .setAlert .top").html("原密码输入错误");
					oldCheck = false;
					pwdCheck = false;
					return false;
				} else {
					$(".adm .setAlert .top").html("");
					oldCheck = true;
					pwdCheck = true;
				}
				if(oldPwd == newPwd || oldPwd == rePwd) {
					$(".adm .setAlert .top").html("新密码与原密码一致");
					pwdCheck = false;
					return false;
				} else {
					$(".adm .setAlert .top").html("");
					pwdCheck = true;
				}
				if(newPwd == rePwd) {
					pwdCheck = true;
				} else {
					$(".adm .setAlert .top").html("两次输入密码不一致");
					pwdCheck = false;
					return false;
				}
			}
		});
	}
});
$(".pass02").blur(function() {
	var oldPwd = $(".pass01").val();
	var newPwd = $(".pass02").val();
	var rePwd = $(".pass03").val();
	$(".adm .setAlert .top").html("");
	if(oldCheck == false) {
		$(".adm .setAlert .top").html("原密码输入错误");
	} else if(newPwd == '') {
		pwdCheck = false;
		$(".adm .setAlert .top").html("新密码不能为空");
	} else {
		if(oldPwd == newPwd) {
			$(".adm .setAlert .top").html("新密码与原密码一致");
			pwdCheck = false;
		} else {
			$(".adm .setAlert .top").html("");
			pwdCheck = true;
		}
	}
});
$(".pass03").blur(function() {
	var oldPwd = $(".pass01").val();
	var newPwd = $(".pass02").val();
	var rePwd = $(".pass03").val();
	if(oldCheck == false) {
		$(".adm .setAlert .top").html("原密码输入错误");
	} else if(oldPwd == newPwd) {
		$(".adm .setAlert .top").html("新密码与原密码一致");
		pwdCheck = false;
	} else {
		$(".adm .setAlert .top").html("");
		pwdCheck = true;
		if(newPwd == rePwd) {
			pwdCheck = true;
		} else {
			$(".adm .setAlert .top").html("两次输入密码不一致");
			pwdCheck = false;
		}
	}
});
//	修改密码状态栏
$(".asUer").on("click", ".position", function() {
	$(".adm .setAlert .con .smallkuang-header span").html("修改密码");
	$(".pass03,.pass02,.pass01").val("");
	$(".adm .setAlert").fadeIn();
	$(".adm .setAlert .con").fadeIn();
	$(".adm .setAlert .top").html("请输入密码")
});

$(".setAlert").on("click", ".btnOk", function() {
	if(pwdCheck == true) {
		sessionStorage.setItem("sPass", $(".pass03").val());
		var sId = sessionStorage.getItem("sId"); //id
		var passd = $(".pass03").val();
		$.ajax({
			url: http + 'systemUser/ updateSystemUserPwd.do',
			type: 'get',
			data: {
				id: sId,
				password: passd
			},
			dataTpye: 'json',
			success: function(data) {
				console.log(data)
				if(data.code == 1) {
					sessionStorage.clear();
					window.location.href = "Login.html";
				} else {
					$(".adm .setAlert .top").html("修改失败")
					return;
				}

			},
			error: function(data) {
			}
		});

	}
});

$(".setAlert").on("click", ".btnNo", function() {
	$(".adm .setAlert").fadeOut();
});
//退出系统
$(".asUer").on("click", ".exit", function() {
	$(".baohu").fadeIn();
	$(".exit-kuang").fadeIn();
	$("[class='exit-kuang-foot-srue']").on("click", function() {
		console.log("456")
		$.ajax({
			url: http + 'systemUser/exitSystem.do',
			type: 'get',
			data: {
				userid: sId
			},
			dataTpye: 'json',
			success: function(data) {
				sessionStorage.clear();
				window.location.href = "Login.html";
			},
			error: function(data) {
				console.log("请检查网络链接，稍后再试");
			}
		});
	})
	$("[class='exit-kuang-foot-close']").on("click", function() {
		$(".baohu").fadeOut();
		$(".exit-kuang").fadeOut();
	})
});

//权限管理界面

//侧边栏
$(".jstDist").unbind("click").on("click", ".jstUlP", function() {
	$(".jstDist .jstLiW").slideUp(500);
	$(this).next().stop(true).slideToggle(500);
});

function autoCheck() { //自动选择和取消
	if($("tbody .fist").size() == $("tbody .fistOn").size()) {
		$("thead .fist").find("img").attr("src", "img/checkbox2.png");
		return;
	}
	$("thead .fist").find("img").attr("src", "img/checkbox.png");
};
//菜单选中哪些
function munAll() {
	var num = '';
	for(var i = 0; i <= $(".codeOn").size(); i++) {
		if($(".codeOn").eq(i).html()) {
			i == 0 ? num = $(".codeOn").eq(i).html() : num += "," + $(".codeOn").eq(i).html();
		}
	};
	return num;
};

var jstAlt = 0; //0否 1确认
//权限弹窗效验
$(".jstAlt .con .body input").blur(function() {
	if($(this)[0].validity.valueMissing) {
		$(".adm .jstAlt .top").html("请填完整不能为空");
		jstAlt = 0;
		return;
	}
	jstAlt = 1;
});

//权限下拉菜单
var addJst = -1; //添加权限
var setJst = -1; //修改权限
//添加查询大队
$(".jstAlt .select").on("click", function() {

});
$(".jstAlt .select").change(function() {
	addJst = $(this).val();
	//	console.log(addJst);
});
$(".jstSetAlt .select").change(function() {
	setJst = $(this).val();
});
//添加权限验证
var jstAltIsOk = 0; //0否 1确认
var jstAltIsOk01 = 0; //0否 1确认
var jstAltIsOk02 = 0; //0否 1确认
$(".jstAlt .meunName").blur(function() {
	if($(this)[0].validity.valueMissing) {
		$(".adm .jstAlt .top").html("请填完整不能为空")
		jstAltIsOk = 0;
		return;
	} else {
		$(".adm .jstAlt .top").html("")
		jstAltIsOk = 1;
	}
});
$(".jstAlt .meunAds").blur(function() {
	if($(this)[0].validity.valueMissing) {
		$(".adm .jstAlt .top").html("请填完整不能为空")
		jstAltIsOk01 = 0;
		return;
	} else {
		$(".adm .jstAlt .top").html("")
		jstAltIsOk01 = 1;
	}
});
//修改权限验证
var jstSetAltIsOk = 0; //0否 1确认
$(".jstSetAlt .con .body input").blur(function() {
	if($(this)[0].validity.valueMissing) {
		$(".adm .jstAlt .top").html("请填完整不能为空")
		jstSetAltIsOk = 0;
		return;
	}
	jstSetAltIsOk = 1;
});
$(".jstSetAlt .setName").blur(function() {

});
$(".jstSetAlt .setAds").blur(function() {

});
$(".jstSetAlt .select").blur(function() {

});

$(".setQi").each(function(i) {
	$(".setQi").eq(i).on("click", function() {
		$(".setQi").attr("src", "img/state.png");
		$(this).attr("src", "img/state2.png");
	});
});
//关闭提示弹窗
$(".promptAltOK").on("click", function() {
	$(".promptAlt").fadeOut();
});
$(".promptAltNO").on("click", function() {
	$(".promptAlt").fadeOut();
});

$(".jstSetAltNO").on("click", function() {
	$(".jstSetAlt").fadeOut();
});

//确定添加菜单
$(".jstBtnOk").on("click", function() {
	//var pagNum = $(".menuNumOn").html();
	$(".adm .jstAlt .con .top").html("");
	var meunName = $(".meunName").val(); //名称
	var meunAds = $(".meunAds").val(); //地址
	var systemuserId = sessionStorage.sId;
	var sortid = $(".sortNumber").val()
	var menuId = $(".jstAlt-add .select").val();
	if(meunName == "" || meunAds == "") {
		$(".adm .jstAlt .con .top").html("请填完整不能为空");
	} else {
		$.ajax({
			type: "get",
			url: http + 'userAuthorityController/saveModel',
			data: {
				userName: sessionStorage.sName,
				deptid: sessionStorage.sUserDept,
				createid: systemuserId,
				modelName: meunName,
				modelUrl: meunAds,
				menuid: menuId,
				sortid: sortid
			},
			dataType: 'json',
			success: function(data) {
				if(data == -2) {
					parent.$(".jstSetAlt .top").html("同一个菜单下不可出现重名子菜单！")
					return;
				} else {
					$("iframe.crumbsCon")[0].contentWindow.jstUpDataMeun(1);
					parent.$(".jstSetAlt").fadeOut();
				}
			}
		});
		$(".adm .jstAlt .con .body p input").val("");
		$(".jstAlt").fadeOut();
		selectUserLeft();
	}
});

$(".jstBtnNo").on("click", function() {
	$(".adm .jstAlt .con .body p input").val("");
	$(".jstAlt").fadeOut();
});

//权限菜单是否启动权限
$(".meunQi").each(function(i) {
	$(".meunQi").parent().eq(i).on("click", function() {
		$(".meunQi").attr("src", "img/state.png");
		$(this).find(".meunQi").attr("src", "img/state2.png");
		i == 0 ? $(".meunIsok").attr("value", "1") : $(".meunIsok").attr("value", "0")
	});
});

//权限菜单页码
function jsetUpdataPage(count, page, row) {
	var cuA = Math.ceil(count / row);
	var val = $(".jstMeun .meunBtn04 input").val();
	$(".jstMeun .meunS .menuPage .menuPageAll").html(count);
	$(".jstMeun .meunS .menuPage .menuPageCur").html(parseInt(page / 10) + 1);
	$(".jstMeun .meunS .menuPage .menuPageCuA").html(cuA);
	var htmlA = "";
	for(var i = 1; i <= cuA; i++) {
		htmlA += "<a class='' href='#'>" + i + "</a>";
	};
	$(".jstMeun .meunS .menuPage .menuPageNum").html(htmlA);
	$(".menuPageNum a").eq(parseInt(page) - 1).addClass("menuNumOn");
	//菜单管理 页码
	$(".menuPageNum a").each(function(i) {
		$(".menuPageNum a").eq(i).unbind("click").on("click", function(e) {
			e.preventDefault();
			//debugger;
			$(".menuPageNum a").removeClass("menuNumOn");
			$(this).addClass("menuNumOn");
			var menuPageCur = i + 1;
			jstUpDataMeun(menuPageCur, val);
		});
	});
	//跳转多少页
	$(".jstMeun .meunS .menuPage .menuDir").unbind("click").on("click", function(e) {
		e.preventDefault();
		var num = $(".jstMeun .meunS .menuPage .menuNum").val();
		var val = $(".jstMeun .meunBtn04 input").val();
		if(num <= cuA) {
			jstUpDataMeun(num, val);
		} else {
			jstUpDataMeun(cuA, val);
		}
	});
	//首页
	$(".jstMeun .meunS .menuPage .menuFirst").unbind("click").on("click", function(e) {
		e.preventDefault();
		var val = $(".jstMeun .meunBtn04 input").val();
		jstUpDataMeun(1, val);

	});
	//末页
	$(".jstMeun .meunS .menuPage .menuLast").unbind("click").on("click", function(e) {
		e.preventDefault();
		var val = $(".jstMeun .meunBtn04 input").val();
		jstUpDataMeun(cuA, val);
	});
}

//权限菜单 数据多少更换
$(".meunS .sel select").change(function() {
	jstUpDataMeun();
});

//系统菜单--搜索
function jstUpDataMeun(menuPageCur, val) {
	var jstMeunHtml = '';
	val = val || '';
	var states = state;
	if(states == -1) {
		states = null;
	}
	var row = $(".meunS .sel select").val();
	if(!row) {
		row = 10;
	}
	$.ajax({
		type: 'get',
		url: http + 'userAuthorityController/getModel',
		data: {
			rows: row,
			page: menuPageCur || 1,
			name: val
		},
		dataType: 'json',
		success: function(data) {
			if(data.obj.results.length == 0) {
				jstMeunHtml += `
					<tr class="changetr">
                    	<td class="deviceid" colspan='8'><img src="img/dataloss.png" style="margin: 145px auto"></img></td>
                    </tr>
				`;
			} else {
				for(var i = 0; i < data.obj.results.length; i++) {
					if(data.obj.results[i].createtime ==""){
						createtime =""
					}else{
						createtime =data.obj.results[i].createtime.slice(0,19)
					}
					jstMeunHtml += `
						<tr>
							<td width='2%' class="fist"><img src="img/checkbox.png" data="${data.obj.results[i].modelid}"></td>
							<td width='14%' >${data.obj.results[i].modelName}</td>
							<td width='20%' class="menuUrl">${data.obj.results[i].modelUrl}</td>
							<td width='14%'>${data.obj.results[i].loginName}</td>
							<td width='14%' >${createtime}</td>
						    <td width='14%' value="${data.obj.results[i].menuid}">${data.obj.results[i].menuName}</td>
						</tr>
					`
				}
			}
			jsetUpdataPage(data.obj.page.totalCount, data.obj.page.currentPage, data.obj.page.pageSize);
			$(".jstMeun .table tbody").html(jstMeunHtml);
			//thead 点击全选和取消
			$(".meunS thead .fist").unbind("click").on("click", function() {

				var src = $(this).find("img").attr("src");
				if(src == "img/checkbox2.png") {
					src = "img/checkbox.png";
					$(".fist").find("img").attr("src", src);
					$("tbody .fist").removeClass("fistOn");
					$("tbody .meunCode ").removeClass("codeOn");
				} else {
					src = "img/checkbox2.png";
					$(".fist").find("img").attr("src", src);
					$("tbody .fist").addClass("fistOn");
					$("tbody .meunCode ").addClass("codeOn");
				}
			});

			//菜单选择
			$(".meunS .fist").each(function(i) {
				$(".meunS").eq(i).unbind("click").on("click", "tbody .fist", function() {
					var src = $(this).find("img").attr("src");
					if(src == "img/checkbox2.png") {
						src = "img/checkbox.png";
						$(this).removeClass("fistOn");
						$(this).parent().find(".meunCode").removeClass("codeOn");
					} else {
						src = "img/checkbox2.png";
						$(this).addClass("fistOn");
						$(this).parent().find(".meunCode").addClass("codeOn");
					}
					$(this).find("img").attr("src", src);
					autoCheck();
				});
			});

		}
	});
	$(".jstMeun .meunS .table thead .fist").find("img").attr("src", "img/checkbox.png");
}

//系统菜单--搜索
$(".jstMeun .meunCon .meunBtn06").on("click", function() {
	var val = $(".jstMeun .meunBtn04 input").val();
	jstUpDataMeun(1, val);
});

//权限菜单 重置
$(".jstMeun .meunCon .meunBtn07").on("click", function() {
	$(".meunBtn04 input").val("");
	$(".jstMeun .meunCon .meunTit .meunBtn05 select").val("-1");
	$(".menuNum").val("");
	state = -1;
	jstUpDataMeun(1); //权限管理菜单详情
});

//大队子菜单
function upDataJstDistId(roleId) {
	var html02 = '';
	var roleId = roleId;
	$.ajax({
		type: "get",
		url: http + 'userAuthorityController/getSystemUserByRoleId',
		data: {
			id: roleId
		},
		dataType: 'json',
		async: false,
		success: function(data) {
			var html = '';
			for(var i = 0; i < data.obj.results.length; i++) {
				html += `
					<div class="jstLi" data-use=${data.obj.results[i].id}>
						${data.obj.results[i].userName}
					</div>
				`;
			}
			html02 = html;
		}
	});
	return html02;
}

//personnelChose 人员管理 
//stateMat 状态管理  stateMatCon
//accountChose 帐号管理
//callChose 点名管理 callChoseCon
//checkMenuChose 菜单管理
//privilegeChose 权限分配
//intChose 对内统计 intChoseCon
//groupChose 大队统计 groupChoseCon
//loginDateChose 登录日志 loginDateChoseCon
//operationDateChose 操作日志 operationDateChoseCon

//attendanceChose 考勤管理

var state = -1;
$(".jstMeun .meunBtn05 select").change(function() {
	state = $(this).val();
	//	 console.log(state)
});

//搜索查询调用
function searchAuto(http, url, staDate, endDate, htmlX, userNum) {
	$(".dataAllR").attr("value", "0");
	var isOkA = $(".dataAllR").val();
	var isOkB = 0;
	userNum = userNum || sUserDept;
	var teadSelect = $(".groupChoseCrb .gCbCon .gCbTit .iCbBtnR .teadSelect option:selected").val();
	if(teadSelect == -1) {
		teadSelect = '';
	}
	if(!teadSelect) {
		teadSelect = '';
	}
	$.ajax({
		url: http + url,
		data: {
			deptId: userNum,
			startDate: staDate,
			endDate: endDate,
			depId: teadSelect
		},
		success: function(dataAll) {
			//开始使用FusionCharts绘制统计图
			dataAll = JSON.parse(dataAll);

			console.log(dataAll);
			if(dataAll.rows) {
				dataAllR = dataAll.rows;
				if(dataAll.total) {
					dataAll.allsum = dataAll.total;
				}
				if(dataAll.allsum != "0") {
					isOkA = 1;
				}
			} else {
				dataAllR = dataAll
				for(var i = 0; i < dataAll.length; i++) {
					if(dataAll[i].value != "0") {
						isOkA = 0;
						isOkB = 1;
					}
				}
				if(isOkB != 0) {
					isOkA = 1;
				}
			}
			autoTable(dataAll.total);
			if(isOkA != 0) {
				var hP = new FusionCharts({
					type: "pie3d", //"column2d",//'column3d',//'pie2d',//'bar3d',//'bar2d',//'column3d',//'column2d',
					renderAt: htmlX,
					width: "800",
					height: "500",
					dataFormat: "json",
					dataSource: {
						data: dataAllR //[{label:xx, value:xx}]

					}
				});
				hP.render(); //将图表内容渲染出来
			} else {
				var hP = new FusionCharts({
					type: "pie3d", //"column2d",//'column3d',//'pie2d',//'bar3d',//'bar2d',//'column3d',//'column2d',
					renderAt: htmlX,
					width: "800",
					height: "500",
					dataFormat: "json",
					dataSource: {
						data: dataAllR //[{label:xx, value:xx}]

					}
				});
				hP.render(); //将图表内容渲染出来
				$(".adm .promptAlt .con .body p").html("没有任何数据");
				$(".promptAlt").fadeIn();
			}
		}
	});
	$(".iCbStable").fadeIn();
}
//队内 搜索
$(".intChoseCrb .iCbBtnR .intGo").on("click", function() {
	//	日期验证
	if($(".intEndDate").val() != "" && $(".intStatDate").val() != "") {
		if($(".intEndDate").val() < $(".intStatDate").val()) {
			$(".adm .promptAlt .con .body p").html("起始时间不能大于结束时间");
			$(".promptAlt").fadeIn();
			return;
		}
	}
	var http = http;
	var staDate = $(".intStatDate").val();
	var endDate = $(".intEndDate").val();
	var index = $(".intChoseCrb .iCbCon .iCbTit .iCbBtn").index($(".intChoseCrb .iCbCon .iCbTit .on"));
	if(index == -1) {
		$(".adm .promptAlt .con .body p").html("请选择出勤还是离队");
		$(".promptAlt").fadeIn();
		return;
	}
	var hUrl = index == 0 ? 'queryAttendanceDataStatistics.do' : 'queryLeaveDataStatistics.do'
	var htmlX = index == 0 ? 'piechartM02' : 'piechartM03'
	if($(".brigadeChose").attr("data-user")) {
		var isAdminChose = $(".brigadeChose").attr("data-user");
	}
	searchAuto(http, hUrl, staDate, endDate, htmlX, isAdminChose);

	$(".chart01,.chart").hide();
	$(".chart01").eq(index).fadeIn();
});

//大队 搜索
$(".groupChoseCrb .iCbBtnR .intGo01").on("click", function() {
	//	日期验证
	if($(".intEndDate01").val() != "" && $(".intStatDate01").val() != "") {
		if($(".intEndDate01").val() < $(".intStatDate01").val()) {
			$(".adm .promptAlt .con .body p").html("起始时间不能大于结束时间");
			$(".promptAlt").fadeIn();
			return;
		}
	}
	var http = http;
	var staDate = $(".intStatDate01").val();
	var endDate = $(".intEndDate01").val();
	var index = $(".groupChoseCrb .gCbCon .gCbTit .gCbBtn").index($(".groupChoseCrb .gCbCon .gCbTit .on"));
	if(index == -1) {
		$(".adm .promptAlt .con .body p").html("请选择数据类型");
		$(".promptAlt").fadeIn();
		return;
	}
	if(index == 0) {
		//		$(".adm .promptAlt .con .body p").html("不能查询");
		//  	$(".promptAlt").fadeIn();
		return;
	}
	if(index == 1) {
		var hUrl = 'rollCallUserInfoController/hasdeletedProportion.do';
		var htmlX = 'piechartW01'
	}
	if(index == 2) {
		var hUrl = 'rollCallUserInfoController/attendanceProportion.do';
		var htmlX = 'piechartW02'
	}
	searchAuto(http, hUrl, staDate, endDate, htmlX);
	$(".chart01,.chart").hide();
	$(".chart01").eq(index + 1).fadeIn();
});

//队内 重置
function intChoseCrbAuto() {
	$(".intChoseCrb .iCbCon .iCbTit .iCbBtnR input").val("");
	$(".intChoseCrb .iCbBtnR .brigadeChose").val("");
	$(".intChoseCrb .iCbCon .iCbTit .iCbBtn").removeClass("on");
	$(".iCbStable").hide();
	$(".intChoseCrb .iCbCon .iCbS .chart").hide();
	$(".intChoseCrb .iCbCon .iCbS .chart01").hide();
	$(".intChoseCrb .brigadeChoseCon").fadeOut();
}
$(".intChoseCrb .iCbBtnR .reGo").on("click", function() {
	intChoseCrbAuto();
});

//大队 重置
function groupChoseCrbAuto() {
	$(".groupChoseCrb .gCbCon .gCbTit .iCbBtnR input").val("");
	$(".groupChoseCrb .gCbCon .gCbTit .gCbBtn").removeClass("on");
	$(".iCbStable").hide();
	$(".groupChoseCrb .gCbCon .gCbS .chart").hide();
	$(".groupChoseCrb .gCbCon .gCbS .chart01").hide();
}
$(".groupChoseCrb .gCbCon .gCbTit .iCbBtnR .reGo01").on("click", function() {
	groupChoseCrbAuto();
});

//队内 大队查询
$(".intChoseCrb .iCbBtnR .brigadeChose").on("click", function() {
	$(".intChoseCrb .brigadeChoseCon").fadeIn();
	$.ajax({
		type: "get",
		url: http + "statistics/deptListByRole.do",
		data: {
			code: sessionStorage.sRoleId,
			deptid: sessionStorage.sUserDept
		},
		dataType: 'json',
		success: function(data) {
			//			console.log(data);
			var html = '';
			$.each(data, function(i, v) {
				html += `
					<p class="brigadeChoseP" data-value="${v.id}">${v.department}</p>
				`;
			});
			$(".intChoseCrb .iCbCon .iCbTit .iCbBtnR .brigadeChoseCon").html('<p class="brigadeChoseP" data-value="-1">请选择大队</p>' + html);
			$(".intChoseCrb .brigadeChoseCon .brigadeChoseP").each(function(i) {
				$(".intChoseCrb .brigadeChoseCon .brigadeChoseP").eq(i).unbind("click").on("click", function() {
					$(".intChoseCrb .iCbBtnR .brigadeChose").val($(this).html());
					$(".intChoseCrb .iCbBtnR .brigadeChose").attr("data-user", $(this).attr("data-value"));
					$(".intChoseCrb .brigadeChoseCon").fadeOut();
				});
			});
		}
	});
});

//调用日历 队内
$(".intStatDate").jeDate({
	format: "YYYY-MM-DD hh:mm:ss",
	isTime: true
});
$(".intEndDate").jeDate({
	format: "YYYY-MM-DD hh:mm:ss",
	isTime: true,
	skinCell: "jedateblue"
});

//调用日历 大队
$(".intStatDate01").jeDate({
	format: "YYYY-MM-DD hh:mm:ss",
	isTime: true
});
$(".intEndDate01").jeDate({
	format: "YYYY-MM-DD hh:mm:ss",
	isTime: true,
	skinCell: "jedateblue"
});

//权限分配---左侧栏--角色显示
function upDataJstDist() {
	$.ajax({
		type: "get",
		url: http + 'userInfoSaveController/getRole',
		data: '',
		dataType: 'json',
		success: function(data) {
			var html = '';
			var htmlTit = '';
			htmlTit = `
			 	<div class="jstUl1 jstUlTit">
					<p class="jstU">女子戒毒所</p>
					<div class="jstLiW">
					</div>
				</div>
			 `;
			for(var i = 0; i < data.obj.results.length; i++) {
				html += `
					<div class="jstUl">
						<p class="jstUlP" data-id="${data.obj.results[i].roleid}">${data.obj.results[i].roleName}</p>
						<div class="jstLiW">
							${upDataJstDistId(data.obj.results[i].roleid)}
						</div>
					</div>
				`;
			}
			$(".jstDist .disCon .left").html(htmlTit + html);
			for(var i = 0; i < $(".left .jstUlP").size(); i++) {
				$(".left ").eq(i).on("click", ".jstUlP", function() {
					$(".left .jstUlP").removeClass("on");
					$(".jstLiW .jstLi").removeClass("on");
					$(this).addClass("on");
					AllotSystemAuthority();
				});
			}
			//权限分配 人名切换
			for(var i = 0; i < $(".left .jstLi").size(); i++) {
				$(".left ").eq(i).on("click", ".jstLi", function() {
					$(".jstLiW .jstLi").removeClass("on");
					$(this).addClass("on");
					AllotSystemAuthority();
				});
			}
		}
	});
}

//权限分配--角色--根据角色编号查询权限集合
function selectRoleId(roleId) {
	var roleId = roleId;
	$(".jstDist .disCon .jstRtxts .jstRtxt").removeClass("jstRtxtON");
	$.ajax({
		type: "get",
		url: http + 'userAuthorityController/getModelByRoleId',
		data: {
			id: roleId
		},
		success: function(data) {
			//			$(".jstDist .disCon .right .jstRtxt").find("img").attr("src","img/checkbox.png");
			var html = '';
			for(var i = 0; i < data.obj.results.length; i++) {
				for(var j = 0; j < $(".jstDist .disCon .jstRtxts .jstRtxt").size(); j++) {
					if($(".jstDist .disCon .jstRtxts .jstRtxt span").eq(j).html() == data.obj.results[i].modelName) {
						$(".jstDist .disCon .jstRtxts .jstRtxt").eq(j).addClass("jstRtxtOn");
						$(".jstDist .disCon .jstRtxts .jstRtxt img").eq(j).attr("src", "img/checkbox2.png");
					};
				}

			}
		}
	});
};
//权限分配--账号---根据账号编号查询权限集合显示
function selectId(id) {
	var id = id;
	$(".jstDist .disCon .jstRtxts .jstRtxt").removeClass("jstRtxtON");
	$.ajax({
		type: "get",
		url: http + 'userAuthorityController/getModelById',
		data: {
			id: id
		},
		success: function(data) {
			var html = '';
			for(var i = 0; i < data.obj.results.length; i++) {
				for(var j = 0; j < $(".jstDist .disCon .jstRtxts .jstRtxt").size(); j++) {
					if($(".jstDist .disCon .jstRtxts .jstRtxt span").eq(j).html() == data.obj.results[i].modelName) {
						$(".jstDist .disCon .jstRtxts .jstRtxt").eq(j).addClass("jstRtxtOn");
						$(".jstDist .disCon .jstRtxts .jstRtxt img").eq(j).attr("src", "img/checkbox2.png");
					};
				}

			}
		}
	});
};

//权限分配--角色/账号--所有权限
function AllotSystemAuthority() {
	$.ajax({
		type: "get",
		url: http + "userAuthorityController/getMenuAndModel",
		//		data:{},
		dataType: 'json',
		success: function(data) {
			var html = '';
			for(var i = 0; i < data.obj.results.length; i++) {

				html += `
						<div class="jstRtits">
							<div class="jstRtit">${data.obj.results[i].menuName}</div>
							<div class="jstRtxts">`;
				for(var j = 0; j < data.obj.results[i].modelList.length; j++) {

					html += `<div class="jstRtxt">
								<img class="" data-menuUseId="${data.obj.results[i].modelList[j].modelid}" src="img/checkbox.png"/><span>${data.obj.results[i].modelList[j].modelName}</span></div>`;
				}
				html += `<div class="claer"></div>
							</div>
						</div>`;
			}
			$(".jstDist .disCon .right").html(
				html + `<div class="jstRtxtBtn"><botton class="jstRtxtBtn00 jstRtxtBtnOK">确定</botton></div>`
			);

			var numId = $(".jstDist .disCon .left .jstUl .on").attr("data-id");
			var Id = $(".jstDist .disCon .left .jstLiW .on").attr("data-use");
			if(Id != undefined) {
				selectId(Id);
				//权限分配--改变权限
				$(".jstRtxt").each(function(j) {
					$(".jstRtxt img").eq(j).unbind("click").on("click", function() {
						var dian = $(this).attr("data-menuuseid")
						var src = $(this).attr("src")
						$.ajax({
							type: "get",
							url: http + 'userAuthorityController/getModelByRoleId',
							data: {
								id: numId
							},
							success: function(data) {
								var array = []
								for(var i = 0; i < data.obj.results.length; i++) {
									array.push(data.obj.results[i].modelid)
								}
								if(array.indexOf(Number(dian)) >= 0) {
									parent.$(".smallkuang-header span").html("权限管理")
									parent.$(".sp18").html("公共权限不能修改")
									parent.$(".baohu").show()
									parent.$(".RejectBtn").show()
								} else {
									if($(".jstDist .disCon .left .jstUl .on").size() == 0) {
										parent.$(".promptAlt .con .body p").html("请选择左侧用户");
										parent.$(".promptAlt").fadeIn();
										return;
									}
									if(src == "img/checkbox.png") {
										$(".jstRtxt img").eq(j).parent().addClass("jstRtxtOn")
										$(".jstRtxt img").eq(j).attr("src", "img/checkbox2.png");
									} else {
										$(".jstRtxt img").eq(j).parent().removeClass("jstRtxtOn")
										$(".jstRtxt img").eq(j).attr("src", "img/checkbox.png");
									};
								}

							}
						});
					});
				});

			} else {
				selectRoleId(numId);
				//人员管理 check切换
				$(".jstRtxt").each(function(i) {
					$(".jstRtxt img").eq(i).unbind("click").on("click", function() {
						if($(".jstDist .disCon .left .jstUl .on").size() == 0) {
							$(".promptAlt .con .body p").html("请选择左侧用户");
							$(".promptAlt").fadeIn();
							return;
						}
						if($(this).attr("src") == "img/checkbox.png") {
							$(this).parent().addClass("jstRtxtOn")
							$(this).attr("src", "img/checkbox2.png");
						} else {
							$(this).parent().removeClass("jstRtxtOn")
							$(this).attr("src", "img/checkbox.png");
						};
					});
				});

			}

		}
	});
}
//权限分配--角色/账号--模块信息修改
function jstRtxtIsOK() {
	$(".promptAltJst").fadeIn();
	$(".promptAltJst .con").fadeIn();
	$(".promptAltJst .con .body p").html("确认进行修改吗！")

	//判断点击的是角色还是账号
	if($("iframe.crumbsCon")[0].contentWindow.$(".jstDist .disCon .left .jstLiW .on").length == 1) {
		//点击的是角色选项  
		$(".promptAltJst .con").on("click", ".promptAltJstOK", function() {
			//权限分配--账号--确定修改
			var Id = $("iframe.crumbsCon")[0].contentWindow.$(".jstDist .disCon .left .jstLiW .on").attr("data-use");
			var loginName = $("iframe.crumbsCon")[0].contentWindow.$(".jstDist .disCon .left .jstLiW .on").html()
			var idsW = '';
			for(var i = 0; i < $("iframe.crumbsCon")[0].contentWindow.$(".jstDist .disCon .jstRtxts .jstRtxtOn").size(); i++) {
				if(i == 0) {
					idsW += $("iframe.crumbsCon")[0].contentWindow.$(".jstRtxtOn").eq(i).find("img").attr("data-menuuseid");
				} else {
					idsW += ',' + $("iframe.crumbsCon")[0].contentWindow.$(".jstRtxtOn").eq(i).find("img").attr("data-menuuseid");
				}
			}
			$.ajax({
				type: "get",
				url: http + "userAuthorityController/updateUserAuthority",
				data: {
					userName: sessionStorage.sName,
					deptid: sessionStorage.sUserDept,
					loginName: loginName,
					id: Id,
					ids: idsW
				},
				dataType: 'json',
				success: function(data) {
					if(data.code ==0){
						parent.$(".wifi_del_sure").show()
						parent.$(".baohu").show()
						selectUserLeft();//刷新左侧栏
					}
				}
			});
			$(".promptAltJst").fadeOut();
		});
	} else {//点击的账号左侧栏
		$(".promptAltJst .con").on("click", ".promptAltJstOK", function() {
			//权限分配--账号--确定修改
			var roleId = $("iframe.crumbsCon")[0].contentWindow.$(".jstDist .disCon .left .jstUl .on").attr("data-id");
			var roleName = $("iframe.crumbsCon")[0].contentWindow.$(".jstDist .disCon .left .jstUl .on").html()
			var idsW = '';
			for(var i = 0; i < $("iframe.crumbsCon")[0].contentWindow.$(".jstDist .disCon .jstRtxts .jstRtxtOn").size(); i++) {
				if(i == 0) {
					idsW += $("iframe.crumbsCon")[0].contentWindow.$(".jstRtxtOn").eq(i).find("img").attr("data-menuuseid");
				} else {
					idsW += ',' + $("iframe.crumbsCon")[0].contentWindow.$(".jstRtxtOn").eq(i).find("img").attr("data-menuuseid");
				}
			}
			$.ajax({
				type: "get",
				url: http + "userAuthorityController/updateRoleAuthority",
				data: {
					userName: sessionStorage.sName,
					deptid: sessionStorage.sUserDept,
					roleName: roleName,
					id: roleId,
					ids: idsW
				},
				dataType: 'json',
				success: function(data) {
					if(data.code ==0){
						parent.$(".wifi_del_sure").show()
						parent.$(".baohu").show()
						selectUserLeft();//刷新左侧栏
					}
				}
			});
			$(".promptAltJst").fadeOut();
		});
	}
}

$(".promptAltJst").on("click", ".promptAltJstNO", function() {
	$("iframe.crumbsCon")[0].contentWindow.AllotSystemAuthority();
	$(".promptAltJst").fadeOut();
});

//角色判断
//$(".promptAltJst").on("click",".promptAltJstNO",function(){
////	var useNum = $(".jstDist .disCon .left .jstUl .on").attr("data-use");
////	console.log(useNum)
////  selectRoleId(useNum);
//	$("iframe.crumbsCon")[0].contentWindow.AllotSystemAuthority();
//	$(".promptAltJst").fadeOut();
//});

$(function() {
	$.ajax({
		type: "get",
		url: http + "statistics/deptListByRole.do",
		data: {
			code: sessionStorage.sRoleId,
			deptid: sessionStorage.sUserDept
		},
		dataType: 'json',
		success: function(data) {

			var html = '';
			for(var i = 0; i < data.obj.length; i++) {
				html += `
		<option value="${data.obj[i].deptid}">${data.obj[i].deptName}</option>
				`;
			}

			$(".iCbBtnR .teadSelect").html(`<option value="-1">请选择大队</option>` + html);
		}
	});
});

////保护层
//function autoMask00(){
//	$(".autoMask").fadeIn();
//}
//function autoMask01(){
//	$(".autoMask").fadeOut();
//}

//操作日志
//function operationDateChoseCrb(){
//	var page = '';
//	var rows = '';
//	$.ajax({
//		url:http+"operationLogController/getOperationLogList.do",
//		type:'POST',
////		data:{
////			operationTime:,//日期
////			operationPersonnel:,//操作人
////			operationIP:,//ip地址
////			page: ,//当前页
////			rows: ,// 每页多少条
////		},
//		datatype:'JSON',
//		success:function(data){
//			
//		}	
//	})
//}

//2017.7.10

//判断全选
function checkAuto00() {
	if($("tbody .changetd").size() == 0) {
		$("thead .changetd").attr("class", "changetd bg5");
		return;
	}
	if($("tbody .changetd").size() == $("tbody .bg6").size()) {
		$("thead .changetd").attr("class", "changetd bg6");
		return;
	}
	$("thead .changetd").attr("class", "changetd bg5");

}


//关闭公告弹窗
$(".publicAlertSmall .publicAlertSmallHeader a").on("click", function() {
	$(".baohu").fadeOut();
	$(".publicAlertSmall").fadeOut();
});

$(".publicAlertSmall .publicAlertSmallfoot .publicSmallBtnNo").on("click", function() {
	$(".baohu").fadeOut();
	$(".publicAlertSmall").fadeOut();
});

if($(".rollcalluserCreatetime").size() >= 0) {
	//调用日历
	$(".rollcalluserCreatetime").jeDate({
		format: "YYYY-MM-DD",
		isTime: false,
		maxDate: "2080-09-19 00:00:00"
	})
}



