var Util = Util || {};
Util.isIE6 = !window.XMLHttpRequest;	//ie6
/*session失效时重定向到的URL地址*/
Util.getLoginUrl = function () {
    return "";
}

/**  数组insert**/
Array.prototype.insertAt = function (index, obj) {
    this.splice(index, 0, obj);
}

/**
 *   功能：合并最终URL地址
 */
Util.getActionUrl = function (url, sysPath, sysSid) {
    var result = !sysPath ? path : sysPath;
    result += url;
    if (url.indexOf("?") >= 0) {
        result += "&sid=" + (!sysSid ? sid : sysSid);
    } else {
        result += "?sid=" + (!sysSid ? sid : sysSid);
    }
    return result;
};
Util.ajaxGet = function (url, params, callback, lock) {
    lock = lock || false;
    if (lock) {
        $.dialog.openLoading();
    }
    if (params) { // 处理参数中的 function、
        for (var i in params) {
            if (typeof params[i] == "function") {
                params[i] = undefined;
            }
        }
    }
    $.ajax({
        type: "POST",
        url: url,
        dataType: "json",
        data: params,
        success: function (data, status) {
            if (lock) {
                $.dialog.closeLoading();
            }
            //if (data && data.Code == -301) {
            //    $.dialog.alert(data.Message, function () {
            //        top.location.href = Util.loginUrl();
            //    });
            //}
            callback(data);
        },
        error: function (err) {
            if (lock) {
                $.dialog.closeLoading();
            }
            //alert("error");
            parent.Util.tips({type: 1, content: '操作失败了哦，请检查您的网络链接！'});
        }
    });
};
Util.ajaxPost = function (url, params, callback, lock, errorback) {
    lock = (lock == undefined ? true : lock);
    var did = "ajaxPost";
    if (lock) {
        $.dialog.openLoading(did);
    }
    if (params) { // 处理参数中的 function、
        for (var i in params) {
            if (typeof params[i] == "function") {
                params[i] = undefined;
            }
        }
    }
    $.ajax({
        type: "POST",
        url: url,
        data: params,
        dataType: "json",
        success: function (data, status) {
            if (lock) {
                $.dialog.closeLoading(did);
            }
            if (data && data.code == -301) {
                $.dialog.alert(data.Message, function () {
                    top.location.href = Util.loginUrl();
                });
            }
            callback(data);
        },
        error: function (err) {
            if (lock) {
                $.dialog.closeLoading(did);
            }
            //parent.Util.tips({ type: 1, content: '操作失败了哦，请检查您的网络链接！' });
            if (errorback) {
                errorback(err);
            }
        }
    });
};
/*获取URL所有参数值*/
Util.getRequest = function () {
    var param, url = location.search, theRequest = {};
    if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        strs = str.split("&");
        for (var i = 0, len = strs.length; i < len; i++) {
            param = strs[i].split("=");
            theRequest[param[0]] = decodeURIComponent(param[1]);
        }
    }
    return theRequest;
}
/*
 *   获取Url参数
 *   p：参数名称
 *   defaultVal:没有找到参数的默认值,可以不填
 */
Util.getParameter = function (p, defaultVal) {
    var url = window.location.toString();
    var str = "{0:0}";
    if (url.indexOf("?") != -1) { //判断有没有参数
        str = "";
        var ary = url.split("?")[1].split("&");
        for (var i = 0; i < ary.length; i++) {
            str += ary[i].split("=")[0] + ":"; //参数名称
            str += "\"" + ary[i].split("=")[1] + "\","; //参数值 
        }
        str = "{" + str.substring(0, str.length - 1) + "}";
    }
    try {
        eval("Pram=" + str)
        var val = eval("Pram." + p)
        return val == undefined ? (defaultVal) : val;
    } catch (e) {
        return defaultVal;
    }
}
Util.beginDate = function () {
    var t = new Date,
        e = t.getFullYear(),
        i = ("0" + (t.getMonth() + 1)).slice(-2),
        r = ("0" + t.getDate()).slice(-2);
    //return (e + "-" + i + "-01");
    var day = t.getDate();
    if (day < 10) {
        day = "0" + day;
    }
    //判断年份
    if (t.getMonth() == 0) {
        e = e - 1;
        i = "12";
    } else {
        i = t.getMonth();
    }
    return (e + "-" + i + "-" + day);
}
Util.endDate = function () {
    var t = new Date,
        e = t.getFullYear();
    //    i = ("0" + (t.getMonth() + 1)).slice(-2),
    //    r = ("0" + t.getDate()).slice(-2);
    //return (e + "-" + i + "-" + r);

    //改成当天的日期
    var month = t.getMonth() + 1
    if (month < 10) {
        month = "0" + month;
    }
    var day = t.getDate();
    if (day < 10) {
        day = "0" + day;
    }

    return (e + "-" + month + "-" + day);
}
//本月最后一天
Util.monthEndDate = function () {

    var d = new Date(new Date().getFullYear(), new Date().getMonth(), 0);
    var t = new Date();
    var e = t.getFullYear();
    var i = ("0" + (t.getMonth() + 1)).slice(-2);
    var r = ("0" + d.getDate()).slice(-2);

    //改成当天的日期
    var month = t.getMonth() + 1
    if (month < 10) {
        month = "0" + month;
    }
    var day = t.getDate();
    if (day < 10) {
        day = "0" + day;
    }

    return (e + "-" + month + "-" + day);
    //
    //return (e + "-" + i + "-" + r);
}
Util.getDate = function (days) {
    var t = new Date;
    t.setDate(t.getDate() + days);
    var e = t.getFullYear(), i = ("0" + (t.getMonth() + 1)).slice(-2), r = ("0" + t.getDate()).slice(-2);
    return (e + "-" + i + "-" + r);
}

function formatNum(i) {
    if (i < 10) {
        return "0" + i;
    }
    return i;
}
/**
 *   功能：json 日期字符串转换成日期对象
 */
Util.ConvertJSONDateToJSDateObject = function (JSONDateString) {
    try {
        var date = new Date(parseInt(JSONDateString.replace("/Date(", "").replace(")/", ""), 10));
        return date;
    } catch (e) {
        return JSONDateString;
    }
}

/**
 *   功能：json 日期字符串转换成日期对象
 *   FOR TEXTFIELD
 */
Util.ConvertJSONDateToJSDateObjectTextField = function (JSONDateString) {
    try {
        var date = new Date(parseInt(JSONDateString.replace("/Date(", "").replace(")/", ""), 10));
        return Util.DateToString(date);
    } catch (e) {
        return JSONDateString;
    }
}

Util.ConvertJSONDateToString = function (jsonDate) {
    try {
        var date = new Date(parseInt(jsonDate.replace("/Date(", "").replace(")/", ""), 10));
        return Util.DateToString(date, true);
    } catch (e) {
        return jsonDate;
    }
}

Util.ProcessDate = function (date) {
    try {
        //判断 date 是不是 date类型
        var nd = new Date(date);
        // console.info(nd);
        //判断nd 是不是真正日期

        var withSeconds = true;
        if (isNaN(nd.getTime())) {
            //非正常格式的日期 ，最后加 :00
            if (typeof date == "string") {
                //解析 string格式 的日期
                var ps = date.split(" ");
                var d = ps[0].split("-");
                var t = ps[1].split(":");
                nd = new Date(d[0], parseInt(d[1]) - 1, d[2], t[0], t[1], 0);
                //withSeconds = false;
            }
        }

        date = nd;
        return date;
    } catch (e) {
        return null;
    }
}
/**
 *  将日期转换成 年-月-日格式的字符串
 */
Util.DateToString = function (date, withTime) {
    try {
        //判断 date 是不是 date类型
        var nd = new Date(date);
        // console.info(nd);
        //判断nd 是不是真正日期

        var withSeconds = true;
        if (isNaN(nd.getTime())) {
            //非正常格式的日期 ，最后加 :00
            if (typeof date == "string") {
                //解析 string格式 的日期
                var ps = date.split(" ");
                var d = ps[0].split("-");
                var t = ps[1].split(":");
                nd = new Date(d[0], parseInt(d[1]) - 1, d[2], t[0], t[1], 0);
                //withSeconds = false;
            }
        }

        date = nd;
        var yyyy = date.getFullYear().toString();
        var month = date.getMonth() + 1; //月份需+1运算
        var MM = month.toString().length == 1 ? "0" + month.toString() : month.toString();
        var dd = date.getDate().toString().length == 1 ? "0" + date.getDate().toString() : date.getDate().toString();
        if (withTime) {
            var hour = date.getHours().toString().length == 1 ? "0" + date.getHours() : date.getHours();
            var mi = date.getMinutes().toString().length == 1 ? "0" + date.getMinutes() : date.getMinutes();
            var s = date.getSeconds().toString().length == 1 ? "0" + date.getSeconds() : date.getSeconds();

            var str = yyyy + "-" + MM + "-" + dd + " " + hour + ":" + mi;
            if (withSeconds) {
                str += ":" + s;
            }
            return str;
        }
        return yyyy + "-" + MM + "-" + dd;
    } catch (e) {
        return null;
    }
}

/**
 *   功能：json 转字符串
 */
Util.jsonToString = function (obj) {
    var THIS = this;
    switch (typeof (obj)) {
        case 'string':
            return '"' + obj.replace(/(["\\])/g, '\\$1') + '"';
        case 'array':
            return '[' + obj.map(THIS.jsonToString).join(',') + ']';
        case 'object':
            if (obj instanceof Array) {
                var strArr = [];
                var len = obj.length;
                for (var i = 0; i < len; i++) {
                    strArr.push(THIS.jsonToString(obj[i]));
                }
                return '[' + strArr.join(',') + ']';
            } else if (obj == null) {
                return 'null';

            } else {
                var string = [];
                for (var property in obj) string.push(THIS.jsonToString(property) + ':' + THIS.jsonToString(obj[property]));
                return '{' + string.join(',') + '}';
            }
        case 'number':
            return obj;
        case false:
            return obj;
    }
};

//设置表格宽高
Util.setGrid = function (adjustH, adjustW) {
    var adjustH = adjustH || 30;
    var adjustW = adjustW || 45;
    var gridW = $(window).width() - adjustW, gridH = $(document).height() - $(".grid-wrap").offset().top - adjustH;

    //console.info(gridW +":" + gridH +" :: " + $(document).height() +">" + $(".grid-wrap").offset().top +" --- " + adjustH);
    return {
        w: gridW,
        h: gridH
    }
};
//重设表格宽高
Util.resizeGrid = function (adjustH, adjustW) {
    var grid = $("#grid");
    var gridWH = Util.setGrid(adjustH, adjustW);
    grid.jqGrid('setGridHeight', gridWH.h);
    grid.jqGrid('setGridWidth', gridWH.w);
};
//重设表格宽高
Util.resizeGridWidth = function (adjustW) {
    var grid = $("#grid");
    var gridWH = Util.setGrid(0, adjustW);
    grid.jqGrid('setGridWidth', gridWH.w);
};

Util.numerical = function (e) {
    var allowed = '0123456789.-', allowedReg;
    allowed = allowed.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
    allowedReg = new RegExp('[' + allowed + ']');
    var charCode = typeof e.charCode != 'undefined' ? e.charCode : e.keyCode;
    var keyChar = String.fromCharCode(charCode);
    if (!e.ctrlKey && charCode != 0 && !allowedReg.test(keyChar)) {
        e.preventDefault();
    }
    ;
};
Util.numToCurrency = function (val, dec) {
    val = parseFloat(val);
    dec = dec || 2;	//小数位
    if (val === 0 || isNaN(val)) {
        return '0';
    }
    val = val.toFixed(dec).split('.');
    var reg = /(\d{1,3})(?=(\d{3})+(?:$|\D))/g;
    return val[0].replace(reg, "$1,") + '.' + val[1];
};
//数值显示
Util.currencyToNum = function (val) {
    var val = String(val);
    if ($.trim(val) == '') {
        return 0.00;
    }
    val = val.replace(/,/g, '');
    val = parseFloat(val);
    return isNaN(val) ? 0 : val;
};
//验证邮箱
Util.isMail = function (email) {
    var patten = new RegExp(/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+(com|cn)$/);
    return patten.test(email);
}
//验证手机
Util.isMobile = function (mobile) {
    var patten = new RegExp(/^1[3|4|5|8][0-9]\d{4,8}$/);
    return patten.test(mobile);
}
Util.billsOper = function (val, opt, row) {
    var html_con = '<div class="operating" data-id="' + opt.rowId + '"><span class="ui-icon ui-icon-plus" title="新增行"></span><span class="ui-icon ui-icon-trash" title="删除行"></span></div>';
    return html_con;
};
Util.billsOperDel = function (val, opt, row) {
    var html_con = '<div class="operating" data-id="' + opt.rowId + '"><span class="ui-icon ui-icon-trash" title="删除行"></span></div>';
    return html_con;
};
Util.billsSave = function (val, opt, row) {
    var html = '<a href="javascript:void(0)" data-id="' + opt.rowId + '"><span class="save">确认</span></a>&nbsp;&nbsp;<a href="javascript:void(0)" data-id="' + opt.rowId + '"><span class="del">取消加班</span></a>';
    return html;
};

Util.getGuid = function () {
    var S4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    var result = S4() + S4();
    result += S4();
    result += S4();
    result += S4();
    result += S4() + S4() + S4();
    return result;
    //return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
}
/*Tab控制函数*/
Util.tabs = function (tabObj) {
    var tabNum = $(tabObj).parent().index("li")
    //设置点击后的切换样式
    $(tabObj).parent().parent().find("li a").removeClass("selected");
    $(tabObj).addClass("selected");
    //根据参数决定显示内容
    $(".tab-content").hide();
    $(".tab-content").eq(tabNum).show();
};
/*操作提示*/
Util.successTips = function (content, options) {
    if (options == undefined) {
        options = {}
    }
    options.content = content;
    Util.tips(options);
}
Util.warningTips = function (content, options) {
    if (options == undefined) {
        options = {}
    }
    options.content = content;
    options.type = 2;
    Util.tips(options);
}
Util.errorTips = function (content, options) {
    if (options == undefined) {
        options = {}
    }
    options.content = content;
    options.type = 1;
    Util.tips(options);
}
Util.tips = function (options) {
    return new Util.Tips(options);
}
Util.Tips = function (options) {
    var defaults = {
        renderTo: 'body',
        type: 0,
        autoClose: true,
        removeOthers: true,
        time: undefined,
        top: 10,
        onClose: null,
        onShow: null
    }
    this.options = $.extend({}, defaults, options);
    this._init();
    !Util.Tips._collection ? Util.Tips._collection = [this] : Util.Tips._collection.push(this);
}
Util.Tips.removeAll = function () {
    try {
        for (var i = Util.Tips._collection.length - 1; i >= 0; i--) {
            Util.Tips._collection[i].remove();
        }
    } catch (e) {
    }
}
Util.Tips.prototype = {
    _init: function () {
        var self = this, opts = this.options, time;
        if (opts.removeOthers) {
            Util.Tips.removeAll();
        }
        this._create();
        this.closeBtn.bind('click', function () {
            self.remove();
        });
        if (opts.autoClose) {
            time = opts.time || opts.type == 1 ? 5000 : 3000;
            window.setTimeout(function () {
                self.remove();
            }, time);
        }
    },
    _create: function () {
        var opts = this.options;
        this.obj = $('<div class="ui-tips"><i></i><span class="close"></span></div>').append(opts.content);
        this.closeBtn = this.obj.find('.close');
        switch (opts.type) {
            case 0:
                this.obj.addClass('ui-tips-success');
                break;
            case 1:
                this.obj.addClass('ui-tips-error');
                break;
            case 2:
                this.obj.addClass('ui-tips-warning');
                break;
            default:
                this.obj.addClass('ui-tips-success');
                break;
        }
        this.obj.appendTo('body').hide();
        this._setPos();
        if (opts.onShow) {
            opts.onShow();
        }
    },
    _setPos: function () {
        var self = this, opts = this.options;
        if (opts.width) {
            this.obj.css('width', opts.width);
        }
        var h = this.obj.outerHeight(), winH = $(window).height(), scrollTop = $(window).scrollTop();
        //var top = parseInt(opts.top) ? (parseInt(opts.top) + scrollTop) : (winH > h ? scrollTop+(winH - h)/2 : scrollTop);
        var top = parseInt(opts.top) + scrollTop;
        this.obj.css({
            position: Util.isIE6 ? 'absolute' : 'fixed',
            left: '50%',
            top: top,
            zIndex: '9999',
            marginLeft: -self.obj.outerWidth() / 2
        });
        window.setTimeout(function () {
            self.obj.show().css({
                marginLeft: -self.obj.outerWidth() / 2
            });
        }, 150);

        if (Util.isIE6) {
            $(window).bind('resize scroll', function () {
                var top = $(window).scrollTop() + parseInt(opts.top);
                self.obj.css('top', top);
            })
        }
    },
    remove: function () {
        var opts = this.options;
        this.obj.fadeOut(200, function () {
            $(this).remove();
            if (opts.onClose) {
                opts.onClose();
            }
        });
    }
};

Util.setCookie = function (name, value, d) {
    var Days = 30;
    if (d) {
        Days = d;
    }
    var exp = new Date();
    exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
    document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString();


    //var strsec = getsec(time);
    //var exp = new Date();
    //exp.setTime(exp.getTime() + strsec*1);
    //document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
}
Util.getCookie = function (name) {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");

    if (arr = document.cookie.match(reg)) {

        return (arr[2]);
    }
    else {
        return null;
    }
}

Util.removeCookie = function (name) {
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval = Util.getCookie(name);
    if (cval != null)
        document.cookie = name + "=" + cval + ";expires=" + exp.toGMTString();
}


/* MD5 Message-Digest Algorithm - JavaScript
 */
Util.getMD5 = function MD5(sMessage) {
    function RotateLeft(lValue, iShiftBits) {
        return (lValue << iShiftBits) | (lValue >>> (32 - iShiftBits));
    }

    function AddUnsigned(lX, lY) {
        var lX4, lY4, lX8, lY8, lResult;
        lX8 = (lX & 0x80000000);
        lY8 = (lY & 0x80000000);
        lX4 = (lX & 0x40000000);
        lY4 = (lY & 0x40000000);
        lResult = (lX & 0x3FFFFFFF) + (lY & 0x3FFFFFFF);
        if (lX4 & lY4) return (lResult ^ 0x80000000 ^ lX8 ^ lY8);
        if (lX4 | lY4) {
            if (lResult & 0x40000000) return (lResult ^ 0xC0000000 ^ lX8 ^ lY8);
            else return (lResult ^ 0x40000000 ^ lX8 ^ lY8);
        } else return (lResult ^ lX8 ^ lY8);
    }

    function F(x, y, z) {
        return (x & y) | ((~x) & z);
    }

    function G(x, y, z) {
        return (x & z) | (y & (~z));
    }

    function H(x, y, z) {
        return (x ^ y ^ z);
    }

    function I(x, y, z) {
        return (y ^ (x | (~z)));
    }

    function FF(a, b, c, d, x, s, ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(F(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    }

    function GG(a, b, c, d, x, s, ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(G(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    }

    function HH(a, b, c, d, x, s, ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(H(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    }

    function II(a, b, c, d, x, s, ac) {
        a = AddUnsigned(a, AddUnsigned(AddUnsigned(I(b, c, d), x), ac));
        return AddUnsigned(RotateLeft(a, s), b);
    }

    function ConvertToWordArray(sMessage) {
        var lWordCount;
        var lMessageLength = sMessage.length;
        var lNumberOfWords_temp1 = lMessageLength + 8;
        var lNumberOfWords_temp2 = (lNumberOfWords_temp1 - (lNumberOfWords_temp1 % 64)) / 64;
        var lNumberOfWords = (lNumberOfWords_temp2 + 1) * 16;
        var lWordArray = Array(lNumberOfWords - 1);
        var lBytePosition = 0;
        var lByteCount = 0;
        while (lByteCount < lMessageLength) {
            lWordCount = (lByteCount - (lByteCount % 4)) / 4;
            lBytePosition = (lByteCount % 4) * 8;
            lWordArray[lWordCount] = (lWordArray[lWordCount] | (sMessage.charCodeAt(lByteCount) << lBytePosition));
            lByteCount++;
        }
        lWordCount = (lByteCount - (lByteCount % 4)) / 4;
        lBytePosition = (lByteCount % 4) * 8;
        lWordArray[lWordCount] = lWordArray[lWordCount] | (0x80 << lBytePosition);
        lWordArray[lNumberOfWords - 2] = lMessageLength << 3;
        lWordArray[lNumberOfWords - 1] = lMessageLength >>> 29;
        return lWordArray;
    }

    function WordToHex(lValue) {
        var WordToHexValue = "", WordToHexValue_temp = "", lByte, lCount;
        for (lCount = 0; lCount <= 3; lCount++) {
            lByte = (lValue >>> (lCount * 8)) & 255;
            WordToHexValue_temp = "0" + lByte.toString(16);
            WordToHexValue = WordToHexValue + WordToHexValue_temp.substr(WordToHexValue_temp.length - 2, 2);
        }
        return WordToHexValue;
    }

    var x = Array();
    var k, AA, BB, CC, DD, a, b, c, d
    var S11 = 7, S12 = 12, S13 = 17, S14 = 22;
    var S21 = 5, S22 = 9, S23 = 14, S24 = 20;
    var S31 = 4, S32 = 11, S33 = 16, S34 = 23;
    var S41 = 6, S42 = 10, S43 = 15, S44 = 21;
    // Steps 1 and 2. Append padding bits and length and convert to words
    x = ConvertToWordArray(sMessage);
    // Step 3. Initialise
    a = 0x67452301;
    b = 0xEFCDAB89;
    c = 0x98BADCFE;
    d = 0x10325476;
    // Step 4. Process the message in 16-word blocks
    for (k = 0; k < x.length; k += 16) {
        AA = a;
        BB = b;
        CC = c;
        DD = d;
        a = FF(a, b, c, d, x[k + 0], S11, 0xD76AA478);
        d = FF(d, a, b, c, x[k + 1], S12, 0xE8C7B756);
        c = FF(c, d, a, b, x[k + 2], S13, 0x242070DB);
        b = FF(b, c, d, a, x[k + 3], S14, 0xC1BDCEEE);
        a = FF(a, b, c, d, x[k + 4], S11, 0xF57C0FAF);
        d = FF(d, a, b, c, x[k + 5], S12, 0x4787C62A);
        c = FF(c, d, a, b, x[k + 6], S13, 0xA8304613);
        b = FF(b, c, d, a, x[k + 7], S14, 0xFD469501);
        a = FF(a, b, c, d, x[k + 8], S11, 0x698098D8);
        d = FF(d, a, b, c, x[k + 9], S12, 0x8B44F7AF);
        c = FF(c, d, a, b, x[k + 10], S13, 0xFFFF5BB1);
        b = FF(b, c, d, a, x[k + 11], S14, 0x895CD7BE);
        a = FF(a, b, c, d, x[k + 12], S11, 0x6B901122);
        d = FF(d, a, b, c, x[k + 13], S12, 0xFD987193);
        c = FF(c, d, a, b, x[k + 14], S13, 0xA679438E);
        b = FF(b, c, d, a, x[k + 15], S14, 0x49B40821);
        a = GG(a, b, c, d, x[k + 1], S21, 0xF61E2562);
        d = GG(d, a, b, c, x[k + 6], S22, 0xC040B340);
        c = GG(c, d, a, b, x[k + 11], S23, 0x265E5A51);
        b = GG(b, c, d, a, x[k + 0], S24, 0xE9B6C7AA);
        a = GG(a, b, c, d, x[k + 5], S21, 0xD62F105D);
        d = GG(d, a, b, c, x[k + 10], S22, 0x2441453);
        c = GG(c, d, a, b, x[k + 15], S23, 0xD8A1E681);
        b = GG(b, c, d, a, x[k + 4], S24, 0xE7D3FBC8);
        a = GG(a, b, c, d, x[k + 9], S21, 0x21E1CDE6);
        d = GG(d, a, b, c, x[k + 14], S22, 0xC33707D6);
        c = GG(c, d, a, b, x[k + 3], S23, 0xF4D50D87);
        b = GG(b, c, d, a, x[k + 8], S24, 0x455A14ED);
        a = GG(a, b, c, d, x[k + 13], S21, 0xA9E3E905);
        d = GG(d, a, b, c, x[k + 2], S22, 0xFCEFA3F8);
        c = GG(c, d, a, b, x[k + 7], S23, 0x676F02D9);
        b = GG(b, c, d, a, x[k + 12], S24, 0x8D2A4C8A);
        a = HH(a, b, c, d, x[k + 5], S31, 0xFFFA3942);
        d = HH(d, a, b, c, x[k + 8], S32, 0x8771F681);
        c = HH(c, d, a, b, x[k + 11], S33, 0x6D9D6122);
        b = HH(b, c, d, a, x[k + 14], S34, 0xFDE5380C);
        a = HH(a, b, c, d, x[k + 1], S31, 0xA4BEEA44);
        d = HH(d, a, b, c, x[k + 4], S32, 0x4BDECFA9);
        c = HH(c, d, a, b, x[k + 7], S33, 0xF6BB4B60);
        b = HH(b, c, d, a, x[k + 10], S34, 0xBEBFBC70);
        a = HH(a, b, c, d, x[k + 13], S31, 0x289B7EC6);
        d = HH(d, a, b, c, x[k + 0], S32, 0xEAA127FA);
        c = HH(c, d, a, b, x[k + 3], S33, 0xD4EF3085);
        b = HH(b, c, d, a, x[k + 6], S34, 0x4881D05);
        a = HH(a, b, c, d, x[k + 9], S31, 0xD9D4D039);
        d = HH(d, a, b, c, x[k + 12], S32, 0xE6DB99E5);
        c = HH(c, d, a, b, x[k + 15], S33, 0x1FA27CF8);
        b = HH(b, c, d, a, x[k + 2], S34, 0xC4AC5665);
        a = II(a, b, c, d, x[k + 0], S41, 0xF4292244);
        d = II(d, a, b, c, x[k + 7], S42, 0x432AFF97);
        c = II(c, d, a, b, x[k + 14], S43, 0xAB9423A7);
        b = II(b, c, d, a, x[k + 5], S44, 0xFC93A039);
        a = II(a, b, c, d, x[k + 12], S41, 0x655B59C3);
        d = II(d, a, b, c, x[k + 3], S42, 0x8F0CCC92);
        c = II(c, d, a, b, x[k + 10], S43, 0xFFEFF47D);
        b = II(b, c, d, a, x[k + 1], S44, 0x85845DD1);
        a = II(a, b, c, d, x[k + 8], S41, 0x6FA87E4F);
        d = II(d, a, b, c, x[k + 15], S42, 0xFE2CE6E0);
        c = II(c, d, a, b, x[k + 6], S43, 0xA3014314);
        b = II(b, c, d, a, x[k + 13], S44, 0x4E0811A1);
        a = II(a, b, c, d, x[k + 4], S41, 0xF7537E82);
        d = II(d, a, b, c, x[k + 11], S42, 0xBD3AF235);
        c = II(c, d, a, b, x[k + 2], S43, 0x2AD7D2BB);
        b = II(b, c, d, a, x[k + 9], S44, 0xEB86D391);
        a = AddUnsigned(a, AA);
        b = AddUnsigned(b, BB);
        c = AddUnsigned(c, CC);
        d = AddUnsigned(d, DD);
    }
    // Step 5. Output the 128 bit digest
    var temp = WordToHex(a) + WordToHex(b) + WordToHex(c) + WordToHex(d);
    return temp.toLowerCase();//toUpperCase返回全是大写字母 toLowerCase :返回小写
}

/**
 *  格式化时间
 * @param d 时间戳
 * @returns {*}
 */
Util.formatDate = function (d, withTime) {
    var date = new Date(d);

    return Util.DateToString(date, withTime);

}

/** 判断 这个日期是不是今天**/
Util.isToday = function (d) {
    var date = new Date(d);
    var today = new Date();

    //console.info(date.getFullYear() +"_" +date.getMonth() +"_" + date.getDate() );
    return (date.getFullYear() == today.getFullYear() &&
    date.getMonth() == today.getMonth() &&
    date.getDate() == today.getDate());
}


/**
 *  参数时间戳
 * @param d1
 * @param d2
 */
Util.dateDiff = function (d1, d2) {
    var date1 = new Date(d2);  //开始时间
    var date2 = new Date(d1);    //结束时间
    var date3 = date2.getTime() - date1.getTime()  //时间差的毫秒数


//计算出相差天数
    var days = Math.floor(date3 / (24 * 3600 * 1000))


//计算出小时数
    var leave1 = date3 % (24 * 3600 * 1000)    //计算天数后剩余的毫秒数
    var hours = Math.floor(leave1 / (3600 * 1000))
//计算相差分钟数
    var leave2 = leave1 % (3600 * 1000)        //计算小时数后剩余的毫秒数
    var minutes = Math.floor(leave2 / (60 * 1000))


//计算相差秒数
    var leave3 = leave2 % (60 * 1000)      //计算分钟数后剩余的毫秒数
    var seconds = Math.round(leave3 / 1000)

    return ( ( days > 0 ? days + "天 " : "") + (hours < 10 ? "0" + hours : hours) + ":"
    + (minutes < 10 ? "0" + minutes : minutes) + ":" +
    (seconds < 10 ? "0" + seconds : seconds) + "");
    //alert(" 相差 "+days+"天 "+hours+"小时 "+minutes+" 分钟"+seconds+" 秒")
}

/**
 *  映射obj属性到 界面上
 * @param obj
 */
Util.mappingValueToPage = function (obj) {
    //查找整个document
    for (var i in obj) {
        if (typeof obj[i] != "function") {
            var dom = document.getElementById(i);
            if (dom) {
                dom.value = obj[i];
//              console.log(dom);
            }
        }
    }
}
/**
 *  将界面上元素映射到 obj对象上
 * @param obj
 */
Util.mappingValue = function (obj) {
    for (var i in obj) {
        if (typeof obj[i] != "function") {
            var dom = document.getElementById(i);
            if (dom) {
                obj[i] = $.trim(dom.value);
            }
        }
    }
}
/**
 *  从原对象中 复制 一些列到新对象中
 * @param srcObj
 * @param columns
 * @returns {{}}
 */
Util.getObj = function (srcObj, columns) {
    var desObj = {};
    for (var o in columns) {
        if (srcObj[columns[o]]) {
            desObj[columns[o]] = srcObj[columns[o]];
        }
    }
    return desObj;
}

Util.getObjVal = function (columns) {
    var desObj = {};
    for (var o in columns) {

        try {
            var dom = $("#" + columns[o]);
            if (dom) {
                desObj[columns[o]] = dom.val();
            }
        } catch (e) {
        }
    }
    return desObj;
}

/**
 *  批量设置表格属性 日期输入框
 * @param targetID
 * @param gridColName
 */
Util.batchDate = function (targetID, gridColName) {
    var html = '<input type="text" id="' + targetID + '_d"  class="ui-input" style="width: 150px;" />&nbsp;' +
        '<input type="button" value="确定" class="btn" id="btnOk_' + targetID + '" />' +
        '<input type="button" value="关闭" class="btn violet" id="btnClose_' + targetID + '" />';


    var bd = $("#" + targetID + "").jBox("Tooltip", {
        content: html,
        onOpen: function () {
            //this.setContent('jBox is opening…');
            $("#" + targetID + "_d").datepicker();
            $("#" + targetID + "_d").val(Util.getDate(0));
            $("#btnOk_" + targetID).on("click", function () {
                //保存
                if (null !== curRow && null !== curCol) {
                    $("#grid").jqGrid("saveCell", curRow, curCol);
                    curRow = null;
                    curCol = null
                }
                var datas = $("#grid").jqGrid("getRowData");
                //alert(datas[0].id);
                var dt = $("#" + targetID + "_d").val();
                if (dt.length > 0) {
                    for (var i = 0, j = datas.length; i < j; i++) {
                        $("#grid").jqGrid("setCell", datas[i].id, gridColName, dt);
                    }
                }
                bd.close();
            });
            $("#btnClose_" + targetID).on("click", function () {
                bd.close();
            });
        },
        trigger: "click",
        //closeOnMouseleave:true,
        //closeOnClick:true,
        1: 1
    });
}


/**
 *  批量设置表格，输入框
 * @param targetID
 * @param gridColName
 */
Util.batchInput = function (targetID, gridColName) {
    var html = '<input type="text" id="' + targetID + '_d"  class="ui-input" style="width: 150px;" />&nbsp;' +
        '<input type="button" value="确定" class="btn" id="btnOk_' + targetID + '" />' +
        '<input type="button" value="关闭" class="btn violet" id="btnClose_' + targetID + '" />';

    var bd = $("#" + targetID + "").jBox("Tooltip", {
        content: html,
        onOpen: function () {
            //this.setContent('jBox is opening…');
            //$("#" + targetID +"_d").datepicker();
            //$("#" + targetID +"_d").val(Util.getDate(0));
            $("#btnOk_" + targetID).on("click", function () {
                //保存
                if (null !== curRow && null !== curCol) {
                    $("#grid").jqGrid("saveCell", curRow, curCol);
                    curRow = null;
                    curCol = null
                }
                var datas = $("#grid").jqGrid("getRowData");
                //alert(datas[0].id);
                var dt = $("#" + targetID + "_d").val();
                if (dt.length > 0) {
                    for (var i = 0, j = datas.length; i < j; i++) {
                        $("#grid").jqGrid("setCell", datas[i].id, gridColName, dt);
                    }
                }
                bd.close();
            });
            $("#btnClose_" + targetID).on("click", function () {
                bd.close();
            });
        },
        trigger: "click",
        //closeOnMouseleave:true,
        //closeOnClick:true,
        1: 1
    });
}

/**
 *  获取 审批日志表格 初始化表格
 * @param elm
 */
Util.getProcessLogGrid = function (elm) {
    var gridDataUrl = basePath + "process/getProcessLog";//查询审批日志
    $("#" + elm).endTable({
        url: gridDataUrl,
        css: "ltable",
        //pager: "pager",
        emptyMsg: "没有符合条件的数据~",
        //width: "700px",
        lock: false,
        loadComplete: function (data) {
        },
        columns: [
            {
                name: "processDate",
                text: '审批时间',
                width: "20%",
                align: "left",
                renderer: function (r, v) {
                    var date = new Date(v);
                    return Util.formatDate(v, true);
                }
            }, {
                name: "nodeTitle",
                text: '审批节点',
                width: "15%",
                align: "left"
            }, {
                name: "processUser",
                text: "审批人",
                align: "left",
                width: "15%",
                renderer: function (r, v) {
                    // if (r.preNodeID == 0) {
                    //     return "";
                    // }
                    if (r.isStart == 1) {
                        return "";
                    }
                    return v;
                }

            }, {
                name: "processResult",
                text: "审批结果",
                align: "left",
                width: "20%",
                renderer: function (r, v) {
                    // if (r.preNodeID == 0) {
                    //     return "";
                    // }
                    if (r.isStart == 1) {
                        return "";
                    }
                    var role = sys.data_getAdResult(v);
                    if (role != null) {
                        return role.Title;
                    }
                    return "";
                }
            }, {
                name: "content",
                text: "意见",
                align: "left",
                renderer: function (r, v) {
                    // if (r.preNodeID == 0) {
                    //     return "";
                    // }
                    if (r.isStart == 1) {
                        return "";
                    }
                    return v;
                }
            }
        ]
    });
}
/**
 *  获取流程信息
 * @param id
 * @param params
 */
Util.getProcessInfo = function (elm, params) {
    var processInfoUrl = basePath + "process/getProcessInfo";//当前流程信息
    $("#" + elm).endTable("loadData", params);
    Util.ajaxPost(processInfoUrl, params, function (d) {
        if (d.code == 0 && d.obj != undefined && d.obj != null) {
            if (d.obj.status == 10) {
                $("#process-finish").show();
                $("#process-on").hide();
            } else {
                $("#process-finish").hide();
                $("#process-on").show();
                $("#process-on span").html(d.obj.nodeTitle);
            }
        }
    }, false);
}

Util.getSharpTime = function (baseDate, hour, day_diff) {
    var myDateTime_tmp = baseDate;
    if (day_diff != '') {
        myDateTime_tmp.add(day_diff, 'd');
    }
    myDateTime_tmp.hours(hour).minutes(0).seconds(0);
    return myDateTime_tmp;
}

/**
 *  判断是否一整天
 * @param d1 开始时间
 * @param d2 结束时间
 */
Util.isHoleDay = function (d1, d2) {
    var dtBegin = new Date(Date.parse(d1));
    var dtEnd = new Date(Date.parse(d2));
    if ((dtBegin.getHours() == 8 && dtBegin.getMinutes() == 30 )
        && (dtEnd.getHours() == 17 && dtEnd.getMinutes() == 0)) {
        return true;
    }
    if ((dtBegin.getHours() == 16 && dtBegin.getMinutes() == 30 )
        && (dtEnd.getHours() == 0 && dtEnd.getMinutes() == 30)) {
        return true;
    }
    if ((dtBegin.getHours() == 8 && dtBegin.getMinutes() == 30 )
        && (dtEnd.getHours() == 21 && dtEnd.getMinutes() == 30)) {
        return true;
    }
    return false;
}

Util.isFirstHour = function (d1) {
    var dtBegin = new Date(Date.parse(d1));
    return (dtBegin.getHours() == 8 && dtBegin.getMinutes() == 30 ) ||
        (dtBegin.getHours() == 16 && dtBegin.getMinutes() == 30)
}
Util.isLastHour = function (d2) {
    var dtEnd = new Date(Date.parse(d2));

    return (dtEnd.getHours() == 17 && dtEnd.getMinutes() == 0) ||
        (dtEnd.getHours() == 0 && dtEnd.getMinutes() == 30)
}
Util.GetWorkHoursForOT = function (beginDateTime, endDateTime, type) {

    var dtBegin = Util.ProcessDate(beginDateTime);
    var dtEnd = Util.ProcessDate(endDateTime);

    //alert(dtBegin + ":" + dtEnd);
    var diffSeconds = (dtEnd.getTime() - dtBegin.getTime()) / 1000;
    var diffHours = Math.floor(diffSeconds / 60.00 / 60.00)//合计相差小时
    var diffDays = Math.floor(diffHours / 24.00);//合计相差天数
    // console.info(diffSeconds +">>"  + diffHours +">>"+ diffDays);
    function isFirstHour(d1) {
        return d1.getHours() == 8 && d1.getMinutes() == 30
    }

    function isLastHour(d2) {
        return (d2.getHours() == 17 && d2.getMinutes() == 0)
    }

    function isLastHourOver(d2) {
        return (d2.getHours() == 21 && d2.getMinutes() == 30)
    }

    //如果当天 8:30  ~ 17:00  算 8小时  8:30 ~ 21:30 算12 小时
    if (diffDays == 0) {
        //当前
        if (isFirstHour(dtBegin)
            && isLastHour(dtEnd)) {
            return 8;
        } else if (isFirstHour(dtBegin)
            && isLastHourOver(dtEnd)) {
            return 12;
        } else {
            //2个相减出来的结果
            var h = Math.round((diffSeconds / 60.00 / 60.00) * 100) / 100;
            if (type == undefined) {
                return h;
            }
            h = h.toString();
            var hour = 0;
            if (h.indexOf('.') == -1) {
                hour = h;
            } else {
                hour = parseInt(h.substring(0, h.indexOf('.')));

                var m = Math.round((diffSeconds / 60.00 % 60.00) * 100) / 100;
                if (m >= 15 && m < 45) {
                    hour = hour + 0.5;
                } else if (m >= 45) {
                    hour = hour + 1;
                }
            }


            return hour;
        }
    }
    //跨天 如果 早上是 8:30
    var leftHours = 0, rightHours = 0;


    var hours = diffDays * 8 + (leftHours + rightHours);
    if (type == undefined) {
        return hours;
    }
    hours=hours.toString();
    var hour = 0;
    if (hours.indexOf('.') == -1) {
        hour = hours;
    } else {
        hour = parseInt(hours.substring(0, hours.indexOf('.')));

        var m = Math.round((diffSeconds / 60.00 % 60.00) * 100) / 100;
        if (m >= 15 && m < 45) {
            hour = hour + 0.5;
        } else if (m >= 45) {
            hour = hour + 1;
        }
    }
    return hour;
}

Util.addDays = function (date, days) {
    if (days == undefined || days == '') {
        days = 1;
    }
    var date = new Date(date);
    date.setDate(date.getDate() + days);
    var month = date.getMonth() + 1;
    var day = date.getDate();
    return date.getFullYear() + '-' + getFormatDate(month) + '-' + getFormatDate(day);
}

// 日期月份/天的显示，如果是1位数，则在前面加上'0'
function getFormatDate(arg) {
    if (arg == undefined || arg == '') {
        return '';
    }

    var re = arg + '';
    if (re.length < 2) {
        re = '0' + re;
    }

    return re;
}

Util.GetWorkHours = function (beginDateTime, endDateTime, type, subHours) {
    //debugger;
    if (subHours == undefined) {
        subHours = 0.5
    }
    var _totalHour = 0;
    //1、获取开始时间和结束时间之间的日
    var _beginDate = moment(beginDateTime);
    var _endDate = moment(endDateTime);
    //整理时间

    if (type == undefined) {
        if (_beginDate.get("hour") < 8) {
            //开始时间小于8点，设置为8点
            _beginDate = Util.getSharpTime(_beginDate, 8);


        }
        //else if (_beginDate.get('hour') == 12) {
        //
        //    //开始时间在12点-13点之间，设置为13点
        //    _beginDate = Util.getSharpTime(_beginDate, 13);
        //}
        else if (_beginDate.get("hour") >= 17) {
            //_beginDate.add(1, 'd').hour(8);
            _beginDate = Util.getSharpTime(_beginDate, 8, 1);
        }

        if (_endDate.get("hour") > 17) {
            //结束时间大于17点，设置为17点
            _endDate = Util.getSharpTime(_endDate, 17);
        }
        //else if (_endDate.get('hour') == 12) {
        //    //结束时间在12点-13点之间，设置为12点
        //    _endDate = Util.getSharpTime(_endDate, 12);
        //
        //}
        else if (_endDate.get("hour") <= 8) {
            _endDate = Util.getSharpTime(_endDate, 17, -1);
        }
    }
    //else if (type == 1) {
    //    if (_beginDate.get("hour") < 8) {
    //        //开始时间小于8点，设置为8点
    //        _beginDate = Util.getSharpTime(_beginDate, 8);
    //
    //
    //    }
    //    //else if (_beginDate.get('hour') == 12) {
    //    //
    //    //    //开始时间在12点-13点之间，设置为13点
    //    //    _beginDate = Util.getSharpTime(_beginDate, 13);
    //    //}
    //    // if (_endDate.get('hour') == 12) {
    //    //    //结束时间在12点-13点之间，设置为12点
    //    //    _endDate = Util.getSharpTime(_endDate, 12);
    //    //
    //    //}
    //    else if (_endDate.get("hour") <= 8) {
    //        _endDate = Util.getSharpTime(_endDate, 17, -1);
    //    }
    //}


    var _tempDateTime = _beginDate; //缓存一个日期，起始时开始时间
    while (moment(_tempDateTime).isBefore(_endDate)) {
        //2.1、判断是否周日，周六
        //var _week = moment(_tempDateTime).weekday();
        //if (_week == 0 || _week == 6) {
        //是周末,不算入时间
        //_tempDateTime.add(1, 'd');
        //continue;
        //}
        if (moment(_tempDateTime).isSame(_beginDate, "day")) {
            if (moment(_tempDateTime).isSame(_endDate, "day")) {
                //开始时间和结束时间是同一天，结束时间-开始时间
                _totalHour += _endDate.diff(_beginDate, "hours", true);
                //如果跨越中午，减去一个小时
                if (moment(_endDate).get('hour') >= 17
                    && moment(_beginDate).get('hour') == 8 && moment(_beginDate).get('minute') <= 30) {
                    _totalHour -= subHours;
                }
                // if (type == undefined) {
                //     if(_totalHour>8){
                //         _totalHour=8;
                //     }
                // }
                _tempDateTime.add(1, 'd');
                continue;
            }
            else {
                //开始时间和结束时间不是同一天，17点减-开始时间
                //_totalHour += moment(_beginDate).hour(17).minute(0).second(0).diff(_beginDate, "hours", true);

                if (type == undefined) {
                    _totalHour += moment(_beginDate).hour(17).minute(0).second(0).diff(_beginDate, "hours", true);
                } else {
                    _totalHour += _endDate.diff(_beginDate, "hours", true);
                }
                //如果跨越中午，减去一个小时
                if (moment(_tempDateTime).get('hour') <= 12) {
                    _totalHour -= subHours;
                }
                _tempDateTime.add(1, 'd').hour(8).minute(30).second(0);

                continue;
            }
        }
        else if (moment(_tempDateTime).isSame(_endDate, "day")) {
            //是否和结束时间是同一天,结束时间-开始时间8点，
            _totalHour += _endDate.diff(moment(_endDate).hour(8).minute(30).second(0), "hours", true);
            //如果跨越中午，减去一个小时
            if (moment(_endDate).get('hour') > 12) {
                _totalHour -= 0;
            }
            _tempDateTime.add(1, 'd');
            continue;
        }
        else {
            _totalHour += 8;
            _tempDateTime.add(1, 'd');
            continue;
        }
    }
//  alert(_totalHour < 0 ? 0 : _totalHour.toFixed(2));
//
    return _totalHour < 0 ? 0 : _totalHour.toFixed(2);

}
Util.getDateType = function (getype) {
    var dateString = Util.DateToString(new Date());
    if (getype == "year") {
        return dateString.substring(0, 4)
    }
    if (getype == "month") {
        return dateString.substring(5, 7)
    }
    if (getype == "day") {
        return dateString.substring(8, 10)
    }
    return "";
}

Util.GetTotalWorkHours = function (beginDateTime1, endDateTime1, beginDateTime2, endDateTime2) {
    if (endDateTime2 == '' || beginDateTime1 == '') {
        alert('开始时间 和  结束时间不能为空');
    }

    if (endDateTime1 == '') {
        return Util.GetWorkHours(beginDateTime1, endDateTime2);
    }
    else {
        if (beginDateTime2 == '') {
            return Util.GetWorkHours(beginDateTime1, endDateTime1);
        }
        else {
            // alert(GetWorkHours(beginDateTime1 ,endDateTime1));
            // alert(GetWorkHours(beginDateTime2 ,endDateTime2));
            var _totalhours1 = parseFloat(Util.GetWorkHours(beginDateTime1, endDateTime1));
            var _totalhours2 = parseFloat(Util.GetWorkHours(beginDateTime2, endDateTime2));
            var _totalhours = _totalhours1 + _totalhours2;


            return _totalhours;
        }
    }
}

/**
 *  选择员工
 * @param param
 */
Util.selectEmp = function (param, callback) {
    param.callback = callback;
    $.dialog({
        id: "add",
        width: 850,
        height: 400,
        zIndex: 6666,
        title: "选择员工",
        content: "url:" + basePath + "pages/selectEmp.jsp",
        data: param,
        lock: true,
        ok: function () {
        },
        cancel: !0
    })

}

$(function () {
    //隐藏选择员工 按钮
    if (typeof currentUser != 'undefined' && currentUser && currentUser.isWorkAttendance != 1) {
        var ctl = $("#selectEmp");
        if (ctl) {
            ctl.hide();
        }
    }
})


/**
 *  选择休假类型
 * @param param
 */
Util.selectRecess = function (param, callback) {

    param.callback = callback;
    $.dialog({
        id: "add",
        width: 880,
        height: 400,
        title: "选择请假/调休单据",
        content: "url:" + basePath + "pages/selectRecess.jsp",
        data: param,
        lock: true,
        ok: function () {
        },
        cancel: !0
    })

}

$(function () {
    //隐藏选择员工 按钮
    if (typeof currentUser != 'undefined' && currentUser && currentUser.isWorkAttendance != 1) {
        var ctl = $("#selectRecess");
        if (ctl) {
            ctl.show();
        }
    }
})
//getype 1是开始时间   2 是结束时间
Util.getStartOrEndDate = function (getype) {
    var date = new Date();
    var day=Util.getDateType("day");
    if(getype==1){
        if(day>20){
            date = date.setDate(21);
        }else{
            var mDate = new Date(date);
            date.setMonth(mDate.getMonth()-1);
            date.setDate(21);
        }
    }else{
        if(day>20){
            var mDate = new Date(date);
            date.setMonth(mDate.getMonth()+1);
            date.setDate(20);
        }else{
            date = date.setDate(20);

        }
    }

    return Util.DateToString(date).substring(0, 10);
}

/**
 *  选择休假类型
 * @param param
 */
Util.selectOvertimeDealy = function (param, callback) {

    param.callback = callback;
    $.dialog({
        id: "add",
        width: 1000,
        height: 400,
        title: "选择加班单据",
        content: "url:" + basePath + "pages/selectOvertimeDealy.jsp",
        data: param,
        lock: true,
        ok: function () {
        },
        cancel: !0
    })

}
Util.selectOvertimeAbnormalApply = function (param, callback) {
    param.callback = callback;
    $.dialog({
        id: "add",
        width: 1000,
        height: 400,
        title: "选择加班单据",
        content: "url:" + basePath + "pages/selectOvertimeAbnormalApply.jsp",
        data: param,
        lock: true,
        ok: function () {
        },
        cancel: !0
    })

}


$(function () {
    //隐藏选择员工 按钮
    if (typeof currentUser != 'undefined' && currentUser && currentUser.isWorkAttendance != 1) {
        var ctl = $("#selectOvertimeDealy");
        if (ctl) {
            ctl.show();
        }
    }
})