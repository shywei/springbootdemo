//帐号管理 修改角色  添加帐号
var sys = Sys = parent.Sys, api = frameElement.api, data = api.data;
var dataT = data.id;
//var refreshData = data.loadData;
var submitUrl = http + "configGateInfoController/configGateInfo";
var getDataUrl = http + "device/queryGateInfo";
accView = {
    init: function () {
        this.initUI();
        this.loadData();
    },
    setValue: function () {
        //根据data里面的值来赋值
        $("#id").val(dataT);
        Util.mappingValueToPage(data);
    },
    loadData: function (parms) {
        if (data.id <= 0) {//不需要加载数据
            return;
        }
        var e = this;
        Util.ajaxGet(getDataUrl, {deviceid: dataT},
            function (d) {
                if (d.code != 0) {
                	parent.parent.Util.tips({type: 1, content:  d.message});
                    return;
                }
                data = Util.getObj(d.obj, ["doorSignal", "time", "magAlarm", "magAlarmTime", "alarmTime","sound","light","sleep","durAlarm","inputSignal","tamperAlarm"]);
                e.setValue();
            });
    },
    initUI: function () {
        var e = this;
        api.button({
            id: "ok",
            name: "确定",
            focus: true,
            callback: function () {
                e.save();
                return false;//不关闭窗口
            }
        }, {
            id: "cancel",
            name: "取消"
        });
    },
    save: function () {
        //保存数据
//              doorSignal:门控信号
//              time:锁驱时长
//              magAlarm:磁门报警
//              magAlarmTime:门磁延迟
//              alarmTime:报警时长
//              sound:终端提示
//              light:终端背光亮度
//              sleep:休眠时长
//              result:0 成功 
//              durAlarm:防胁迫报警
//              inputSignal:报警信号输出
//              tamperAlarm:防拆报警
		var data={};
        data.confirmNum=  dataT;
        data.doorSignal = $("#doorSignal option:selected").val()/1;
        data.time = $("#time").val()/1;
        data.magAlarm = $("#magAlarm option:selected").val()/1;
        data.magAlarmTime = $("#magAlarmTime option:selected").val()/1;
        data.alarmTime = $("#alarmTime option:selected").val()/1;
        data.sound = $("#sound option:selected").val()/1;
        data.light = $("#light option:selected").val()/1;
        data.sleep = $("#sleep option:selected").val()/1;
        data.durAlarm = $("#durAlarm option:selected").val()/1;
        data.inputSignal = $("#inputSignal option:selected").val()/1;
        data.tamperAlarm = $("#tamperAlarm option:selected").val()/1;
        data.currentId = sessionStorage['sId'];
        if($("#id").val()){
        	
        }
        Util.ajaxPost(submitUrl, data, function (d) {
            if (d.code != 0) {
                parent.parent.Util.tips({type: 1, content: "数据提交失败！" + d.message});
                return;
            }
//          refreshData();
      		api.close();
        });
    }
};
accView.init();






