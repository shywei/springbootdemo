//帐号管理 修改角色  添加帐号
var sys = Sys = parent.Sys, api = frameElement.api, data = api.data;
var dataT = data.id;
var refreshData = data.loadData;
var submitUrl = http + "WifiController/saveWifi";
var getDataUrl = http + "WifiController/getWiFiInfoByID";
accView = {
    init: function () {
        this.initUI();
        this.loadData();
    },
    setValue: function () {
        //根据data里面的值来赋值
        Util.mappingValueToPage(data);
        $("#status").val(data.status);
    },
    loadData: function (parms) {
        if (data.id <= 0) {//不需要加载数据
            return;
        }
        var e = this;
        Util.ajaxGet(getDataUrl, {id: data.id},
            function (d) {
                if (d.code != 0) {
                    return;
                }
                console.log(d)
                data = Util.getObj(d.obj, ["wifiName", "wifiPassWord", "status", "memoInfo"]);
                data.status = d.obj.status;
                e.setValue();
            });
    },
    initUI: function () {
        var e = this;
        api.button({
            id: "ok",
            name: "确定",
            focus: true,
            callback: function () {
                e.save();
                return false;//不关闭窗口
            }
        }, {
            id: "cancel",
            name: "取消"
        });
    },
    save: function () {
        //保存数据
        data.wifiName     = $("#wifiName").val();
        data.wifiPassWord = $("#wifiPassWord").val();
        data.status       = $("#status option:selected").val();
        data.memoInfo	  = $("#memoInfo").val();
        data.id           = dataT;
        data.userid       = sessionStorage['sId'];
//userid		当前登录用户的id
//wifiName	WiFi名称
//wifiPassWord	WiFi密码
//status		WiFi状态
//memoInfo	备注信息
 		if(data.wifiName.length==0){
 			parent.parent.Util.tips({type: 1, content: "请填写WiFi名称！"});
 			return;
 		}
 		if(data.wifiPassWord.length==0){
 			parent.parent.Util.tips({type: 1, content: "请填写WiFi密码！"});
 			return;
 		}
 		if(data.status==''){
 			parent.parent.Util.tips({type: 1, content: "请选择WiFi状态！"});
 			return;
 		}
 		
        Util.ajaxPost(submitUrl, data, function (d) {
            if (d.code != 0) {
                parent.parent.Util.tips({type: 1, content: "数据提交失败！" + d.message});
                return;
            }
            refreshData();
      		api.close();
        });
    }
};
accView.init();






