
//指静脉设备管理..

var sys = Sys = parent.Sys,  api = frameElement.api

var gridDataUrl=http+'fingerDriviceController/queryDriviceList'; //查询
var deleteUrl =http +"fingerDriviceController/deleteDrivice";

var data={};
DataView = {
    init: function () {
        //加载数据
//      this.initGrid();
        this.loadData();
        this.addEvent();
    },
    addEvent: function () {
        var e = this;
        //点击查询
        pubQ.tableCheck();
		$("#seach").on("click",function(){
			e.loadData();
		});
		//添加帐号
		$("#add").on("click",function(){
			e.showAdd(0);
		});
		//修改
		$("#modi").on("click",function(){
			e.showAdd(0);
		});
		//删除帐号
		$("#del").on("click",function(){
            e.showDel(0)
		});
		//绑定网络
		$("#bindWifi").on("click",function(){
            e.showWifi(0)
		});
    }, 
    showChose:function(val){
    	var ids = val;
         //如果id小于等于0  是批量删除 就需要获取所有选择的ID
        if(val<=0){
        	ids="";
            $(".pubTabelSty tbody .checked").each(function () {
                //alert($(this).is(":checked"));
                console.log($(this).hasClass(".checked"))
                if ($(this).hasClass("checked")) {
                    if (!isNaN($(this).attr("data-value"))) {
                        ids += $(this).attr("data-value") + ",";
                        //objs.push(e.getInfoById($(this).val()));
                    }
                }
            });
			
            if(ids==0){
                pubQ.alertTrue("请选择需要绑定的数据")
                return;
            }
            val = ids.substring(0,ids.length-1);
		}
    },
    showWifi: function (val) {//绑定wifi
        var e = this;
        var title='绑定网络';
        var ids = val;
         //如果id小于等于0  是批量删除 就需要获取所有选择的ID
        if(val<=0){
        	ids="";
            $(".pubTabelSty tbody .checked").each(function () {
                //alert($(this).is(":checked"));
                if ($(this).hasClass("checked")) {
                    if (!isNaN($(this).attr("data-value"))) {
                        ids += $(this).attr("data-value") + ",";
                        //objs.push(e.getInfoById($(this).val()));
                    }
                }
            });
            if(ids==0){
                pubQ.alertTrue("请选择需要绑定的数据")
                return;
            }
            val = ids.substring(0,ids.length-1);
	        data.id = val;
	        data.loadData= e.loadData;
	        $.dialog({
	            id:"accDialogWifi",
	            width: 440,
	            height: 400,
	            title: title,
	            content: "url:" + httpUrl +"page/deviceMent/deviceConNewWork.html",
	            data: data,
	            max:false,
	            min:false,
	            lock: true,
	            ok: function () {
	
	            },
	            cancel: !0
	        });
        }
    },
    showAdd: function (val) {//添加帐号
        var e = this;
        var title='修改';
        if(val<=0){
            title='添加';
        }
        var ids = val;
         //如果id小于等于0  是批量删除 就需要获取所有选择的ID
        if(val<=0){
        	ids="";
            $(".pubTabelSty tbody .checked").each(function () {
                //alert($(this).is(":checked"));
                console.log($(this).hasClass(".checked"))
                if ($(this).hasClass("checked")) {
                    if (!isNaN($(this).attr("data-value"))) {
                        ids += $(this).attr("data-value") + ",";
                        //objs.push(e.getInfoById($(this).val()));
                    }
                }
            });
			
            if(ids==0){
                pubQ.alertTrue("请选择需要修改的数据")
                return;
            }
            
            console.log(val)
			if( $(".pubTabelSty tbody .checked").size() !=1){
				  pubQ.alertTrue("只能选择单个！")
                return;
			}
            val = ids.substring(0,ids.length-1);
	        data.id = val;
	        data.loadData= e.loadData;
	        $.dialog({
	            id:"accDialogAdd",
	            width: 440,
	            height: 600,
	            title: title,
	            content: "url:" + httpUrl +"page/deviceMent/deviceConAdd.html",
	            data: data,
	            max:false,
	            min:false,
	            lock: true,
	            ok: function () {
	
	            },
	            cancel: !0
	        });
        }
    },
    showDel: function (val) {
        var e = this;
        var ids = val;
         //如果id小于等于0  是批量删除 就需要获取所有选择的ID
        if(val<=0){
        	ids="";
            $(".pubTabelSty tbody .checked").each(function () {
                //alert($(this).is(":checked"));
                console.log($(this).hasClass(".checked"))
                if ($(this).hasClass("checked")) {
                    if (!isNaN($(this).attr("data-value"))) {
                        ids += $(this).attr("data-value") + ",";
                        //objs.push(e.getInfoById($(this).val()));
                    }
                }
            });
			
            if(ids.length<2||ids==0){
                pubQ.alertTrue("请选择需要删除的数据")
                return;
            }
            ids = ids.substring(0,ids.length-1);
            console.log(ids)
        }
        $.dialog.confirm("是否确定删除？", function () {
            Util.ajaxGet(deleteUrl,{mesIDs:ids,currentId:sessionStorage['sId']}, function (data) {
                if(data.code==0){
					pubQ.alertTrue("删除成功")
                    e.loadData();
                }else{
                    pubQ.alertTrue("删除失败")
                }
                return;
            });
        });
    },
    loadData: function (num,selNum) {
		var data={};
		data.areaID = sessionStorage['sUserDept'];
		data.driviceName = $("#driviceName").val();
		data.status = $("#status option:selected").val()==-1?'':$("#status option:selected").val();
		data.driviceState = $("#driviceState option:selected").val()==-1?'':$("#driviceState option:selected").val();
		
		data.page=num||$(".ycolor").html()||1;//当前页码
		data.rows= selNum||$(".pubSel select option:selected").html()||10;//一共多少条数据
		
//		currentId, 当前登录用户的主键id
//		driviceID,设备编号（不是主键id）
//		driviceName,设备名称
//		wifiName,wifi名称
//		status,在线状态0在线1离线
//		driviceState,设备状况 0 正常 1 停用 2 损坏3备用
//		areaID,监区id
//		workingStation,工位编码
		DataView.initGrid(data);
    },
    initGrid: function (data) {
    	var e =this ;
    	$.ajax({
			type: 'get',
	        url:gridDataUrl,
	        data:data,
	        dataType: 'json',
	        success: function(d){
	        	console.log(d)
	        	var html='';
        		   $.each(d.obj,function(i,v){
        		   	var num = v.driviceState;
        		   		if(num ==0){num='正常'}
        		   		if(num ==1){num='停用'}
        		   		if(num ==2){num='损坏'}
        		   		if(num ==3){num='备用'}
	                	html+='<tr>'
	                    	+'<td><div class="check" data-value='+v.id+'></div></td>'
	                    	+'<td>'+v.driviceName+'</td>'
	                    	+'<td>'+v.driviceID+'</td>'
	                    	+'<td>'+(v.seriviceIP||"")+'</td>'
	                    	+'<td>'+v.wifiName+'</td>'
	                    	+'<td>'+v.status+'</td>'
	                    	+'<td>'+num+'</td>'
	                    	+'<td>'+v.driviceType+'</td>'
	                    	+'<td>'+v.areaName+'</td>'
	                    	+'<td>'+v.ownerName+'</td>'
	                    	+'<td>'+v.collectedNum+'</td>'
	                    +'</tr>'
	                });
		                  	
			    $('.pubTabelSty thead .checked').removeClass("checked");
			    $('.pubTabelSty tbody').html(html);    	
			    var dataAll = {};
					dataAll.dataPage=d.objExt.currentPage;//dataPage 当前页码
					dataAll.dataCount=d.objExt.totalCount;//dataCount 一共多少条数据
					dataAll.pageNum=d.objExt.pageSize;//pageNum 一页多少数据
					dataAll.fun=DataView.loadData;//fun 方法名
				$(".pubPageSty").pageNumAuto(dataAll); 
				if(d.obj.length==0){
		        	pubQ.htmlNullAuto(11,'.pubTabelSty tbody');
		       	}
	        },
	        error:function(){
	        	alert('网络异常,请检查网络链接');
	        }
		});
    	
  	}
}

DataView.init();


