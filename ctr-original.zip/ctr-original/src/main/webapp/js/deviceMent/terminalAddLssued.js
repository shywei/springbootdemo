//帐号管理 修改角色  添加帐号
var sys = Sys = parent.Sys, api = frameElement.api, data = api.data;
var dataT = data.id;
//var refreshData = data.loadData;
var submitUrl = http + "adminDataDownloadController/adminDataDownload";
var getDataUrl = http + "adminDataDownloadController/getUserInfoBydeptID";
accView = {
    init: function () {
        this.initUI();
        this.loadData();
    },
    setValue: function () {
        //根据data里面的值来赋值
    },
    loadData: function (parms) {
    	var e = this;
        Util.ajaxGet(getDataUrl, {deptid: sessionStorage['sUserDept']},
            function (d) {
                var html='';
                $.each(d, function(i,v) {
                	html+='<option value="'+v.userid+'">'+v.userName+'</option>';
                });
                $("#userid").html('<option value="">请选择</option>' + html);
                e.setValue();
            });
        if (data.id <= 0) {//不需要加载数据
            return;
        }
       
//      Util.ajaxGet(getDataUrl, {deptid: sessionStorage['sUserDept']},
//          function (d) {
//              if (d.code != 0) {
//              	parent.parent.Util.tips({type: 1, content:  d.message});
//                  return;
//              }
//              data = Util.getObj(d.obj, ["doorSignal", "time", "magAlarm", "magAlarmTime", "alarmTime","sound","light","sleep","durAlarm","inputSignal","tamperAlarm"]);
//              e.setValue();
//          });
    },
    initUI: function () {
        var e = this;
        api.button({
            id: "ok",
            name: "确定",
            focus: true,
            callback: function () {
                e.save();
                return false;//不关闭窗口
            }
        }, {
            id: "cancel",
            name: "取消"
        });
    },
    save: function () {
        //保存数据
		var data={};
        data.deviceid=  dataT;
        data.userid = $("#userid option:selected").val()/1;
        data.currentId = sessionStorage['sId'];
        if(data.userid==''){
        	 parent.parent.Util.tips({type: 1, content: "请选择管理员"});
        }
        Util.ajaxPost(submitUrl, data, function (d) {
            if (d.code != 0) {
                parent.parent.Util.tips({type: 1, content: "数据提交失败！" + d.message});
                return;
            }if(d.code ==0){
            	parent.parent.Util.tips({type: 0, content: d.message});
        	}
//          refreshData();
      		api.close();
        });
    }
};
accView.init();






