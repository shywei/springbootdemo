//帐号管理 修改角色  添加帐号
var sys = Sys = parent.Sys, api = frameElement.api, data = api.data;
var dataT = data.id;
var refreshData = data.loadData;
var submitUrl = http + "fingerDriviceController/bingNet";
var getDataDrivce = http + "fingerDriviceController/querySeverCanBeUsed";
var getDataWifi = http + "fingerDriviceController/queryWifiInfoCanBeUsed";
accView = {
    init: function () {
        this.initUI();
        this.loadData();
    },
    setValue: function () {
        //根据data里面的值来赋值
    },
    loadData: function (parms) {
        var e = this;
        var htmlChos='<option value="-1">请选择</option>';
        pubQ.ajaxAuto(getDataDrivce, {}, function (d) {
           	console.log(d)
           	var html = '';
            $.each(d, function(i,v) {
            	html+= '<option value="'+v.serverid+'">'+v.serverIP+'</option>';
            });
            $("#drivice").html(htmlChos+html);
        });
        pubQ.ajaxAuto(getDataWifi, {}, function (d) {
           	console.log(d)
           	var html = '';
            $.each(d, function(i,v) {
            	html+= '<option value="'+v.id+'">'+v.wifiName+'</option>';
            });
            $("#wifi").html(htmlChos+html);
        });
    },
    initUI: function () {
        var e = this;
        api.button({
            id: "ok",
            name: "确定",
            focus: true,
            callback: function () {
                e.save();
                return false;//不关闭窗口
            }
        }, {
            id: "cancel",
            name: "取消"
        });
    },
    save: function () {
        //保存数据
        data.ids = dataT;
        data.currentId = sessionStorage['sId'];
        data.severID = $("#drivice option:selected").val();
        data.wifiID = $("#wifi option:selected").val();
        
        if(data.severID == -1){
        	 parent.parent.Util.tips({type: 1, content: "请选择服务器"});
        }
        if(data.wifiID == -1){
        	 parent.parent.Util.tips({type: 1, content: "请选择WiFi"});
        }
        
        Util.ajaxPost(submitUrl, data, function (d) {
            if (d.code != 0) {
                parent.parent.Util.tips({type: 1, content: "数据提交失败！" + d.message});
                return;
            }
            refreshData();
      		api.close();
        });
    }
};
accView.init();






