
//指静脉设备管理..

var sys = Sys = parent.Sys,  api = frameElement.api

var gridDataUrl=http+'WifiController/queryWifiListByPage'; //查询
var deleteUrl =http +"WifiController/deleteWifi";//删除接口
var delData={};//删除 数据
delData.userid=sessionStorage['sId'];
//userid		当前登录用户的id
var data={};
DataView = {
    init: function () {
        //加载数据
//      this.initGrid();
        this.loadData();
        this.addEvent();
    },
    addEvent: function () {
        var e = this;
        //点击查询
        pubQ.tableCheck();
		$("#seach").on("click",function(){
			e.loadData();
		});
		//添加帐号
		$("#add").on("click",function(){
			e.showAdd(0);
		});
		//修改
		$("#modi").on("click",function(){
			e.showAdd(-1);
		});
		//删除帐号
		$("#del").on("click",function(){
            e.showDel(0)
		});
		//绑定网络
		$("#bindWifi").on("click",function(){
            e.showWifi(0)
		});
    },
    showAdd: function (val) {//添加帐号
        var e = this;
        var title='修改';
        if(val==0){
            title='添加';
        }
        var ids = val;
         //如果id小于等于0  是批量删除 就需要获取所有选择的ID
        if(val<0){
        	ids="";
            $(".pubTabelSty tbody .checked").each(function () {
                //alert($(this).is(":checked"));
                console.log($(this).hasClass(".checked"))
                if ($(this).hasClass("checked")) {
                    if (!isNaN($(this).attr("data-value"))) {
                        ids += $(this).attr("data-value") + ",";
                        //objs.push(e.getInfoById($(this).val()));
                    }
                }
            });
            if($(".pubTabelSty tbody .checked").size() <=0 ){
                pubQ.alertTrue("请选择需要修改的数据")
                return;
            }
			if( $(".pubTabelSty tbody .checked").size() !=1 && val!=0){
				  pubQ.alertTrue("只能选择单个！")
                return;
			}
            val = ids.substring(0,ids.length-1);
        }
        data.id = val;
        data.loadData= e.loadData;
        $.dialog({
            id:"accDialogAdd",
            width: 440,
            height: 500,
            title: title,
            content: "url:" + httpUrl +"page/deviceMent/deviceWifiConAdd.html",
            data: data,
            max:false,
            min:false,
            lock: true,
            ok: function () {

            },
            cancel: !0
        });
    },
    showDel: function (val) {
        var e = this;
        var ids = val;
         //如果id小于等于0  是批量删除 就需要获取所有选择的ID
        if(val<=0){
        	ids="";
            $(".pubTabelSty tbody .checked").each(function () {
                //alert($(this).is(":checked"));
                console.log($(this).hasClass(".checked"))
                if ($(this).hasClass("checked")) {
                    if (!isNaN($(this).attr("data-value"))) {
                        ids += $(this).attr("data-value") + ",";
                        //objs.push(e.getInfoById($(this).val()));
                    }
                }
            });
			
            if(ids.length<2||ids==0){
                pubQ.alertTrue("请选择需要删除的数据")
                return;
            }
            ids = ids.substring(0,ids.length-1);
            console.log(ids)
        }
        delData.ids = ids;
        $.dialog.confirm("是否确定删除？", function () {
            Util.ajaxGet(deleteUrl,delData, function (data) {
                if(data.code==0){
					pubQ.alertTrue("删除成功")
                    e.loadData();
                }else{
                    pubQ.alertTrue("删除失败")
                }
                return;
            });
        });
    },
    loadData: function (num,selNum) {
		var data={};
		data.wifiName = $("#driviceName").val();
		data.status = $("#status option:selected").val()==-1?'':$("#status option:selected").val();
		
		data.page=num||$(".ycolor").html()||1;//当前页码
		data.rows= selNum||$(".pubSel select option:selected").html()||10;//一共多少条数据
		
		DataView.initGrid(data);
    },
    initGrid: function (data) {
    	var e =this ;
    	$.ajax({
			type: 'get',
	        url:gridDataUrl,
	        data:data,
	        dataType: 'json',
	        success: function(d){
	        	console.log(d)
	        	var html='';
        		   $.each(d.obj.results,function(i,v){
        		   	var createDate = Util.DateToString((v.createDate||''),1)||'' ;
        		   	var modifyDate = Util.DateToString((v.modifyDate||''),1)||'' ;
        		   	var sta = '';
        		   	if(v.status==0){sta = '正常';};
        		   	if(v.status==1){sta = '停用';};
        		   	if(v.status==2){sta = '损坏';};
//      		   	0正常1停用2损坏
	                	html+='<tr>'
	                    	+'<td><div class="check" data-value='+v.id+'></div></td>'
	                    	+'<td>'+( v.wifiName||"--")+'</td>'
	                    	+'<td>'+( v.wifiPassWord||"--")+'</td>'
	                    	+'<td>'+( createDate||"--")+'</td>'
	                    	+'<td>'+( modifyDate||"--")+'</td>'
	                    	+'<td>'+( sta||"--")+'</td>'
	                    	+'<td>'+( v.memoInfo||"--")+'</td>'
	                    +'</tr>'
	                });
		                  	
			    $('.pubTabelSty thead .checked').removeClass("checked");
			    $('.pubTabelSty tbody').html(html);    	
			    var dataAll = {};
					dataAll.dataPage=d.obj.page.currentPage;//dataPage 当前页码
					dataAll.dataCount=d.obj.page.totalCount;//dataCount 一共多少条数据
					dataAll.pageNum=d.obj.page.pageSize;//pageNum 一页多少数据
					dataAll.fun=DataView.loadData;//fun 方法名
				$(".pubPageSty").pageNumAuto(dataAll); 
				if(d.obj.results.length==0){
		        	pubQ.htmlNullAuto($(".pubTabelSty table thead th").size(),'.pubTabelSty tbody');
		       	}
	        },
	        error:function(){
	        	pubQ.htmlNullAuto($(".pubTabelSty table thead th").size(),'.pubTabelSty tbody');
	        }
		});
    	
  	}
}

DataView.init();


