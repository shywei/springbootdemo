var sId = sessionStorage.getItem("sId"); //id

if(sessionStorage['sRoleId'] / 1 === 2 || sessionStorage['sRoleId'] / 1 === 1) {
	var suo = `
		<tr>
			<th>队名</th>
			<th>考勤时间</th>
			<th>病假人数</th>
			<th>其它人数</th>
			<th>应到人数</th>
			<th>实到人数</th>
			<th>缺勤人数</th>
		</tr>
	`;
} else if(sessionStorage['sRoleId'] / 1 === 3) {
	var suo = `
		<tr>
			<th style="width:20%">点名时段</th>
			<th style="width:15%"> 编号 </th>
			<th style="width:20%"> 姓名 </th>
			<th style="width:20%">考勤时间</th>
			<th style="width:10%"> 状态 </th>
			<th style="width:15%"> 考勤设备 </th>
		</tr>
	`;
}
$("#rollcall thead").html(suo);
$("#daochu thead").html(suo);
//		异步加载函数6
var Maxpage1 = 1;
var userstotal; //总数据数量
//用户账号---列表渲染
function load(a, b) {
	$.ajax({
		type: 'GET',
		url: http + "systemUser/ querySystemUser.do?pageNo=" + a + "&pageSize=" + b,
		datatype: 'JSON',
		success: function(callback) {
			var html = '';
			for(var i = 0; i < callback.obj.results.length; i++) {
				var t = callback.obj.results[i].createtime;
				t = t.slice(0, 19);
				html += `
					<tr>
						<td class="xuan">
							<input type="checkbox" />
							<span class="duigou"></span>
						</td>
						<td>${callback.obj.results[i].id}</td>
						<td>${callback.obj.results[i].loginName}</td>
						<td>${callback.obj.results[i].userName}</td>
						<td>${callback.obj.results[i].deptName}</td>
						<td>${t}</td>
						<td><a href="">初始化密码</a></td>
					</tr>
				`
			}
			$("div.account table.account tbody").html(html);
			$("div.account table.account thead input").attr("checked", false);
			$("div.account table.account thead span").removeClass("zhong");
			//动态生成分页
			var dangqian = callback.obj.page.currentPage;  //当前页码
			userstotal = callback.obj.page.totalCount;     //一共多少条数据
			var rows = callback.obj.page.pageSize;         //一页多少数据
			var yeshu = Math.ceil(userstotal / rows);      //总页数
			if(yeshu == 0) {
				yeshu = 1;
			}
			Maxpage1 = yeshu;
			var html1 = '';
			if(dangqian == 1) {
				if(dangqian <= yeshu) {
					html1 += `<li class="clicked">${dangqian}</li>`;
				}
				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
				if(dangqian + 4 <= yeshu) {
					html1 += `<li>${dangqian+4}</li>`;
				}
			} else if(dangqian == 2) {
				html1 += `<li>${dangqian-1}</li>`;
				html1 += `<li class="clicked">${dangqian}</li>`;
				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
			} else if(dangqian == yeshu && dangqian >= 5) {
				html1 += `
					<li>${dangqian-4}</li>
					<li>${dangqian-3}</li>
					<li>${dangqian-2}</li>
					<li >${dangqian-1}</li>
					<li class="clicked">${dangqian}</li>
				`
			} else if(dangqian == yeshu - 1 && dangqian >= 5) {
				html1 += `
					<li>${dangqian-3}</li>
					<li>${dangqian-2}</li>
					<li>${dangqian-1}</li>
					<li class="clicked">${dangqian}</li>
					<li>${dangqian+1}</li>
				`
			} else {
				if(dangqian - 2 > 0) {
					html1 += `<li>${dangqian-2}</li>`;
				}
				if(dangqian - 1 > 0) {
					html1 += `<li>${dangqian-1}</li>`;
				}
				html1 += `<li class="clicked">${dangqian}</li>`;
				if(dangqian < yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 1 < yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
			}
			//页码区显示
			$("div.pagers ul").html(html1);                      //页码显示
			$("div.pagers span.pagerstotal").html(userstotal);   //总数据量
			$("div.pagers span.dangqian").html(dangqian);        //当前页
			$("div.pagers span.yeshu").html(yeshu);              //总页数
		}
	})
}

//用户账号--当前页条数----
$("div.account div.pagers ul").on("click", "li", function(e) {
	$("table.account thead span.duigou").removeClass('zhong');
	document.querySelector("table.account thead th input").checked = false;
	load(e.target.innerHTML, $("div.account div.pagers select").val());
})
//用户账号--去末页
$("div.account div.pagers a.toleast").click(function(e) {
	var page = $("div.pagers span.dangqian").html();
	var lastPage = $("div.pagers span.yeshu").html();
	e.preventDefault();
	if(page != lastPage) {
		load(Maxpage1, $("div.account div.pagers select").val());
	}
})
//用户账号--去首页
$("div.account div.pagers a.tofirst").click(function(e) {
	var page = $("div.pagers span.dangqian").html();
	e.preventDefault();
	if(page != 1) {
		load(1, $("div.account div.pagers select").val());
	}
})
//点击GO
$("div.account div.pagers a.go").click(function(e) {
	e.preventDefault();
	var a = $("div.account div.pagers input").val();
	var page = $("div.pagers span.dangqian").html();
	if(a != page) {
		if(a / 1 > Maxpage1) {
			$("div.alert").fadeIn();
			$("div.alert_content").hide();
			$("div.tishi").show();
			$("div.tishi p").html("页码越界");
			return;
		}
		var reg = /^\d+$/;
		if(!reg.test(a)) {
			$("div.alert").fadeIn();
			$("div.alert_content").hide();
			$("div.tishi").show();
			$("div.tishi p").html("页码为非法字符");
			return;
		}
		if(a == '') {
			return;
		}
		load(a, $("div.account div.pagers input").val());
	}
})
//用户账号--初始化密码
$("table.account").on("click", " tbody td a", function(e) {
	e.preventDefault();
	var i = $(this).parent().siblings().eq(1).html();
	$.ajax({
		type: 'POST',
		url: http + 'systemUser/resetPassword.do',
		datatype: 'JSON',
		data: {
			id: i,
			userid: sessionStorage.sId
		},
		success: function(callback) {
			if(callback.code == 1) {
				parent.$("div.alert").fadeIn();
				parent.$("div.alert_content").hide();
				parent.$("div.tishi").show();
				parent.$("div.tishi p").html("已成功把密码初始化为123456");
				parent.$(".tishi .yes").on("click", function() {
					parent.$("div.tishi").hide();
					parent.$("div.alert").fadeOut();
				})
			} else {
				parent.$("div.alert").fadeIn();
				parent.$("div.alert_content").hide();
				parent.$("div.tishi").show();
				parent.$("div.tishi p").html("初始化失败");
			}
		}
	})
})

//用户账号--添加--用户归属
var Maxteam;
$("a.account_add").click(function(e) {
	e.preventDefault();
	parent.$("div.alert").fadeIn();
	parent.$("div.alert .smallkuang-header span").html("添加账号");
	parent.$("div.alert_content").show();
	$.ajax({
		type: 'GET',
		url: http + 'systemUser/queryDept.do',
		datatype: 'JSON',
		success: function(callback) {
			var html = "<option value='-1'>请选择</option>";
			for(var i = 0; i < callback.obj.length; i++) {
				if(callback.obj[i].deptName === '管理员') {
					continue;
				}
				html += `
					<option value='${callback.obj[i].deptid}'>${callback.obj[i].deptName}</option>
				`
				if(i / 1 === 0) {
					Maxteam = callback.obj[i].deptid;
				} else {
					if(callback.obj[i].deptid > Maxteam) {
						Maxteam = callback.obj[i].deptid
					}
				}
			}
			Maxteam = Maxteam / 1 + 1;
			parent.$("#dadui").html(html);
		}
	})
	//用户账号--添加--角色下拉框
	$.ajax({
		type: 'GET',
		url: http + 'statistics/queryRole.do',
		datatype: 'JSON',
		success: function(data) {
			var html = "<option value='-1'>请选择</option>";
			for(var i = 0; i < data.obj.length; i++) {
				html += `
					<option value='${data.obj[i].roleid}'>${data.obj[i].roleName}</option>
				`
			}
			parent.$("#role").html(html);
		}
	})
})
$("div.alert_content .close").click(function() {
	$('div.alert').fadeOut();
})
var yanzheng = -1;
var mima = -1;
// 		验证用户名是否符合规则
$("#uname").blur(function() {
	var n = uname.value;
	if(n == '') {
		$("div.alert_content span.zhanghao").addClass('warning');
		$("div.alert_content span.zhanghao").html("账号不能为空");
		return;
	}
	n = n.replace(/\s+/g, "");
	var reg = /^\d+$/;
	if(reg.test(n)) {
		$("div.alert_content span.zhanghao").addClass('warning');
		$("div.alert_content span.zhanghao").html("账号不能纯数字");
		return;
	} else {
		$("div.alert_content span.zhanghao").removeClass('warning');
		$("div.alert_content span.zhanghao").html(" ");
	}
	$.ajax({
		type: 'POST',
		data: {
			systemuserUserid: n
		},
		url: http + 'systemUser/ checkSystemUser.do',
		datatype: 'JSON',
		//		 				jsonp:'callback',
		success: function(callback) {
			if(callback.code == 0) {
				$('div.alert span.zhanghao').removeClass('warning');
				$("div.alert span.zhanghao").html("账号可用");
				$("div.alert_content span.zhanghao").addClass("success");
				yanzheng = 1;
			} else {
				$('div.alert span.zhanghao').removeClass('success');
				$('div.alert span.zhanghao').addClass('warning');
				$("div.alert span.zhanghao").html("账号已存在");
				yanzheng = -1;
			}
		}
	})
});
$("#truename").blur(function() {
	if($(this).val() === '') {
		$('div.alert span.zhanghao').removeClass('success');
		$("div.alert_content span.xingming").html("姓名不能为空");
		$("div.alert_content span.xingming").addClass('warning');
	} else {
		$("div.alert_content  span.xingming").html(" ");
		$("div.alert_content  span.xingming").removeClass('warning');
	}
})
//密码不能为空
$("div.alert_content #upwd").blur(function() {
	if($(this).val() == '') {
		$('div.alert span.zhanghao').removeClass('success');
		$("div.alert_content span.mima").html("密码不能为空");
		$("div.alert_content span.mima").addClass('warning');
		mima = -1;
	} else {
		$("div.alert_content span.mima").html(" ");
		$("div.alert_content span.mima").removeClass('warning');
		mima = 1;
	}
})
//验证密码是否输入一致
$("div.alert_content #pwdagain").blur(function() {
	var p = upwd.value;
	var pa = pwdagain.value;
	if(p === '') {
		$("div.alert_content span.mima1").addClass('warning');
		$('div.alert span.zhanghao').removeClass('success');
		$("div.alert_content span.mima1").html("密码不能为空");

		return;
	}
	if(p != pa) {
		$('div.alert span.zhanghao').removeClass('success');
		$("div.alert_content span.mima1").removeClass('success');
		$("div.alert_content span.mima1").removeClass('success');
		$("div.alert_content span.mima1").addClass('warning');
		$("div.alert_content span.mima1").html("密码输入不一致");
		mima = -1;
	} else {
		$("div.alert_content span.mima1").html("密码输入一致");
		$("div.alert_content span.mima1").removeClass("warning");
		$("div.alert_content span.mima1").addClass("success");
		mima = 1;
	}
})
var te = -1;
$("#dadui").change(function() {
	te = this.value;
})
//用户账号--添加--确定
$("div.alert_content span.yes").click(function() {
	var n = uname.value;
	var t = truename.value;
	var p = upwd.value;
	var pa = pwdagain.value;
	var roleid = $("#role option:selected").val()
	//验证账号不能为空
	if(n === '') {
		$('div.alert span.zhanghao').removeClass('success');
		$("div.alert_content span.zhanghao").html("帐号不能为空");
		$("div.alert_content span.zhanghao").addClass('warning');
		return;
	}
	//验证账号姓名不能为空
	if(t === '') {
		$('div.alert span.zhanghao').removeClass('success');
		$("div.alert_content span.xingming").html("姓名不能为空");
		$("div.alert_content span.xingming").addClass('warning');
		return;
	}
	//验证密码不能为空
	if(p === '') {
		$('div.alert span.zhanghao').removeClass('success');
		$("div.alert_content span.mima").html("密码不能为空");
		$("div.alert_content span.mima").addClass('warning');
		return;
	}
	//验证密码是否一致
	if(p != pa) {
		$('div.alert span.zhanghao').removeClass('success');
		$("div.alert_content span.mima1").html("密码输入不一致");
		$("div.alert_content span.mima1").addClass('warning');
		mima = -1;
	} else {//验证是否选择大队
		$("div.alert_content span.mima1").html("密码输入一致");
		$("div.alert_content span.mima1").removeClass("warning");
		$("div.alert_content span.mima1").addClass("success");
		mima = 1;
		if(te / 1 === -1) {
			$('div.alert span.zhanghao').removeClass('success');
			$("div.alert_content span.guishu").html("尚未选择大队");
			$("div.alert_content span.guishu").addClass('warning');
			return;
		} else {
			$("div.alert_content span.guishu").html("已选择大队");
			$("div.alert_content span.guishu").removeClass("warning");
			$("div.alert_content span.guishu").addClass("success");
		}
		if(yanzheng < 0) {
			return;
		}
		if(mima < 0) {
			return;
		}
		$.ajax({
			type: 'POST',
			url: http + 'systemUser/ insertSysetemUser.do',
			data: {
				loginName: n,
				userName: t,
				password: p,
				deptid: te,
				roleid: roleid,
				userid: sId
			},
			datatype: 'JSONP',
			success: function(callback) {
				te = -1;
				$("div.alert_content div.form-group span").html(" ");
				var userstotal = $("iframe.crumbsCon")[0].contentWindow.userstotal;
				var dangqian = $("iframe.crumbsCon")[0].contentWindow.$("div.pagers ul li.clicked").html();
				var ifeWind = $("iframe.crumbsCon")[0].contentWindow
				userstotal += 1;
				if(callback.code == 0) {
					//先判断是不是最后一页,不是最后一页直接到最后一页,这样用户能直接看到自己添加的用户 
					if(Math.ceil(userstotal / ifeWind.$("div.account div.pagers select").val()) > dangqian) {
						ifeWind.load(Math.ceil(userstotal / ifeWind.$("div.account div.pagers select").val()), ifeWind.$("div.account div.pagers select").val());
					} else {
						if(userstotal % ifeWind.$("div.account div.pagers select").val() <= ifeWind.$("div.account div.pagers select").val() / 1 - 1) {
							ifeWind.load(dangqian, ifeWind.$("div.account div.pagers select").val());
						} else {
							ifeWind.load(dangqian + 1, ifeWind.$("div.account div.pagers select").val());
						}
					}
					$("div.alert").fadeOut();
					uname.value = '';
					truename.value = '';
					upwd.value = '';
					pwdagain.value = '';
				}
			},
			error: function(callback) {
			}
		})
	}
})
$("div.footer span.close1").click(function() {
	$("div.alert").fadeOut();
	$("div.alert_content div.form-group span").html(" ");
	uname.value = '';
	truename.value = '';
	upwd.value = '';
	pwdagain.value = '';
})
//用户账号--删除
$("a.account_delete").click(function(e) {
	var xuanze;
	e.preventDefault();
	var b = document.querySelectorAll("table.account tbody input");
	//定义一个数组
	var hash = [];
	for(var i = 0; i < b.length; i++) {
		if(b[i].checked) {
			//把选中的账号放入数组
			hash.push(b[i]);
		}
	}
	//判断是否选中要删除账号（多选）
	if(hash.length === 0) {//没有选中账号
		parent.$(".smallkuang-header span").html("删除账号");
		parent.$(".smallkuang1>span").html("请选择需要删除的账号！");
		parent.$(".smallkuang1").fadeIn();
		parent.$(".baohu").fadeIn();
		//点击取消关闭弹出框
		parent.$(".sp5").click(function() {
			parent.$(".smallkuang1").fadeOut();
			parent.$(".baohu").fadeOut();
		})
		return false;
	} else {//选中删除账号
		xuanze = 1;
		var strrr = "";
		for(var j = 0; j < hash.length; j++) {
			var d = hash[j].parentElement.nextElementSibling.innerHTML;
			if(j === 0) {
				strrr = d;
			} else {
				strrr += "," + d;
			}
		}
		parent.$("div.alert").fadeIn();
		parent.$("div.tishi").show();
		parent.$("div.alert_content").hide();
		parent.$("div.tishi p").html("是否确定删除");
		//用户账户--删除--确定
		parent.$("div.tishi span.yes").click(function() {
			if(xuanze === 1) {
				var yema; //加载函数要发送的页码
				var zonggong = Math.ceil(userstotal / $("div.account div.pagers select").val()); //一共多少页
				//最后一页剩多少条数据
				var sheng = userstotal % $("div.account div.pagers select").val();
				//当前页码
				var dangqian = $("div.pagers ul li.clicked").html() / 1;
				//如果当前页是最后一页
				if(zonggong === dangqian) {
					if(sheng > hash.length) {
						yema = dangqian;
					} else {
						yema = dangqian - 1;
					}
				} else {//如果不是最后一页
					yema = dangqian;
				}
				//如果是第一页直接1
				if(dangqian === 1) {
					yema = 1;
				}
				$.ajax({
					type: 'GET',
					url: http + 'systemUser/deleteSystemUser.do',
					data: {
						ids: strrr,
						userid: sId
					},
					dataType: "JSON",
					success: function(data) {
						if(data.code == 1) {
							load(yema, $("div.account div.pagers select").val());
						}
					},
					error: function() {
						load(yema, $("div.account div.pagers select").val());
					}
				});
				parent.$(".alert").hide();
			}
		})
	}
})

//批量选中
$("table.account").on("change", 'tbody tr td input', function(e) {
	//为异步加载的元素添加js事件
	var b = document.querySelectorAll("table.account tbody tr td input");
	var n = document.querySelector("table.account thead input");
	if(this.checked) {
		$(e.target).siblings("span").addClass('zhong');
		$(this).parent().parent().addClass("checked");
		for(var i = 0; i < b.length; i++) {
			if(!b[i].checked) {
				return;
			}
		}
		$("table.account thead span.duigou").addClass('zhong');
		document.querySelector("table.account thead th input").checked = true;
	} else {
		n.checked = false;
		$("table.account thead span.duigou").removeClass("zhong");
		$(this).parent().parent().removeClass("checked");
		$(e.target).siblings("span").removeClass('zhong');
	}
});
$("table.account thead th input").on("click", function() {
	var b = document.querySelectorAll("table.account tbody input");
	if(this.checked) {
		$("table.account thead span.duigou").addClass('zhong');
		for(var i = 0; i < b.length; i++) {
			b[i].checked = true;
		}
		$("table.account tbody tr").addClass("checked");
		$("table.account tbody span.duigou").addClass('zhong');
	} else {
		$("table.account thead span.duigou").removeClass('zhong');
		for(var i = 0; i < b.length; i++) {
			b[i].checked = false;
		}
		$("table.account tbody tr").removeClass("checked");
		$("table.account tbody span.duigou").removeClass('zhong');
	}
})

//通用提示框的影藏
//		$("div.tishi span.yes").click(function(){
//			$("div.alert").fadeOut();
//			$("div.tishi").hide();
//		});
$("div.tishi span.no").click(function() {
	$("div.alert").fadeOut();
	$("div.tishi").hide();
});
//		所长查询
var Maxpage = 1;

function suosearch(a, b, p, r) {
	$("[name=stateid]").hide();
	$.ajax({
		type: 'GET',
		datatype: 'JSONP',
		JSONP: 'callback',
		data: {
			roleid: a,
			recordDate: b,
			page: p,
			rows: r,
			recordDeptId: 1
		},
		url: http + 'AttendPeopleRecordController/ShowRecord.do',
		success: function(data) {
			console.log(data);
			var html = '';
			if(data.result.length != 0) {
				for(var i = 0; i < data.result.length; i++) {
					if(data.result[i].starttime) {
						data.result[i].starttime = data.result[i].starttime.substring(0, 19);
					}
					if(data.result[i].absensenum / 1 < 0) {
						data.result[i].absensenum = 0;
					}
					html += `
						<tr>
							<td>${data.result[i].deptName}</td>
							<td>${data.result[i].starttime}</td>
							<td>${data.result[i].sickleavenum}</td>
							<td>${data.result[i].othernum}</td>
							<td>${data.result[i].rollcallnum}</td>
							<td>${data.result[i].attendnum}</td>
							<td>${data.result[i].absensenum}</td>
							</tr>
						`
				}
			} else {
				html += `
					<tr>
						<td colspan="7" style="text-align:center">暂无数据</td>
					</tr>
				`
			}
			$("#rollcall tbody").html(html);
			var dangqian = data.page;     //当前页码
			var zong = data.total;        //一共多少条数据
			var rows = data.pageSize;     //一页多少数据
			var yeshu = data.count;       //总页数
			if(yeshu == 0) {
				yeshu = 1;
			}
			Maxpage = data.count;
			var html1 = '';
			if(dangqian == 1) {
				if(dangqian <= yeshu) {
					html1 += `<li class="clicked">${dangqian}</li>`;
				}
				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
				if(dangqian + 4 <= yeshu) {
					html1 += `<li>${dangqian+4}</li>`;
				}
			} else if(dangqian == 2) {
				html1 += `<li>${dangqian-1}</li>`;
				html1 += `<li class="clicked">${dangqian}</li>`;

				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
			} else if(dangqian == yeshu && dangqian >= 5) {
				html1 += `
						<li>${dangqian-4}</li>

						<li>${dangqian-3}</li>

						<li>${dangqian-2}</li>

						<li >${dangqian-1}</li>
						<li class="clicked">${dangqian}</li>
						`
			} else if(dangqian == yeshu - 1 && dangqian >= 5) {
				html1 += `
						<li>${dangqian-3}</li>

						<li>${dangqian-2}</li>

						<li>${dangqian-1}</li>

						<li class="clicked">${dangqian}</li>
						<li>${dangqian+1}</li>
						`
			} else {
				if(dangqian - 2 > 0) {
					html1 += `<li>${dangqian-2}</li>`;
				}
				if(dangqian - 1 > 0) {
					html1 += `<li>${dangqian-1}</li>`;
				}
				html1 += `<li class="clicked">${dangqian}</li>`;
				if(dangqian < yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 1 < yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
			}
			$("div.rollcallbottom ul").html(html1);
			$("div.rollcallbottom span.pagerstotal").html(zong);
			$("div.rollcallbottom span.dangqian").html(dangqian);
			$("div.rollcallbottom span.yeshu").html(yeshu);
			var op = '';
			if(data.dlist != null) {
				for(var j = 0; j < data.dlist.length; j++) {
					if(data.dlist[j].id == 0) {
						op += `
							<option value='0'>暂无数据</option>
							`
						break;
					}
					if(startid / 1 == data.dlist[j].id) {
						op += `
							<option value="${data.dlist[j].id}" selected="selected">${data.dlist[j].starttime.substring(10,16)}</option>
								`
					} else {
						op += `
							<option value="${data.dlist[j].id}">${data.dlist[j].starttime.substring(10,16)}</option>
							`
					}
				}
			} else {
				op += `
					<option value='0'>暂无数据</option>
					`
			}
			$("[name='startDate']").html(op);
		}
	})
}

function duisearch(a, b, c, p, r, username, userid, startDate, stateid, startid) {
	$("[name=stateid]").show();
	$.ajax({
		type: 'GET',
		datatype: 'JSONP',
		JSONP: 'callback',
		url: http + 'AttendPeopleRecordController/ShowRecord.do',
		data: {
			roleid: a,
			recordDate: b,
			recordDeptId: c,
			page: p,
			rows: r,
			recordUsername: username,
			recordUserId: userid,
			startDate: startDate,
			stateid: stateid,
			startid: startid
		},
		success: function(data) {
//console.log(data)
			var html = '';
			var op = '';
			if(data.recordDate != null) {
				$("[name='recordDate']").val(data.recordDate.substring(0, 10));
			}
			if(data.dlist != null) {
				for(var j = 0; j < data.dlist.length; j++) {
					if(data.dlist[j].id == 0) {
						op += `
							<option value='0'>暂无数据</option>
							`
						break;
					}
					if(startid / 1 == data.dlist[j].id) {
						op += `
								<option value="${data.dlist[j].id}" selected="selected">${data.dlist[j].starttime.substring(10,16)}</option>
								`
					} else {
						op += `
							<option value="${data.dlist[j].id}">${data.dlist[j].starttime.substring(10,16)}</option>
							`
					}
				}
			} else {
				op += `
					<option value='0'>暂无数据</option>
					`
			}
			$("[name='startDate']").html(op);
			var startDateSelect = $("[name='startDate']>option:selected").html();
			var device='';


			if(data.result.length > 0) {
				for(var i = 0; i < data.result.length; i++) {
					if(data.result[i].recordDatetime) {
						data.result[i].recordDatetime = data.result[i].recordDatetime.substring(0, 19);
					}
					if(data.result[i].deviceType==null){
						device="--";
					}else{
						if(data.result[i].deviceType==0){
							device="掌静脉";
						}else if(data.result[i].deviceType==1){
							device="指静脉"
						}
					}
					//console.log(device)
					html += `
					<tr>
						<td>${startDateSelect}</td>
						<td>${data.result[i].userId}</td>
						<td>${data.result[i].userName}</td>
						<td>${data.result[i].recordtime}</td>
						<td>${data.result[i].stateName}</td>
						<td>${device}</td>
						</tr>
					`
				}
			} else {
				html += `
				<tr>
					<td colspan="6" style="text-align:center">暂无数据</td>

					</tr>
					`
			}
			$("#rollcall tbody").html(html);

			var dangqian = data.page; //当前页码
			var zong = data.total; //一共多少条数据
			var rows = data.pageSize; //一页多少数据
			var yeshu = data.count; //总页数
			if(yeshu == 0) {
				yeshu = 1;
			}
			Maxpage = data.count;
			var html1 = '';
			if(dangqian == 1) {
				if(dangqian <= yeshu) {
					html1 += `<li class="clicked">${dangqian}</li>`;
				}
				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
				if(dangqian + 4 <= yeshu) {
					html1 += `<li>${dangqian+4}</li>`;
				}
			} else if(dangqian == 2) {
				html1 += `<li>${dangqian-1}</li>`;
				html1 += `<li class="clicked">${dangqian}</li>`;

				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
			} else if(dangqian == yeshu && dangqian >= 5) {
				html1 += `
						<li>${dangqian-4}</li>

						<li>${dangqian-3}</li>

						<li>${dangqian-2}</li>

						<li >${dangqian-1}</li>
						<li class="clicked">${dangqian}</li>
						`
			} else if(dangqian == yeshu - 1 && dangqian >= 5) {
				html1 += `
						<li>${dangqian-3}</li>

						<li>${dangqian-2}</li>

						<li>${dangqian-1}</li>

						<li class="clicked">${dangqian}</li>
						<li>${dangqian+1}</li>
						`
			} else {
				if(dangqian - 2 > 0) {
					html1 += `<li>${dangqian-2}</li>`;
				}
				if(dangqian - 1 > 0) {
					html1 += `<li>${dangqian-1}</li>`;
				}
				html1 += `<li class="clicked">${dangqian}</li>`;
				if(dangqian < yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 1 < yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
			}
			$("div.rollcallbottom ul").html(html1);
			$("div.rollcallbottom span.pagerstotal").html(zong);
			$("div.rollcallbottom span.dangqian").html(dangqian);
			$("div.rollcallbottom span.yeshu").html(yeshu);
		}
	})
}
var username = '';
var userid = '';
var startDate = '';
var stateid = '';
var startid = 0;
//点击日期查询
$(function() {
	var d = $("[name='recordDate']").val();
	username = $("[name='recordUsername']").val();
	userid = $("[name='recordUserId']").val();
	if($("[name='startDate']").val() != null && d == $("[name='startDate']").html().substring(0, 10)) {
		//				startDate = $("[name='startDate']").val().substring(0,19);
		startid = $("[name='startDate']").val();
	} else {
		startid = $("[name='startDate']").val();
	}
	//			console.log($("[name='startDate']").val()!=null&&d==$("[name='startDate']").val().substring(0,10));
	//			console.log($("[name='startDate']").val().substring(0,10));
	//			console.log(startDate);
	stateid = $("[name='stateid']").val();
	var j = sessionStorage['sUserDept'];

	if(sessionStorage['sRoleId'] / 1 === 2 || sessionStorage['sRoleId'] / 1 === 1) {
		suosearch(2, d, 1, $("div.rollcallbottom p select").val())
	} else if(sessionStorage['sRoleId'] / 1 === 3) {
		duisearch(3, d, j, 1, $("div.rollcallbottom p select").val(), username, userid, startDate, stateid, startid);
	}
})

//点击查询搜索
$("span.datebtn").click(function() {
	var d = $("[name='recordDate']").val();
	username = $("[name='recordUsername']").val();
	userid = $("[name='recordUserId']").val();
	console.log(d);
	if($("[name='startDate']").val() != null && d == $("[name='startDate']").val()) {
		//				startDate = $("[name='startDate']").val().substring(0,19);
		startid = $("[name='startDate']").val();
	} else {
		//				startDate = '';
		startid = $("[name='startDate']").val();
	}
	//			console.log($("[name='startDate']").val()!=null&&d==$("[name='startDate']").val().substring(0,10));
	//			console.log($("[name='startDate']").val().substring(0,10));
	//			console.log(startDate);
	stateid = $("[name='stateid'] option:selected").val();
	var j = sessionStorage['sUserDept'];
	if(sessionStorage['sRoleId'] / 1 === 2 || sessionStorage['sRoleId'] / 1 === 1) {
		suosearch(2, d, 1, $("div.rollcallbottom p select").val())
	} else if(sessionStorage['sRoleId'] / 1 === 3) {

		duisearch(3, d, j, 1, $("div.rollcallbottom p select").val(), username, userid, startDate, stateid, startid);
	}
})
$("div.rollcallbottom a.tofirst").click(function(e) {
	var d = $("[name='recordDate']").val();
	e.preventDefault();
	var page = $("div.rollcallbottom span.dangqian").html();
	if(page != 1) {
		username = $("[name='recordUsername']").val();
		userid = $("[name='recordUserId']").val();
		console.log(d);
		if($("[name='startDate']").val() != null && d == $("[name='startDate']").val()) {
			//				startDate = $("[name='startDate']").val().substring(0,19);
			startid = $("[name='startDate']").val();
		} else {
			//				startDate = '';
			startid = $("[name='startDate']").val();
		}
		//		console.log($("[name='startDate']").val()!=null&&d==$("[name='startDate']").val().substring(0,10));
		//		console.log($("[name='startDate']").val().substring(0,10));
		//		console.log(startDate);
		stateid = $("[name='stateid']").val();
		var j = sessionStorage['sUserDept'];
		if(sessionStorage['sRoleId'] / 1 === 2 || sessionStorage['sRoleId'] / 1 === 1) {
			suosearch(2, d, 1, $("div.rollcallbottom p select").val())
		} else if(sessionStorage['sRoleId'] / 1 === 3) {

			duisearch(3, d, j, 1, $("div.rollcallbottom p select").val(), username, userid, startDate, stateid, startid);
		}
	}
})
$("div.rollcallbottom a.toleast").click(function(e) {
	e.preventDefault();
	var page = $("div.rollcallbottom span.dangqian").html();
	var lastPage = $("div.rollcallbottom span.yeshu").html();
	if(page != lastPage) {
		var d = $("[name='recordDate']").val();
		username = $("[name='recordUsername']").val();
		userid = $("[name='recordUserId']").val();
		console.log(d);
		if($("[name='startDate']").val() != null && d == $("[name='startDate']").val()) {
			//				startDate = $("[name='startDate']").val().substring(0,19);
			startid = $("[name='startDate']").val();
		} else {
			//				startDate = '';
			startid = $("[name='startDate']").val();
		}
		stateid = $("[name='stateid']").val();
		var j = sessionStorage['sUserDept'];
		if(sessionStorage['sRoleId'] / 1 === 2 || sessionStorage['sRoleId'] / 1 === 1) {
			suosearch(2, d, Maxpage, $("div.rollcallbottom p select").val())
		} else if(sessionStorage['sRoleId'] / 1 === 3) {
			duisearch(3, d, j, Maxpage, $("div.rollcallbottom p select").val(), username, userid, startDate, stateid, startid);
		}
	}
})
$("div.rollcallbottom a.go").click(function(e) {
	var d = $("[name='recordDate']").val();
	username = $("[name='recordUsername']").val();
	userid = $("[name='recordUserId']").val();
	console.log(d);
	var page = $("div.rollcallbottom span.dangqian").html();
	var a = $("div.rollcallbottom input").val();
	e.preventDefault();
	if(page != a) {
		if($("[name='startDate']").val() != null && d == $("[name='startDate']").val()) {
			//				startDate = $("[name='startDate']").val().substring(0,19);
			startid = $("[name='startDate']").val();
		} else {
			//				startDate = '';
			startid = $("[name='startDate']").val();
		}
		stateid = $("[name='stateid']").val();
		var j = sessionStorage['sUserDept'];
		var a = $("div.rollcallbottom input").val();
		var zong= $("div.rollcallbottom span.yeshu").html();

		if(a / 1 > zong) {
			parent.$(".smallkuang3").fadeIn();
			parent.$(".baohu").fadeIn();
			parent.$(".sp9").click(function() {
				parent.$(".smallkuang3").fadeOut();
				parent.$(".baohu").fadeOut();
				$("div.jogger input").val('');
			})
			return;
		}
		if(a == '') {
			return;
		}
		if(sessionStorage['sRoleId'] / 1 === 2 || sessionStorage['sRoleId'] / 1 === 1) {
			suosearch(2, d, a, $("div.rollcallbottom p select").val())
		} else if(sessionStorage['sRoleId'] / 1 === 3) {
			duisearch(3, d, j, a, $("div.rollcallbottom p select").val(), username, userid, startDate, stateid, startid);
		}
	}
})
//点击页码查询
$("div.rollcallbottom ul.yema").on("click", "li", function(e) {
	var d = $("[name='recordDate']").val();
	username = $("[name='recordUsername']").val();
	userid = $("[name='recordUserId']").val();
	console.log(d);
	var ye = e.target.innerHTML;
	if($("[name='startDate']").val() != null && d == $("[name='startDate']").val()) {
		//			startDate = $("[name='startDate']").val().substring(0,19);
		startid = $("[name='startDate']").val();
	} else {
		//			startDate = '';
		startid = $("[name='startDate']").val();
	}
	stateid = $("[name='stateid']").val();
	var j = sessionStorage['sUserDept'];
	if(sessionStorage['sRoleId'] / 1 === 2 || sessionStorage['sRoleId'] / 1 === 1) {
		suosearch(2, d, ye, $("div.rollcallbottom p select").val())
	} else if(sessionStorage['sRoleId'] / 1 === 3) {
		duisearch(3, d, j, ye, $("div.rollcallbottom p select").val(), username, userid, startDate, stateid, startid);
	}
})
$("span.excel").click(function() {
	var d = $("div.date input").val();
	var DAOCHU;
	if(sessionStorage['sRoleId'] / 1 === 2 || sessionStorage['sRoleId'] / 1 === 1) {
		DAOCHU = http + "AttendPeopleRecordController/outputExcl.do?roleid=" +
			sessionStorage['sRoleId'] + "&recordDate=" + d;
	} else if(sessionStorage['sRoleId'] / 1 === 3) {
		DAOCHU = http + "AttendPeopleRecordController/outputExcl.do?roleid=" +
			sessionStorage['sRoleId'] + "&recordDate=" + d + "&recordDeptId=" + sessionStorage['sUserDept'];
	}
	$.ajax({
		type: 'GET',
		dataType: 'JSON',
		jsonp: 'callback',
		url: DAOCHU,
		success: function(data) {
			console.log(data);
			if(sessionStorage['sRoleId'] / 1 === 2 || sessionStorage['sRoleId'] / 1 === 1) {
				var html = '';
				for(var i = 0; i < data.length; i++) {
					if(data[i].starttime) {
						data[i].starttime = data[i].starttime.substring(0, 19);
					}
					if(data[i].absensenum / 1 < 0) {
						data[i].absensenum = 0;
					}
					html += `
							<tr>
							<td>${data[i].deptName}</td>
							<td>${data[i].starttime}</td>
							<td>${data[i].sickleavenum}</td>
							<td>${data[i].othernum}</td>
							<td>${data[i].rollcallnum}</td>
							<td>${data[i].attendnum}</td>
							<td>${data[i].absensenum}</td>
							</tr>
						`
				}

				$("#daochu tbody").html(html);
				$("#daochu").tableExport({
					type: "excel",
					escape: "false",
					fileName: sessionStorage['department'] + d + "出勤情况"
				});

			} else if(sessionStorage['sRoleId'] / 1 === 3) {
				var html = '';
				if(data.dlist.length == 0) {
					return;
				}
				for(var i = 0; i < data.dlist.length; i++) {
					html += `
								<tr><td></td></tr>
								<tr>
								<tr><td colspan="4"  >点名时段</td></tr>
									<tr>
										<td colspan="2"  >${data.dlist[i].starttime.substring(0,19)}</td>
									</tr>
									<tr>
									<td>编号</td><td>姓名</td><td>考勤时间</td><td>状态</td>
									</tr>
									`
					var list = [];
					list = data.result[i]
					if(list.length != 0) {
						for(var k = 0; k < list.length; k++) {
							html +=
								`<tr>
											<td>${data.result[i][k].userId}</td>
											<td>${data.result[i][k].userName}</td>
											<td>${data.result[i][k].recordtime.substring(0,19)}</td>
											<td>${data.result[i][k].stateName}</td>
											</tr>`
						}
					} else {
						html += `<tr><td colspan="4" align="center">暂无数据</td></tr>`
					}
				}
				$("#daochu tbody").html(html);
				$("#daochu").tableExport({
					type: "excel",
					escape: "false",
					fileName: sessionStorage['department'] + d + "出勤情况"
				});
			}
		}
	})

})
var oldData007 = '';
var oldData009 = '';
//	var allpeople1=[0];
//	var allpeople2=[];
//	var allpeople3=[];
//	var allpeople4=[];
//	var allpeople5=[];
var bianhao = 0;
//	var hash1=[];
//	var hash2=[];
//	var hash3=[];
//	var hash4=[];
//	var hash5=[];
var numcode = 0;
var isSetOver = true;

function qingqiu() {
	//		var isSetOver = $("iframe.crumbsCon")[0].contentWindow.isSetOver;
	//		console.log(!isSetOver)
	//		console.log(allpeople1)
	if(!isSetOver) {
		return
	};
	setTimeout(qingqiu, 650);
	$.ajax({
		type: 'post',
		url: http + "AttendPeopleRecordController/prepareRecord.do",
		data: {
			recordDeptId: sessionStorage['sUserDept']
		},
		datatype: 'JSONP',
		jsonp: 'callbacck',
		traditional: true,
		success: function(callback) {
			//				var ifeWindow = $("iframe.crumbsCon")[0].contentWindow
			var data = JSON.parse(callback).result;
			var numdata = JSON.parse(callback);
			numcode += data.length;
			if(numcode === 0) {
				parent.$("div.people-rollcall div.mainrollcall ul.btns li.wan").css({
					'opacity': 0.4
				})
				parent.$("div.people-rollcall div.mainrollcall ul.btns li.zan").css({
					'opacity': 0.4
				})
				return;
			} else {
				parent.$("div.people-rollcall div.mainrollcall ul.btns li.wan").css({
					'opacity': 1
				})
				parent.$("div.people-rollcall div.mainrollcall ul.btns li.zan").css({
					'opacity': 1
				})
			}
			parent.$("div.people-rollcall a.total").html("总人数：" + numdata.allnum);
			parent.$("div.people-rollcall a.bingxiu").html("病休：" + numdata.sickleavenum);
			parent.$("div.people-rollcall a.qita").html("其他：" + numdata.othernum);

			if(data.length <= 0) {
				return;
			}
			if(oldData007 == data[0].id) {
				return
			};
			oldData007 = data[0].id;
			//				if(data.length>0){
			//					if(hash1.length<500){
			//						hash1.push(data[0].id);
			//					}
			//					else if(hash2.length<500){
			//						hash2.push(data[0].id);
			//					}
			//					else if(hash3.length<500){
			//						hash3.push(data[0].id);
			//					}
			//					else if(hash4.length<500){
			//						hash4.push(data[0].id);
			//					}
			//					else if(hash5.length<500){
			//						hash5.push(data[0].id);
			//					}
			//				}	

			//				allpeople1=hash1;
			//				allpeople2=hash2;
			//				allpeople3=hash3;
			//				allpeople4=hash4;
			//				allpeople5=hash5;
			showPhoto(data[0], numdata);
		}
	})
}

function showPhoto(data, numdata) {
	parent.$("div.people-rollcall div.renyuan").html(data.department + "   编号" + data.userNo + "  " + data.userName);
	if(data.photoUrl != null) {
		parent.$("div.people-rollcall div.zhaopian img").attr("src", data.photoUrl);
	} else {
		parent.$("div.people-rollcall div.zhaopian img").attr("src", "img/no-people.png");
	}
	bianhao++;
	parent.$("div.people-rollcall a.queqin").html("缺勤：" + (numdata.allnum - numdata.sickleavenum - numdata.othernum - bianhao));
	parent.$("div.people-rollcall a.chugong").html("出工：" + bianhao);
	parent.$("div.people-rollcall div.zhaopian").animate({
		width: 0
	}, 250);
	parent.$("div.people-rollcall div.zhaopian").animate({
		width: 280
	}, 250);
}
var kaishi;
var time; //定时器
$("div.rollcallBTN").click(function() {
	$.ajax({
		type: "POST",
		datatype: 'JSON',
		data: {
			recordDeptId: 1
		},
		url: http + "AttendPeopleRecordController/clearRecord.do",
		success: function(data) {
			console.log(data)
			//var data=JSON.parse(data);
			if(data.flag.depFlag == true) {
				window.open("Rollcall.html")
			} else {
				alert("正在点名······")
			}
		}

	})
	//
	//isSetOver = true;
	//$.ajax({
	//	type:"POST",
	//	datatype:'JSON',
	//	data:{recordDeptId:sessionStorage['sUserDept']},
	//	url:http+"AttendPeopleRecordController/clearRecord.do",
	//	success:function(data){
	//		data=JSON.parse(data);
	//		if(data.code>=0){
	//			parent.$("div.alert").fadeIn();
	//			parent.$("div.alert div.alert_content").hide();
	//			parent.$("div.alert div.people-rollcall").fadeIn();
	//			kaishi=new Date();
	//			kaishi=kaishi.toString().substr(16,8);
	//			bianhao=0;
	//			qingqiu();
	//		}
	//	}
	//})
})
$("div.people-rollcall div.mainrollcall ul.btns li.zhong").click(function() {
	var ifeWindow = $("iframe.crumbsCon")[0].contentWindow;
	ifeWindow.isSetOver = false;
	bianhao = 0;
	ifeWindow.oldData007 = '';
	ifeWindow.oldData009 = '';
	//		      	 ifeWindow.allpeople1=[0];
	//		      	 ifeWindow.allpeople2=[];
	//		      	 ifeWindow.allpeople3=[];
	//		      	 ifeWindow.allpeople4=[];
	//		      	 ifeWindow.allpeople5=[];
	ifeWindow.bianhao = 0;
	//		      	 ifeWindow.hash1=[];
	//		      	 ifeWindow.hash2=[];
	//		      	 ifeWindow.hash3=[];
	//		      	 ifeWindow.hash4=[];
	//		      	 ifeWindow.hash5=[];
	ifeWindow.numcode = 0;
	ifeWindow.oldData009 = '';
	//  	 ifeWindow.allpeople1=[0];
	//  	 ifeWindow.allpeople2=[];
	//  	 ifeWindow.allpeople3=[];
	//  	 ifeWindow.allpeople4=[];
	//  	 ifeWindow.allpeople5=[];
	ifeWindow.bianhao = 0;
	//  	 ifeWindow.hash1=[];
	//  	 ifeWindow.hash2=[];
	//  	 ifeWindow.hash3=[];
	//  	 ifeWindow.hash4=[];
	//  	 ifeWindow.hash5=[];
	ifeWindow.numcode = 0;
	$.ajax({
		type: 'POST',
		data: {
			recordDeptId: sessionStorage['sUserDept']
		},
		datatype: 'JSONP',
		jsonp: 'callback',
		url: http + 'AttendPeopleRecordController/shutdownRecord.do',
		//			data:{ids1:ifeWindow.allpeople1,
		//				ids2:ifeWindow.allpeople2,
		//				ids3:ifeWindow.allpeople3,
		//				ids4:ifeWindow.allpeople4,
		//				ids5:ifeWindow.allpeople5},
		traditional: true,
		success: function() {
			$("div.alert").fadeOut();
			$("div.alert div.alert_content").hide();
			$("div.alert div.people-rollcall").fadeOut();
			$("div.alert div.people-rollcall").hide();
			$("div.people-rollcall div.renyuan").html("暂未有人录入");
			$("div.people-rollcall a.total").html("总人数：");
			$("div.people-rollcall a.bingxiu").html("病休：");
			$("div.people-rollcall a.qita").html("其他：");
			$("div.people-rollcall a.queqin").html("缺勤：");
			$("div.people-rollcall div.zhaopian img").attr("src", "img/moren.png");
			$("div.people-rollcall a.chugong").html("出工：");
			$("div.people-rollcall div.mainrollcall ul.btns li.zan").html("暂停点名");
		}
	})
	parent.oldData007 = '';
	parent.oldData009 = '';
	//				 parent.allpeople1=[0];
	//		      	 parent.allpeople2=[];
	//		      	 parent.allpeople3=[];
	//		      	 parent.allpeople4=[];
	//		      	 parent.allpeople5=[];
	parent.bianhao = 0;
	//		      	 parent.hash1=[];
	//		      	 parent.hash2=[];
	//		      	 parent.hash3=[];
	//		      	 parent.hash4=[];
	//		      	 parent.hash5=[];
	parent.numcode = 0;

	ifeWindow.oldData007 = '';
	ifeWindow.oldData009 = '';
	//		      	 ifeWindow.allpeople1=[0];
	//		      	 ifeWindow.allpeople2=[];
	//		      	 ifeWindow.allpeople3=[];
	//		      	 ifeWindow.allpeople4=[];
	//		      	 ifeWindow.allpeople5=[];
	ifeWindow.bianhao = 0;
	//		      	 ifeWindow.hash1=[];
	//		      	 ifeWindow.hash2=[];
	//		      	 ifeWindow.hash3=[];
	//		      	 ifeWindow.hash4=[];
	//		      	 ifeWindow.hash5=[];
	ifeWindow.numcode = 0;

	oldData007 = '';
	oldData009 = '';
	//		      	 allpeople1=[0];
	//		      	 allpeople2=[];
	//		      	 allpeople3=[];
	//		      	 allpeople4=[];
	//		      	 allpeople5=[];
	bianhao = 0;
	//		      	 hash1=[];
	//		      	 hash2=[];
	//		      	 hash3=[];
	//		      	 hash4=[];
	//		      	 hash5=[];
	numcode = 0;
})
var zandate;
$("div.people-rollcall div.mainrollcall ul.btns li.zan").click(function() {
	var ifeWindow = $("iframe.crumbsCon")[0].contentWindow;
	if($(this).css("opacity") / 1 === 0.4) {
		return
	}
	if($(this).html() == "暂停点名") {
		$(this).html("恢复点名");
		ifeWindow.isSetOver = false;
		zandate = new Date();
		zandate = zandate.toString().substr(16, 8);
	} else {
		$(this).html("暂停点名");
		//			$.ajax({
		//				type:'POST',
		//				datatype:'JSONP',
		//				jsonp:'callback',
		//				url:http+'AttendPeopleRecordController/pauseRecord.do',
		//				data:{pauseDatetime:zandate,recordDeptId:sessionStorage['sUserDept']},
		//				success:function(callback){}
		//			})
		ifeWindow.isSetOver = true;
		ifeWindow.qingqiu();
	}
})
//完成点名
$("div.people-rollcall div.mainrollcall ul.btns li.wan").click(function() {
	var ifeWindow = $("iframe.crumbsCon")[0].contentWindow;
	numcode = 0;
	if($(this).css("opacity") / 1 === 0.4) {
		return
	}
	ifeWindow.isSetOver = false;
	parent.oldData007 = '';
	parent.oldData009 = '';
	//				 parent.allpeople1=[0];
	//		      	 parent.allpeople2=[];
	//		      	 parent.allpeople3=[];
	//		      	 parent.allpeople4=[];
	//		      	 parent.allpeople5=[];
	parent.bianhao = 0;
	//		      	 parent.hash1=[];
	//		      	 parent.hash2=[];
	//		      	 parent.hash3=[];
	//		      	 parent.hash4=[];
	//		      	 parent.hash5=[];
	parent.numcode = 0;

	ifeWindow.oldData007 = '';
	ifeWindow.oldData009 = '';
	//		      	 ifeWindow.allpeople1=[0];
	//		      	 ifeWindow.allpeople2=[];
	//		      	 ifeWindow.allpeople3=[];
	//		      	 ifeWindow.allpeople4=[];
	//		      	 ifeWindow.allpeople5=[];
	ifeWindow.bianhao = 0;
	//		      	 ifeWindow.hash1=[];
	//		      	 ifeWindow.hash2=[];
	//		      	 ifeWindow.hash3=[];
	//		      	 ifeWindow.hash4=[];
	//		      	 ifeWindow.hash5=[];
	ifeWindow.numcode = 0;

	oldData007 = '';
	oldData009 = '';
	//		      	 allpeople1=[0];
	//		      	 allpeople2=[];
	//		      	 allpeople3=[];
	//		      	 allpeople4=[];
	//		      	 allpeople5=[];
	bianhao = 0;
	//		      	 hash1=[];
	//		      	 hash2=[];
	//		      	 hash3=[];
	//		      	 hash4=[];
	//		      	 hash5=[];
	numcode = 0;
	bianhao = 0;
	var endDate = new Date();
	endDate = endDate.toString().substr(16, 8);
	var kaishi = new Date();
	kaishi = kaishi.toString().substr(16, 8);
	$.ajax({
		url: http + "AttendPeopleRecordController/commitRecord.do",
		type: 'POST',
		dataType: 'JSON',
		traditional: true,
		data: {
			//				ids1:ifeWindow.allpeople1,
			//				ids2:ifeWindow.allpeople2,
			//				ids3:ifeWindow.allpeople3,
			//				ids4:ifeWindow.allpeople4,
			//				ids5:ifeWindow.allpeople5,
			recordDeptId: sessionStorage['sUserDept'],
			attendNum: $("div.people-rollcall a.chugong").html().slice(3),
			startDatetime: kaishi,
			endDatetime: endDate,
			absenseNum: $("div.people-rollcall a.queqin").html().slice(3)
		},
		success: function(callback) {
			var ifeWindow = $("iframe.crumbsCon")[0].contentWindow
			ifeWindow.$(".end-body ul").empty();
			//				console.log(callback);
			var len = callback.result.length;
			//console.log(len);
			var h = "";
			if(len <= 0) {
				$(".end-body ul").hide();
				$(".end-line ").hide();
				$(".end-body2").show();

			} else {
				$(".end-body ul").show();
				$(".end-line ").show();
				$(".end-body2").hide();
				h += "<li><span class='wid-141' style='font-weight:bold '>学员编号</span> &nbsp <span class='wid-64' style='font-weight:bold '>学员姓名</span></li><li><span class='wid-141' style='font-weight:bold '>学员编号</span> &nbsp <span class='wid-64' style='font-weight:bold '>学员姓名</span></li>"

				for(var i = 0; i < len; i++) {
					h += "<li><span class='wid-141'>" + callback.result[i].userNo + "</span> &nbsp <span class='wid-64'>" + callback.result[i].userName + "</span></li>";

				}
				parent.$("[name='endbody']").html(h)
			}
			parent.$("[class='rollcallnum']").html(callback.rollcallnum);
			parent.$("[class='attendnum']").html(callback.attendnum);
			parent.$("[name='absensenum']").html(callback.absensenum);
			//				console.log(callback.absensenum);
			$("div.alert div.alert_content").hide();
			$("div.alert div.people-rollcall").hide();
			$("div.alert div.end").show();
			$("div.people-rollcall div.renyuan").html("暂未有人录入");
			$("div.people-rollcall a.total").html("总人数：");
			$("div.people-rollcall a.bingxiu").html("病休：");
			$("div.people-rollcall a.qita").html("其他：");
			$("div.people-rollcall div.zhaopian img").attr("src", "img/moren.png");
			$("div.people-rollcall a.chugong").html("出工：");
			$("div.people-rollcall a.queqin").html("缺勤：");
			$("div.people-rollcall div.mainrollcall ul.btns li.zan").html("暂停点名");

		}
	})
})
//点名完成弹出框
$(function() {

	if(sessionStorage['sRoleId'] / 1 === 2 || sessionStorage['sRoleId'] / 1 === 1) {
		$("[name='stateid']").show();
	} else if(sessionStorage['sRoleId'] / 1 === 3) {
		$("[name='stateid']").hide();

	}
	$("[name='end']").on("click", function() {
		//console.log("45646");
		$("div.alert").fadeOut();
		$("div.alert div.end").fadeOut();
		//刷新页面
		var d = $("div.date input").val();
		var j = sessionStorage['sUserDept'];
		if(sessionStorage['sRoleId'] / 1 === 2 || sessionStorage['sRoleId'] / 1 === 1) {
			suosearch(2, d, 1, $("div.rollcallbottom p select").val())
		} else if(sessionStorage['sRoleId'] / 1 === 3) {
			duisearch(3, d, j, 1, $("div.rollcallbottom p select").val());
		}
		oldData007 = '';
		oldData009 = '';
		parent.oldData007 = '';
		parent.oldData009 = '';
		//      	 parent.allpeople1=[0];
		//		      	 parent.allpeople2=[];
		//		      	 parent.allpeople3=[];
		//		      	 parent.allpeople4=[];
		//		      	 parent.allpeople5=[];
		parent.bianhao = 0;
		//		      	 parent.hash1=[];
		//		      	 parent.hash2=[];
		//		      	 parent.hash3=[];
		//		      	 parent.hash4=[];
		//		      	 parent.hash5=[];
		parent.numcode = 0;

		//		      	 allpeople1=[0];
		//		      	 allpeople2=[];
		//		      	 allpeople3=[];
		//		      	 allpeople4=[];
		//		      	 allpeople5=[];
		bianhao = 0;
		//		      	 hash1=[];
		//		      	 hash2=[];
		//		      	 hash3=[];
		//		      	 hash4=[];
		//		      	 hash5=[];
		numcode = 0;
	})
})
/////////////////////////登陆日志////////////////////////////////////////////
$(".logindate").jeDate({
	format: "YYYY-MM-DD",
	isTime: true,
	maxDate: "2080-09-19 00:00:00"
});
$(".logindate").jeDate({
	format: "YYYY-MM-DD",
	isTime: true,
	skinCell: "jedateblue",
	minDate: "2016-09-19 00:00:00"
});
var loginMax;

function loadrecord(a, b) {
	var c = $("div.loginDateChoseCrbOn input.loginname").val();
	var d = $("div.loginDateChoseCrbOn input.logindate").val();
	var e = $("div.loginDateChoseCrbOn input.loginip").val();
	if(!c) {
		c = '';
	}
	if(!d) {
		d = '';
	}
	if(!e) {
		e = '';
	}
	$.ajax({
		datatype: 'JSON',
		type: 'POST',
		url: http + "CtrLogController/selectAllCtrLog.do?",
		data: {
			page: a,
			row: b,
			logName: c,
			logCreateTime: d,
			logComIP: e
		},
		jsonp: 'callback',
		success: function(callback) {
			var data = JSON.parse(callback);
			var dangqian = data.page / 1;
			var zongshu = data.count / 1;
			var yeshu = data.pages / 1;
			if(yeshu == 0) {
				yeshu = 1;
			}
			loginMax = yeshu;
			var html = '';
			//console.log(callback)
			if(data.result.length > 0) {
				for(var i = 0; i < data.result.length; i++) {
					if(data.result[i].logExitTime == null) {
						data.result[i].logExitTime = "暂未退出"
					}
					html += `
				<tr>
					<td>${data.result[i].logId}</td>
					<td>${data.result[i].logName}</td>
					<td>${data.result[i].logComIP}</td>
					<td>${data.result[i].logCreateTime}</td>
					<td>${data.result[i].logExitTime}</td>
					</tr>
				`
				}
			} else {
				html += `
			<tr>
				<td colspan="5" style="text-align:center">暂无数据</td>

				</tr>
				`
			}

			$("div.loginDateChoseCrbOn div.mainpart table tbody").html(html);
			$("div.loginDateChoseCrbOn div.pagers span.pagerstotal").html(zongshu);
			$("div.loginDateChoseCrbOn div.pagers span.dangqian").html(dangqian);
			$("div.loginDateChoseCrbOn div.pagers span.yeshu").html(yeshu);
			var html1 = '';
			if(dangqian == 1) {
				if(dangqian <= yeshu) {
					html1 += `<li class="clicked">${dangqian}</li>`;
				}
				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
				if(dangqian + 4 <= yeshu) {
					html1 += `<li>${dangqian+4}</li>`;
				}
			} else if(dangqian == 2) {
				html1 += `<li>${dangqian-1}</li>`;
				html1 += `<li class="clicked">${dangqian}</li>`;

				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
			} else if(dangqian == yeshu && dangqian >= 5) {
				html1 += `
						<li>${dangqian-4}</li>

						<li>${dangqian-3}</li>

						<li>${dangqian-2}</li>

						<li >${dangqian-1}</li>
						<li class="clicked">${dangqian}</li>
						`
			} else if(dangqian == yeshu - 1 && dangqian >= 5) {
				html1 += `
						<li>${dangqian-3}</li>

						<li>${dangqian-2}</li>

						<li>${dangqian-1}</li>

						<li class="clicked">${dangqian}</li>
						<li>${dangqian+1}</li>
						`
			} else {
				if(dangqian - 2 > 0) {
					html1 += `<li>${dangqian-2}</li>`;
				}
				if(dangqian - 1 > 0) {
					html1 += `<li>${dangqian-1}</li>`;
				}
				html1 += `<li class="clicked">${dangqian}</li>`;
				if(dangqian < yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 1 < yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
			}
			$("div.loginDateChoseCrbOn div.pagers ul").html(html1);
		}
	})
}
//loadrecord(1,$(".loginDateChoseCrbOn div.pagers select").val());
$("div.loginDateChoseCrbOn div.pagers ul").on("click", "li", function(e) {
	loadrecord(e.target.innerHTML, $(".loginDateChoseCrbOn div.pagers select").val());
})
$("div.loginDateChoseCrbOn div.pagers a.tofirst").click(function(e) {
	var page = $("div.loginDateChoseCrbOn div.pagers span.dangqian").html();

	e.preventDefault();
	if(page != 1) {
		loadrecord(1, $(".loginDateChoseCrbOn div.pagers select").val());
	}

})
$("div.loginDateChoseCrbOn div.pagers a.toleast").click(function(e) {
	e.preventDefault();
	var page = $("div.loginDateChoseCrbOn div.pagers span.dangqian").html();
	var lastPage = $("div.loginDateChoseCrbOn div.pagers span.yeshu").html();
	if(page != lastPage) {
		loadrecord(loginMax, $(".loginDateChoseCrbOn div.pagers select").val());
	}

})
$("div.loginDateChoseCrbOn div.pagers a.go").click(function(e) {
	e.preventDefault();
	var tar = $("div.loginDateChoseCrbOn div.pagers input").val();
	var page = $("div.loginDateChoseCrbOn div.pagers span.dangqian").html();
	if(page != tar) {
		if(tar == '') {
			return;
		}
		if(tar > loginMax) {
			$("div.alert").fadeIn();
			$("div.alert_content").hide();
			$("div.tishi").show();
			$("div.tishi p").html("页码越界");
			return;
		}
		loadrecord(tar, $(".loginDateChoseCrbOn div.pagers select").val());
	}
})
$("div.loginDateChoseCrbOn span.search").click(function() {
	loadrecord(1, $(".loginDateChoseCrbOn div.pagers select").val());
})
/////////////人员管理 分页选择功能
$("div.footDiv div.jogger select").change(function() {
	var rollcalluserId = $(".contentChild .rollcalluserId01").val();
	var roleid = $(".role option:selected").val();
	var rollcalluserName = $(".contentChild .rollcalluserName01").val();
	var rollcalluserCreatetime = $(".contentChild .rollcalluserCreatetime01").val();
	var rollcalluserDeletetime = $(".contentChild .rollcalluserDeletetime01").val();
	var deptid = $(".whichTeam option:selected").val();
	var selectPic = $(".personnel .selectPic option:selected").val();
	var num = $("div.footDiv div.jogger select").val();
	var aNum = $(".personnel  .yema .ycolor").html();
	$(".theadview .view1").attr("class", "view1 bg1");
	//loading(1,num);
	loading(1, num, rollcalluserId, rollcalluserName, selectPic, rollcalluserCreatetime, rollcalluserDeletetime);

	$("div.jogger input").val("");
	$("div.jogger1 input").val("");
})
///////////////状态管理
$("div.footDiv1 div.jogger1 select").change(function() {
	$(".changehead .changetd").attr("class", "changetd bg5");
	var rollcalluserId = $(".changeview .rollcalluserId").val();
	var rollcalluserName = $(".changeview .rollcalluserName").val();
	$(".theadview .view1").attr("class", "view1 bg1")
	if(zhuangtai == -1) {
		zhuangtai = ''
	};
	$.ajax({
		type: "POST",
		url: http + "userInfoListController/queryUserInfoList",
		data: {
			roleid: sessionStorage.sRoleId,
			userid: rollcalluserId,
			userName: rollcalluserName,
			stateid: zhuangtai,
			page: 1,
			rows: $("div.footDiv1 div.jogger1 select").val(),
			deptid: sessionStorage.getItem("sUserDept")
		},
		datatype: 'JSON',
		success: function(callback) {
			var html = "";
			for(var x = 0; x < callback.obj.length; x++) {
				html += `
   							<tr>
								<td class="peoplechild" ><div class="changetd bg5"></div></td>
								<td class="peoplenum"  data-wid="${callback.obj[x].id}">${callback.obj[x].userid}</td>
								<td class="peoplename">${callback.obj[x].userName}</td>
								<td class="peoplecompany">${callback.obj[x].deptName}</td>
								<td class="nowcurrent">${callback.obj[x].stateName}</td>
							</tr>
							`
			}
			$(".changebody").html(html);
			var dangqian = callback.objExt.currentPage / 1;
			//当前页码
			userstotal1 = callback.objExt.totalCount; //一共多少条数据
			var rows = callback.objExt.pageSize / 1; //一页多少数据
			var yeshu = Math.ceil(userstotal1 / rows);
			if(yeshu == 0) {
				yeshu = 1;
			}
			var html1 = '';
			if(dangqian == 1) {
				if(dangqian <= yeshu) {
					html1 += `<li class="clicked">${dangqian}</li>`;
				}
				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
				if(dangqian + 4 <= yeshu) {
					html1 += `<li>${dangqian+4}</li>`;
				}
			} else if(dangqian == 2) {
				html1 += `<li>${dangqian-1}</li>`;
				html1 += `<li class="clicked">${dangqian}</li>`;

				if(dangqian + 1 <= yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 2 <= yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
				if(dangqian + 3 <= yeshu) {
					html1 += `<li>${dangqian+3}</li>`;
				}
			} else if(dangqian == yeshu && dangqian >= 5) {
				html1 += `
						<li>${dangqian-4}</li>

						<li>${dangqian-3}</li>

						<li>${dangqian-2}</li>

						<li >${dangqian-1}</li>
						<li class="clicked">${dangqian}</li>
						`
			} else if(dangqian == yeshu - 1 && dangqian >= 5) {
				html1 += `
						<li>${dangqian-3}</li>

						<li>${dangqian-2}</li>

						<li>${dangqian-1}</li>

						<li class="clicked">${dangqian}</li>
						<li>${dangqian+1}</li>
						`
			} else {
				if(dangqian - 2 > 0) {
					html1 += `<li>${dangqian-2}</li>`;
				}
				if(dangqian - 1 > 0) {
					html1 += `<li>${dangqian-1}</li>`;
				}
				html1 += `<li class="clicked">${dangqian}</li>`;
				if(dangqian < yeshu) {
					html1 += `<li>${dangqian+1}</li>`;
				}
				if(dangqian + 1 < yeshu) {
					html1 += `<li>${dangqian+2}</li>`;
				}
			}
			$("ul.yema1").html(html1);
			$(".look1 .allpeople1").html(userstotal1);
			$(".look1 .nowpage1").html(dangqian);
			$(".look1 .allpage1").html(yeshu);
			$("div.jogger input").val("");
			$("div.jogger1 input").val("");
		},
		error: function(callback) {}
	})
})
//////////////账号管理分页
$("div.account div.pagers select").change(function() {
	load(1, $("div.account div.pagers select").val());
	$("div.account div.pagers input").val("");
})
///////////点名管理
$("div.rollcallbottom p select").change(function() {
	var d = $("[name='recordDate']").val();
	username = $("[name='recordUsername']").val();
	userid = $("[name='recordUserId']").val();
	//	console.log(d);
	if($("[name='startDate']").val() != null && d == $("[name='startDate']").html().substring(0, 10)) {
		//		startDate = $("[name='startDate']").val().substring(0,19);
		startid = $("[name='startDate']").val();
	} else {
		startid = $("[name='startDate']").val();
	}
	//	console.log($("[name='startDate']").val()!=null&&d==$("[name='startDate']").val().substring(0,10));
	//	console.log($("[name='startDate']").val().substring(0,10));
	//	console.log(startDate);
	stateid = $("[name='stateid']").val();
	var j = sessionStorage['sUserDept'];
	if(sessionStorage['sRoleId'] / 1 === 2 || sessionStorage['sRoleId'] / 1 === 1) {
		suosearch(2, d, 1, $("div.rollcallbottom p select").val());
	} else if(sessionStorage['sRoleId'] / 1 === 3) {
		duisearch(3, d, j, 1, $("div.rollcallbottom p select").val(), username, userid, startDate, stateid, startid);
	}
	$("div.rollcallbottom input").val("");
})
////////////////登陆日志
$(".loginDateChoseCrbOn div.pagers select").change(function() {
	loadrecord(1, $(".loginDateChoseCrbOn  div.pagers select").val());
	$("div.loginDateChoseCrbOn div.pagers input").val("");
})