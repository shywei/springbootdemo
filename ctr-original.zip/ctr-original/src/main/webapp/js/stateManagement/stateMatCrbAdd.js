//帐号管理 修改角色  添加帐号
var sys = Sys = parent.Sys, api = frameElement.api, data = api.data;
var dataT = data.id;
var refreshData = data.loadData;
var submitUrl = http + "fingerDriviceController/saveDrivice";
var getDataUrl = http + "userStateController/getUserDetailsById.do";
var depUrl = http + 'fingerDriviceController/deptList';

accView = {
    init: function () {
        this.initUI();
        this.loadData();
    },
    setValue: function () {
        //根据data里面的值来赋值
        Util.mappingValueToPage(data);
        $("#driviceState").val(data.driviceState)
        $("#driviceType").val(data.driviceType)
        $("#areaID").val(data.areaID)
    },
    loadData: function (parms) {
    	
    	Util.ajaxGet(depUrl, {}, function (d) {
	        if (!d) {
	            return;
	        }
	        var html = '';
	        $.each(d, function(i,v) {
				html += '<option value="'+v.deptid+'">'+v.deptName+'</option>';	        	
	        });
	        $("#areaID").html(html)
	    });
	    
        if (data.id <= 0) {//不需要加载数据
            return;
        }
        var e = this;
        
        Util.ajaxGet(getDataUrl, {mesID: data.id},
            function (d) {
                if (d.code != 0) {
                    return;
                }
                console.log(d)
                data = Util.getObj(d.obj, ["driviceName", "driviceState", "memoInfo", "driviceID", "ownerID", "areaID", "driviceType","workingStation"]);
                data.driviceState = d.obj.driviceState;
                data.driviceType = d.obj.driviceType;
                data.areaID = d.obj.areaID;
                e.setValue();
//driviceName 	设备名							需要
//driviceState	设备状况0正常1损坏2停用3备用		需要
//memoInfo	备注							     	需要
//driviceID	设备编号（非主键ID）					需要
//ownerID		持有人id							需要
//areaID		设备所归属的部门id				需要
//driviceType	设备类型0固定版1移动版			需要
//workingStation	工位编码						需要
            });
    },
    initUI: function () {
        var e = this;
        api.button({
            id: "ok",
            name: "确定",
            focus: true,
            callback: function () {
                e.save();
                return false;//不关闭窗口
            }
        }, {
            id: "cancel",
            name: "取消"
        });
    },
    save: function () {
        //保存数据
        data.driviceName = $("#driviceName").val();
        data.driviceState = $("#driviceState option:selected").val();
        data.memoInfo = $("#memoInfo").val();
        data.driviceID = $("#driviceID").val();
        data.ownerID = $("#ownerID").val();
        data.areaID = $("#areaID option:selected").val();
        data.driviceType = $("#driviceType").val();
        data.workingStation = $("#workingStation").val();
        data.id =  dataT;
        data.currentId = sessionStorage['sId'];
//      status		在线状态0在线1离线
//      id		设备的主键id（修改时需传给后端该参数）			
//		currentID 	当前登录用户的id
//driviceName 	设备名							需要
//driviceState	设备状况0正常1损坏2停用3备用		需要
//memoInfo	备注							     	需要
//driviceID	设备编号（非主键ID）					需要
//ownerID		持有人id							需要
//areaID		设备所归属的部门id				需要
//driviceType	设备类型0固定版1移动版			需要
//workingStation	工位编码						需要
        Util.ajaxPost(submitUrl, data, function (d) {
            if (d.code != 0) {
                parent.parent.Util.tips({type: 1, content: "数据提交失败！" + d.message});
                return;
            }
            refreshData();
      		api.close();
        });
    }
};
accView.init();






