 var getUserStateList=http+'userStateController/getUserStateList.do';//状态下拉框
 var getUserStateById=http + 'userStateController/getUserStateById.do';//状态更改弹窗里面状态信息
 var gridDataUrl=http+'userStateController/getRollCallUserInfo.do';//表格	

 var viewData={
 	inti:function(){
 		this.loadData();
 		this.showSateCon();
 		
 		
 		this.addEvent();
 	},
 	addEvent:function(){
 		
		var e = this;
 		//切换 列表和图片列表
		$("#tab").on("click",function(){
			$(".checked").removeClass("checked");
			$("#pic").removeClass("on");
			$(this).addClass("on");
			$(this).find("img").attr("src","../../img/tab1.png");
			$("#pic").find("img").attr("src","../../img/pic1.png");
			$(".pubTabelSty").fadeIn();
			$(".pubPicSty").hide();
			e.loadData(1);
		});
		
		//图片列表
		$("#pic").on("click",function(){
			$(".checked").removeClass("checked");
			$("#tab").removeClass("on")
			$(this).addClass("on");
			$(this).find("img").attr("src","../../img/pic2.png");
			$("#tab").find("img").attr("src","../../img/tab2.png");
			$(".pubPicSty").fadeIn();
			$(".pubTabelSty").hide();
			e.loadData(1);
		});
		
        //点击查询
        pubQ.picCheck();
        pubQ.tableCheck();
		$("#seach").on("click",function(){
			e.loadData(1);
		});
		//状态更改
		$("#stateModi").on("click",function(){
            e.showSateModi(0)
		});
		parent.$(".prompt .sp10").unbind("click").on("click",function(){
			e.modiTrue();
		});
		parent.$(".menu .sp11").unbind("click").on("click",function(){
			parent.$(".prompt").fadeOut();
			parent.$(".baohu").fadeOut();
		});
 	},
 	showSateCon:function(){//状态下拉框
 		pubQ.ajaxAuto(getUserStateList,{},function(d){
 			if( !d ){return;};
 			var d=JSON.parse(d);
 			var html="<option value=''>请选择</option>";
 			$.each(d,function(i,v){
 				html+=" <option value='"+v.stateid+"'>"+v.stateName+"</option>"
 			});
 			$("#stateid").html(html);
 		});
 	},
 	showSateModi:function(rollcalluserId){//弹窗
 		var e = this;
 		rollcalluserId = $(".checked").attr("data-value") || '0';
 		if(rollcalluserId==0){return pubQ.alertTrue("请选择","状态更改");};
 		if($(".checked").size()>1){return pubQ.alertTrue("只能选择一个","状态更改");};
 		
 		e.showDetails(rollcalluserId , true);
 		
 	},
 	showDetails:function(rollcalluserId,isOperation){//详情
// 		event.stopPropagation();
 		isOperation = isOperation||false;
 		$("#note").val('');
 		$("#noteCon").val('');
 		pubQ.getAjax(getUserStateById,{id:rollcalluserId},
 			function(d){
 				if( !d ){return;};
 				var d=JSON.parse(d);
 				console.log(d)
		 		var html='';
				var html01='';
				var htmlKey='';
	            for(var i=0;i<d.userStateList.length;i++){
	            	if(d.userStateList[i].isAttended!==0){
	            		html01+='<span> <i class="check '+(d.userStateList[i].isSelected=="0"?"":"checked")+' "><input type="text" value="'+d.userStateList[i].stateid+'" /></i><b>'+d.userStateList[i].stateName+'</b></span>';
	            		if( d.userStateList[i].stateName=="请假" ){
	            			
	            		}
	            	}else{
	                	html+='<span> <i class="check '+(d.userStateList[i].isSelected=="0"?"":"checked")+' "><input type="text" value="'+d.userStateList[i].stateid+'" /></i><b>'+d.userStateList[i].stateName+'</b></span>';
	               	}
	            };
	            var isKey=d.userStateInfo.isKey;
	            var note = note||"";
	            var noteCon = noteCon||"";
	            if(d.userStateInfo.stateid==2){
	            	note=d.userStateInfo.note||"";
	            }else if(d.userStateInfo.stateid>2){
	            	noteCon=d.userStateInfo.note||"";
	            }
	            parent.$(".prompt .promptBody .stateConIs01").html(html01+'<div class="leavNote leavNoteSty hide00"><b>请假备注 : </b><input type="text" id="leavNoteCon" value="'+note+'" /></div>');//参加出勤
	            if( d.userStateInfo.stateid!=2 ){
	            	parent.$(".stateConIs01").css("height", Math.ceil( parent.$(".stateConIs01 span").size()/3 ) * 30+"px");
	            }else{
	            	parent.$(".leavNote").fadeIn();
	            	parent.$(".stateConIs01").css("height", Math.ceil( parent.$(".stateConIs01 span").size()/3 ) * 30 + 44 +"px");
	            };
	
	            parent.$(".prompt .promptBody .stateConIs00").html(html+'<div class="leavNoteSty"><b>备注 : </b><input type="text" id="noteCon"  value="'+noteCon+'"/></div>');
	            if(isKey==0){
	            	htmlKey='<span> <i class="check"><input type="text" value="1" /></i><b>是</b></span><span> <i class="check checked"><input type="text" value="0" /></i><b>否</b></span>';
	            }else{
	            	htmlKey='<span> <i class="check checked"><input type="text" value="1" /></i><b>是</b></span><span> <i class="check "><input type="text" value="0" /></i><b>否</b></span>';
	            };
	            
	        	parent.$(".prompt .isKey").html(htmlKey);
	            parent.$(".prompt input").eq(0).val(" "+d.userStateInfo.id);
				parent.$("[name='sIdHidden']").val(d.userStateInfo.id);
				parent.$(".prompt input").eq(2).val(" "+d.userStateInfo.name);
				
				
				parent.$(".prompt").fadeIn();
				parent.$(".baohu").fadeIn();
				
				if(!isOperation){
					parent.$(".isOpe").show();
					parent.$(".condition .prompt>.smallkuang-header span").html('详情');
				}else{
					parent.$(".isOpe").hide();
					parent.$(".condition .prompt>.smallkuang-header span").html('修改状态');
				}
	       },function(d){
	       		alert("链接失败！请检查网络链接")
	       });
	       
// 		var data={};
//		$.dialog({
//			id: "isTrue",
//			width: 500,
//			height: 600,
//			title: '详情',
//			content: "url:" + httpUrl + "page/stateManagement/stateMatCrbAdd.html",
//			data: data,
//			max: false,
//			min: false,
//			lock: true,
//			ok: function() {
//	
//			}
//		});

 	},
 	modiTrue:function(){
 		var zhuangtai = $("div.changeview select.zhuangtai").val();
	 	var danwei = $("div.changeview select.team").val();
		var bian01 = parent.$("[name='sIdHidden']").val();
		var stateid='';
		var isKey='';
		stateid = parent.$(".state .checked").find("input").val();
		isKey = parent.$(".isKey .checked").find("input").val(); 
		var operationPersonnel=sessionStorage.sUid;
		var depCode=sessionStorage.sUserDept;
		var operationIP  =sessionStorage.logComIP;
		var statConIndex = stateid
		var note = stateid==2?parent.$("#leavNoteCon").val():parent.$("#noteCon").val();
		if( parent.$("#leavNoteCon").is(":visible") && parent.$("#leavNoteCon").val().length=='' ){
			return pubQ.alertTrue("请填写请假备注","请假备注");
		};
		console.log(statConIndex)
		console.log(parent.$(".stateConIs01 span").size())
		if( statConIndex > parent.$(".stateConIs01 span").size() && parent.$("#noteCon").val().length=='' ){
			return pubQ.alertTrue("请填写备注","备注");
		};
		
		$.ajax({
			url:http+'userStateController/saveUserState.do',
			type:'POST',
			datatype:'JSONP',
			jsonp:'callback',
			data:{
				id:bian01,//编号
				stateid:stateid,//选择的状态编号
				isKey:isKey,//是否是重点关注人群
				note:note,//备注
//					operationPersonnel:operationPersonnel,//谁更改这个状态
//					depCode:depCode,//大队编号
//					operationIP:operationIP//ip地址
			},
			success:function(callback){
				console.log(callback)
				if(callback/1>0){
					parent.$("div.condition div.prompt").fadeOut();
					parent.$("div.baohu").fadeOut();
					viewData.loadData();
				}
				
				
			}
		})
 	},
 	onErrorHandle:function(obj){  
		obj.src="../../img/moren.png";  
	},
 	loadData:function(num,selNum){
 		
		var data={};
		data.id = $("#id").val()||'';//人员编号 
		data.name = $("#name").val()||'';//人员姓名  
		data.stateid  = $("#stateid option:selected").val()||'';//当前状态
		data.code = sUserDept;
		
 		data.page=num||$(".ycolor").html()||1;//当前页码
		data.rows= selNum||$(".pubSel select option:selected").html()||10;//一共多少条数据	
 		viewData.intiGrid(data);
 		viewData.intiPic(data);
 	},
 	intiGrid:function(data){
 		$(".pubTabelSty").tableAuto({
			url: gridDataUrl,
            data: data,
            emptyMsg: '<img src="../../img/dataloss.png">',
            loadTr: function (data) {
                if(data.isKey==0){
					return "";                	
                };
                return "tRred";
            },
            pager:{
            	className:'.pubPageSty',
            	renderer:function(data){
            		//分页          	 	
					var dataAll={};
					dataAll.dataPage = parseInt(data.pag)/1; //dataPage 当前页码
					dataAll.dataCount= data.count; //dataCount 一共多少条数据
					dataAll.pageNum =data.row; //pageNum 一页多少数据
					dataAll.fun = viewData.loadData; //fun 方法名
					$(".pubPageSty").pageNumAuto(dataAll);
            	}
            },
            columns: [
                {
                    name: "rollcalluserId",
                    text: '<div class="check" data-value></div>',
                    width: "4%",
                    thAlign: "center",
                    align: "center",
                    renderer: function (row, val) {
                        var html = '<div class="check" data-value='+val+'></div>';
                        return html;
                    }
                },
                {
                    name: "rollcalluserId",
                    text: '人员编号',
                    width: "24%",
                    thAlign: "center",
                    align: "center"
                },
                {
                    name: "rollcalluserName",
                    text: '人员姓名',
                    width: "24%",
                    thAlign: "center",
                    align: "center"
                },
                {
                    name: "depName",
                    text: '人员单位',
                    width: "24%",
                    thAlign: "center",
                    align: "center"
                },
                {
                    name: "stataName",
                    text: '当前状态',
                    width: "24%",
                    thAlign: "center",
                    align: "center"
                }
            ]
		});
 	},
 	intiPic:function(data){
 		$(".pubPicSty").tableAuto({
			url: gridDataUrl,
            data: data,
            isImg:true ,
            emptyMsg: '<img src="../../img/dataloss.png">',
            loadPic: function (data) {
                if(data.isKey==0){
					return "picMask picMaskOn";                	
                };
                return "tRred picMask picMaskOn";
            },
            pager:{
            	className:'.pubPageSty',
            	renderer:function(data){
            		//分页          	 	
					var dataAll={};
					dataAll.dataPage = parseInt(data.pag)/1; //dataPage 当前页码
					dataAll.dataCount= data.count; //dataCount 一共多少条数据
					dataAll.pageNum =data.row; //pageNum 一页多少数据
					dataAll.fun = viewData.loadData; //fun 方法名
					$(".pubPageSty").pageNumAuto(dataAll);
            	}
            },
            columns: [
                {
                    name: "rollcalluserId",
                    text: '<div class="check" data-value></div>',
//                  width: "4%",
                    thAlign: "center",
                    align: "center",
                    className: "pubCheck",
                    renderer: function (row, val) {
                        var html = '<div class="check" data-value='+val+'></div>';
                        return html;
                    }
                },
                {
                    name: "photoUrl",
                    text: '',
//                  width: "24%",
                    thAlign: "center",
                    align: "center",
                    className: "pubUrl ",
                    renderer:function(row,val){
                    	val = val+"?time="+((Math.random()+"").substring(0,8));
                    	var html ='<img src="'+val+'" onerror="viewData.onErrorHandle(this)" />';
                    	return html;
                	}
            	},
                {
                    name: "rollcalluserId",
                    text: '人员编号',
//                  width: "24%",
                    thAlign: "center",
                    align: "center",
                    className: "pubNum pubConSty",
                    renderer:function(row,val){
                    	var html = '<span onclick="viewData.showDetails('+val+')">'+"编号 : " +val+'</span>';
                    	return html;
                	}
                },
                {
                    name: "rollcalluserName",
                    text: '人员姓名',
//                  width: "24%",
                    thAlign: "center",
                    align: "center",
                    className: "pubName pubConSty",
                    renderer:function(row,val){
                    	var html ='<span>'+"姓名 : "+val+'</span>';
                    	return html;
                	}
                }
                
                
            ]
		});
 	}
 };
 viewData.inti();