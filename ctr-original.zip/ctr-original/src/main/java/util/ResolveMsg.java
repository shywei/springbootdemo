package util;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.DatatypeConverter;

import com.jschange.ctr.model.FingerDrivice;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.UserInfo;
import com.jschange.ctr.service.VenaDigitalisService;

/*
 * 对socket发来的报文进行处理
 * @gaoxujian 2017/7/25 17:55
 * */
public class ResolveMsg {
	 //获取被Spring管理的VenaDigitalInfoService类
	private static VenaDigitalisService venaDigitalisService= (VenaDigitalisService) AutoWiredUtil.getBean("venaDigitalisService");
	private static ResultModel resultModel;
	//获取继电器配置文件中参数
	private static String relayIP = Env.getInstance().getProperty("relayIP");
	private static int relayRoad = Integer.parseInt(Env.getInstance().getProperty("relayRoad"));
	
	public static boolean resolve(Socket socket) throws Exception{
		try {
			//获取输入流数据
			InputStream is=socket.getInputStream();
			byte[] temp=null;
			try {
				//捕捉异常，超时返回false
				//read方法阻塞进程
				temp = StreamTool.readStream(is,socket);
			} catch (Exception e) {
				return false;
			}
            //调用逆转义方法，获取实际报文
            byte[] recv=QJCmdReceive.getMessage(temp);
            byte[] check=QJCmdReceive.checkCmd(recv);
           
            if((recv[1]&0xFF)==0x80){
            	switch(recv[2]){
            	//8001,设备请求登录
            	case 01:
            		System.err.println("设备登录请求成功");
            		Thread.sleep(1000);
            		
            		QJCmdSend.send(socket, 0x0001, check);
            		//获取设备指纹模块编码
            		String fingerCode=GetDriviceNo.getDriviceNo(recv);
            		SocketIDMap.setMap(socket, fingerCode);
            		//根据截取的终端ID查询终端信息
            		FingerDrivice drivice=venaDigitalisService.selectDriviceInfoByFingerCode(fingerCode);
	            	//如果终端信息存在，查询相关信息
            		//如果终端信息不存在，插入设备编号
            		if(drivice!=null){
            			venaDigitalisService.updateDriviceStatus(fingerCode);
            		}else{
            			venaDigitalisService.insertVenaInfo(fingerCode);            			
            		}	
	            	System.err.println("模块编码"+fingerCode);
	            	VenaMap.setMap(fingerCode, socket);
            		break;
            	//8002，设备心跳报文
            	case 02:
            		byte[] body={0x01};
            		Thread.sleep(1000);
            		QJCmdSend.send(socket, 0x0002, body);
            		break;
            	//8003,静脉采集
        		//解析报文数组下标位24的byte
        		//00为录入指静脉失败
        		//01为两次全部成功
        		//02为第一次采集成功
            	case 03:
            		int j=0;
            		byte[] body0={0x01};
            		byte[] finger=new byte[1072];
            		
            		if(recv[24]==0x00){
            			Thread.sleep(1000);
            			QJCmdSend.send(socket, 0x0003,body0 );
            			Thread.sleep(1000);
            			SocketMap.setMap(socket, "0");
            			System.err.println("采集失败");
            		}else if(recv[24]==0x02){
            			Thread.sleep(1000);
            			QJCmdSend.send(socket, 0x0003,body0 );
            			System.err.println("第一次采集成功");
            			SocketMap.setMap(socket, "2");
            		}
            		else if(recv[24]==0x01){
            			String userID="";
            			
            			//将报文中的指纹数据赋值给新的数组
            			for(int i=25;i<1097;i++,j++){
            				finger[j]=recv[i];
            			}
            			//获取用户ID
            			//将byte转化为String
            			for (int i = 22; i < 24; i++)
	                    {
	                        String hex = Integer.toHexString(recv[i] & 0xFF);
	                        if (hex.length() == 1)
	                        {
	                            hex = '0' + hex;
	                        }
	                        userID+=hex;
	                    }
            			//将获取到的16进制ID转为10进制
            			Integer keyId=Integer.parseInt(userID, 16);
            			VenaFingerMap.setFingerMap(keyId, finger);
            			byte[] test={0x01};
            			Thread.sleep(1000);
            			QJCmdSend.send(socket, 0x0003,test );
            			SocketMap.setMap(socket, "1");
            			System.err.println("第二次采集成功");
            		}
            		break;
            	//8004认证	
            	case 04:
            		System.err.println("8004认证");        			
        			//获取用户ID
        			//将byte转化为String
        			String userID="";
        			for (int i = 22; i < 24; i++){
                        String hex = Integer.toHexString(recv[i] & 0xFF);
                        if (hex.length() == 1){
                            hex = '0' + hex;
                        }
                        userID+=hex;
                    }
        			Integer keyId=Integer.parseInt(userID, 16);
            		System.err.println("指纹模块中的用户ID:"+keyId);
        			Thread.sleep(1000);
            		byte[] body4=QJCmdReceive.checkCmd(recv);
            		QJCmdSend.send(socket, 0x0004, body4);
            		//通过设备中读取的ID，查询人员相关信息
            		UserInfo user=venaDigitalisService.queryUserInfo(keyId);
            		if(user!=null){
	            		Map<String,Object> map=new HashMap<String,Object>();
	            		String userId=user.getUserid();
	            		String userName=user.getUserName();
	            		Integer deptid=user.getDeptid();
	            		//Integer deviceid=user.getFingerDeviceid();
	            		map.put("id", userId);
	            		map.put("userName", userName);
	            		map.put("deptid", deptid);
	            		//map.put("deviceid", deviceid);
	            		venaDigitalisService.insertRecord(map);
            		}else{
            			System.err.println("未获取人员信息");
            		}
            		//网络继电器门禁
            		//参数:1.继电器IP 2.继电器端口号 3.设备地址 4.继电器路数(0--7) 5.开关(1表示开,0表示关)
//            		ModbusUtil.writeDigitalOutput(relayIP,10000,254,relayRoad,1);
//            		Thread.sleep(10000);
//            		ModbusUtil.writeDigitalOutput(relayIP,10000,254,relayRoad,0);
            		break;
            	
            	//8010设备升级
            	case 16:
            		System.err.println("8010终端上报升级成功结果");
            		byte[] upgradebody={0x01};
            		Thread.sleep(1000);
            		QJCmdSend.send(socket, 0x0010, upgradebody);
            		break;
            	
            	default:
            		System.err.println("未知指令："+DatatypeConverter.printHexBinary(recv));
            		break;
            	}
            }else if((recv[1]&0xFF)==0x01){
            	switch(recv[2]){
            	
            	case 0x01:
            		System.err.println("录入指纹应答");
            		if(recv[20]==1){
            			System.err.println("成功");
            		}else if(recv[20]==0){
            			System.err.println("失败");
            		}
            		break;
            	case 0x02:
            		System.err.println("删除指纹应答");
            		if(recv[20]==1){
            			System.err.println("删除成功");
            			SocketMap.setMap(socket, "1");
            		}else if(recv[20]==0){
            			System.err.println("删除失败");
            			SocketMap.setMap(socket, "0");
            		}
            		break;
            	
            	case 0x03:
            		System.err.println("下发指纹数据应答");
            		if(recv[20]==1){
            			System.err.println("下发成功");
            			SocketMap.setMap(socket, "1");
            		}else if(recv[20]==0){
            			System.err.println("下发失败");
            			SocketMap.setMap(socket, "0");
            		}
            		break;
            		
            	case 0x04:
            		System.err.println("修改无线应答");
            		if(recv[20]==1){
            			System.err.println("修改成功");
            			SocketMap.setMap(socket, "3");
            		}else if(recv[20]==0){
            			System.err.println("修改失败");
            			SocketMap.setMap(socket, "4");
            		}
            		break;
            	
            	case 0x05:
            		System.err.println("修改有线应答");
            		if(recv[20]==1){
            			System.err.println("修改成功");
            			SocketMap.setMap(socket, "1");
            		}else if(recv[20]==0){
            			System.err.println("修改失败");
            			SocketMap.setMap(socket, "0");
            		}
            		break;
            		
            	case 0x07:
            		System.err.println("取消指纹录入应答");
            		if(recv[20]==0){
            			System.err.println("取消失败");
            		}else if(recv[20]==1){
            			System.err.println("取消成功");
            		}
            		break;
            		
            	case 0x08:
            		System.err.println("清空指纹应答");
            		if(recv[20]==0){
            			System.err.println("清空失败");
            			SocketMap.setMap(socket, "清空失败");
            		}else if(recv[20]==1){
            			System.err.println("清空成功");
            			SocketMap.setMap(socket, "清空成功");
            		}
            		break;
            	
            	case 0x09:
            		System.err.println("更新图片应答");
            		if(recv[20]==0){
            			System.err.println("更新图片失败");
            		}else if(recv[20]==1){
            			System.err.println("更新图片成功");
            		}
            		break;
            	
            	case 0x10:
            		System.err.println("升级应答");
            		if(recv[20]==0){
            			System.err.println("接收失败");
            		}else if(recv[20]==1){
            			System.err.println("接收成功");
            		}else if(recv[20]==2){
            			System.err.println("升级数据校验失败");
            		}else if(recv[20]==3){
            			System.err.println("升级数据校验成功（开始升级）");
            		}else if(recv[20]==4){
            			System.err.println("超级块未初始化");
            		}else if(recv[20]==5){
            			System.err.println("取消升级");
            		}
            		break;
            	}
            }
		} catch (IOException e) {
			e.printStackTrace();
		}
		return true;
	}

	public static Map<String,Object> queryDriviceInfo(String fingerCode) {
		Map<String,Object> map=new HashMap<String,Object>();
		//根据截取的终端ID查询终端信息
		FingerDrivice drivice=venaDigitalisService.selectDriviceInfoByFingerCode(fingerCode);
    	//设备ID
    	Integer id=drivice.getId();
    	map.put("driviceID", id);
		//设备对应的服务器ID
		Integer serviceID=drivice.getServiceID();
		map.put("serviceID", serviceID);
		//设备对应的无线ID
		Integer wifiID=drivice.getWifiID();
		map.put("wifiID", wifiID);

		return map;
	}
}
