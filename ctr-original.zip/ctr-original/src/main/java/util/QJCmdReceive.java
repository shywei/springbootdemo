package util;
/*
 * 对终端发来的报文进行转义和校验
 * @gaoxujian 2017/7/25 16:22
 * */
public class QJCmdReceive {
	//对终端发来的报文转义
	public static byte[] getMessage(byte[] cmd){
		int j=0;
		byte[] chg=new byte[cmd.length];
		for(int tmp=0; tmp<cmd.length;){
			if(cmd[tmp]==0x7D&&cmd[tmp+1]==0x02){
				chg[j++]=0x7E;
				tmp+=2;
			}else if(cmd[tmp]==0x7D&&cmd[tmp+1]==0x01){
				chg[j++]=0x7D;
				tmp+=2;
			}else{
				chg[j++]=cmd[tmp++];
			}
		}
		byte[] msg=new byte[j];
		System.arraycopy(chg, 0, msg, 0, j);
		return msg;
	}
	//对终端发来的报文中的校验码进行校验
	public static byte[] checkCmd(byte[] msg){
		byte checkBit=0;
		for(int i=1;i<msg.length-2;++i){
			checkBit ^= msg[i];
		}
		if(checkBit==msg[msg.length-2]){
			byte[] body={0x01};
			return body;
		}else{
			byte[] body={0x00};
			return body;
		}
	}
}
