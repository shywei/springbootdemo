package util;
/*
 * 获取设备编号
 * @gaoxujian 2017/7/26 09:06
 * */
public class GetDriviceNo {

	public static String getDriviceNo(byte[] recv) {
		// TODO Auto-generated method stub
		byte[] check=QJCmdReceive.checkCmd(recv);
        int checkNum=check[0];
      	byte[] key=new byte[15]; 
  		int a=0;
  		for(int m=5;m<20;m++,a++){
  			key[a]=recv[m];
  		}
  		//获取终端ID
  		String mesID="";
  		for (int i = 0; i < key.length; i++)
          {
              String hex = Integer.toHexString(key[i] & 0xFF);
              if (hex.length() == 1)
              {
                  hex = '0' + hex;
              }
              mesID+=hex;
          }
		return mesID;
	}

}
