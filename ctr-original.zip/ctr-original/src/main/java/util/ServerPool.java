package util;
import java.io.IOException;  
import java.net.ServerSocket;  
import java.net.Socket;
import util.ServerThread;
/*
 * 线程池
 * 最大连接数量100
 * @gaoxujian 2017/7/25 16:24
 * */
  
 
public class ServerPool { 
    private static final int THREADPOOLSIZE = 100;  
    private static String port = Env.getInstance().getProperty("fingerDrivicePort");//从配置文件里获取设备端口号
    public static void treadPool() throws IOException{  
   
        final ServerSocket server = new ServerSocket(Integer.parseInt(port));  
          
        for(int i=0;i<THREADPOOLSIZE;i++){  
            Thread thread = new Thread(){  
                public void run(){  
                    while(true){  
                            try {
								Socket client = server.accept();
								System.err.println("与socket连接成功！正在请求登录中...");
								ServerThread serverThread=new ServerThread(client);  
								serverThread.execute(client);
							} catch (ClassNotFoundException e) {
								e.printStackTrace();
							} catch (IOException e) {
								e.printStackTrace();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}  
                    }   
                }  
            };  
            thread.start(); 
        }  
    } 
}  
