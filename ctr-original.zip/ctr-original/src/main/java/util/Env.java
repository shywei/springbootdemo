package util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Env extends Properties{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static Env env = null;
	
	private Env(){
		InputStream is = getClass().getResourceAsStream("/jdbc.properties");
		try {
			load(is);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static synchronized Env getInstance(){
		if(env==null){
			env = new Env();
		}
		return env;
	}
}
