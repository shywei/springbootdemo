package util;

import java.util.ResourceBundle;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;


public class RedisUtil {
	
	private static JedisPool pool;
	private static Jedis jedis;
	
	public static JedisPool getPool() {
		return pool;
	}

	public static void setPool(JedisPool pool) {
		RedisUtil.pool = pool;
	}

	public static Jedis getJedis() {
		
		jedis = pool.getResource();
//		System.err.println(jedis);
//		jedis.auth(bundle.getString("redis.passWord"));
		return jedis;
	}

	public static void setJedis(Jedis jedis) {
		RedisUtil.jedis = jedis;
	}

	static {
		ResourceBundle bundle = ResourceBundle.getBundle("redis");
		if (bundle == null) {
		throw new IllegalArgumentException(
		"[redis.properties] is not found!");
		}
		JedisPoolConfig config = new JedisPoolConfig();
		config.setMaxIdle(Integer.valueOf(bundle
		.getString("redis.pool.maxActive")));
		config.setMaxIdle(Integer.valueOf(bundle
		.getString("redis.pool.maxIdle")));
		config.setMaxWaitMillis(Long.valueOf(bundle.getString("redis.pool.maxWait")));
		config.setTestOnBorrow(Boolean.valueOf(bundle
		.getString("redis.pool.testOnBorrow")));
		config.setTestOnReturn(Boolean.valueOf(bundle
		.getString("redis.pool.testOnReturn")));
		System.err.println(bundle.getString("redis.ip"));
		pool = new JedisPool(config, bundle.getString("redis.ip"),
		Integer.valueOf(bundle.getString("redis.port")),3000,bundle.getString("redis.passWord"));
		System.err.println(bundle.getString("redis.port"));
	}
	

}
