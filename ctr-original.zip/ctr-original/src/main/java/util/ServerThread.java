package util;

import java.net.Socket;
import util.ResolveMsg;

/*
 * 对客户端socket的设置
 * @gaoxujian 2017/7/25 16:30
 * */

public class ServerThread implements Runnable {

	
	private Socket socket = null;
	public ServerThread(Socket socket) {
		this.socket = socket;
	}

	public  void execute(Socket socket) throws Exception{
		boolean flag=true;
		//设置socket连接超时时间为60s
		socket.setSoTimeout(60000);
		while(flag){
			flag=ResolveMsg.resolve(socket);
		}
	}

	public void run() {
		try {
			execute(socket);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

