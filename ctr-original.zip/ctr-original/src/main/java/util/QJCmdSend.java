package util;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
/*
 * 给终端返回报文
 * @gaoxujian 2017/7/25 16:23
 * */

public class QJCmdSend {
	public static void send(Socket socket,int msgID,byte[] body) throws IOException{
		OutputStream os=socket.getOutputStream();
		os.write(QJCmdMaker.GetCmd(msgID, body));
	}
}
