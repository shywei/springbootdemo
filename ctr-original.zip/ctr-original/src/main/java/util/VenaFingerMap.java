package util;

import java.util.HashMap;
import java.util.Map;
/*
 * 将用户ID做为key，指纹数据做为value出入map集合中
 * @gaoxujian 2017/7/25 17:10
 * */
public class VenaFingerMap {
	public static Map<Integer, byte[]> fingerMap=new HashMap<Integer, byte[]>();
	public static void setFingerMap(Integer key,byte[] value){
		fingerMap.put(key, value);
	}
}
