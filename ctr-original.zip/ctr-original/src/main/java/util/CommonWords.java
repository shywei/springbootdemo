package util;

public class CommonWords {
	public static final String operatorSuccess= "操作成功";
	public static final String operatorFail= "操作失败";
	public static final String operatorError= "终端异常";
	public static final String timeSynchronization= "时间同步";
	public static final String restartDevice= "远程重启";
	public static final String updateDevice= "终端修改";
	public static final String connectFail="无法连接服务器";
	public static final String recoverFail="恢复人员失败";
	public static final String recoverSuccess="恢复人员成功";
	public static final String recoverError="恢复人员异常";
	public static final String paramError="参数错误";
	public static final String USBnotfound="未插入加密狗";
	public static final String USBerror="未插入加密狗";
}
