package util;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
/**
 * 获取被Spring管理类的工具类
 * @gaoxujian 2017/7/25 16:58
 *
 */
public final class AutoWiredUtil implements ApplicationContextAware{
	private static ApplicationContext applicationContext=null;
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		if(AutoWiredUtil.applicationContext==null){
			AutoWiredUtil.applicationContext=applicationContext;
		}
	}
	public static ApplicationContext getApplicationContext(){
		return applicationContext;
	}
	public static Object getBean(String name){
		return getApplicationContext().getBean(name);
	}
}