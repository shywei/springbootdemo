package util;

import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
/*
 * 记录每个登录上来的socket和对应的设备编号,方便调用
 * @gaoxujian 2017/7/31 10:50
 * */
public class SocketIDMap {
	public static Map<Socket, String> socketMap=new HashMap<Socket, String>();
	public static void setMap(Socket socket,String fingerCode){
		socketMap.put(socket, fingerCode);	
	}
}
