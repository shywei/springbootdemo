package util;
/*
 * 报文信息的封装方法
 * 给终端发送报文时，需要封装信息
 * @gaoxujian 2017/7/25 16:20
 * */
public class QJCmdMaker {
	private static final int T808_MAX_CMD_LEN = 2048;
	//public static byte[] Cmd;
    //封装消息方法
	public static byte[] GetCmd(int msgID, byte[] body) {
		byte[] TxBuf = new byte[T808_MAX_CMD_LEN];
		int i=0, j=0;
		byte checkBit=0;
		Integer iO;
		
		/* 判断长度 */
		if(body.length >= T808_MAX_CMD_LEN - 12){
			return null;
		}
		
		/*1. 封装消息ID*/
		iO = msgID>>8;
		TxBuf[i++] = iO.byteValue();
		iO = msgID&0xff;
		TxBuf[i++] = iO.byteValue();
                                            
		/*2. 封装消息体属性 */
		iO = body.length>>8;
		//TxBuf[i++] = isMultiPack|encrypt|iO.byteValue();
		TxBuf[i++] = iO.byteValue();
		iO = body.length&0xff;
		TxBuf[i++] = iO.byteValue();

		/*3. 封装终端ID */
		for(int tmp=0; tmp<15; ++tmp){
			TxBuf[i++] = 0x00;
		}

		

		/*5. 封装消息体 */
		for(int n=0; n<body.length; i++, n++){
			TxBuf[i] = body[n];
		}

		/*6. 封装校验位 */
		for(int tmp=0; tmp<i; ++tmp){
			checkBit ^= TxBuf[tmp];
		}
		TxBuf[i++] = checkBit;
		
		/*7.1 发送首位7E */
		byte[] Cmd = new byte[T808_MAX_CMD_LEN];
		Cmd[j++] = 0x7E;

		/*7.2 转义 */
		for(int tmp=0; tmp<i; ++tmp){
			if(TxBuf[tmp] == 0x7E){
				Cmd[j++] = 0x7D;
				Cmd[j++] = 0x02;
			}
			else if(TxBuf[tmp] == 0x7D){
				Cmd[j++] = 0x7D;
				Cmd[j++] = 0x01;
			}
			else{
				Cmd[j++] = TxBuf[tmp];
			}
			
			/* 判断长度 */
			if(j >= T808_MAX_CMD_LEN-2){
				return null;
			}
		}
		

		/*7.3 发送末位7E */
		Cmd[j++] = 0x7E;
		
		
		/* 判断长度 */
		if(j >= T808_MAX_CMD_LEN){
			return null;
		}
		
		byte[] Ret = new byte[j];
		System.arraycopy(Cmd, 0, Ret, 0, j);
		
		return Ret;
	}
}
