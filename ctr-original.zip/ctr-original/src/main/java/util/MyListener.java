package util;


import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import util.ServerPool;

import java.io.IOException;
import util.ServerPool;
/*
 * 启动设备线程池
 * @gaoxujian 2017/7/25 16:12
 * */

public class MyListener implements ServletContextListener {
    private ServerPool serverPool;

    public void contextDestroyed(ServletContextEvent e) {

    }

    public void contextInitialized(ServletContextEvent e) {
        try {
            serverPool.treadPool();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }
}