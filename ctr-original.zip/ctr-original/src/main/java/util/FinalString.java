package util;
/*
 * 设备端口号
 * @gaoxujian 2017/7/25 17:02
 * */
public class FinalString {

	public static final String PORT=Env.getInstance().getProperty("fingerDrivicePort");;
	
}
