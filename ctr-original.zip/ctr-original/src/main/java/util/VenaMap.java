package util;

import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
/*
 * 根据指静脉模块ID存储对应的Socket连接
 * @gaoxujian 2017/7/25 16:47
 * */
public class VenaMap {
	public static Map<String, Socket> venaMap=new HashMap<String, Socket>();
	public static void setMap(String fingerCode,Socket socket){
		venaMap.put(fingerCode, socket);
	}
}
