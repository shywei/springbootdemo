package util;

import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
/*
 * socket做为key,返回值做为value,方便controller层获取数据
 * @gaoxujian 2017/7/25 16:50
 * */
public class SocketMap {
	public static Map<Socket, String> socketMap=new HashMap<Socket, String>();
	public static void setMap(Socket socket,String resp){
		socketMap.put(socket, resp);	
	}
}
