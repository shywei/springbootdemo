package util;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.Socket;
import java.util.Map;

import com.jschange.ctr.service.VenaDigitalisService;
/*
 * 获取输入流字节
 * 判断设备是否离线，设备超过30秒没有发送任何信息，为离线
 * @gaoxujian 2017/7/25 16:38
 * */
public class StreamTool {
	private static VenaDigitalisService venaDigitalisService= (VenaDigitalisService) AutoWiredUtil.getBean("venaDigitalisService");
	
	public static byte[] readStream(InputStream is,Socket socket) throws Exception {  
		int count = 0;  
		long startTime=System.currentTimeMillis();
	    while (count == 0) {  
	        count = is.available();
	        long endTime=System.currentTimeMillis();
	        if(endTime-startTime>30000){
	        		socket.close();
	        	}
	        } 
	    byte[] b = new byte[count];  
	    is.read(b);  
	    return b; 
	} 
}
