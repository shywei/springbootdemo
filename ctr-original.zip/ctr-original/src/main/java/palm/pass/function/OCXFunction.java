package palm.pass.function;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

public class OCXFunction {

	public static final int PVS_INITCTRL_SUCCESS = 1;
	
	
	/*
	 * 通过OCX控件获取采集数据 ， 用于识别
	 * 
	 * */
	public byte[] getCaptureDataByOCX() {

		
		ActiveXComponent activeX;
		Dispatch dispath;

		activeX = new ActiveXComponent(
				"clsid:372969D6-CB4D-4228-A191-556B5205E75A");
		dispath = activeX.getObject();
		
		/*初始化传感器*/
		Variant loginVar = Dispatch.call(dispath, "Pvs_InitCtrl");
		if (PVS_INITCTRL_SUCCESS == loginVar.getInt())
		{
			System.out.println("Init Success\n");
		}
		else {
			
			System.out.println("Init Fail\n");
			
			return null;
		}
		
		/*执行采集*/
		loginVar = Dispatch.call(dispath, "Pvs_LoadLoginDialog");
		if (PVS_INITCTRL_SUCCESS == loginVar.getInt())
		{
			System.out.println("Capture Success\n");
		}
		else {
			
			/*关闭传感器*/
			Dispatch.call(dispath, "Pvs_CloseSensor");
			
			System.out.println("Capture Failure\n");
			
			return null;
		}
		
		/*获取采集数据*/
		loginVar = Dispatch.call(dispath, "Pvs_GetCaptureVeinData");
		String s = loginVar.getString();
		
		/*解码采集数据*/
		byte[] captureData = org.apache.commons.codec.binary.Base64.decodeBase64(s.getBytes()); 
		
		System.out.println("Capture len : " + captureData.length);

		
	    /*关闭传感器*/
	    Dispatch.call(dispath, "Pvs_CloseSensor");
	    
	    return captureData;
	}
	
	/*
	 * 	通过OCX控件获取注册掌静脉数据， 用于用户注册
	 * 
	 * */
	public byte[] getEnrollDataByOCX() {
		
		ActiveXComponent activeX;
		Dispatch dispath;

		activeX = new ActiveXComponent(
				"clsid:372969D6-CB4D-4228-A191-556B5205E75A");
		dispath = activeX.getObject();
		
		/*初始化传感器*/
		Variant loginVar = Dispatch.call(dispath, "Pvs_InitCtrl");
		if (PVS_INITCTRL_SUCCESS == loginVar.getInt())
		{
			System.out.println("Init Success\n");
		}
		else {
			
			System.out.println("Init Fail\n");
			
			return null;
		}
		
		/*执行注册*/
		loginVar = Dispatch.call(dispath, "Pvs_EnrollSingleHand");
		if (PVS_INITCTRL_SUCCESS == loginVar.getInt())
		{
			System.out.println("Enroll Success\n");
		}
		else {
			
			/*关闭传感器*/
			Dispatch.call(dispath, "Pvs_CloseSensor");
			
			System.out.println("Enroll Failure\n");
			
			
			return null;
		}
	
		/*获取注册数据*/
		loginVar = Dispatch.call(dispath, "Pvs_GetEnrollVeinData");
		String s = loginVar.getString();


		/*解码注册数据*/
		byte[] veinData = org.apache.commons.codec.binary.Base64.decodeBase64(s.getBytes()); 
		
		System.out.println("veinData len : " + veinData.length);
		
		
		/*关闭传感器*/
		Dispatch.call(dispath, "Pvs_CloseSensor");
		
		return veinData;
	}
}
