package palm.pass.function;

import palmpass.client.DeviceInfo;
import palmpass.client.DeviceMac;
import palmpass.client.GateInfo;
import palmpass.client.TerminalSocketFunction;

public class TerminalFlowFunction {

	
	/*
	 * 添加终端
	 * @parameter:	remoteIP : remote terminal IP address 
	 * 				port: socket port
	 * 				confirmNum: terminal number
	 * 				confirmType:  terminal type
	 * 				confirmModel: terminal model
	 * 				confirmPasswd: connect password
	 * 				webIP : web IP
	 * 
	 *  @return DeviceMac.result [int]
	 * 		0 = function success
	 * 		1 = function failure
	 * 		2 = error terminal number
	 * 		3 = error type or error model 
	 *  	4 = error password
	 * 		5 = connect web error
	 * 		
	 *  @return DeviceMac.mac [string]
	 * 			null = add terminal fail
	 * 			other = terminal mac
	 * 
	 * */
	public DeviceMac AddNewTerminal(String remoteIP,
								int port , 
								long confirmNum, 
								int confirmType,
								int confirmModel, 
								byte[] confirmPasswd , 
								String webIP)
	{
		
		TerminalSocketFunction function = new TerminalSocketFunction();
		
		DeviceMac ret = function.addDevice(remoteIP, port, confirmNum, confirmType, confirmModel, confirmPasswd, webIP);
			
		return ret;
	}
	

	/*
	 * 远程开门
	 * @parameter:	remoteIP : remote terminal IP address 
	 * 				port: socket port
	 * 				confirmNum: terminal number
	 * 				confirmType:  terminal type
	 * 				confirmModel: terminal model
	 * 				confirmPasswd: connect password
	 * 				
	 * 
	 *  @return 
	 * 		0 = function success
	 * 		1 = function failure
	 * 		2 = error terminal number
	 * 		3 = error type or error model 
	 *  	4 = error password
	 * 		5 = connect web error
	 * 		
	 * 
	 * */
	public int RemoteOpenDoor(String remoteIP,
			int port , 
			long confirmNum, 
			int confirmType,
			int confirmModel, 
			byte[] confirmPasswd )
	{
		int ret = 0;
		TerminalSocketFunction function = new TerminalSocketFunction();
		
		ret = function.remoteOpenDoor(remoteIP, port, confirmNum, confirmType, confirmModel, confirmPasswd);
		
		return ret;
	}
	
	

	/*
	 * 管理员下发
	 * @parameter:	remoteIP : remote terminal IP address 
	 * 				port: socket port
	 * 				confirmNum: terminal number
	 * 				confirmType:  terminal type
	 * 				confirmModel: terminal model
	 * 				confirmPasswd: connect password
	 * 				totalNum: total administrator hands number
	 * 				adminID: administrator user id,
	 * 						  all administrator's ID format 30*totalNum bytes
	 * 				openDoorID: administrator open door ID
	 * 						   openDoorID format 10*totalNum bytes
	 * 				veinData: administrator enroll vein data
	 * 							veinData format 15000 * totalNum bytes
	 *  @return 
	 * 		0 = function success
	 * 		1 = function failure
	 * 		2 = error terminal number
	 * 		3 = error type or error model 
	 *  	4 = error password
	 * 		5 = connect web error
	 * 		
	 * 
	 * */
	public int adminDownLoad(String remoteIP, int port, long confirmNum,
			int confirmType, int confirmModel, byte[] confirmPasswd,
			int totalNum, byte[] adminID, byte[] openDoorID, byte[] veinData)
	{
		
		int ret = 0;
		TerminalSocketFunction function = new TerminalSocketFunction();
		
		ret = function.adminDataDownload(remoteIP, port, confirmNum, confirmType, confirmModel, confirmPasswd, totalNum, adminID, openDoorID, veinData);
		
		
		return ret;
		
	}
	
	/*
	 * 获取终端连接状态
	 * @parameter:	remoteIP : remote terminal IP address 
	 * 				port: socket port
	 * 				confirmNum: terminal number
	 * 				confirmType:  terminal type
	 * 				confirmModel: terminal model
	 * 				confirmPasswd: connect password
	 * 
	 *  @return 
	 * 		0 = function success
	 * 		1 = function failure
	 * 		2 = error terminal number
	 * 		3 = error type or error model 
	 *  	4 = error password
	 * 		5 = connect web error
	 * 		
	 * 
	 * */
	public int GetTerminalStatus(String remoteIP,
			int port , 
			long confirmNum, 
			int confirmType,
			int confirmModel, 
			byte[] confirmPasswd )
	{
		int ret = 0;
		TerminalSocketFunction function = new TerminalSocketFunction();
		
		ret = function.detectDeviceState(remoteIP, port, confirmNum, confirmType, confirmModel, confirmPasswd);
		
		
		return ret;
	}
	
	/*
	 * 远程重启终端
	 * @parameter:	remoteIP : remote terminal IP address 
	 * 				port: socket port
	 * 				confirmNum: terminal number
	 * 				confirmType:  terminal type
	 * 				confirmModel: terminal model
	 * 				confirmPasswd: connect password
	 * 
	 *  @return 
	 * 		0 = function success
	 * 		1 = function failure
	 * 		2 = error terminal number
	 * 		3 = error type or error model 
	 *  	4 = error password
	 * 		5 = connect web error
	 * 		
	 * 
	 * */
	public int RemoteReboot(String remoteIP,
			int port , 
			long confirmNum, 
			int confirmType,
			int confirmModel, 
			byte[] confirmPasswd )
	{
		int ret = 0;
		TerminalSocketFunction function = new TerminalSocketFunction();
		
		ret = function.restartDevice(remoteIP, port, confirmNum, confirmType, confirmModel, confirmPasswd);
		
		
		return ret;
	}
	
	/*
	 * 终端时间同步
	 * @parameter:	remoteIP : remote terminal IP address 
	 * 				port: socket port
	 * 				confirmNum: terminal number
	 * 				confirmType:  terminal type
	 * 				confirmModel: terminal model
	 * 				confirmPasswd: connect password
	 * 				timeStamp: synchronize time ,
	 *							format:%YEAR%MONTH%DAY%HOUR%MINUTE%SECOND
	 *            					[4][2][2][2][2][2] 
	 *  @return 
	 * 		0 = function success
	 * 		1 = function failure
	 * 		2 = error terminal number
	 * 		3 = error type or error model 
	 *  	4 = error password
	 * 		5 = connect web error
	 * 		
	 * 
	 * */
	public int SyncTime(String remoteIP,
			int port , 
			long confirmNum, 
			int confirmType,
			int confirmModel, 
			byte[] confirmPasswd,
			byte[] timeStamp)
	{
		int ret = 0;
		TerminalSocketFunction function = new TerminalSocketFunction();
		
		ret = function.syncTime(remoteIP, port, confirmNum, confirmType, confirmModel, confirmPasswd,timeStamp);
		
		
		return ret;
	}
	
	
	/*
	 * 终端重新初始化
	 * @parameter:	remoteIP : remote terminal IP address 
	 * 				port: socket port
	 * 				confirmNum: terminal number
	 * 				confirmType:  terminal type
	 * 				confirmModel: terminal model
	 * 				confirmPasswd: connect password
	 *  @return 
	 * 		0 = function success
	 * 		1 = function failure
	 * 		2 = error terminal number
	 * 		3 = error type or error model 
	 *  	4 = error password
	 * 		5 = connect web error
	 * 		
	 * 
	 * */
	public int SystemInitial(String remoteIP,
			int port , 
			long confirmNum, 
			int confirmType,
			int confirmModel, 
			byte[] confirmPasswd )
	{
		int ret = 0;
		TerminalSocketFunction function = new TerminalSocketFunction();
		
		ret = function.restoreDefaultConfig(remoteIP, port, confirmNum, confirmType, confirmModel, confirmPasswd);
		
		return ret;
	}
	
	
	
	/*
	 * 获取终端信息
	 * @parameter:	remoteIP : remote terminal IP address 
	 * 				port: socket port
	 * 				confirmNum: terminal number
	 * 				confirmType:  terminal type
	 * 				confirmModel: terminal model
	 * 				confirmPasswd: connect password
	 * 				webIP : web IP
	 * 
	 *  @return DeviceInfo.result [int]
	 * 		0 = function success
	 * 		1 = function failure
	 * 		2 = error terminal number
	 * 		3 = error type or error model 
	 *  	4 = error password
	 * 		5 = connect web error
	 * 		
	 *  @return DeviceInfo.version [string]
	 * 			null = get information fail
	 * 			other = version
	 * 
	 *  @return DeviceInfo.adminNum [int]
	 *					   administrator hands number
	 * */
	public DeviceInfo GetTerminalInfo(String remoteIP,
			int port , 
			long confirmNum, 
			int confirmType,
			int confirmModel, 
			byte[] confirmPasswd )
	{
		
		TerminalSocketFunction function = new TerminalSocketFunction();
		
		DeviceInfo info = function.showDeviceInfo(remoteIP, port, confirmNum, confirmType, confirmModel, confirmPasswd);
		
		return info;
	}
	
	
	/*
	 * 设置终端门禁信息
	 * @parameter:	remoteIP : remote terminal IP address 
	 * 				port: socket port
	 * 				confirmNum: terminal number
	 * 				confirmType:  terminal type
	 * 				confirmModel: terminal model
	 * 				confirmPasswd: connect password
	 * 				doorSignal: 0 -- wiegand26 
	 * 							1 -- wiegand34
	 * 							2 -- electric 
	 * 							3 -- no 
	 * 				time : lock time
	 * 				magAlarm: Door contact alarm switch
	 * 				magAlarmTime : Door contact delay
	 * 				durAlarm : duress alarm switch
	 * 				tamperAlarm : tamper alarm switch 
	 * 				inputSignal : alarm signal 
	 * 							0 -- local
	 * 							1 -- extern
	 * 							2 -- local & extern
	 * 						
	 * 				sound: 		sound value
	 * 				sleep : 	sleep time
	 * 
	 * 				light:		light value
	 * 
	 * 
	 *  @return
	 * 		0 = function success
	 * 		1 = function failure
	 * 		2 = error terminal number
	 * 		3 = error type or error model 
	 *  	4 = error password
	 * 		5 = connect web error
	 * */
	public int SetGateInfo(String remoteIP, int port, long confirmNum,
			int confirmType, int confirmModel, byte[] confirmPasswd,
			int doorSignal, int time, int magAlarm, int magAlarmTime,
			int durAlarm, int tamperAlarm, int inputSignal, int alarmTime,
			int sound, int sleep, int light)
	{
		int ret = 0;
		TerminalSocketFunction function = new TerminalSocketFunction();
		
		ret = function.configGateInfo(remoteIP, port, confirmNum, confirmType, confirmModel, confirmPasswd, doorSignal, time, magAlarm, magAlarmTime, durAlarm, tamperAlarm, inputSignal, alarmTime, sound, sleep, light);
				
		return ret;
	}
	
	/*
	 * 获取终端门禁信息
	 * @parameter:	remoteIP : remote terminal IP address 
	 * 				port: socket port
	 * 				confirmNum: terminal number
	 * 				confirmType:  terminal type
	 * 				confirmModel: terminal model
	 * 				confirmPasswd: connect password
	 * 
	 * 
	 *  @return GateInfo.result
	 * 		0 = function success
	 * 		1 = function failure
	 * 		2 = error terminal number
	 * 		3 = error type or error model 
	 *  	4 = error password
	 * 		5 = connect web error
	 * 
	 * 	 * 	doorSignal: 0 -- wiegand26 
	 * 					1 -- wiegand34
	 * 					2 -- electric 
	 * 					3 -- no 
	 * 				time : lock time
	 * 				magAlarm: Door contact alarm switch
	 * 				magAlarmTime : Door contact delay
	 * 				durAlarm : duress alarm switch
	 * 				tamperAlarm : tamper alarm switch 
	 * 				inputSignal : alarm signal 
	 * 							0 -- local
	 * 							1 -- extern
	 * 							2 -- local & extern
	 * 						
	 * 				sound: 		sound value
	 * 				sleep : 	sleep time
	 * 
	 * 				light:		light value
	 * */
	public GateInfo GetGateInfo(String remoteIP,
			int port , 
			long confirmNum, 
			int confirmType,
			int confirmModel, 
			byte[] confirmPasswd )
	{
		
		TerminalSocketFunction function = new TerminalSocketFunction();
		
		GateInfo info = function.showGateInfo(remoteIP, port, confirmNum, confirmType, confirmModel, confirmPasswd);
		
		return info;
	}
	
	
	/*
	 * 设置终端信息
	 * @parameter:	remoteIP : remote terminal IP address 
	 * 				port: socket port
	 * 				confirmNum: terminal number
	 * 				confirmType:  terminal type
	 * 				confirmModel: terminal model
	 * 				confirmPasswd: connect password
	 * 				newNum : new Terminal number
	 * 				newIP:	 new Terminal IP address
	 * 				newMask: new Terminal mask
	 * 				newGate : new Terminal gate way
	 * 				newPort : new socket port
	 * 				newPasswd : new connect password
	 * 				webIP : web IP
	 *  @return
	 * 		0 = function success
	 * 		1 = function failure
	 * 		2 = error terminal number
	 * 		3 = error type or error model 
	 *  	4 = error password
	 * 		5 = connect web error
	 * */

	public int SetTerminalConfig(String remoteIP, int port, long confirmNum,
			int confirmType, int confirmModel, byte[] confirmPasswd,
			long newNum,  String newIP, String newMask,
			String newGate, int newPort, byte[] newPasswd, String webIP) 
	{
		int ret = 0;
		
		TerminalSocketFunction function = new TerminalSocketFunction();
		ret = function.configBaseInfo(remoteIP, port, confirmNum, confirmType, confirmModel, confirmPasswd, newNum,  newIP, newMask, newGate, newPort, newPasswd, webIP);
		
		return ret ;
	}

	
	/*
	 * 终端远程升级
	 * @parameter:	remoteIP : remote terminal IP address 
	 * 				port: socket port
	 * 				confirmNum: terminal number
	 * 				confirmType:  terminal type
	 * 				confirmModel: terminal model
	 * 				confirmPasswd: connect password
	 *				fileLen : upgrade file length
	 * 				fileData : read from upgrade file
	 *  @return
	 * 		0 = function success
	 * 		1 = function failure
	 * 		2 = error terminal number
	 * 		3 = error type or error model 
	 *  	4 = error password
	 * 		5 = connect web error
	 * */
	public int deviceUpgrade(String remoteIP, int port, long confirmNum,
			int confirmType, int confirmModel, byte[] confirmPasswd,
			long fileLen, byte[] fileData)
	{
		int ret = new TerminalSocketFunction().deviceUpgrade(remoteIP, port, confirmNum, confirmType, confirmModel, confirmPasswd, fileLen, fileData);
		
		return ret;
	}
}
