package palm.pass.ui;



import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import palm.pass.function.ServerFlowFunction;



public class GetStateDlg extends JDialog implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5494011117562363465L;

	public static GetStateDlg dlg;
	
	public String title = "获取服务器连接状态";
	
	public static String GET_STATE_OK_BUTTON_CMD = "getStateOK";
	public static String GET_STATE_CANCEL_BUTTON_CMD = "getStateCanel";
	
	JButton okButton;
	JButton cancelButton;
	
	JTextField ipTextField;
	
	public static GetStateDlg getInstance()
	{
		if (dlg == null) {
			dlg = new GetStateDlg();
		}
		return dlg;
	}
	
	private GetStateDlg()
	{
		
		setTitle(title);
		setLayout(null);
		setModal(true);
		setResizable(false);
		
		setBounds(350, 350, 450, 300);
		
		
		okButton = new JButton();
		okButton.setText("确定");
		okButton.setBounds(50,130,150,80);
		okButton.setActionCommand(GET_STATE_OK_BUTTON_CMD);
		okButton.addActionListener(this);
		okButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(okButton);
        
        cancelButton = new JButton();
        cancelButton.setText("取消");
        cancelButton.setBounds(250,130,150,80);
        cancelButton.setActionCommand(GET_STATE_CANCEL_BUTTON_CMD);
        cancelButton.addActionListener(this);
        cancelButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(cancelButton);
        
        JLabel userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("服务器IP:");
        userLabel.setBounds(20, 20, 109, 61);
        add(userLabel);
 
        
        ipTextField = new JTextField();
        ipTextField.setFont(new java.awt.Font("宋体", 0, 25)); // NOI18N
        ipTextField.setText("");
        ipTextField.setBounds(130, 20, 300, 61);
        add(ipTextField);
	
		
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		
		String cmd = event.getActionCommand();
		
		if (cmd == null || cmd.length() == 0)
		{
			return;
		}
		
		if (cmd.equals(GET_STATE_OK_BUTTON_CMD))
		{
			String ip = ipTextField.getText();
			if (ip == null || ip.length() == 0)
			{
				JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
			}
			else {
				Pattern p = Pattern.compile("([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])");
				Matcher m = p.matcher(ip);
				if (!m.matches()) {
					JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
					ipTextField.setText("");
				}
				else {
					
					ServerFlowFunction function = new ServerFlowFunction();				
					int ret = function.GetServerStateFunction(ip);
					
					JOptionPane.showMessageDialog(null, "获取服务器状态: "+ret );
					this.setVisible(false);
					
				}
				
			}
			
			ipTextField.requestFocusInWindow();
		}
		
		
		if (cmd.equals(GET_STATE_CANCEL_BUTTON_CMD))
		{
			this.setVisible(false);
			
		}
		
		
		
	}
	
}
