package palm.pass.ui;



import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import palm.pass.function.OCXFunction;
import palm.pass.function.ServerFlowFunction;
import palmpass.server.IdentifyResult;


public class IdentifyDlg extends JDialog implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5494011117562363465L;

	public static IdentifyDlg dlg;
	
	public String title = "1:N比对";
	
	public static String IDENTIFY_OK_BUTTON_CMD = "identifyOK";
	public static String IDENTIFY_CANCEL_BUTTON_CMD = "identifyCanel";
	
	JButton okButton;
	JButton cancelButton;
	
	JTextField ipTextField;
	
	public static IdentifyDlg getInstance()
	{
		if (dlg == null) {
			dlg = new IdentifyDlg();
		}
		return dlg;
	}
	
	private IdentifyDlg()
	{
		
		setTitle(title);
		setLayout(null);
		setModal(true);
		setResizable(false);
		
		setBounds(350, 350, 450, 300);
		
		
		okButton = new JButton();
		okButton.setText("确定");
		okButton.setBounds(50,130,150,80);
		okButton.setActionCommand(IDENTIFY_OK_BUTTON_CMD);
		okButton.addActionListener(this);
		okButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(okButton);
        
        cancelButton = new JButton();
        cancelButton.setText("取消");
        cancelButton.setBounds(250,130,150,80);
        cancelButton.setActionCommand(IDENTIFY_CANCEL_BUTTON_CMD);
        cancelButton.addActionListener(this);
        cancelButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(cancelButton);
        
        JLabel userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("服务器IP:");
        userLabel.setBounds(20, 20, 109, 61);
        add(userLabel);
 
        
        ipTextField = new JTextField();
        ipTextField.setFont(new java.awt.Font("宋体", 0, 25)); // NOI18N
        ipTextField.setText("");
        ipTextField.setBounds(130, 20, 300, 61);
        add(ipTextField);
	
		
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		
		String cmd = event.getActionCommand();
		
		if (cmd == null || cmd.length() == 0)
		{
			return;
		}
		
		if (cmd.equals(IDENTIFY_OK_BUTTON_CMD))
		{
			String ip = ipTextField.getText();
			if (ip == null || ip.length() == 0)
			{
				JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
			}
			else {
				Pattern p = Pattern.compile("([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])");
				Matcher m = p.matcher(ip);
				if (!m.matches()) {
					JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
					ipTextField.setText("");
				}
				else {
					ServerFlowFunction function = new ServerFlowFunction();	
					OCXFunction oxcFunction = new OCXFunction();
					
					this.setVisible(false);
					qianjiDemo.instanceFrame.setBounds(0, 0, 0, 0);
					
					/*通过OCX获取采集数据*/
					byte[] captureData = oxcFunction.getCaptureDataByOCX();
					if (captureData == null)
					{
						JOptionPane.showMessageDialog(null, "用户采集失败 " );
						this.setVisible(false);
						ipTextField.requestFocusInWindow();
					}
					else
					{
						System.out.println("veinData:" + captureData==null ? 0:captureData.length);
						/*调用jar函数*/
						IdentifyResult ret = function.IdentifyRequestFunction(ip, captureData);
						
						JOptionPane.showMessageDialog(null, "用户1:N识别 : " + ret.result  + " , ID:" + ret.ID);
						this.setVisible(false);
						ipTextField.requestFocusInWindow();
					}
					
					qianjiDemo.instanceFrame.setBounds(200, 200, 800, 600);	
					
				}
				
			}
			
			ipTextField.requestFocusInWindow();
		}
		
		
		if (cmd.equals(IDENTIFY_CANCEL_BUTTON_CMD))
		{
			this.setVisible(false);
			
		}
		
		
		
	}
	
}
