package palm.pass.ui;



import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import palm.pass.function.OCXFunction;
import palm.pass.function.ServerFlowFunction;



public class VerifyDlg extends JDialog implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6306303053432429772L;

	public static VerifyDlg dlg;
	
	public String title = "用户1:1识别";
	
	public static String VERIFY_OK_BUTTON_CMD = "verifyOK";
	public static String VERIFY_CANCEL_BUTTON_CMD = "verifyCanel";
	
	JButton okButton;
	JButton cancelButton;
	
	JTextField ipTextField;
	JTextField idTextField;
	
	public static VerifyDlg getInstance()
	{
		if (dlg == null) {
			dlg = new VerifyDlg();
		}
		return dlg;
	}
	
	private VerifyDlg()
	{
		
		setTitle(title);
		setLayout(null);
		setModal(true);
		setResizable(false);
		
		setBounds(350, 350, 450, 300);
		
		
		okButton = new JButton();
		okButton.setText("确定");
		okButton.setBounds(50,150,150,80);
		okButton.setActionCommand(VERIFY_OK_BUTTON_CMD);
		okButton.addActionListener(this);
		okButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(okButton);
        
        cancelButton = new JButton();
        cancelButton.setText("取消");
        cancelButton.setBounds(250,150,150,80);
        cancelButton.setActionCommand(VERIFY_CANCEL_BUTTON_CMD);
        cancelButton.addActionListener(this);
        cancelButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(cancelButton);
        
        
        JLabel userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 24));
        userLabel.setText("服务器IP:");
        userLabel.setBounds(20, 20, 109, 50);
        add(userLabel);
 
        
        ipTextField = new JTextField();
        ipTextField.setFont(new java.awt.Font("宋体", 0, 24)); // NOI18N
        ipTextField.setText("");
        ipTextField.setBounds(130, 20, 300, 50);
        add(ipTextField);
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 24));
        userLabel.setText("用户ID:");
        userLabel.setBounds(20, 80, 109, 50);
        add(userLabel);
 
        
        idTextField = new JTextField();
        idTextField.setFont(new java.awt.Font("宋体", 0, 24)); // NOI18N
        idTextField.setText("");
        idTextField.setBounds(130, 80, 300, 50);
        add(idTextField);
        
	
		
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		
		String cmd = event.getActionCommand();
		
		if (cmd == null || cmd.length() == 0)
		{
			return;
		}
		
		if (cmd.equals(VERIFY_OK_BUTTON_CMD))
		{
			String ip = ipTextField.getText();
			String id = idTextField.getText();
			if (ip == null || ip.length() == 0)
			{
				JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
				ipTextField.requestFocusInWindow();
			}
			else if (id == null || id.length() ==0){
				JOptionPane.showMessageDialog(null, "请输入ID" );
				idTextField.requestFocusInWindow();
			}
			else if (id.length() > 20) {
				JOptionPane.showMessageDialog(null, "输入ID长度超过20" );
				idTextField.setText("");
				idTextField.requestFocusInWindow();
			}
			else {
				Pattern p = Pattern.compile("([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])");
				Matcher m = p.matcher(ip);
				if (!m.matches()) {
					JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
					ipTextField.setText("");
					ipTextField.requestFocusInWindow();
				}
				else {
					
					ServerFlowFunction function = new ServerFlowFunction();	
					OCXFunction oxcFunction = new OCXFunction();
					this.setVisible(false);
					qianjiDemo.instanceFrame.setBounds(0, 0, 0, 0);
					
					/*通过OCX获取采集数据*/
					byte[] captureData = oxcFunction.getCaptureDataByOCX();
					if (captureData == null)
					{
						JOptionPane.showMessageDialog(null, "用户采集失败 " );
						this.setVisible(false);
						ipTextField.requestFocusInWindow();
					}
					else
					{
						System.out.println("veinData:" + captureData==null ? 0:captureData.length);
						/*调用jar函数*/
						int ret = function.VerifyRequestFunction(ip, id,captureData);
						
						JOptionPane.showMessageDialog(null, "用户1:1比对 : " + ret );
						this.setVisible(false);
						ipTextField.requestFocusInWindow();
					}
					
					qianjiDemo.instanceFrame.setBounds(200, 200, 800, 600);	
				}
				
			}
			
			
		}
		
		
		if (cmd.equals(VERIFY_CANCEL_BUTTON_CMD))
		{
			this.setVisible(false);
			
		}
		
		
		
	}
	
}
