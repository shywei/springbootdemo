package palm.pass.ui;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

import palm.pass.ui.terminal.AddNewTerminalDlg;
import palm.pass.ui.terminal.AdminDownLoadDlg;
import palm.pass.ui.terminal.GetGateInfoDlg;
import palm.pass.ui.terminal.GetTerminalInfoDlg;
import palm.pass.ui.terminal.GetTerminalStatusDlg;
import palm.pass.ui.terminal.InitialTerminalDlg;
import palm.pass.ui.terminal.RemoteOpenDoorDlg;
import palm.pass.ui.terminal.RemoteRebootDlg;
import palm.pass.ui.terminal.SetGateInfoDlg;
import palm.pass.ui.terminal.SetTerminalConfigDlg;
import palm.pass.ui.terminal.SyncTimeDlg;
import palm.pass.ui.terminal.TerminalFWUpgradeDlg;


public class TerminalAPIPanel extends JPanel implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4125186598774777583L;

	private static String ADD_NEW_TERMINAL = "addNewTerminal";
	private static String ADMIN_DOWN_LOAD  = "adminDownLoad";
	private static String REMOTE_FW_UPGRADE = "remoteFWUpgrade";
	private static String REMOTE_SYNC_TIME = "remoteSyncTime";
	
	private static String REBOOT_TERMINAL	= "rebootTerminal";
	private static String REMOTE_OPEN_DOOR = "remoteOpenDoor";
	private static String REINITALIZE = "reInit";
	private static String GET_TERMINAL_STATUS = "getTerminalStatus";
	private static String GET_SYSTEM_INFO	="getSystemInfo";
	private static String SET_TERMINAL_CONF = "setTerminalConfig";
	
	private static String GET_GATE_INFO	= "getGateInfo";
	private static String SET_GATE_INFO	= "setGateInfo";
	
	public static TerminalAPIPanel panel;
	
	/*kinds of dlg */
	AddNewTerminalDlg addNewTerminalDlg;
	TerminalFWUpgradeDlg terminalFwUpgradeDlg;
	AdminDownLoadDlg adminDownloadDlg;
	SyncTimeDlg		syncTimeDlg;
	RemoteOpenDoorDlg remoteOpenDoorDlg;
	RemoteRebootDlg remoteRebootDlg;
	GetTerminalStatusDlg getTerminalStatusDlg;
	InitialTerminalDlg initialTerminalDlg;
	GetTerminalInfoDlg getTerminalInfoDlg;
	GetGateInfoDlg getGateInfoDlg;
	SetGateInfoDlg setGateInfoDlg;
	SetTerminalConfigDlg setTerminalConfigDlg;
	
	public static TerminalAPIPanel getInstatnce()
	{
		if (panel == null )
		{
			panel = new TerminalAPIPanel();
		}
		
		return panel;
	}
	
	
	JButton addNewTerminal;
	JButton addDownLoad;
	JButton remoteFWUpgrade;
	JButton remoteSyncTime;
	JButton setTerminalConf;
	JButton rebootTerminal;
	JButton remoteOpenDoor;
	JButton reInital;
	JButton getTerminalStatus;
	JButton getTerminalInfo;
	JButton setTerminalInfo;
	JButton getTerminalGateInfo;
	JButton setTerminalGateInfo;
	
	private  TerminalAPIPanel()
	{
		setLayout(null);
		
		addNewTerminal = new JButton("添加设备");
		addNewTerminal.setFont(new Font("微软雅黑",0,20));
		addNewTerminal.setBounds(87, 50, 150, 50);
		addNewTerminal.setActionCommand(ADD_NEW_TERMINAL);
		addNewTerminal.addActionListener(this);
		add(addNewTerminal);
		
		addDownLoad = new JButton("管理员下发");
		addDownLoad.setFont(new Font("微软雅黑",0,20));
		addDownLoad.setBounds(324, 50, 150, 50);
		addDownLoad.setActionCommand(ADMIN_DOWN_LOAD);
		addDownLoad.addActionListener(this);
		add(addDownLoad);
		
		remoteFWUpgrade = new JButton("系统升级");
		remoteFWUpgrade.setFont(new Font("微软雅黑",0,19));
		remoteFWUpgrade.setBounds(561, 50, 150, 50);
		remoteFWUpgrade.setActionCommand(REMOTE_FW_UPGRADE);
		remoteFWUpgrade.addActionListener(this);
		add(remoteFWUpgrade);
		
		
		remoteSyncTime = new JButton("时间同步");
		remoteSyncTime.setFont(new Font("微软雅黑",0,20));
		remoteSyncTime.setBounds(87, 150, 150, 50);
		remoteSyncTime.setActionCommand(REMOTE_SYNC_TIME);
		remoteSyncTime.addActionListener(this);
		add(remoteSyncTime);
		
		remoteOpenDoor = new JButton("远程开门");
		remoteOpenDoor.setFont(new Font("微软雅黑",0,19));
		remoteOpenDoor.setBounds(324, 150, 150, 50);
		remoteOpenDoor.setActionCommand(REMOTE_OPEN_DOOR);
		remoteOpenDoor.addActionListener(this);
		add(remoteOpenDoor);
		
		rebootTerminal = new JButton("远程重启");
		rebootTerminal.setFont(new Font("微软雅黑",0,20));
		rebootTerminal.setBounds(561, 150, 150, 50);
		rebootTerminal.setActionCommand(REBOOT_TERMINAL);
		rebootTerminal.addActionListener(this);
		add(rebootTerminal);
		
		
		getTerminalStatus = new JButton("终端状态");
		getTerminalStatus.setFont(new Font("微软雅黑",0,20));
		getTerminalStatus.setBounds(87, 250, 150, 50);
		getTerminalStatus.setActionCommand(GET_TERMINAL_STATUS);
		getTerminalStatus.addActionListener(this);
		add(getTerminalStatus);
		
		reInital = new JButton("系统初始化");
		reInital.setFont(new Font("微软雅黑",0,19));
		reInital.setBounds(324, 250, 150, 50);
		reInital.setActionCommand(REINITALIZE);
		reInital.addActionListener(this);
		add(reInital);
		
		getTerminalInfo = new JButton("终端信息");
		getTerminalInfo.setFont(new Font("微软雅黑",0,20));
		getTerminalInfo.setBounds(561, 250, 150, 50);
		getTerminalInfo.setActionCommand(GET_SYSTEM_INFO);
		getTerminalInfo.addActionListener(this);
		add(getTerminalInfo);		
		
		
		setTerminalInfo = new JButton("设置终端");
		setTerminalInfo.setFont(new Font("微软雅黑",0,19));
		setTerminalInfo.setBounds(87, 350, 150, 50);
		setTerminalInfo.setActionCommand(SET_TERMINAL_CONF);
		setTerminalInfo.addActionListener(this);
		add(setTerminalInfo);
		
		getTerminalGateInfo = new JButton("获取门禁信息");
		getTerminalGateInfo.setFont(new Font("微软雅黑",0,19));
		getTerminalGateInfo.setBounds(324, 350, 150, 50);
		getTerminalGateInfo.setActionCommand(GET_GATE_INFO);
		getTerminalGateInfo.addActionListener(this);
		add(getTerminalGateInfo);
		
		setTerminalGateInfo = new JButton("设置门禁信息");
		setTerminalGateInfo.setFont(new Font("微软雅黑",0,19));
		setTerminalGateInfo.setBounds(561, 350, 150, 50);
		setTerminalGateInfo.setActionCommand(SET_GATE_INFO);
		setTerminalGateInfo.addActionListener(this);
		add(setTerminalGateInfo);	
		
		
		/*create all kinds of dlg */
		addNewTerminalDlg = AddNewTerminalDlg.getInstance();
		terminalFwUpgradeDlg = TerminalFWUpgradeDlg.getInstance();
		adminDownloadDlg = AdminDownLoadDlg.getInstance();
		syncTimeDlg = SyncTimeDlg.getInstance();
		remoteOpenDoorDlg = RemoteOpenDoorDlg.getInstance();
		remoteRebootDlg = RemoteRebootDlg.getInstance();
		getTerminalStatusDlg = GetTerminalStatusDlg.getInstance();
		initialTerminalDlg = InitialTerminalDlg.getInstance();
		getTerminalInfoDlg = GetTerminalInfoDlg.getInstance();
		getGateInfoDlg = GetGateInfoDlg.getInstance();
		setGateInfoDlg = SetGateInfoDlg.getInstance();
		setTerminalConfigDlg = SetTerminalConfigDlg.getInstance();
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub
		String cmd = event.getActionCommand();
		
		if (cmd == null || cmd.length() == 0)
		{
			return;
		}
		
		if (cmd.equals(ADD_NEW_TERMINAL)){	//添加新设备
	
			addNewTerminalDlg.setVisible(true);
		}
		else if (cmd.equals(ADMIN_DOWN_LOAD)) {	//管理员下发
			adminDownloadDlg.setVisible(true);
			
		}
		else if (cmd.equals(REMOTE_FW_UPGRADE))	//固件升级
		{
			terminalFwUpgradeDlg.setVisible(true);
		}
		else if (cmd.equals(REMOTE_SYNC_TIME))	//时间同步
		{
			syncTimeDlg.setVisible(true);
		}
		else if (cmd.equals(REMOTE_OPEN_DOOR))	//远程开门
		{
			remoteOpenDoorDlg.setVisible(true);
		}
		else if (cmd.equals(REBOOT_TERMINAL))	//远程重启
		{
			remoteRebootDlg.setVisible(true);
			
		}
		else if (cmd.equals(GET_TERMINAL_STATUS))	//获取终端状态
		{
			getTerminalStatusDlg.setVisible(true);
		}
		else if (cmd.equals(REINITALIZE))	//初始化
		{
			initialTerminalDlg.setVisible(true);
		}
		else if (cmd.equals(GET_SYSTEM_INFO)) //获取设备信息
		{
			getTerminalInfoDlg.setVisible(true);
		}
		else if (cmd.equals(GET_GATE_INFO))//获取门控信息
		{
			getGateInfoDlg.setVisible(true);
		}
		else if (cmd.equals(SET_GATE_INFO))	//设置门控信息
		{
			setGateInfoDlg.setVisible(true);
		}
		else if (cmd.equals(SET_TERMINAL_CONF))
		{
			setTerminalConfigDlg.setVisible(true);
		}
		
	}

}
