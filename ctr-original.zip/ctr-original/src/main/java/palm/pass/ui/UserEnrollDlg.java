package palm.pass.ui;



import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import palm.pass.function.OCXFunction;
import palm.pass.function.ServerFlowFunction;



public class UserEnrollDlg extends JDialog implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6306303053432429772L;

	public static UserEnrollDlg dlg;
	
	public String title = "用户注册";
	
	public static String USER_ENROLL_OK_BUTTON_CMD = "userEnrollOK";
	public static String USER_ENROLL_CANCEL_BUTTON_CMD = "userEnrollCanel";
	
	JButton okButton;
	JButton cancelButton;
	
	JTextField ipTextField;
	JTextField idTextField;
	
	public static UserEnrollDlg getInstance()
	{
		if (dlg == null) {
			dlg = new UserEnrollDlg();
		}
		return dlg;
	}
	
	private UserEnrollDlg()
	{
		
		setTitle(title);
		setLayout(null);
		setModal(true);
		setResizable(false);
		
		setBounds(350, 350, 450, 300);
		
		
		okButton = new JButton();
		okButton.setText("确定");
		okButton.setBounds(50,150,150,80);
		okButton.setActionCommand(USER_ENROLL_OK_BUTTON_CMD);
		okButton.addActionListener(this);
		okButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(okButton);
        
        cancelButton = new JButton();
        cancelButton.setText("取消");
        cancelButton.setBounds(250,150,150,80);
        cancelButton.setActionCommand(USER_ENROLL_CANCEL_BUTTON_CMD);
        cancelButton.addActionListener(this);
        cancelButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(cancelButton);
        
        
        JLabel userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 24));
        userLabel.setText("服务器IP:");
        userLabel.setBounds(20, 20, 109, 50);
        add(userLabel);
 
        
        ipTextField = new JTextField();
        ipTextField.setFont(new java.awt.Font("宋体", 0, 24)); // NOI18N
        ipTextField.setText("");
        ipTextField.setBounds(130, 20, 300, 50);
        add(ipTextField);
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 24));
        userLabel.setText("用户ID:");
        userLabel.setBounds(20, 80, 109, 50);
        add(userLabel);
 
        
        idTextField = new JTextField();
        idTextField.setFont(new java.awt.Font("宋体", 0, 24)); // NOI18N
        idTextField.setText("");
        idTextField.setBounds(130, 80, 300, 50);
        add(idTextField);
        
	
		
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		
		String cmd = event.getActionCommand();
		
		if (cmd == null || cmd.length() == 0)
		{
			return;
		}
		
		if (cmd.equals(USER_ENROLL_OK_BUTTON_CMD))
		{
			String ip = ipTextField.getText();
			String id = idTextField.getText();
			if (ip == null || ip.length() == 0)
			{
				JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
				ipTextField.requestFocusInWindow();
			}
			else if (id == null || id.length() ==0){
				JOptionPane.showMessageDialog(null, "请输入ID" );
				idTextField.requestFocusInWindow();
			}
			else if (id.length() > 20) {
				JOptionPane.showMessageDialog(null, "输入ID长度超过20" );
				idTextField.setText("");
				idTextField.requestFocusInWindow();
			}
			else {
				Pattern p = Pattern.compile("([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])");
				Matcher m = p.matcher(ip);
				if (!m.matches()) {
					JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
					ipTextField.setText("");
					ipTextField.requestFocusInWindow();
				}
				else {
					
					ServerFlowFunction function = new ServerFlowFunction();	
					OCXFunction oxcFunction = new OCXFunction();
					this.setVisible(false);
					qianjiDemo.instanceFrame.setBounds(0, 0, 0, 0);
					
					/*通过OCX获取注册数据*/
					byte[] veinData = oxcFunction.getEnrollDataByOCX();
					if (veinData == null)
					{
						JOptionPane.showMessageDialog(null, "用户注册失败 " );
						this.setVisible(false);
						ipTextField.requestFocusInWindow();
					}
					else
					{
						System.out.println("veinData:" + veinData==null ? 0:veinData.length);
						/*调用jar函数*/
						int ret = function.UserEnrollFunction(ip, id,veinData);
						
						JOptionPane.showMessageDialog(null, "用户注册 : " + ret );
						this.setVisible(false);
						ipTextField.requestFocusInWindow();
					}
					
					qianjiDemo.instanceFrame.setBounds(200, 200, 800, 600);	
				}
				
			}
			
			
		}
		
		
		if (cmd.equals(USER_ENROLL_CANCEL_BUTTON_CMD))
		{
			this.setVisible(false);
			
		}
		
		
		
	}
	
}
