package palm.pass.ui.terminal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import palm.pass.function.TerminalFlowFunction;

public class RemoteOpenDoorDlg  extends JDialog implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9047475337040628052L;

	public String title = "远程开门";

	public static RemoteOpenDoorDlg dlg;
	
	public static String OPENDOOR_OK_BUTTON_CMD = "GetOK";
	public static String OPENDOOR_CANCEL_BUTTON_CMD = "GetCanel";
	
	JButton okButton;
	JButton cancelButton;
	
	JTextField numberTextField;
	JComboBox<String> typeComboBox;
	String[] value = { "门禁考勤一体机" ,"消费机","自助机" };
	
	JComboBox<String> modelComboBox;
	String[] modelValue = { "PSN900" ,"PSN900Lite" };
	
	JTextField ipTextField;
	JTextField portTextField;
	JTextField pwdTextField;
	
	
	
	public static RemoteOpenDoorDlg getInstance() {
		if (dlg == null) {
			dlg = new RemoteOpenDoorDlg();
		}
		return dlg;
	}
	
	private RemoteOpenDoorDlg()
	{
		setTitle(title);
		setLayout(null);
		setModal(true);
		setResizable(false);

		setBounds(350, 250, 450, 420);
		
		JLabel userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("编号:");
        userLabel.setBounds(20, 20, 109, 30);
        add(userLabel);
 
        
        numberTextField = new JTextField();
        numberTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        numberTextField.setText("");
        numberTextField.setBounds(130, 20, 300, 30);
        add(numberTextField);
	
		
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("类型:");
        userLabel.setBounds(20, 60, 109, 30);
        add(userLabel);
 
        typeComboBox = new JComboBox<String>();
		for (int i=0; i<value.length; i++) {
			typeComboBox.addItem(value[i]);
		}
		typeComboBox.setFocusable(false);
		typeComboBox.setFont(new java.awt.Font("宋体", 0, 20));
		typeComboBox.setBounds(130, 60, 300, 30);
        add(typeComboBox); 

        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("型号:");
        userLabel.setBounds(20, 100, 109, 30);
        add(userLabel);
 
        modelComboBox = new JComboBox<String>();
		for (int i=0; i<modelValue.length; i++) {
			modelComboBox.addItem(modelValue[i]);
		}
		modelComboBox.setFocusable(false);
		modelComboBox.setFont(new java.awt.Font("宋体", 0, 20));
		modelComboBox.setBounds(130, 100, 300, 30);
        add(modelComboBox);       
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("IP:");
        userLabel.setBounds(20, 140, 109, 30);
        add(userLabel);
 
        
        ipTextField = new JTextField();
        ipTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        ipTextField.setText("");
        ipTextField.setBounds(130, 140, 300, 30);
        add(ipTextField);       
                
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("端口:");
        userLabel.setBounds(20, 180, 109, 30);
        add(userLabel);
 
        
        portTextField = new JTextField();
        portTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        portTextField.setText("");
        portTextField.setBounds(130, 180, 300, 30);
        add(portTextField);       
        
        
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("连接密码:");
        userLabel.setBounds(20, 220, 109, 30);
        add(userLabel);
 
        
        pwdTextField = new JTextField();
        pwdTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        pwdTextField.setText("");
        pwdTextField.setBounds(130, 220, 300, 30);
        add(pwdTextField);    
        

        
		okButton = new JButton();
		okButton.setText("确定");
		okButton.setBounds(50,270,150,50);
		okButton.setActionCommand(OPENDOOR_OK_BUTTON_CMD);
		okButton.addActionListener(this);
		okButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(okButton);
        
        cancelButton = new JButton();
        cancelButton.setText("取消");
        cancelButton.setBounds(250,270,150,50);
        cancelButton.setActionCommand(OPENDOOR_CANCEL_BUTTON_CMD);
        cancelButton.addActionListener(this);
        cancelButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(cancelButton);
	}
	

	public int checkParameters()
	{
		int ret = 0;
		
		String number = numberTextField.getText();
		if (number == null || number.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "设备编号错误，填入小于六位数字" );
			numberTextField.setText("");
			numberTextField.requestFocusInWindow();
			return ret;
		}
		
		Pattern p = Pattern.compile("([0-9]+)");
		Matcher m = p.matcher(number);
		if (!m.matches() || number.length() > 6)
		{
			
			JOptionPane.showMessageDialog(null, "设备编号错误，填入小于六位数字"  );
			numberTextField.setText("");
			numberTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		String ip = ipTextField.getText();
		if (ip == null || ip.length() == 0)
		{
			JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
			ipTextField.setText("");
			ipTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		else {
			p = Pattern.compile("([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])");
			m = p.matcher(ip);
			if (!m.matches()) {
				JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
				ipTextField.setText("");
				ipTextField.requestFocusInWindow();
				ret = 1;
				return ret;
			}
		}
		
		String port = portTextField.getText();
		if (port == null || port.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "端口号错误，填入1024-65535间数字" );
			portTextField.setText("");
			portTextField.requestFocusInWindow();
			return ret;
		}
		
		p = Pattern.compile("([0-9]+)");
		m = p.matcher(port);
		if (!m.matches() ||Integer.valueOf(port) > 65535 || Integer.valueOf(port) < 1024 )
		{
			
			JOptionPane.showMessageDialog(null, "端口号错误，填入1024-65535间数字" );
			portTextField.setText("");
			portTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		
		String pwd = pwdTextField.getText();
		if (pwd == null || pwd.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "连接密码错误，填入6位数字" );
			pwdTextField.setText("");
			pwdTextField.requestFocusInWindow();
			return ret;
		}
		
		 p = Pattern.compile("([0-9]+)");
		 m = p.matcher(pwd);
		if (!m.matches() || pwd.length() != 6)
		{
			
			JOptionPane.showMessageDialog(null, "连接密码错误，填入6位数字"  );
			pwdTextField.setText("");
			pwdTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		return ret;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub
		String cmd = event.getActionCommand();
		
		if (cmd == null || cmd.length() == 0)
		{
			return;
		}
		
		if (cmd.equals(OPENDOOR_OK_BUTTON_CMD))
		{
			int ret = checkParameters();
			if ( 0 != ret)
			{
				
				
			}
			else {
				
				TerminalFlowFunction function = new TerminalFlowFunction();	
				
				String terminalIP = ipTextField.getText();
				int port = Integer.valueOf(portTextField.getText());
				long number = Integer.valueOf(numberTextField.getText());
				
				byte[] pwd = pwdTextField.getText().getBytes(); 
				
				int type = typeComboBox.getSelectedIndex(); 
				int model = modelComboBox.getSelectedIndex();
			
				
				ret = function.RemoteOpenDoor(terminalIP , port , number,type , model,pwd);
				
				JOptionPane.showMessageDialog(null, "远程开门: "+ ret );
				this.setVisible(false);
			}
		}
		else if (cmd.equals(OPENDOOR_CANCEL_BUTTON_CMD))
		{
			this.setVisible(false);
		}
	}

}
