package palm.pass.ui.terminal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import palm.pass.function.TerminalFlowFunction;

public class SyncTimeDlg  extends JDialog implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7885074168671780017L;

	public String title = "时间同步";

	public static SyncTimeDlg dlg;
	
	
	public static String SYNC_OK_BUTTON_CMD = "SyncOK";
	public static String SYNC_CANCEL_BUTTON_CMD = "SyncCanel";


	JButton okButton;
	JButton cancelButton;

	JTextField numberTextField;
	JComboBox<String> typeComboBox;
	String[] value = { "门禁考勤一体机", "消费机", "自助机" };

	JComboBox<String> modelComboBox;
	String[] modelValue = { "PSN900", "PSN900Lite" };

	JTextField ipTextField;
	JTextField portTextField;
	JTextField pwdTextField;

	JTextField yearTextField;
	JTextField monthTextField;
	JTextField dayTextField;
	
	JTextField hourTextField;
	JTextField minTextField;
	JTextField secondTextField;
	
	
	public static SyncTimeDlg getInstance() {
		if (dlg == null) {
			dlg = new SyncTimeDlg();
		}
		return dlg;
	}
	
	private SyncTimeDlg()
	{
		setTitle(title);
		setLayout(null);
		setModal(true);
		setResizable(false);

		setBounds(350, 250, 460, 420);
		
		JLabel userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 20));
		userLabel.setText("编号:");
		userLabel.setBounds(20, 20, 109, 30);
		add(userLabel);

		numberTextField = new JTextField();
		numberTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		numberTextField.setText("");
		numberTextField.setBounds(130, 20, 300, 30);
		add(numberTextField);

		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 20));
		userLabel.setText("类型:");
		userLabel.setBounds(20, 60, 109, 30);
		add(userLabel);

		typeComboBox = new JComboBox<String>();
		for (int i = 0; i < value.length; i++) {
			typeComboBox.addItem(value[i]);
		}
		typeComboBox.setFocusable(false);
		typeComboBox.setFont(new java.awt.Font("宋体", 0, 20));
		typeComboBox.setBounds(130, 60, 300, 30);
		add(typeComboBox);

		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 20));
		userLabel.setText("型号:");
		userLabel.setBounds(20, 100, 109, 30);
		add(userLabel);

		modelComboBox = new JComboBox<String>();
		for (int i = 0; i < modelValue.length; i++) {
			modelComboBox.addItem(modelValue[i]);
		}
		modelComboBox.setFocusable(false);
		modelComboBox.setFont(new java.awt.Font("宋体", 0, 20));
		modelComboBox.setBounds(130, 100, 300, 30);
		add(modelComboBox);

		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 20));
		userLabel.setText("IP:");
		userLabel.setBounds(20, 140, 109, 30);
		add(userLabel);

		ipTextField = new JTextField();
		ipTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		ipTextField.setText("");
		ipTextField.setBounds(130, 140, 300, 30);
		add(ipTextField);

		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 20));
		userLabel.setText("端口:");
		userLabel.setBounds(20, 180, 109, 30);
		add(userLabel);

		portTextField = new JTextField();
		portTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		portTextField.setText("");
		portTextField.setBounds(130, 180, 300, 30);
		add(portTextField);

		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 20));
		userLabel.setText("连接密码:");
		userLabel.setBounds(20, 220, 109, 30);
		add(userLabel);

		pwdTextField = new JTextField();
		pwdTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		pwdTextField.setText("");
		pwdTextField.setBounds(130, 220, 300, 30);
		add(pwdTextField);

		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 19));
		userLabel.setText("时间:");
		userLabel.setBounds(20, 260, 109, 30);
		add(userLabel);
		
		yearTextField = new JTextField();
		yearTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		yearTextField.setText("");
		yearTextField.setBounds(130, 260, 50, 30);
		add(yearTextField);
		
		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 19));
		userLabel.setText("年");
		userLabel.setBounds(180, 260, 20, 30);
		add(userLabel);
		
		
		monthTextField = new JTextField();
		monthTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		monthTextField.setText("");
		monthTextField.setBounds(200, 260, 30, 30);
		add(monthTextField);
		
		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 19));
		userLabel.setText("月");
		userLabel.setBounds(230, 260, 20, 30);
		add(userLabel);
		
		dayTextField = new JTextField();
		dayTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		dayTextField.setText("");
		dayTextField.setBounds(250, 260, 30, 30);
		add(dayTextField);
		
		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 19));
		userLabel.setText("日");
		userLabel.setBounds(280, 260, 20, 30);
		add(userLabel);
		
		hourTextField = new JTextField();
		hourTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		hourTextField.setText("");
		hourTextField.setBounds(300, 260, 30, 30);
		add(hourTextField);
		
		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 19));
		userLabel.setText("时");
		userLabel.setBounds(330, 260, 20, 30);
		add(userLabel);
		
		minTextField = new JTextField();
		minTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		minTextField.setText("");
		minTextField.setBounds(350, 260, 30, 30);
		add(minTextField);
		
		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 19));
		userLabel.setText("分");
		userLabel.setBounds(380, 260, 20, 30);
		add(userLabel);
		
		secondTextField = new JTextField();
		secondTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		secondTextField.setText("");
		secondTextField.setBounds(400, 260, 30, 30);
		add(secondTextField);
		
		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 19));
		userLabel.setText("秒");
		userLabel.setBounds(430, 260, 20, 30);
		add(userLabel);
		
		
		okButton = new JButton();
		okButton.setText("确定");
		okButton.setBounds(50, 310, 150, 50);
		okButton.setActionCommand(SYNC_OK_BUTTON_CMD);
		okButton.addActionListener(this);
		okButton.setFont(new java.awt.Font("宋体", 0, 30));
		add(okButton);

		cancelButton = new JButton();
		cancelButton.setText("取消");
		cancelButton.setBounds(250, 310, 150, 50);
		cancelButton.setActionCommand(SYNC_CANCEL_BUTTON_CMD);
		cancelButton.addActionListener(this);
		cancelButton.setFont(new java.awt.Font("宋体", 0, 30));
		add(cancelButton);

	}
	
	public int checkParameters()
	{
		int ret = 0;
		
		String number = numberTextField.getText();
		if (number == null || number.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "设备编号错误，填入小于六位数字" );
			numberTextField.setText("");
			numberTextField.requestFocusInWindow();
			return ret;
		}
		
		Pattern p = Pattern.compile("([0-9]+)");
		Matcher m = p.matcher(number);
		if (!m.matches() || number.length() > 6)
		{
			
			JOptionPane.showMessageDialog(null, "设备编号错误，填入小于六位数字"  );
			numberTextField.setText("");
			numberTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		String ip = ipTextField.getText();
		if (ip == null || ip.length() == 0)
		{
			JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
			ipTextField.setText("");
			ipTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		else {
			p = Pattern.compile("([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])");
			m = p.matcher(ip);
			if (!m.matches()) {
				JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
				ipTextField.setText("");
				ipTextField.requestFocusInWindow();
				ret = 1;
				return ret;
			}
		}
		
		String port = portTextField.getText();
		if (port == null || port.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "端口号错误，填入1024-65535间数字" );
			portTextField.setText("");
			portTextField.requestFocusInWindow();
			return ret;
		}
		
		p = Pattern.compile("([0-9]+)");
		m = p.matcher(port);
		if (!m.matches() ||Integer.valueOf(port) > 65535 || Integer.valueOf(port) < 1024 )
		{
			
			JOptionPane.showMessageDialog(null, "端口号错误，填入1024-65535间数字" );
			portTextField.setText("");
			portTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		
		String pwd = pwdTextField.getText();
		if (pwd == null || pwd.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "连接密码错误，填入6位数字" );
			pwdTextField.setText("");
			pwdTextField.requestFocusInWindow();
			return ret;
		}
		
		 p = Pattern.compile("([0-9]+)");
		 m = p.matcher(pwd);
		if (!m.matches() || pwd.length() != 6)
		{
			
			JOptionPane.showMessageDialog(null, "连接密码错误，填入6位数字"  );
			pwdTextField.setText("");
			pwdTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		
		String year = yearTextField.getText();
		if (year == null || year.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "年份输入错误，输入4位年份" );
			yearTextField.setText("");
			yearTextField.requestFocusInWindow();
			return ret;
		}
		
		p = Pattern.compile("([0-9]+)");
		m = p.matcher(year);
		if (!m.matches() || year.length() != 4 || Integer.valueOf(year) < 1970)
		{
			
			JOptionPane.showMessageDialog(null, "年份输入错误，输入4位年份"  );
			yearTextField.setText("");
			yearTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}		
		
		String month = monthTextField.getText();
		if (month == null || month.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "月份输入错误，输入2位月份" );
			monthTextField.setText("");
			monthTextField.requestFocusInWindow();
			return ret;
		}
		
		p = Pattern.compile("([0-9]+)");
		m = p.matcher(month);
		if (!m.matches() || month.length() != 2 || Integer.valueOf(month) < 1 || Integer.valueOf(month) > 12)
		{
			
			JOptionPane.showMessageDialog(null, "月份输入错误，输入2位月份"  );
			monthTextField.setText("");
			monthTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		String day = dayTextField.getText();
		if (day == null || day.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "日期输入错误，输入2位日期" );
			dayTextField.setText("");
			dayTextField.requestFocusInWindow();
			return ret;
		}
		
		p = Pattern.compile("([0-9]+)");
		m = p.matcher(day);
		if (!m.matches() || day.length() != 2 || Integer.valueOf(day) < 1 || Integer.valueOf(day) > 31)
		{
			
			JOptionPane.showMessageDialog(null, "日期输入错误，输入2位日期"  );
			dayTextField.setText("");
			dayTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		String hour = hourTextField.getText();
		if (hour == null || hour.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "小时输入错误，输入2位小时" );
			hourTextField.setText("");
			hourTextField.requestFocusInWindow();
			return ret;
		}
		
		p = Pattern.compile("([0-9]+)");
		m = p.matcher(hour);
		if (!m.matches() || hour.length() != 2 || Integer.valueOf(hour) < 0 || Integer.valueOf(hour) > 23)
		{
			
			JOptionPane.showMessageDialog(null, "小时输入错误，输入2位小时"  );
			hourTextField.setText("");
			hourTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		String minute = minTextField.getText();
		if (minute == null || minute.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "分钟输入错误，输入2位分钟" );
			minTextField.setText("");
			minTextField.requestFocusInWindow();
			return ret;
		}
		
		p = Pattern.compile("([0-9]+)");
		m = p.matcher(minute);
		if (!m.matches() || minute.length() != 2 || Integer.valueOf(minute) < 0 || Integer.valueOf(minute) > 59)
		{
			
			JOptionPane.showMessageDialog(null, "分钟输入错误，输入2位分钟"  );
			minTextField.setText("");
			minTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}

		String second = secondTextField.getText();
		if (second == null || second.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "秒输入错误，输入2位秒" );
			secondTextField.setText("");
			secondTextField.requestFocusInWindow();
			return ret;
		}
		
		p = Pattern.compile("([0-9]+)");
		m = p.matcher(second);
		if (!m.matches() || second.length() != 2 || Integer.valueOf(second) < 0 || Integer.valueOf(second) > 59)
		{
			
			JOptionPane.showMessageDialog(null, "秒输入错误，输入2位秒"  );
			secondTextField.setText("");
			secondTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		return ret;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub
		String cmd = event.getActionCommand();
		
		if (cmd == null || cmd.length() == 0)
		{
			return;
		}
		
		if (cmd.equals(SYNC_OK_BUTTON_CMD))
		{
			int ret = checkParameters();
			if ( 0 != ret)
			{
				
				
			}
			else {
				
				TerminalFlowFunction function = new TerminalFlowFunction();	
				
				String terminalIP = ipTextField.getText();
				int port = Integer.valueOf(portTextField.getText());
				long number = Integer.valueOf(numberTextField.getText());
				
				byte[] pwd = pwdTextField.getText().getBytes(); 
				
				int type = typeComboBox.getSelectedIndex(); 
				int model = modelComboBox.getSelectedIndex();
			
				String timeStamp = yearTextField.getText() + monthTextField.getText() + dayTextField.getText()
						+ hourTextField.getText() + minTextField.getText() + secondTextField.getText();
				System.err.println(timeStamp);
				ret = function.SyncTime(terminalIP , port , number,type , model,pwd ,timeStamp.getBytes());
				
				JOptionPane.showMessageDialog(null, "同步时间: "+ ret );
				this.setVisible(false);
			}
			
		}
		else if (cmd.equals(SYNC_CANCEL_BUTTON_CMD))
		{
			this.setVisible(false);
		}
	}

}
