package palm.pass.ui;



import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import palm.pass.function.ServerFlowFunction;



public class ServerConfigDlg extends JDialog implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3063037013916494206L;

	public static ServerConfigDlg dlg;
	
	public String title = "服务器配置";
	
	public static String AUTO_REBOOT_CONFIG_OK_BUTTON_CMD = "autoRebootOK";
	public static String AUTO_REBOOT_CONFIG_CANCEL_BUTTON_CMD = "autoRebootCanel";
	
	public static int	PRECISION_LEVEL_NORMAL 	= 1;
	public static int	PRECISION_LEVEL_HIGH	= 2;
	public static int	PRECISION_LEVEL_HIGHEST	= 3;
	
	JButton okButton;
	JButton cancelButton;
	
	
	JComboBox<String> precisionBox;
	String[] value = { "普通" ,"高" ,"最高"};
	JTextField ipTextField;

	
	
	public static ServerConfigDlg getInstance()
	{
		if (dlg == null) {
			dlg = new ServerConfigDlg();
		}
		return dlg;
	}
	
	private ServerConfigDlg()
	{
		
		setTitle(title);
		setLayout(null);
		setModal(true);
		setResizable(false);
		
		setBounds(350, 350, 450, 300);
		
		
		okButton = new JButton();
		okButton.setText("确定");
		okButton.setBounds(50,180,150,60);
		okButton.setActionCommand(AUTO_REBOOT_CONFIG_OK_BUTTON_CMD);
		okButton.addActionListener(this);
		okButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(okButton);
        
        cancelButton = new JButton();
        cancelButton.setText("取消");
        cancelButton.setBounds(250,180,150,60);
        cancelButton.setActionCommand(AUTO_REBOOT_CONFIG_CANCEL_BUTTON_CMD);
        cancelButton.addActionListener(this);
        cancelButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(cancelButton);
        
        JLabel userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("服务器IP:");
        userLabel.setBounds(20, 20, 109, 50);
        add(userLabel);
 
        
        ipTextField = new JTextField();
        ipTextField.setFont(new java.awt.Font("宋体", 0, 25)); // NOI18N
        ipTextField.setText("");
        ipTextField.setBounds(130, 20, 300, 50);
        add(ipTextField);
        
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("识别精度:");
        userLabel.setBounds(20, 100, 109, 50);
        add(userLabel);
        
        precisionBox = new JComboBox<String>();
        precisionBox.setBounds(130, 100 , 150, 50);
        precisionBox.setFont(new Font("宋体",0,25));
		
		for (int i=0; i<value.length; i++) {
			precisionBox.addItem(value[i]);
		}
		precisionBox.setFocusable(false);
		add(precisionBox);
	
       
		
        
     
        
        
        
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		
		String cmd = event.getActionCommand();
		
		if (cmd == null || cmd.length() == 0)
		{
			return;
		}
		
		if (cmd.equals(AUTO_REBOOT_CONFIG_OK_BUTTON_CMD))
		{
			String ip = ipTextField.getText();
			
			if (ip == null || ip.length() == 0)
			{
				JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
				ipTextField.requestFocusInWindow();
			}
			
			else {
				Pattern p = Pattern.compile("([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])");
				Matcher m = p.matcher(ip);
				if (!m.matches()) {
					JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
					ipTextField.setText("");
					ipTextField.requestFocusInWindow();
				}
				else {
					
					ServerFlowFunction function = new ServerFlowFunction();	
					int flag = precisionBox.getSelectedIndex(); 
					int precisionValue = 0;
					
					switch(flag)
					{
					case 0:	//普通
					{
						precisionValue = PRECISION_LEVEL_NORMAL;
					}
						break;
					case 1:	//高
					{
						precisionValue = PRECISION_LEVEL_HIGH;
					}
						break;
					case 2:	//最高
					{
						precisionValue = PRECISION_LEVEL_HIGHEST;
					}
						break;
					default:
						precisionValue = PRECISION_LEVEL_NORMAL;
						break;
					}
					
					int ret = function.ConfigServerFunction(ip, precisionValue);
					JOptionPane.showMessageDialog(null, "配置服务器 : " + ret );
				
					this.setVisible(false);
					ipTextField.requestFocusInWindow();
				}
				
			}
			
			
		}
		
		
		if (cmd.equals(AUTO_REBOOT_CONFIG_CANCEL_BUTTON_CMD))
		{
			this.setVisible(false);
			
		}
		
		
		
	}
	
}
