package palm.pass.ui.terminal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import palm.pass.function.TerminalFlowFunction;
import palmpass.client.GateInfo;

public class SetGateInfoDlg  extends JDialog implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5808993868356516148L;

	public String title = "设置门禁信息";

	public static SetGateInfoDlg dlg;
	
	
	public static String SET_GATE_INFO_OK_BUTTON_CMD = "SetGateInfoOK";
	public static String SET_GATE_INFO_CANCEL_BUTTON_CMD = "SetGateInfoCanel";
	
	JButton okButton;
	JButton cancelButton;
	
	JTextField numberTextField;
	JComboBox<String> typeComboBox;
	String[] value = { "门禁考勤一体机" ,"消费机","自助机" };
	
	JComboBox<String> modelComboBox;
	String[] modelValue = { "PSN900" ,"PSN900Lite" };
	
	JTextField ipTextField;
	JTextField portTextField;
	JTextField pwdTextField;
	
	
	JComboBox<String> lockControlComboBox;
	String[] lockControlValue = { "韦根26" ,"韦根34","电锁","无输出" };
	
	JTextField lockTimeTextField;
	
	String[] switchValue = {"关闭","开启"};
	
	JComboBox<String> contactAlarmComboBox;
	JComboBox<String> contactAlarmTimeComboBox;
	String[] contactValue = {"10","20","30","40","50","60","120"};
	
	
	JComboBox<String> soundComboBox;
	String[] soundValue = {"关闭","1","2","3","4","5"};
	
	
	JComboBox<String> lightComboBox;
	String[] lightValue = {"1","2","3","4","5"};
	

	JComboBox<String> sleepComboBox;
	String[] sleepValue = {"不休眠","1","4","8","12"};
	
	
	JComboBox<String> duressAlarmComboBox;
	
	JComboBox<String> tamperAlarmComboBox;
	
	JComboBox<String> alarmSignalComboBox;
	String[] alarmSignalValue = {"本机报警","外接报警","本机报警 & 外接报警"};
	
	JComboBox<String> alarmTimeComboBox;
	String[] alarmTimeValue = {"一直响","10","20","30","40","50","60","120"};
	
	
	
	public static SetGateInfoDlg getInstance() {
		if (dlg == null) {
			dlg = new SetGateInfoDlg();
		}
		return dlg;
	}
	
	private SetGateInfoDlg()
	{
		setTitle(title);
		setLayout(null);
		setModal(true);
		setResizable(false);

		setBounds(350, 150, 500, 820);
		
		JLabel userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("编号:");
        userLabel.setBounds(20, 20, 150, 30);
        add(userLabel);
 
        
        numberTextField = new JTextField();
        numberTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        numberTextField.setText("");
        numberTextField.setBounds(160, 20, 300, 30);
        add(numberTextField);
	
		
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("类型:");
        userLabel.setBounds(20, 60, 150, 30);
        add(userLabel);
 
        typeComboBox = new JComboBox<String>();
		for (int i=0; i<value.length; i++) {
			typeComboBox.addItem(value[i]);
		}
		typeComboBox.setFocusable(false);
		typeComboBox.setFont(new java.awt.Font("宋体", 0, 20));
		typeComboBox.setBounds(160, 60, 300, 30);
        add(typeComboBox); 

        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("型号:");
        userLabel.setBounds(20, 100, 150, 30);
        add(userLabel);
 
        modelComboBox = new JComboBox<String>();
		for (int i=0; i<modelValue.length; i++) {
			modelComboBox.addItem(modelValue[i]);
		}
		modelComboBox.setFocusable(false);
		modelComboBox.setFont(new java.awt.Font("宋体", 0, 20));
		modelComboBox.setBounds(160, 100, 300, 30);
        add(modelComboBox);       
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("IP:");
        userLabel.setBounds(20, 140, 150, 30);
        add(userLabel);
 
        
        ipTextField = new JTextField();
        ipTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        ipTextField.setText("");
        ipTextField.setBounds(160, 140, 300, 30);
        add(ipTextField);       
                
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("端口:");
        userLabel.setBounds(20, 180, 150, 30);
        add(userLabel);
 
        
        portTextField = new JTextField();
        portTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        portTextField.setText("");
        portTextField.setBounds(160, 180, 300, 30);
        add(portTextField);       
        
        
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("连接密码:");
        userLabel.setBounds(20, 220, 150, 30);
        add(userLabel);
 
        
        pwdTextField = new JTextField();
        pwdTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        pwdTextField.setText("");
        pwdTextField.setBounds(160, 220, 300, 30);
        add(pwdTextField);    
        
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("门控信号:");
        userLabel.setBounds(20, 260, 150, 30);
        add(userLabel);
 
        lockControlComboBox = new JComboBox<String>();
		for (int i=0; i<lockControlValue.length; i++) {
			lockControlComboBox.addItem(lockControlValue[i]);
		}
		lockControlComboBox.setFocusable(false);
		lockControlComboBox.setFont(new java.awt.Font("宋体", 0, 20));
		lockControlComboBox.setBounds(160, 260, 300, 30);
        add(lockControlComboBox);  
        
               
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("锁驱时长(秒):");
        userLabel.setBounds(20, 300, 150, 30);
        add(userLabel);  
        
        lockTimeTextField = new JTextField();
        lockTimeTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        lockTimeTextField.setText("");
        lockTimeTextField.setBounds(160, 300, 300, 30);
        add(lockTimeTextField);    
        
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("门磁报警开关:");
        userLabel.setBounds(20, 340, 150, 30);
        add(userLabel);
        
        contactAlarmComboBox = new JComboBox<String>();
 		for (int i=0; i<switchValue.length; i++) {
 			contactAlarmComboBox.addItem(switchValue[i]);
 		}
 		contactAlarmComboBox.setFocusable(false);
 		contactAlarmComboBox.setFont(new java.awt.Font("宋体", 0, 20));
 		contactAlarmComboBox.setBounds(160, 340, 300, 30);
        add(contactAlarmComboBox);  
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 19));
        userLabel.setText("门磁延迟时长(秒):");
        userLabel.setBounds(0, 380, 170, 30);
        add(userLabel);
       
        contactAlarmTimeComboBox = new JComboBox<String>();
 		for (int i=0; i<contactValue.length; i++) {
 			contactAlarmTimeComboBox.addItem(contactValue[i]);
 		}
 		contactAlarmTimeComboBox.setFocusable(false);
 		contactAlarmTimeComboBox.setFont(new java.awt.Font("宋体", 0, 20));
 		contactAlarmTimeComboBox.setBounds(160, 380, 300, 30);
        add(contactAlarmTimeComboBox); 
        
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("提示音量:");
        userLabel.setBounds(20, 420, 150, 30);
        add(userLabel);
        
        soundComboBox = new JComboBox<String>();
 		for (int i=0; i<soundValue.length; i++) {
 			soundComboBox.addItem(soundValue[i]);
 		}
 		soundComboBox.setFocusable(false);
 		soundComboBox.setFont(new java.awt.Font("宋体", 0, 20));
 		soundComboBox.setBounds(160, 420, 300, 30);
        add(soundComboBox);        
        
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("显示屏亮度:");
        userLabel.setBounds(20, 460, 150, 30);
        add(userLabel);
     
        lightComboBox = new JComboBox<String>();
 		for (int i=0; i<lightValue.length; i++) {
 			lightComboBox.addItem(lightValue[i]);
 		}
 		lightComboBox.setFocusable(false);
 		lightComboBox.setFont(new java.awt.Font("宋体", 0, 20));
 		lightComboBox.setBounds(160, 460, 300, 30);
        add(lightComboBox);     
        
        
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("休眠时间(分):");
        userLabel.setBounds(20, 500, 150, 30);
        add(userLabel);
        
        sleepComboBox = new JComboBox<String>();
 		for (int i=0; i<sleepValue.length; i++) {
 			sleepComboBox.addItem(sleepValue[i]);
 		}
 		sleepComboBox.setFocusable(false);
 		sleepComboBox.setFont(new java.awt.Font("宋体", 0, 20));
 		sleepComboBox.setBounds(160, 500, 300, 30);
        add(sleepComboBox);     
        
        
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("防胁迫报警开关:");
        userLabel.setBounds(10, 540, 150, 30);
        add(userLabel);
        
        
        duressAlarmComboBox = new JComboBox<String>();
 		for (int i=0; i<switchValue.length; i++) {
 			duressAlarmComboBox.addItem(switchValue[i]);
 		}
 		duressAlarmComboBox.setFocusable(false);
 		duressAlarmComboBox.setFont(new java.awt.Font("宋体", 0, 20));
 		duressAlarmComboBox.setBounds(160, 540, 300, 30);
        add(duressAlarmComboBox); 
        
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("防拆报警开关:");
        userLabel.setBounds(20, 580, 150, 30);
        add(userLabel);
        
        tamperAlarmComboBox = new JComboBox<String>();
   		for (int i=0; i<switchValue.length; i++) {
   			tamperAlarmComboBox.addItem(switchValue[i]);
   		}
   		tamperAlarmComboBox.setFocusable(false);
   		tamperAlarmComboBox.setFont(new java.awt.Font("宋体", 0, 20));
   		tamperAlarmComboBox.setBounds(160, 580, 300, 30);
        add(tamperAlarmComboBox); 
          
        
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("报警信号输出:");
        userLabel.setBounds(20, 620, 150, 30);
        add(userLabel);
        
        alarmSignalComboBox = new JComboBox<String>();
   		for (int i=0; i<alarmSignalValue.length; i++) {
   			alarmSignalComboBox.addItem(alarmSignalValue[i]);
   		}
   		alarmSignalComboBox.setFocusable(false);
   		alarmSignalComboBox.setFont(new java.awt.Font("宋体", 0, 20));
   		alarmSignalComboBox.setBounds(160, 620, 300, 30);
        add(alarmSignalComboBox); 
        
       
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("报警时长:");
        userLabel.setBounds(20, 660, 150, 30);
        add(userLabel);
        
        alarmTimeComboBox = new JComboBox<String>();
   		for (int i=0; i<alarmTimeValue.length; i++) {
   			alarmTimeComboBox.addItem(alarmTimeValue[i]);
   		}
   		alarmTimeComboBox.setFocusable(false);
   		alarmTimeComboBox.setFont(new java.awt.Font("宋体", 0, 20));
   		alarmTimeComboBox.setBounds(160, 660, 300, 30);
        add(alarmTimeComboBox); 
        
        
        
        
        
		okButton = new JButton();
		okButton.setText("确定");
		okButton.setBounds(50,710,150,50);
		okButton.setActionCommand(SET_GATE_INFO_OK_BUTTON_CMD);
		okButton.addActionListener(this);
		okButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(okButton);
        
        cancelButton = new JButton();
        cancelButton.setText("取消");
        cancelButton.setBounds(250,710,150,50);
        cancelButton.setActionCommand(SET_GATE_INFO_CANCEL_BUTTON_CMD);
        cancelButton.addActionListener(this);
        cancelButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(cancelButton);
	}
	
	public int checkParameters()
	{
		int ret = 0;
		
		String number = numberTextField.getText();
		if (number == null || number.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "设备编号错误，填入小于六位数字" );
			numberTextField.setText("");
			numberTextField.requestFocusInWindow();
			return ret;
		}
		
		Pattern p = Pattern.compile("([0-9]+)");
		Matcher m = p.matcher(number);
		if (!m.matches() || number.length() > 6)
		{
			
			JOptionPane.showMessageDialog(null, "设备编号错误，填入小于六位数字"  );
			numberTextField.setText("");
			numberTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		String ip = ipTextField.getText();
		if (ip == null || ip.length() == 0)
		{
			JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
			ipTextField.setText("");
			ipTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		else {
			p = Pattern.compile("([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])");
			m = p.matcher(ip);
			if (!m.matches()) {
				JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
				ipTextField.setText("");
				ipTextField.requestFocusInWindow();
				ret = 1;
				return ret;
			}
		}
		
		
		
		String port = portTextField.getText();
		if (port == null || port.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "端口号错误，填入1024-65535间数字" );
			portTextField.setText("");
			portTextField.requestFocusInWindow();
			return ret;
		}
		
		p = Pattern.compile("([0-9]+)");
		m = p.matcher(port);
		if (!m.matches() ||Integer.valueOf(port) > 65535 || Integer.valueOf(port) < 1024 )
		{
			
			JOptionPane.showMessageDialog(null, "端口号错误，填入1024-65535间数字" );
			portTextField.setText("");
			portTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		
		String pwd = pwdTextField.getText();
		if (pwd == null || pwd.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "连接密码错误，填入6位数字" );
			pwdTextField.setText("");
			pwdTextField.requestFocusInWindow();
			return ret;
		}
		
		p = Pattern.compile("([0-9]+)");
		m = p.matcher(pwd);
		if (!m.matches() || pwd.length() != 6)
		{
			
			JOptionPane.showMessageDialog(null, "连接密码错误，填入6位数字"  );
			pwdTextField.setText("");
			pwdTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		String lockTime = lockTimeTextField.getText();
		if (lockTime == null || lockTime.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "锁驱时长错误，填入小于等于60的数字" );
			lockTimeTextField.setText("");
			lockTimeTextField.requestFocusInWindow();
			return ret;
		}
		
		p = Pattern.compile("([0-9]+)");
		m = p.matcher(lockTime);
		if (!m.matches() || Integer.valueOf(lockTime) > 60)
		{
			
			JOptionPane.showMessageDialog(null, "锁驱时长错误，填入小于等于60的数字"  );
			lockTimeTextField.setText("");
			lockTimeTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		return ret;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub
		String cmd = event.getActionCommand();
		
		if (cmd == null || cmd.length() == 0)
		{
			return;
		}
		
		if (cmd.equals(SET_GATE_INFO_OK_BUTTON_CMD))
		{
			int ret = checkParameters();
			if ( 0 != ret)
			{
				
				
			}
			else {
				
				TerminalFlowFunction function = new TerminalFlowFunction();	
				
				String terminalIP = ipTextField.getText();
				int port = Integer.valueOf(portTextField.getText());
				long number = Integer.valueOf(numberTextField.getText());
				
				byte[] pwd = pwdTextField.getText().getBytes(); 
				
				int type = typeComboBox.getSelectedIndex(); 
				int model = modelComboBox.getSelectedIndex();
				
				int doorSignal = lockControlComboBox.getSelectedIndex();
				int time =  Integer.valueOf(lockTimeTextField.getText());
				
				int magAlarm = contactAlarmComboBox.getSelectedIndex();//门磁报警开关
				int magAlarmTime = (contactAlarmTimeComboBox.getSelectedIndex()+1)*10;
				
				if (magAlarmTime > 60)
				{
					magAlarmTime = 120;
				}
				
				int durAlarm = duressAlarmComboBox.getSelectedIndex();	//防胁迫
				int	tamperAlarm = tamperAlarmComboBox.getSelectedIndex();	//防拆报警
				int inputSignal = alarmSignalComboBox.getSelectedIndex();	
				
				int	alarmTime = alarmTimeComboBox.getSelectedIndex() * 10;	//报警时长
				if (alarmTime > 60)
				{
					alarmTime = 120;
				}
				else if (alarmTime  == 0)	//always alarm
				{
					alarmTime = 121;
				}
				
				int sound = soundComboBox.getSelectedIndex();
				int sleep = sleepComboBox.getSelectedIndex();
				
				switch(sleep)
				{
				case 0:
				case 1:
					break;
				case 2:
						sleep = 4;
					break;
				case 3:
						sleep = 8;
					break;
				case 4:
						sleep = 12;
					break;
				default:
					break;
				}
				
				int light = lightComboBox.getSelectedIndex() + 1;
				
				ret = function.SetGateInfo(terminalIP, port, number, type, model, pwd, doorSignal, time, magAlarm, magAlarmTime, durAlarm, tamperAlarm, inputSignal, alarmTime, sound, sleep, light);
				
				
				JOptionPane.showMessageDialog(null, "设置门禁信息: "+ ret);
					
				this.setVisible(false);
			}
		}
		else if (cmd.equals(SET_GATE_INFO_CANCEL_BUTTON_CMD))
		{
			this.setVisible(false);
		}
	}

}
