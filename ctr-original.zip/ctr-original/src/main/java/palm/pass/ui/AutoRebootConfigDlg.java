package palm.pass.ui;



import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import palm.pass.function.ServerFlowFunction;



public class AutoRebootConfigDlg extends JDialog implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3063037013916494206L;

	public static AutoRebootConfigDlg dlg;
	
	public String title = "自动重启配置";
	
	public static String AUTO_REBOOT_CONFIG_OK_BUTTON_CMD = "autoRebootOK";
	public static String AUTO_REBOOT_CONFIG_CANCEL_BUTTON_CMD = "autoRebootCanel";
	
	JButton okButton;
	JButton cancelButton;
	
	
	JComboBox<String> rebootBox;
	String[] value = { "关闭" ,"开启" };
	JTextField ipTextField;
	JTextField hourTextField;
	JTextField minTextField;
	
	public static AutoRebootConfigDlg getInstance()
	{
		if (dlg == null) {
			dlg = new AutoRebootConfigDlg();
		}
		return dlg;
	}
	
	private AutoRebootConfigDlg()
	{
		
		setTitle(title);
		setLayout(null);
		setModal(true);
		setResizable(false);
		
		setBounds(350, 350, 450, 300);
		
		
		okButton = new JButton();
		okButton.setText("确定");
		okButton.setBounds(50,200,150,50);
		okButton.setActionCommand(AUTO_REBOOT_CONFIG_OK_BUTTON_CMD);
		okButton.addActionListener(this);
		okButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(okButton);
        
        cancelButton = new JButton();
        cancelButton.setText("取消");
        cancelButton.setBounds(250,200,150,50);
        cancelButton.setActionCommand(AUTO_REBOOT_CONFIG_CANCEL_BUTTON_CMD);
        cancelButton.addActionListener(this);
        cancelButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(cancelButton);
        
        JLabel userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("服务器IP:");
        userLabel.setBounds(20, 20, 109, 50);
        add(userLabel);
 
        
        ipTextField = new JTextField();
        ipTextField.setFont(new java.awt.Font("宋体", 0, 25)); // NOI18N
        ipTextField.setText("");
        ipTextField.setBounds(130, 20, 300, 50);
        add(ipTextField);
        
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("开启重启:");
        userLabel.setBounds(20, 80, 109, 50);
        add(userLabel);
        
		rebootBox = new JComboBox<String>();
		rebootBox.setBounds(130, 80 , 150, 50);
		rebootBox.setFont(new Font("宋体",0,25));
		
		for (int i=0; i<value.length; i++) {
			rebootBox.addItem(value[i]);
		}
		rebootBox.setFocusable(false);
		add(rebootBox);
	
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("重启时间:");
        userLabel.setBounds(20, 140, 109, 50);
        add(userLabel);
		
        
        hourTextField = new JTextField();
        hourTextField.setFont(new java.awt.Font("宋体", 0, 25)); 
        hourTextField.setText("");
        hourTextField.setHorizontalAlignment(SwingConstants.CENTER);
        hourTextField.setBounds(130, 140, 50, 50);
        add(hourTextField);
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 25));
        userLabel.setText(":");
        userLabel.setBounds(190, 140, 20, 50);
        add(userLabel);
        
        minTextField = new JTextField();
        minTextField.setFont(new java.awt.Font("宋体", 0, 24)); 
        minTextField.setText("");
        minTextField.setHorizontalAlignment(SwingConstants.CENTER);
        minTextField.setBounds(210, 140, 50, 50);
        add(minTextField);
        
        
        
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		
		String cmd = event.getActionCommand();
		
		if (cmd == null || cmd.length() == 0)
		{
			return;
		}
		
		if (cmd.equals(AUTO_REBOOT_CONFIG_OK_BUTTON_CMD))
		{
			String ip = ipTextField.getText();
			String hour = hourTextField.getText();
			String min = minTextField.getText();
			if (ip == null || ip.length() == 0)
			{
				JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
				ipTextField.requestFocusInWindow();
			}
			else if (hour == null || hour.length() == 0 || Integer.valueOf(hour) < 0 ||
					Integer.valueOf(hour) > 23)
			{
				JOptionPane.showMessageDialog(null, "定时重启时间格式错误" );
				hourTextField.setText("");
				hourTextField.requestFocusInWindow();
				
			}
			else if (min == null || min.length()==0 || Integer.valueOf(min) < 0
				|| Integer.valueOf(min) > 59)
			{
				JOptionPane.showMessageDialog(null, "定时重启时间格式错误" );
				minTextField.setText("");
				minTextField.requestFocusInWindow();
			}
			else {
				Pattern p = Pattern.compile("([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])");
				Matcher m = p.matcher(ip);
				if (!m.matches()) {
					JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
					ipTextField.setText("");
					ipTextField.requestFocusInWindow();
				}
				else {
					
					ServerFlowFunction function = new ServerFlowFunction();	
					int flag = rebootBox.getSelectedIndex(); 
					
					int ret = function.AutoRebootConfigFunction(ip, flag, Integer.valueOf(hour), Integer.valueOf(min));				
					JOptionPane.showMessageDialog(null, "定时重启配置: "+ ret );
					
					this.setVisible(false);
					ipTextField.requestFocusInWindow();
				}
				
			}
			
			
		}
		
		
		if (cmd.equals(AUTO_REBOOT_CONFIG_CANCEL_BUTTON_CMD))
		{
			this.setVisible(false);
			
		}
		
		
		
	}
	
}
