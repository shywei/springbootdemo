package palm.pass.ui;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;


public class ServerAPIPanel extends JPanel implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5176479437432077883L;
	
	JButton newUserRegisterButton;
	JButton updateUserButton;
	JButton deleteUserButton;
	
	JButton serverConfigButton;
	JButton verifyButton;
	JButton identifyButton;
	
	JButton getStateButton;
	JButton reloadButton;
	JButton rebootSetButton;
	
	public static String GET_STATE_BUTTON_CMD = "getState";
	public static String RELOAD_BUTTON_CMD	= "reload";
	public static String REBOOT_BUTTON_CMD	= "reboot";
	
	
	public static String NEW_USER_REGISTER_BUTTON_CMD = "newUser";
	public static String UPDATE_USER_BUTTON_CMD = "updateUser";
	public static String DELETE_USER_BUTTON_CMD	= "deleteUser";
	
	public static String SERVER_CONFIG_BUTTON_CMD = "serverConfig";
	public static String VERIFY_BUTTON_CMD = "verify";
	public static String IDENTIFY_BUTTON_CMD = "identify";
	
	
	public static ServerAPIPanel panel;
	
	GetStateDlg getStateDlg ;
	ReloadDataDlg reloadDataDlg;
	AutoRebootConfigDlg autoRebootConfigDlg;
	
	UserEnrollDlg	userEnrollDlg;
	UserUpdateDlg 	userUpdateDlg;
	UserDeleteDlg 	userDeleteDlg;
	
	IdentifyDlg 	identifyDlg;
	VerifyDlg		verifyDlg;
	
	ServerConfigDlg 	serverConfigDlg;
	
	
	
	public static ServerAPIPanel getInstatnce()
	{
		if (panel == null )
		{
			panel = new ServerAPIPanel();
		}
		
		return panel;
	}
	
	private  ServerAPIPanel()
	{
		setLayout(null);
		
		getStateButton = new JButton("获取状态");
		getStateButton.setFont(new Font("微软雅黑",0,20));
		getStateButton.setBounds(87, 50, 150, 50);
		getStateButton.setActionCommand(GET_STATE_BUTTON_CMD);
		getStateButton.addActionListener(this);
		add(getStateButton);
		
		reloadButton = new JButton("重载数据");
		reloadButton.setFont(new Font("微软雅黑",0,20));
		reloadButton.setBounds(324, 50, 150, 50);
		reloadButton.setActionCommand(RELOAD_BUTTON_CMD);
		reloadButton.addActionListener(this);
		add(reloadButton);
		
		rebootSetButton = new JButton("定时重启设置");
		rebootSetButton.setFont(new Font("微软雅黑",0,19));
		rebootSetButton.setBounds(561, 50, 150, 50);
		rebootSetButton.setActionCommand(REBOOT_BUTTON_CMD);
		rebootSetButton.addActionListener(this);
		add(rebootSetButton);
		
		
		newUserRegisterButton = new JButton("新用户注册");
		newUserRegisterButton.setFont(new Font("微软雅黑",0,20));
		newUserRegisterButton.setBounds(87, 150, 150, 50);
		newUserRegisterButton.setActionCommand(NEW_USER_REGISTER_BUTTON_CMD);
		newUserRegisterButton.addActionListener(this);
		add(newUserRegisterButton);
		
		updateUserButton = new JButton("用户更新");
		updateUserButton.setFont(new Font("微软雅黑",0,20));
		updateUserButton.setBounds(324, 150, 150, 50);
		updateUserButton.setActionCommand(UPDATE_USER_BUTTON_CMD);
		updateUserButton.addActionListener(this);
		add(updateUserButton);
		
		deleteUserButton = new JButton("用户删除");
		deleteUserButton.setFont(new Font("微软雅黑",0,20));
		deleteUserButton.setBounds(561, 150, 150, 50);
		deleteUserButton.setActionCommand(DELETE_USER_BUTTON_CMD);
		deleteUserButton.addActionListener(this);
		add(deleteUserButton);
		
		
		serverConfigButton = new JButton("比对配置");
		serverConfigButton.setFont(new Font("微软雅黑",0,20));
		serverConfigButton.setBounds(87, 250, 150, 50);
		serverConfigButton.setActionCommand(SERVER_CONFIG_BUTTON_CMD);
		serverConfigButton.addActionListener(this);
		add(serverConfigButton);
		
		identifyButton = new JButton("1:N比对");
		identifyButton.setFont(new Font("微软雅黑",0,20));
		identifyButton.setBounds(324, 250, 150, 50);
		identifyButton.setActionCommand(IDENTIFY_BUTTON_CMD);
		identifyButton.addActionListener(this);
		add(identifyButton);
		
		verifyButton = new JButton("1:1比对");
		verifyButton.setFont(new Font("微软雅黑",0,20));
		verifyButton.setBounds(561, 250, 150, 50);
		verifyButton.setActionCommand(VERIFY_BUTTON_CMD);
		verifyButton.addActionListener(this);
		add(verifyButton);		
		
		
		getStateDlg = GetStateDlg.getInstance();
		reloadDataDlg = ReloadDataDlg.getInstance();
		autoRebootConfigDlg = AutoRebootConfigDlg.getInstance();
		
		/*用户注册，更新，删除页面*/
		userEnrollDlg = UserEnrollDlg.getInstance();
		userUpdateDlg = UserUpdateDlg.getInstance();
		userDeleteDlg = UserDeleteDlg.getInstance();
		
		identifyDlg = IdentifyDlg.getInstance();
		verifyDlg = VerifyDlg.getInstance();
		
		serverConfigDlg = ServerConfigDlg.getInstance();
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub
		String cmd = event.getActionCommand();
		
		if (cmd == null || cmd.length() == 0)
		{
			return;
		}
		
		if (cmd.equals(GET_STATE_BUTTON_CMD)){	//获取连接状态
			
			getStateDlg.setVisible(true);
		}
		else if (cmd.equals(RELOAD_BUTTON_CMD)){	//重新读取数据
			
			reloadDataDlg.setVisible(true);
		}
		else if (cmd.equals(REBOOT_BUTTON_CMD))	{	//自动重启配置
			
			autoRebootConfigDlg.setVisible(true);
		}
		else if (cmd.equals(NEW_USER_REGISTER_BUTTON_CMD)){	//用户注册
			
			userEnrollDlg.setVisible(true);
		}
		else if (cmd.equals(UPDATE_USER_BUTTON_CMD)) {	//用户更新
			userUpdateDlg.setVisible(true);
		}
		else if (cmd.equals(DELETE_USER_BUTTON_CMD)) {	//用户删除
			
			userDeleteDlg.setVisible(true);
		}
		else if (cmd.equals(IDENTIFY_BUTTON_CMD))	{	//用户1:N比对
			
			identifyDlg.setVisible(true);
		}
		else if (cmd.equals(VERIFY_BUTTON_CMD))	{	//用户1:1 比对
			
			verifyDlg.setVisible(true);			
		}
		else if (cmd.equals(SERVER_CONFIG_BUTTON_CMD)) {	//配置比对服务器信息
			
			serverConfigDlg.setVisible(true);
		}
		
		
	}
	
	
}
