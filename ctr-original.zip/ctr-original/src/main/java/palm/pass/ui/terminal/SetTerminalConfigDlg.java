package palm.pass.ui.terminal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import palm.pass.function.TerminalFlowFunction;
import palmpass.client.DeviceInfo;

public class SetTerminalConfigDlg  extends JDialog implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5808993868356516148L;

	public String title = "修改基础配置";

	public static SetTerminalConfigDlg dlg;
	
	
	public static String GET_TERMINAL_INFO_OK_BUTTON_CMD = "GetTerminalInfoOK";
	public static String GET_TERMINAL_INFO_CANCEL_BUTTON_CMD = "GetTerminalInfoCanel";
	
	JButton okButton;
	JButton cancelButton;
	
	JTextField numberTextField;
	JTextField newNumberTextField;
	
	
	JComboBox<String> typeComboBox;
	String[] value = { "门禁考勤一体机" ,"消费机","自助机" };
	
	JComboBox<String> modelComboBox;
	String[] modelValue = { "PSN900" ,"PSN900Lite" };
	
	JTextField ipTextField;
	JTextField newIpTextField;
	JTextField newNetMaskTextField;
	JTextField newGatewayTextField;
	
	JTextField portTextField;
	JTextField newPortTextField;
	
	JTextField pwdTextField;
	JTextField newPwdTextField;
	
	JTextField webIPTextField;
	
	
	
	public static SetTerminalConfigDlg getInstance() {
		if (dlg == null) {
			dlg = new SetTerminalConfigDlg();
		}
		return dlg;
	}
	
	private SetTerminalConfigDlg()
	{
		setTitle(title);
		setLayout(null);
		setModal(true);
		setResizable(false);

		setBounds(350, 250, 800, 560);
		
		JLabel userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("连接设备信息: ");
        userLabel.setBounds(20, 20, 250, 30);
        add(userLabel);
		
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("修改设备信息:");
        userLabel.setBounds(450, 20, 250, 30);
        add(userLabel);
        
        
		userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("编号:");
        userLabel.setBounds(20, 60, 109, 30);
        add(userLabel);
 
        
        numberTextField = new JTextField();
        numberTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        numberTextField.setText("");
        numberTextField.setBounds(130, 60, 300, 30);
        add(numberTextField);
        
        /*new TextField*/
        newNumberTextField = new JTextField();
        newNumberTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        newNumberTextField.setText("");
        newNumberTextField.setBounds(450, 60, 300, 30);
        add(newNumberTextField);       
        
	
		
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("类型:");
        userLabel.setBounds(20, 100, 109, 30);
        add(userLabel);
 
        typeComboBox = new JComboBox<String>();
		for (int i=0; i<value.length; i++) {
			typeComboBox.addItem(value[i]);
		}
		typeComboBox.setFocusable(false);
		typeComboBox.setFont(new java.awt.Font("宋体", 0, 20));
		typeComboBox.setBounds(130, 100, 300, 30);
        add(typeComboBox); 

        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("型号:");
        userLabel.setBounds(20, 140, 109, 30);
        add(userLabel);
 
        modelComboBox = new JComboBox<String>();
		for (int i=0; i<modelValue.length; i++) {
			modelComboBox.addItem(modelValue[i]);
		}
		modelComboBox.setFocusable(false);
		modelComboBox.setFont(new java.awt.Font("宋体", 0, 20));
		modelComboBox.setBounds(130, 140, 300, 30);
        add(modelComboBox);       
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("IP:");
        userLabel.setBounds(20, 180, 109, 30);
        add(userLabel);
 
        
        ipTextField = new JTextField();
        ipTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        ipTextField.setText("");
        ipTextField.setBounds(130, 180, 300, 30);
        add(ipTextField);       
        
        /*new configure*/
        newIpTextField = new JTextField();
        newIpTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        newIpTextField.setText("");
        newIpTextField.setBounds(450, 180, 300, 30);
        add(newIpTextField);  
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("子网掩码:");
        userLabel.setBounds(20, 220, 109, 30);
        add(userLabel);
 
        
        newNetMaskTextField = new JTextField();
        newNetMaskTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        newNetMaskTextField.setText("");
        newNetMaskTextField.setBounds(450, 220, 300, 30);
        add(newNetMaskTextField);  
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("网关:");
        userLabel.setBounds(20, 260, 109, 30);
        add(userLabel);
        
        newGatewayTextField = new JTextField();
        newGatewayTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        newGatewayTextField.setText("");
        newGatewayTextField.setBounds(450, 260, 300, 30);
        add(newGatewayTextField);  
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("端口:");
        userLabel.setBounds(20, 300, 109, 30);
        add(userLabel);
 
        
        portTextField = new JTextField();
        portTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        portTextField.setText("");
        portTextField.setBounds(130, 300, 300, 30);
        add(portTextField);       
        
        newPortTextField = new JTextField();
        newPortTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        newPortTextField.setText("");
        newPortTextField.setBounds(450, 300, 300, 30);
        add(newPortTextField);             
            
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 20));
        userLabel.setText("连接密码:");
        userLabel.setBounds(20, 340, 109, 30);
        add(userLabel);
 
        
        pwdTextField = new JTextField();
        pwdTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        pwdTextField.setText("");
        pwdTextField.setBounds(130, 340, 300, 30);
        add(pwdTextField);   
        
       
        
        newPwdTextField = new JTextField();
        newPwdTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        newPwdTextField.setText("");
        newPwdTextField.setBounds(450, 340, 300, 30);
        add(newPwdTextField);   
        
        
        userLabel = new JLabel();      
        userLabel.setFont(new java.awt.Font("宋体", 0, 19));
        userLabel.setText("服务器IP:");
        userLabel.setBounds(20, 380, 109, 30);
        add(userLabel);
 
        
        webIPTextField = new JTextField();
        webIPTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
        webIPTextField.setText("");
        webIPTextField.setBounds(130, 380, 300, 30);
        add(webIPTextField);  
        
        
		okButton = new JButton();
		okButton.setText("确定");
		okButton.setBounds(200,440,150,50);
		okButton.setActionCommand(GET_TERMINAL_INFO_OK_BUTTON_CMD);
		okButton.addActionListener(this);
		okButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(okButton);
        
        cancelButton = new JButton();
        cancelButton.setText("取消");
        cancelButton.setBounds(450,440,150,50);
        cancelButton.setActionCommand(GET_TERMINAL_INFO_CANCEL_BUTTON_CMD);
        cancelButton.addActionListener(this);
        cancelButton.setFont(new java.awt.Font("宋体", 0, 30)); 
        add(cancelButton);
	}
	
	public int checkParameters()
	{
		int ret = 0;
		
		String number = numberTextField.getText();
		if (number == null || number.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "设备编号错误，填入小于六位数字" );
			numberTextField.setText("");
			numberTextField.requestFocusInWindow();
			return ret;
		}
		
		Pattern p = Pattern.compile("([0-9]+)");
		Matcher m = p.matcher(number);
		if (!m.matches() || number.length() > 6)
		{
			
			JOptionPane.showMessageDialog(null, "设备编号错误，填入小于六位数字"  );
			numberTextField.setText("");
			numberTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		
		number = newNumberTextField.getText();
		if (number == null || number.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "新设备编号错误，填入小于六位数字" );
			newNumberTextField.setText("");
			newNumberTextField.requestFocusInWindow();
			return ret;
		}
		
		p = Pattern.compile("([0-9]+)");
		m = p.matcher(number);
		if (!m.matches() || number.length() > 6)
		{
			
			JOptionPane.showMessageDialog(null, "新设备编号错误，填入小于六位数字"  );
			newNumberTextField.setText("");
			newNumberTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		String ip = ipTextField.getText();
		if (ip == null || ip.length() == 0)
		{
			JOptionPane.showMessageDialog(null, "IP格式错误" );
			ipTextField.setText("");
			ipTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		else {
			p = Pattern.compile("([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])");
			m = p.matcher(ip);
			if (!m.matches()) {
				JOptionPane.showMessageDialog(null, "IP格式错误" );
				ipTextField.setText("");
				ipTextField.requestFocusInWindow();
				ret = 1;
				return ret;
			}
		}
		
		ip = newIpTextField.getText();
		if (ip == null || ip.length() == 0)
		{
			JOptionPane.showMessageDialog(null, "新IP格式错误" );
			newIpTextField.setText("");
			newIpTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		else {
			p = Pattern.compile("([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])");
			m = p.matcher(ip);
			if (!m.matches()) {
				JOptionPane.showMessageDialog(null, "新IP格式错误" );
				newIpTextField.setText("");
				newIpTextField.requestFocusInWindow();
				ret = 1;
				return ret;
			}
		}
		
		String netmask = newNetMaskTextField.getText();
		if (netmask == null || netmask.length() == 0)
		{
			JOptionPane.showMessageDialog(null, "子网掩码格式错误" );
			newNetMaskTextField.setText("");
			newNetMaskTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		else {
			p = Pattern.compile("([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])");
			m = p.matcher(netmask);
			if (!m.matches()) {
				JOptionPane.showMessageDialog(null, "子网掩码格式错误" );
				newNetMaskTextField.setText("");
				newNetMaskTextField.requestFocusInWindow();
				ret = 1;
				return ret;
			}
		}
		
		String gateway = newGatewayTextField.getText();
		if (gateway == null || gateway.length() == 0)
		{
			JOptionPane.showMessageDialog(null, "网关格式错误" );
			newGatewayTextField.setText("");
			newGatewayTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		else {
			p = Pattern.compile("([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])");
			m = p.matcher(gateway);
			if (!m.matches()) {
				JOptionPane.showMessageDialog(null, "网关格式错误" );
				newGatewayTextField.setText("");
				newGatewayTextField.requestFocusInWindow();
				ret = 1;
				return ret;
			}
		}
		
		String port = portTextField.getText();
		if (port == null || port.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "端口号错误，填入1024-65535间数字" );
			portTextField.setText("");
			portTextField.requestFocusInWindow();
			return ret;
		}
		
		p = Pattern.compile("([0-9]+)");
		m = p.matcher(port);
		if (!m.matches() ||Integer.valueOf(port) > 65535 || Integer.valueOf(port) < 1024 )
		{
			
			JOptionPane.showMessageDialog(null, "端口号错误，填入1024-65535间数字" );
			portTextField.setText("");
			portTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		port = newPortTextField.getText();
		if (port == null || port.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "新端口号错误，填入1024-65535间数字" );
			newPortTextField.setText("");
			newPortTextField.requestFocusInWindow();
			return ret;
		}
		
		p = Pattern.compile("([0-9]+)");
		m = p.matcher(port);
		if (!m.matches() ||Integer.valueOf(port) > 65535 || Integer.valueOf(port) < 1024 )
		{
			
			JOptionPane.showMessageDialog(null, "新端口号错误，填入1024-65535间数字" );
			newPortTextField.setText("");
			newPortTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		
		String pwd = pwdTextField.getText();
		if (pwd == null || pwd.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "连接密码错误，填入6位数字" );
			pwdTextField.setText("");
			pwdTextField.requestFocusInWindow();
			return ret;
		}
		
		 p = Pattern.compile("([0-9]+)");
		 m = p.matcher(pwd);
		if (!m.matches() || pwd.length() != 6)
		{
			
			JOptionPane.showMessageDialog(null, "连接密码错误，填入6位数字"  );
			pwdTextField.setText("");
			pwdTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		
		pwd = newPwdTextField.getText();
		if (pwd == null || pwd.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "新连接密码错误，填入6位数字" );
			newPwdTextField.setText("");
			newPwdTextField.requestFocusInWindow();
			return ret;
		}
		
		 p = Pattern.compile("([0-9]+)");
		 m = p.matcher(pwd);
		if (!m.matches() || pwd.length() != 6)
		{
			
			JOptionPane.showMessageDialog(null, "新连接密码错误，填入6位数字"  );
			newPwdTextField.setText("");
			newPwdTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		
		
		String webIP = webIPTextField.getText();
		if (webIP == null || webIP.length() == 0)
		{
			JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
			webIPTextField.setText("");
			webIPTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		else {
			p = Pattern.compile("([1-9]|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])\\.(\\d|[1-9]\\d|1\\d{2}|2[0-4]\\d|25[0-5])");
			m = p.matcher(webIP);
			if (!m.matches()) {
				JOptionPane.showMessageDialog(null, "服务器IP格式错误" );
				webIPTextField.setText("");
				webIPTextField.requestFocusInWindow();
				ret = 1;
				return ret;
			}
		}
		
		return ret;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub
		String cmd = event.getActionCommand();
		
		if (cmd == null || cmd.length() == 0)
		{
			return;
		}
		
		if (cmd.equals(GET_TERMINAL_INFO_OK_BUTTON_CMD))
		{
			int ret = checkParameters();
			if ( 0 != ret)
			{
				
				
			}
			else {
				
				TerminalFlowFunction function = new TerminalFlowFunction();	
				
				String terminalIP = ipTextField.getText();
				int port = Integer.valueOf(portTextField.getText());
				long number = Integer.valueOf(numberTextField.getText());
				
				byte[] pwd = pwdTextField.getText().getBytes(); 
				
				int type = typeComboBox.getSelectedIndex(); 
				int model = modelComboBox.getSelectedIndex();
				
				
				String newIp = newIpTextField.getText();
				String newNetMask = newNetMaskTextField.getText();
				String newGateWay = newGatewayTextField.getText();
				long newNumber = Integer.valueOf(newNumberTextField.getText());
				int newPort = Integer.valueOf(newPortTextField.getText());
				byte[] newPwd = newPwdTextField.getText().getBytes();
				
				String webIP = webIPTextField.getText();
				
				ret = function.SetTerminalConfig(terminalIP, port, number, type, model, pwd, newNumber, newIp, newNetMask, newGateWay, newPort, newPwd, webIP);
				
				
				JOptionPane.showMessageDialog(null, "设置终端: " + ret);
				this.setVisible(false);
			}
		}
		else if (cmd.equals(GET_TERMINAL_INFO_CANCEL_BUTTON_CMD))
		{
			this.setVisible(false);
		}
	}

}
