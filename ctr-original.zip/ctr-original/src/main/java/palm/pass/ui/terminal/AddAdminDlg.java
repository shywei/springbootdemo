package palm.pass.ui.terminal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import palm.pass.function.OCXFunction;
import palm.pass.function.ServerFlowFunction;
import palm.pass.ui.qianjiDemo;

public class AddAdminDlg  extends JDialog implements ActionListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2774668119192502617L;

	public String title = "增加管理员";

	public static AddAdminDlg dlg;
	
	public static AddAdminDlg getInstance() {
		if (dlg == null) {
			dlg = new AddAdminDlg();
		}
		return dlg;
	}
	
	
	public static String ADD_OK_BUTTON_CMD = "DownloadOK";
	public static String ADD_CANCEL_BUTTON_CMD = "DownloadCanel";
	
	JButton okButton;
	JButton cancelButton;
	
	JTextField adminIDTextField;
	JTextField openDoorIDTextField;
	
	JTextArea adminInfoTextArea;
	JTextField adminNumTextField;
	
	
	

	public void setAdminNumberAndInfo(JTextField textField, JTextArea textArea)
	{
		adminNumTextField = textField;
		adminInfoTextArea = textArea;
	}
	
	
	
	private AddAdminDlg()
	{
		setTitle(title);
		setLayout(null);
		setModal(true);
		setResizable(false);

		setBounds(350, 250, 450, 210);
		
		
		JLabel userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 20));
		userLabel.setText("管理员ID:");
		userLabel.setBounds(20, 20, 109, 30);
		add(userLabel);

		adminIDTextField = new JTextField();
		adminIDTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		adminIDTextField.setText("");
		adminIDTextField.setBounds(130, 20, 300, 30);
		add(adminIDTextField);

		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 20));
		userLabel.setText("开门ID:");
		userLabel.setBounds(20, 60, 109, 30);
		add(userLabel);


		openDoorIDTextField = new JTextField();
		openDoorIDTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		openDoorIDTextField.setText("");
		openDoorIDTextField.setBounds(130, 60, 300, 30);
		add(openDoorIDTextField);

		
	
		okButton = new JButton();
		okButton.setText("确定");
		okButton.setBounds(50, 110, 150, 50);
		okButton.setActionCommand(ADD_OK_BUTTON_CMD);
		okButton.addActionListener(this);
		okButton.setFont(new java.awt.Font("宋体", 0, 30));
		add(okButton);

		cancelButton = new JButton();
		cancelButton.setText("取消");
		cancelButton.setBounds(250, 110, 150, 50);
		cancelButton.setActionCommand(ADD_CANCEL_BUTTON_CMD);
		cancelButton.addActionListener(this);
		cancelButton.setFont(new java.awt.Font("宋体", 0, 30));
		add(cancelButton);
		
		
		
		
	}
	
	public int checkParameters()
	{
		int ret = 0;
		
		String adminID = adminIDTextField.getText();
		if (adminID == null || adminID.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "管理员ID错误，填入小于30位数字" );
			adminIDTextField.setText("");
			adminIDTextField.requestFocusInWindow();
			return ret;
		}
		
		Pattern p = Pattern.compile("([0-9]+)");
		Matcher m = p.matcher(adminID);
		if (!m.matches() || adminID.length() > 30)
		{
			
			JOptionPane.showMessageDialog(null, "管理员ID错误，填入小于30位数字");
			adminIDTextField.setText("");
			adminIDTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		String openID = openDoorIDTextField.getText();
		if (openID == null || openID.length() == 0 )
		{
			ret = 1;
			JOptionPane.showMessageDialog(null, "开门ID错误，填入小于10位数字" );
			openDoorIDTextField.setText("");
			openDoorIDTextField.requestFocusInWindow();
			return ret;
		}
		
		 p = Pattern.compile("([0-9]+)");
		 m = p.matcher(openID);
		if (!m.matches() || openID.length() > 10)
		{
			
			JOptionPane.showMessageDialog(null, "开门ID错误，填入小于10位数字");
			openDoorIDTextField.setText("");
			openDoorIDTextField.requestFocusInWindow();
			ret = 1;
			return ret;
		}
		
		return ret;
	}
	
	

	@Override
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub
		String cmd = event.getActionCommand();
		
		if (cmd == null || cmd.length() == 0)
		{
			return;
		}
		
		if (cmd.equals(ADD_OK_BUTTON_CMD))
		{
			
			if (0 != checkParameters())
			{
				adminIDTextField.setText("");
				openDoorIDTextField.setText("");
			}
			else 
			{
				
				ServerFlowFunction function = new ServerFlowFunction();	
				OCXFunction oxcFunction = new OCXFunction();
				this.setVisible(false);
				qianjiDemo.instanceFrame.setBounds(0, 0, 0, 0);
				AdminDownLoadDlg.getInstance().setVisible(false);
				/*通过OCX获取注册数据*/
				byte[] veinData = oxcFunction.getEnrollDataByOCX();
				if (veinData == null)
				{
					JOptionPane.showMessageDialog(null, "用户注册失败 " );
					this.setVisible(false);
					
				}
				else
				{
					/*调用jar函数*/
					AdminDownLoadDlg dlg = AdminDownLoadDlg.getInstance();
					
					
					int adminNum = Integer.valueOf(adminNumTextField.getText());
					String adminInfo = adminInfoTextArea.getText();
					
					System.arraycopy(adminIDTextField.getText().getBytes(), 0, dlg.userID, 30*adminNum	, adminIDTextField.getText().getBytes().length);
					System.arraycopy(openDoorIDTextField.getText().getBytes(), 0 , dlg.openID, 10*adminNum, openDoorIDTextField.getText().getBytes().length	);
					System.arraycopy(veinData, 0, dlg.veinData, 15000*adminNum, 15000);
					
					adminNum += 1;
					adminInfo = adminInfo + adminNum + "、管理员ID:"+adminIDTextField.getText()
							+ " ,开门ID:" + openDoorIDTextField.getText() + "\r\n";
						
					adminNumTextField.setText(""+adminNum);
					adminInfoTextArea.setText(adminInfo);
					
					
					this.setVisible(false);
					
				}	
				adminIDTextField.setText("");
				openDoorIDTextField.setText("");
				
				qianjiDemo.instanceFrame.setBounds(200, 200, 800, 600);				
				AdminDownLoadDlg.getInstance().setVisible(true);
				
			
			}
			
		}
		else if (cmd.equals(ADD_CANCEL_BUTTON_CMD))
		{
			adminIDTextField.setText("");
			openDoorIDTextField.setText("");
			this.setVisible(false);
		}
		
	}

}
