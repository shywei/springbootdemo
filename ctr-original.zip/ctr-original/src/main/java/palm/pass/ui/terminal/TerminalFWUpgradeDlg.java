package palm.pass.ui.terminal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import palm.pass.function.TerminalFlowFunction;

public class TerminalFWUpgradeDlg extends JDialog implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6852211023561741248L;

	public String title = "固件升级";

	public static TerminalFWUpgradeDlg dlg;

	public static String UPGRADE_OK_BUTTON_CMD = "AddOK";
	public static String UPGRADE_CANCEL_BUTTON_CMD = "AddCanel";
	public static String UPGRADE_FILE_CHOOSE = "fileChoose";

	JButton okButton;
	JButton cancelButton;

	JTextField numberTextField;
	JComboBox<String> typeComboBox;
	String[] value = { "门禁考勤一体机", "消费机", "自助机" };

	JComboBox<String> modelComboBox;
	String[] modelValue = { "PSN900", "PSN900Lite" };

	JTextField ipTextField;
	JTextField portTextField;
	JTextField pwdTextField;

	JFileChooser fileChooser;
	JTextField fileTextField;
	JButton fileButton;

	public static TerminalFWUpgradeDlg getInstance() {
		if (dlg == null) {
			dlg = new TerminalFWUpgradeDlg();
		}
		return dlg;
	}

	private TerminalFWUpgradeDlg() {

		setTitle(title);
		setLayout(null);
		setModal(true);
		setResizable(false);

		setBounds(350, 250, 450, 420);

		JLabel userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 20));
		userLabel.setText("编号:");
		userLabel.setBounds(20, 20, 109, 30);
		add(userLabel);

		numberTextField = new JTextField();
		numberTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		numberTextField.setText("");
		numberTextField.setBounds(130, 20, 300, 30);
		add(numberTextField);

		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 20));
		userLabel.setText("类型:");
		userLabel.setBounds(20, 60, 109, 30);
		add(userLabel);

		typeComboBox = new JComboBox<String>();
		for (int i = 0; i < value.length; i++) {
			typeComboBox.addItem(value[i]);
		}
		typeComboBox.setFocusable(false);
		typeComboBox.setFont(new java.awt.Font("宋体", 0, 20));
		typeComboBox.setBounds(130, 60, 300, 30);
		add(typeComboBox);

		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 20));
		userLabel.setText("型号:");
		userLabel.setBounds(20, 100, 109, 30);
		add(userLabel);

		modelComboBox = new JComboBox<String>();
		for (int i = 0; i < modelValue.length; i++) {
			modelComboBox.addItem(modelValue[i]);
		}
		modelComboBox.setFocusable(false);
		modelComboBox.setFont(new java.awt.Font("宋体", 0, 20));
		modelComboBox.setBounds(130, 100, 300, 30);
		add(modelComboBox);

		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 20));
		userLabel.setText("IP:");
		userLabel.setBounds(20, 140, 109, 30);
		add(userLabel);

		ipTextField = new JTextField();
		ipTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		ipTextField.setText("");
		ipTextField.setBounds(130, 140, 300, 30);
		add(ipTextField);

		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 20));
		userLabel.setText("端口:");
		userLabel.setBounds(20, 180, 109, 30);
		add(userLabel);

		portTextField = new JTextField();
		portTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		portTextField.setText("");
		portTextField.setBounds(130, 180, 300, 30);
		add(portTextField);

		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 20));
		userLabel.setText("连接密码:");
		userLabel.setBounds(20, 220, 109, 30);
		add(userLabel);

		pwdTextField = new JTextField();
		pwdTextField.setFont(new java.awt.Font("宋体", 0, 20)); // NOI18N
		pwdTextField.setText("");
		pwdTextField.setBounds(130, 220, 300, 30);
		add(pwdTextField);

		userLabel = new JLabel();
		userLabel.setFont(new java.awt.Font("宋体", 0, 19));
		userLabel.setText("文件选择:");
		userLabel.setBounds(20, 260, 109, 30);
		add(userLabel);
		
		fileTextField = new JTextField();
		fileTextField.setFont(new java.awt.Font("宋体", 0, 15)); // NOI18N
		fileTextField.setText("");
		fileTextField.setBounds(130, 260, 220, 30);
		add(fileTextField);
		
		
		fileButton = new JButton();
		fileButton.setText("文件");
		fileButton.setBounds(350, 260, 80, 30);
		fileButton.setActionCommand(UPGRADE_FILE_CHOOSE);
		fileButton.addActionListener(this);
		fileButton.setFont(new java.awt.Font("宋体", 0, 15));
		add(fileButton);
		

		okButton = new JButton();
		okButton.setText("确定");
		okButton.setBounds(50, 310, 150, 50);
		okButton.setActionCommand(UPGRADE_OK_BUTTON_CMD);
		okButton.addActionListener(this);
		okButton.setFont(new java.awt.Font("宋体", 0, 30));
		add(okButton);

		cancelButton = new JButton();
		cancelButton.setText("取消");
		cancelButton.setBounds(250, 310, 150, 50);
		cancelButton.setActionCommand(UPGRADE_CANCEL_BUTTON_CMD);
		cancelButton.addActionListener(this);
		cancelButton.setFont(new java.awt.Font("宋体", 0, 30));
		add(cancelButton);

		fileChooser = new JFileChooser();
	    FileNameExtensionFilter filter = new FileNameExtensionFilter(
	            "tar.gz", "gz");
	    fileChooser.setFileFilter(filter);

	}

	
	/** 
	     * NIO way 
	     * @param filename 
	     * @return 
	     * @throws IOException 
	     */  
	   public static byte[] toByteArray2(String filename)throws IOException{  
	          
	        File f = new File(filename);  
	        if(!f.exists()){  
	            throw new FileNotFoundException(filename);  
	        }  
	          
	        FileChannel channel = null;  
	        FileInputStream fs = null;  
	        try{  
	            fs = new FileInputStream(f);  
	            channel = fs.getChannel();  
	            ByteBuffer byteBuffer = ByteBuffer.allocate((int)channel.size());  
	            while((channel.read(byteBuffer)) > 0){  
	                // do nothing  
	//              System.out.println("reading");  
	            }  
	            return byteBuffer.array();  
	        }catch (IOException e) {  
	            e.printStackTrace();  
	            throw e;  
	        }finally{  
	            try{  
	                channel.close();  
	            }catch (IOException e) {  
	                e.printStackTrace();  
	            }  
	            try{  
	                fs.close();  
	            }catch (IOException e) {  
	               e.printStackTrace();  
	            }  
	        }  
	    }  

	@Override
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub

		String cmd = event.getActionCommand();

		if (cmd == null || cmd.length() == 0) {
			return;
		}

		if (cmd.equals(UPGRADE_OK_BUTTON_CMD)) {
			

			try {
				byte[] fileData =	toByteArray2(fileChooser.getSelectedFile().getPath());
				
				System.out.println("file len:"+fileData.length);
				
				TerminalFlowFunction function = new TerminalFlowFunction();	
				
				String terminalIP = ipTextField.getText();
				int port = Integer.valueOf(portTextField.getText());
				long number = Integer.valueOf(numberTextField.getText());
				
				byte[] pwd = pwdTextField.getText().getBytes(); 
				
				int type = typeComboBox.getSelectedIndex(); 
				int model = modelComboBox.getSelectedIndex();
			
				
				int ret = function.deviceUpgrade(terminalIP , port , number,type , model,pwd ,fileData.length , fileData);
				
				JOptionPane.showMessageDialog(null, "终端远程升级: "+ ret );
				
				this.setVisible(false);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} else if (cmd.equals(UPGRADE_CANCEL_BUTTON_CMD)) {
			this.setVisible(false);
		}
		else if (cmd.equals(UPGRADE_FILE_CHOOSE)){
			
			int intRetVal = fileChooser.showOpenDialog(this);
			if (intRetVal == JFileChooser.APPROVE_OPTION) {
				fileTextField.setText(fileChooser.getSelectedFile().getPath());
		
			}
		}
	}

}
