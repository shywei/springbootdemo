package palm.pass.ui;

import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;

public class qianjiDemo  extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4277304938706192478L;
	private JTabbedPane jTabbedpane = new JTabbedPane();// 存放选项卡的组件
	private String[] tabNames = { "服务器管理", "终端管理" };
	
	public static JFrame instanceFrame;

	public qianjiDemo(JFrame frame) {
		instanceFrame = frame;
		layoutComponents();
	}

	private void layoutComponents() {
		
		
		int i = 0;
		// 第一个标签下的JPanel
		ServerAPIPanel jpanelFirst = ServerAPIPanel.getInstatnce();
	
		jTabbedpane.addTab(tabNames[i++], null, jpanelFirst, "first");// 加入第一个页面
		jTabbedpane.setFont(new Font("微软雅黑",0,30));
	
		// 第二个标签下的JPanel
		TerminalAPIPanel jpanelSecond =  TerminalAPIPanel.getInstatnce();
		jTabbedpane.addTab(tabNames[i++], null, jpanelSecond, "second");// 加入第一个页面
		
		setLayout(new GridLayout(1, 1));
		add(jTabbedpane);

	}


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
//        System.out.println(System.getProperty("java.library.path")); 
//        System.out.println(System.getProperty("java.class.path")); 
        
		SwingUtilities.invokeLater(new Runnable() {

			public void run() {
				//JFrame.setDefaultLookAndFeelDecorated(true);// 将组建外观设置为Java外观
				JFrame frame = new JFrame();
				frame.setLayout(null);
				frame.setContentPane(new qianjiDemo(frame));
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setBounds(200, 200, 800, 600);
				frame.setVisible(true);
				frame.setResizable(false);
				frame.setTitle("千机例程");
				
			}
		});
	}

}