package com.jschange.ctr.model;

public class Drop {
	
	private int deleted;//离队人数
	
	private int inuser;//在队人数
	
	private String depName;
	
	private Integer code;
	
	public int getDeleted() {
		return deleted;
	}

	public void setDeleted(int deleted) {
		this.deleted = deleted;
	}

	public int getInuser() {
		return inuser;
	}

	public void setInuser(int inuser) {
		this.inuser = inuser;
	}

	public String getDepName() {
		return depName;
	}

	public void setDepName(String depName) {
		this.depName = depName;
	}

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	
	
}
