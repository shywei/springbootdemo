package com.jschange.ctr.model;

import java.io.Serializable;

public class CouldAttendUsr implements Serializable {	
	private Integer id;
	private String userid;//身份ID
	private String deptName;//部门名称
	private String photoUrl;//图片路径
	private String userName;//用户姓名
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getPhotoUrl() {
		return photoUrl;
	}
	public void setPhotoUrl(String photoUrl) {
		this.photoUrl = photoUrl;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
	public CouldAttendUsr() {
		
	}
	public CouldAttendUsr(Integer id, String userid, String deptName, String photoUrl, String userName) {
		this.id = id;
		this.userid = userid;
		this.deptName = deptName;
		this.photoUrl = photoUrl;
		this.userName = userName;
	}
	
	

	
}
