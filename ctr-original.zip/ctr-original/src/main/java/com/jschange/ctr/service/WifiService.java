package com.jschange.ctr.service;


import java.util.Map;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.model.WiFiDriviceModel;

public interface WifiService {

	ResultList<WiFiDriviceModel> queryWifiListByPage(Map<String, Object> map, Pagination page);

	Integer insertWifi(WiFiDriviceModel wifi);

	Integer updateWifi(WiFiDriviceModel wifi);

	Integer deleteWifi(String ids, Integer userid);
	
	WiFiDriviceModel getWiFiInfoByID(Integer id);


}
