package com.jschange.ctr.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.deser.Deserializers.Base;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.SystemUser;
import com.jschange.ctr.service.ChangeReviseStateService;
import com.jschange.ctr.service.OperationLogService;


@Controller
@RequestMapping("/ChangeReviseStateController")
public class ChangeReviseStateController extends BaseController{

	private static final int Object = 0;

	@Autowired
	private ChangeReviseStateService service;

	@Autowired
	private OperationLogService operationLogService;
	
	private OperationLog operationLog=new OperationLog();

	
	/**
	 * 部门调度按钮（将人员状态改为调队中、接收部门改为即将要去的部门）
	 * @param response
	 * @param ids 需要调度的人员编号，拼接
	 * @param reviseState 调队中传 1
	 * @param deptId 需要调入的部门
	 * @param fingerDevID 设备ID
	 * @return
	 */
	@RequestMapping("/readyChangeDept")
	@ResponseBody
	public ResultModel readyChangeDept(HttpServletResponse response,HttpServletRequest request,
			String ids,String reviseState ,String deptId,String currentId,String fingerDevID) {
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel rs=new ResultModel();
		Map<String, Object> map = new HashMap<String, Object>();
		//插入操作日志
		String sysIp=super.getIP(request);//获取登陆IP
		SystemUser user=operationLogService.queryCurrentUser(currentId);//获取当前登录人员信息
		operationLog.setOperationPersonnel(user.getUserName());
		operationLog.setDeptid(user.getDeptid().toString());
		operationLog.setOperationIP(sysIp);
		map.put("logUserDept", user.getDeptName());
		if(null != fingerDevID){
			map.put("fingerDevID", fingerDevID);
		}else{
			rs.setCode(-1);
			rs.setMessage("请选择一台需要调入的掌静脉设备！");
			return rs;
		}
		if(user.getDeptid()==Integer.parseInt(deptId)){
			rs.setCode(-1);
			rs.setMessage("不可将本队人员调入本队！");
			return rs;
		}
		if (null != ids && !"".equals(ids)) {
			String[] array=ids.split(",");
			map.put("array", array);
			for(int i=0;i<array.length;i++){
				//查询人员当前状态
				Integer state=service.queryRCUserInfoStateById(array[i]);
				if(state!=null){
					if(state==1){//处于调队中
						rs.setCode(-2);
						rs.setMessage("处于调队中的人员不可再进行调队！");
						return rs;
					}
				}
				//人员已经离队不能再调队
				Integer del=service.queryIsDel(array[i]);
				if(del==1){//已经被删除
					rs.setCode(-3);
					rs.setMessage("离队人员不能进行调队！");
					return rs;
				}
				
			}
		} else {
			rs.setCode(-3);
			rs.setMessage("请选择要操作的数据！");
			return rs;
		}
		if (null != deptId && !"".equals(deptId)) {
			map.put("receiveDeptId", deptId);
		}
		if (null != reviseState && !"".equals(reviseState)) {
			map.put("reviseState", reviseState);
		} else {
			rs.setCode(-4);
			rs.setMessage("请选择要操作的类型！");
			return rs;
		}
		Integer i=service.readyChangeDept(map,operationLog);
		rs.setCode(i);
		return rs;
	}
	
	
	/**
	 * 修改人员调队状态(驳回/接收)
	 * @param response
	 * @param ids
	 * @param note
	 * @param reviseState 
	 * @param deptId
	 * @return
	 */
	@RequestMapping("/updateRCUserInfoState")
	@ResponseBody
	public ResultModel updateRCUserInfoState(HttpServletResponse response, HttpServletRequest request,
			String ids,String note, String reviseState ,String deptId,String currentId) {
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		//插入操作日志
		String sysIp=super.getIP(request);//获取登陆IP
		SystemUser user=operationLogService.queryCurrentUser(currentId);//获取当前登录人员信息
		operationLog.setOperationPersonnel(user.getUserName());
		operationLog.setDeptid(user.getDeptid().toString());
		operationLog.setOperationIP(sysIp);
		ResultModel rs=new ResultModel();
		Map<String, Object> map = new HashMap<String, Object>();
		if (null != ids && !"".equals(ids)) {
			map.put("ids", ids);
		} else {
			rs.setCode(-3);
			rs.setMessage("请选择要操作的数据！");
			return rs;
		}
		if (null != note && !"".equals(note)) {
			map.put("note", note);
		}
		if (null != deptId && !"".equals(deptId)) {
			map.put("deptId", deptId);
		}
		if (null != reviseState && !"".equals(reviseState)) {
			map.put("reviseState", reviseState);
		} else {
			rs.setCode(-4);
			rs.setMessage("请选择要操作的类型！");
			return rs;
		}
		  Object obj =  service.updateRCUserInfoState(map,operationLog);
		  if(obj==(Object)(-10)){
			  rs.setMessage("该指静脉状态不可用！");
		  }else if(obj==(Object)(-9)){
			  rs.setMessage("指静脉设备人员调动失败！");
		  }else if(obj==(Object)(-8)){
			  rs.setMessage("指静脉设备人员下发失败！接收人员失败!");
		  }else if(obj==(Object)(-7)){
			  rs.setMessage("该指静脉状态不可用！");
		  }else if(obj==(Object)(-2) || obj==(Object)(-3)){
			  rs.setMessage("未知原因，操作失败！");
		  }else{
			  rs.setObj(obj);
		  }
		  return rs;
	}
	

	/**
	 * 撤回调队人员
	 * @param response
	 * @param ids
	 * @return
	 */
	@RequestMapping("/recallChangeDeptUser")
	@ResponseBody
	public ResultModel recallChangeDeptUser(HttpServletResponse response,HttpServletRequest request,
			String ids,String currentId,String userNames) {
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel rs=new ResultModel();
		Map<String, Object> map = new HashMap<String, Object>();
		//插入操作日志
		String sysIp=super.getIP(request);//获取登陆IP
		SystemUser user=operationLogService.queryCurrentUser(currentId);//获取当前登录人员信息
		operationLog.setOperationPersonnel(user.getUserName());
		operationLog.setDeptid(user.getDeptid().toString());
		operationLog.setOperationIP(sysIp);
		if(null != ids && !"".equals(ids) ){
			map.put("ids", ids);
		}
		Integer i=service.recallChangeDeptUser(map,operationLog);
		rs.setCode(i);
		return rs;
	}
	
	
	
	
}

