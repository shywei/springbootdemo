package com.jschange.ctr.service.impl;

import java.rmi.ServerException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.common.ResultListImpl;
import com.jschange.ctr.dao.OperationLogMapper;
import com.jschange.ctr.dao.ServerMapper;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.Server;
import com.jschange.ctr.service.ServerService;

import palm.pass.function.ServerFlowFunction;
import palmpass.server.SocketFunction;
@Service
public class ServerServiceImpl implements ServerService{

	@Autowired
	private ServerMapper serverMapper;
	
	@Autowired
	private OperationLogMapper operationLogMapper;
	
	private static ServerFlowFunction function = new ServerFlowFunction();
	
	
	//检查比对服务器
	@Override
	public Integer checkContrastServer(Server server) throws ServerException {
		try {
			//注册认证服务器，通过富士通接口认证该服务器状态
			int states=function.GetServerStateFunction(server.getServerIP());
			if(states==0){//服务器连接正常，添加到本地数据库中
				int sta=function.ConfigServerFunction(server.getServerIP(), server.getIdentifyPrecision());
				if(sta==0){
					return 0;
				}else{
					return sta;
				}
			}else{
				return states;
			}
		} catch (Exception e) {
			return -1;
		}
	}
	
	//注册数据服务器
	@Override
	public Integer insertServer(Server server,OperationLog operationLog) throws ServerException {
		try {
			Integer i=serverMapper.checkIP(server);
			if(i>0){//同类型IP地址已经存在
				return -2;
			} 
			Integer states=serverMapper.insertServer(server);
			if(server.getServerType()==1){//注册的服务器为比对服务器，添加操作日志
				operationLog.setOperationType(3);//比对服务器
				operationLog.setOperationContext("注册比对服务器"+server.getServerIP()+"成功！");
				operationLogMapper.insertOperationLog(operationLog);
			}
			operationLog.setOperationContext("注册应用服务器"+server.getServerIP()+"成功！");
			operationLogMapper.insertOperationLog(operationLog);
			return states;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//添加失败
	}

	
	
	@Override
	public ResultList<Server> queryServerList(Map<String, Object> map, Pagination page) throws ServerException {
		try {
			if(null != page ){
				int totalCount =serverMapper.countServerNum(map);
				page.setTotalCount(totalCount);
				map.put("page", (page.getCurrentPage()-1)*page.getPageSize());
				map.put("rows",page.getPageSize());
			}
			List<Server> list=serverMapper.queryServerList(map);
			ResultList<Server> rl=new ResultListImpl<>();
			rl.setResults(list);
			return rl;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public Integer updateServer(Server server) throws ServerException {
		try {
			Integer i=serverMapper.checkIP(server);
			if(i>0){//同类型IP地址已经存在
				return -2;
			}
			Map<String, Object> map=new HashMap<>();
			map.put("serverid", server.getServerid());
			map.put("serverIP", server.getServerIP());
			int count=serverMapper.checkServerInUse(map);
			if(count>0){//已有设备绑定该服务器，不可操作
				return -1;
			}
			return serverMapper.updateServer(server);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -3;//修改失败
	}

	@Override
	public Integer delServer(Map<String, Object> map) throws SQLException {
		try {
			int count=serverMapper.checkServerInUse(map);
			if(count>0){
				return -1;
			}
			return serverMapper.delServer(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -2;
	}




	

}
