package com.jschange.ctr.service;

import java.util.List;

import com.jschange.ctr.model.Area;

public interface AreaService {

	public List<Area> areaList();//获取区域列表
}
