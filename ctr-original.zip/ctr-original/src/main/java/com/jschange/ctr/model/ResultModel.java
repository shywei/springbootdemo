package com.jschange.ctr.model;

public class ResultModel {
	
	private int code;
	
	private String message;
	
	private Object obj;
	
	private Object objExt;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getObj() {
		return obj;
	}

	public void setObj(Object obj) {
		this.obj = obj;
	}

	public Object getObjExt() {
		return objExt;
	}

	public void setObjExt(Object objExt) {
		this.objExt = objExt;
	}
	
}
