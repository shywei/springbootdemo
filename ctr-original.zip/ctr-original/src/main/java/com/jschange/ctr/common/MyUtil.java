package com.jschange.ctr.common;

public class MyUtil {
	
	/**
	 * 计算 checksum 
	 * @param data 		需要计算 checksum 的数据主体
	 * @param offset	数据主体的偏移
	 * @param len		需要计算的长度
	 * @return			校验码
	 */
	public static int checkSum(byte[] data, int offset, int len) {
		int sum = 0;
		for (int i = 0; i < len; i++) {
		int temp = data[i + offset] & 0xff;
		sum += temp;
		}
		return sum % 256;
	}
	
}
