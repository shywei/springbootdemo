package com.jschange.ctr.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.jschange.ctr.model.AttendanceDataStatistics;
import com.jschange.ctr.model.DeptInfo;
import com.jschange.ctr.model.Drop;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.Role;
import com.jschange.ctr.service.StatisticsService;

@Controller
@RequestMapping("statistics")
public class StatisticsController extends BaseController {

	@Autowired
	StatisticsService statisticsService;
	
	private ResultModel result;

	/**
	 * 所有大队离队在队人数
	 * 
	 * @param response
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping("hasdeletedProportion")
	public Object hasdeletedProportion(HttpServletResponse response, HttpServletRequest request, String startTime,
			Integer depId,Integer roleid) {
		response.setHeader("Access-Control-Allow-Origin", "*");

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

		if ("".equals(startTime) || startTime == null || startTime == "undefined") {
			startTime = sdf.format(new Date());
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("startTime", startTime);
		map.put("roleid", roleid);
		// 离队人数和在队人数
		List<Drop> dropList = statisticsService.selectsumhasdeleted(map, depId);
		// List<DeptTotal> attendanceList = new ArrayList<DeptTotal>();
		// attendanceList.add(new DeptTotal("离队人数",hasdeletedsum));
		// attendanceList.add(new DeptTotal("在队人数",inuser));
		//
		// return JSON.toJSON(attendanceList);
		response.setCharacterEncoding("utf-8");
		return JSON.toJSON(dropList);
	}

	/**
	 * 大队考勤数据
	 * 
	 * @param response
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/attendanceProportion")
	public Object attendanceProportion(HttpServletResponse response, HttpServletRequest request, String startTime,
			Integer code) {
		response.setHeader("Access-Control-Allow-Origin", "*");
		Map<String, Object> map = new HashMap<String, Object>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		if ("".equals(startTime) || startTime == null || startTime == "undefined") {
			startTime = sdf.format(new Date());
		}
		map.put("startTime", startTime);
		map.put("deptid", code);

		List<AttendanceDataStatistics> ads = statisticsService.selectSumAttendnum(map);
		for (AttendanceDataStatistics attendanceDataStatistics : ads) {
			// int i = attendanceDataStatistics.getTime().length()-2;
			// System.err.println(i);
			attendanceDataStatistics.setEndtime(attendanceDataStatistics.getEndtime().substring(0, 19));
		}

		response.setCharacterEncoding("utf-8");
		return JSON.toJSON(ads);

	}
	
	/**
	 * 账号角色列表
	 * @param request
	 * @param response
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryRole")
	public ResultModel queryRole(HttpServletRequest request,HttpServletResponse response){
		response.setHeader("Access-Control-Allow-Origin", "*");
		result = new ResultModel();
		List<Role> list = statisticsService.queryRole();
		result.setObj(list);
		return result;
	}
	
	/**
	 * 根据账号的权限显示列表
	 * @param request
	 * @param response
	 * @return
	 */
	@ResponseBody
	@RequestMapping("deptListByRole")
	public ResultModel deptListByRole(HttpServletRequest request,HttpServletResponse response,Integer code,Integer deptid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		result = new ResultModel();
		List<DeptInfo> list = statisticsService.deptListByRole(code,deptid);
		result.setObj(list);
		return result;
	}
}
