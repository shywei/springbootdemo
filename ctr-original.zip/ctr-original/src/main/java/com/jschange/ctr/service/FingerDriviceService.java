package com.jschange.ctr.service;



import java.util.List;
import java.util.Map;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.Area;
import com.jschange.ctr.model.Department;
import com.jschange.ctr.model.FingerDrivice;
import com.jschange.ctr.model.Server;
import com.jschange.ctr.model.WiFiDriviceModel;



public interface FingerDriviceService {
	public ResultList<FingerDrivice> queryDriviceList(Map<String, Object> map,Pagination page)throws ServiceException;//分页查询指静脉设备信息列表
	
	public FingerDrivice queryDriviceById(Integer mesID)throws ServiceException;//根据指静脉设备id查询设备信息
	
	public Integer updateDrivice(FingerDrivice driviceModel) throws ServiceException;//修改设备信息

	public Integer chenckDriviceID(FingerDrivice fingerDrivice)throws ServiceException;//查重设备信息

	public Integer insertDrivice(FingerDrivice fingerDrivice)throws ServiceException;//添加设备信息

	public int deleteDrivice(Integer id)throws ServiceException;//删除设备信息
	
	public List<FingerDrivice> queryDriviceListCanBeUsed(Map<String, Object> map)throws ServiceException;//查询可用设备，map中可存放查询参数：ownerID：持有人（登录用户）id，areaID：监区id，driviceType:设备类型0固定版1移动版

	public List<Department> deptList()throws ServiceException;//选择区域部门信息

	public WiFiDriviceModel queryWifiInfoByWifiID(Integer wifiID)throws ServiceException;//根据wifi的id查找绑定的wifi信息

	public Server queryServerInfoByseverID(Integer severID)throws ServiceException;//根据服务器的id查找绑定的服务器信息

	public int bingNet(Map<String, Object> map)throws ServiceException;//绑定wifi信息和服务器信息

	public List<WiFiDriviceModel> queryWifiInfoCanBeUsed()throws ServiceException;//查询可用的WiFi信息列表

	public List<Server> queryServerCanBeUsed()throws ServiceException;//查询可用的服务器信息列表

	

}
