package com.jschange.ctr.dao;

import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.Menu;
import com.jschange.ctr.model.Model;
import com.jschange.ctr.model.SystemUser;

public interface UserAuthorityMapper {
	
	//查询模块集合
	public List<Model> getModelList(Map<String,Object> param);
	//查询模块数量
	public int getModelCount(Map<String,Object> param);
	//添加模块前查询模块名称是否存在
	public int checkAddModel(Model model);
	//添加模块
	public int addModel(Model model);
	//添加菜单前查询菜单名称是否存在
	public int checkAddMenu(Model model);
	//添加菜单
	public int addMenu(Model menu);
	//修改模块前查询模块名称是否存在
	public int checkUpdateModel(Model model);
	//修改模块
	public int updateModel(Model model);
	//批量删除模块之删除模块表
	public int delModel(String id);
	//批量删除模块之删除帐号模块中间表
	public int delUserModel(String id);
	//根据模块id查询模块名称
	public String getModelNameById(String id);
	//根据账号id查询菜单栏
	public List<Menu> getMenuById(String id);
	//根据菜单id、账号id查询模块
	public List<Model> getModelByMenuIdAndId(Map<String,Object> param);
	//查询属于该角色的帐号集合(权限分配)
	public List<SystemUser> getSystemUserByRoleId(String id);
	//查询菜单集合
	public List<Menu> getMenuList();
	//根据菜单id查询模块(权限分配)
	public List<Model> getModelByMenuId(Integer id);
	//根据角色id查询模块集合(权限分配)
	public List<Model> getModelByRoleId(String id);
	//根据账号id查询模块集合(权限分配)
	public List<Model> getModelById(String id);
	//修改角色权限之删除原有权限(权限分配)
	public int delRoleAuthority(String id);
	//修改角色权限之添加新权限(权限分配)
	public int addRoleAuthority(Map<String,Object> param);
	//修改该角色下的帐号权限之删除原有角色权限(权限分配)
	public int delUserOfRole(String id);
	//根据角色id查询帐号id(权限分配)
	public List<String> getIdByRoleId(String id);
	//修改账号权限之删除原有权限(权限分配)
	public int delUserAuthority(String id);
	//修改账号权限之添加新权限(权限分配)
	public int addUserAuthority(Map<String,Object> param);
}
