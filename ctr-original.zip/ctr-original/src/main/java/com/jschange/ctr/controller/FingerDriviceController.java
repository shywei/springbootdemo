package com.jschange.ctr.controller;

import java.io.IOException;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jschange.ctr.common.Pagination;

import com.jschange.ctr.model.Department;
import com.jschange.ctr.model.FingerDrivice;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.Server;
import com.jschange.ctr.model.SystemUser;
import com.jschange.ctr.model.WiFiDriviceModel;
import com.jschange.ctr.service.FingerDriviceService;
import com.jschange.ctr.service.OperationLogService;
import com.sun.xml.fastinfoset.sax.Properties;

import util.Env;
import util.QJCmdSend;
import util.SocketMap;
import util.VenaMap;

/**
 * 指静脉设备
 * @author Administrator
 *
 */
@Controller
@RequestMapping("fingerDriviceController")
public class FingerDriviceController extends BaseController{
	
	private String port = Env.getInstance().getProperty("fingerDrivicePort");//从配置文件里获取设备端口号
	@Autowired
	private FingerDriviceService fingerDriviceService;
	
	@Autowired
	private OperationLogService operationLogService;
	

	private OperationLog operationLog=new OperationLog();
	
	
	/**
	 * 根据条件和分页查询设备信息列表
	 * @param response
	 * @param request
	 * @param driviceID
	 * @param driviceName
	 * @param serverIP
	 * @param wifiName
	 * @param status
	 * @param driviceState
	 * @param ownerName
	 * @param areaID
	 * @param workingStation
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryDriviceList")
	public ResultModel queryDeviceList(HttpServletResponse response,HttpServletRequest request,
			String driviceID,String driviceName,String serverIP,String wifiName,
			Integer status,Integer driviceState,String ownerName, Integer driviceType,Integer areaID,Integer currentId,String workingStation){
		
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		Pagination page = getPage();
		System.err.println(page.getCurrentPage()+"!!!"+page.getPageSize());

		ResultModel resultModel = new ResultModel();
		Map<String, Object> param = new HashMap<String, Object>();
		
		try {
			if(driviceID!=null && !"".equals(driviceID)){//设备编号（非主键ID）
				param.put("driviceID", driviceID);	
			}
			if(driviceName!=null && !"".equals(driviceName)){//设备名称
				param.put("driviceName", driviceName);	
			}
			if(serverIP!=null && !"".equals(serverIP)){//服务器ip地址
				param.put("seriviceIP", serverIP);	
			}
			if(wifiName!=null && !"".equals(wifiName)){//wifi名称
				param.put("wifiName", wifiName);	
			}
			if(status!=null ){//设备在线状态
				param.put("status", status);	
			}
			if(driviceState!=null){//设备状况
				param.put("driviceState", driviceState);	
			}
			if(ownerName!=null){//持有人的userid
				param.put("ownerName", ownerName);	
			}
			if(areaID!=null){//监区id
				param.put("areaID", areaID);	
			}
			if(workingStation!=null){//工位编码
				param.put("workingStation", workingStation);	
			}
			if(driviceType !=null){
				param.put("driviceType",driviceType);
			}
			if(currentId !=null){
				param.put("ownerID",currentId);
			}

			
			List<FingerDrivice> list=fingerDriviceService.queryDriviceList(param, page).getResults();

			resultModel.setObjExt(page);
			resultModel.setObj(list);
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
		
	}
	
	/**
	 * 根据id查询设备
	 * @param response
	 * @param request
	 * @param mesID
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryDriviceById")
	public ResultModel queryDriviceById(HttpServletResponse response,HttpServletRequest request,Integer mesID){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel resultModel = new ResultModel();
		try{
			FingerDrivice fingerDrivice=fingerDriviceService.queryDriviceById(mesID);
			resultModel.setObj(fingerDrivice);
		}catch(Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		
		return resultModel;
	}
	
	/**
	 * 保存设备信息
	 * @param response
	 * @param request
	 * @param fingerDrivice
	 * @param currentId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("saveDrivice")
	public ResultModel updateDrivice(HttpServletResponse response,HttpServletRequest request,FingerDrivice fingerDrivice,Integer currentId){
		
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel resultModel = new ResultModel();
		System.err.println(fingerDrivice.getWorkingStation()+"WorkingStation");
		try{
			System.err.println("currentId"+currentId);
			String sysIp=super.getIP(request);//获取登陆IP
			SystemUser user=operationLogService.queryCurrentUser(currentId+"");//获取当前登录人员信息
			operationLog.setOperationPersonnel(user.getUserName());
			operationLog.setDeptid(user.getDeptid().toString());
			operationLog.setOperationIP(sysIp);
			
			
			if(fingerDrivice.getId()!=null && fingerDrivice.getId()>0){//id>0，执行修改方法
				int j=fingerDriviceService.chenckDriviceID(fingerDrivice);//查看设备编号（非主键ID）是否有相同
				System.err.println("修改的driviceID="+fingerDrivice.getDriviceID()+"个数="+j);
				if(j>0){
					resultModel.setCode(1);
					resultModel.setMessage("设备编号不可重复！");
					System.err.println("！！！修改的driviceID="+fingerDrivice.getDriviceID()+"个数="+j);
					return resultModel;
				}
					fingerDrivice.setModifyID(currentId);
					int i=fingerDriviceService.updateDrivice(fingerDrivice);
					resultModel.setCode(0);
					resultModel.setMessage("设备信息修改成功！");
					operationLog.setOperationContext("修改"+fingerDrivice.getDriviceName()+"指静脉设备信息");
					operationLogService.insertOperationLog(operationLog);
					return resultModel;
				

			}else {
				int j=fingerDriviceService.chenckDriviceID(fingerDrivice);//查看设备编号（非主键ID）是否有相同
				System.err.println("添加的driviceID="+fingerDrivice.getDriviceID()+"个数="+j);
				if(j>0){
					resultModel.setCode(1);
					resultModel.setMessage("设备编号不可重复！");
					return resultModel;
				}
				fingerDrivice.setCreateID(currentId);
				int i=fingerDriviceService.insertDrivice(fingerDrivice);
				resultModel.setCode(0);
				resultModel.setMessage("设备信息添加成功！");
				operationLog.setOperationContext("添加"+fingerDrivice.getDriviceName()+"指静脉设备信息");
				operationLogService.insertOperationLog(operationLog);
				return resultModel;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;

	}
	
	/**
	 * 删除设备信息
	 * @param response
	 * @param request
	 * @param mesIDs
	 * @param currentId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("deleteDrivice")
	public ResultModel deleteDrivice(HttpServletResponse response,HttpServletRequest request,String mesIDs,Integer currentId){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel resultModel = new ResultModel();
		//System.err.println(mesIDs);
		try{
			if(mesIDs !=null && !"".equals(mesIDs)){
				String sysIp=super.getIP(request);//获取登陆IP
				SystemUser user=operationLogService.queryCurrentUser(currentId+"");//获取当前登录人员信息
				operationLog.setOperationPersonnel(user.getUserName());
				operationLog.setDeptid(user.getDeptid().toString());
				operationLog.setOperationIP(sysIp);
				
				String[] ids=mesIDs.split(",");
				FingerDrivice fingerDrivice=new FingerDrivice();
				String driviceName=null;
				String driviceID=null;
				for(String mesID:ids){
					Integer id=Integer.parseInt(mesID);
					
					fingerDrivice=fingerDriviceService.queryDriviceById(id);
					//if(fingerDrivice.getDriviceName()!=null){
					//	driviceName=fingerDrivice.getDriviceName();
					//}
					if(fingerDrivice !=null){
						if(fingerDrivice.getDriviceID() !=null){
							driviceID=fingerDrivice.getDriviceID();
						}
					}
					int i=fingerDriviceService.deleteDrivice(id);
					//System.err.println("要删除的设备ID="+id+"!!!"+i);
					if(i>0){
						operationLog.setOperationContext("删除"+driviceID+"指静脉设备信息");//前端如需显示设备名称，则将driviceID换成driviceName即可
						operationLogService.insertOperationLog(operationLog);
					}
				}
				resultModel.setCode(0);
				resultModel.setMessage("删除成功");
				return resultModel;
			}
			else{
				resultModel.setCode(1);
				resultModel.setMessage("所选设备信息有误");
				return resultModel;
			}
		}catch(Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
			
		}
		return resultModel;
	}
	
	
	/**
	 * 绑定网络信息
	 * @param request
	 * @param response
	 * @param wifiID
	 * @param severID
	 * @param ids
	 * @param currentId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("bingNet")
	public ResultModel bingNet(HttpServletRequest request, HttpServletResponse response,Integer wifiID,Integer severID, String ids,Integer currentId){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel resultModel = new ResultModel();
		Map<String, Object> map = new HashMap<String, Object>();
		StringBuffer mesIDsCanBeBund=new StringBuffer();
		
		String sysIp=super.getIP(request);//获取登陆IP
		SystemUser user=operationLogService.queryCurrentUser(currentId+"");//获取当前登录人员信息
		operationLog.setOperationPersonnel(user.getUserName());
		operationLog.setDeptid(user.getDeptid().toString());
		operationLog.setOperationIP(sysIp);
		
		//拆分多台设备id所拼接出 的字符串
		if(ids !=null && !"".equals(ids) ){
			String[] mesids=ids.split(",");
			System.out.println(mesids.length+"8888888888888888");
			//判断前端返回的设备ids里是否存在停用或损坏或离线的情况，如果有，则返回给前端提示信息
			for(String checkID :mesids){
				Integer driviceId=Integer.parseInt(checkID);
				FingerDrivice fingerDrivice=fingerDriviceService.queryDriviceById(driviceId);	
				if(fingerDrivice !=null){
					if(fingerDrivice.getStatus()==1 ||fingerDrivice.getDriviceState()==2){
						resultModel.setCode(1);
						resultModel.setMessage(":所选设备中含有损坏或离线的设备，请重新选择！");
						return resultModel;
					}
				}else{
					resultModel.setCode(1);
					resultModel.setMessage(":所选设备信息异常，请联系管理员！");
					return resultModel;
				}
			}
			//查询要绑定的服务器信息信息是否正常
			Server serverInfo=fingerDriviceService.queryServerInfoByseverID(severID);
			if(serverInfo==null||serverInfo.getServerIP() ==null || serverInfo.getServerIP() ==null){
				resultModel.setCode(1);
				resultModel.setMessage("获取服务器数据异常");
				return resultModel;
			}
			//查询要绑定的wifi的名称和密码是否正常
			WiFiDriviceModel wifiDriviceModel= fingerDriviceService.queryWifiInfoByWifiID(wifiID);
			if(wifiDriviceModel ==null || wifiDriviceModel.getWifiName() ==null ||wifiDriviceModel.getWifiPassWord() ==null || wifiDriviceModel.getStatus() !=0){
				resultModel.setCode(1);
				resultModel.setMessage("所选wifi信息有误");
				return resultModel;
			}
			// 端口号
			//String port="1400";
			if(port ==null || port.equals("")){
				resultModel.setCode(1);
				resultModel.setMessage("设备端口号信息错误");
				return resultModel;
			}
			byte[] tempPort = port.getBytes();
			byte[] serverPort = new byte[5];
			for (int i = 0; i < tempPort.length; i++) {
				serverPort[i] = tempPort[i];
			}
			
			//IP地址
			String IP=serverInfo.getServerIP();
			byte[] tempIP = IP.getBytes();//服务器地址,不变，从数据库中获取
			byte[] ip = new byte[15];
			for (int i = 0; i < tempIP.length; i++) {
				ip[i] = tempIP[i];
			}
		
			// WiFi账号
			String wifiName=wifiDriviceModel.getWifiName();
			byte[] tempWifiAccount = wifiName.getBytes();
			byte[] WifiAccount = new byte[32];
			for (int i = 0; i < tempWifiAccount.length; i++) {
				WifiAccount[i] = tempWifiAccount[i];
			}
			
			// WiFi密码
			String wifiPassWord=wifiDriviceModel.getWifiPassWord();
			byte[] tempWifiPwd = wifiPassWord.getBytes();
			byte[] WifiPwd = new byte[32];
			for (int i = 0; i < tempWifiPwd.length; i++) {
				WifiPwd[i] = tempWifiPwd[i];
			}
			
			byte[] server = ArrayUtils.addAll(ip, serverPort);
			byte[] wifi = ArrayUtils.addAll(WifiPwd, WifiAccount);
			byte[] body = ArrayUtils.addAll(server, wifi);
			
			
			//遍历ids，对设备进行绑定操作
			for(String id:mesids){
				try{	
					
					Integer mesID=Integer.parseInt(id);
					// 获取所选机器的机器信息
					FingerDrivice fingerDrivice = fingerDriviceService.queryDriviceById(mesID);// 参数为所选设备ID
					// 将机器信息的ID赋值给key
					String key = fingerDrivice.getDriviceNo();
					if(key ==null || key ==""){
						resultModel.setCode(1);
						resultModel.setMessage("设备模块数据异常");
						return resultModel;
					}
					// 通过获取的key获取map集合中的特定socket
					Socket socket = VenaMap.venaMap.get(key);
					if(socket !=null && body !=null){
						QJCmdSend.send(socket, 0x8104, body);
					}
					String res = null;
					boolean flag=true;
					Long startTime = System.currentTimeMillis();//定义一个开始时间
					System.err.println("计时开始");
					while(flag){
						res=SocketMap.socketMap.get(socket);
						if(res !=null){
							if(res.equals("3")){//设备返回3，代表绑定成功，接下来则修改设备连接信息表
								mesIDsCanBeBund.append(id);
								mesIDsCanBeBund.append(",");
								flag=false;
							}
							else{
								flag=false;
							}
						}
						Long endTime = System.currentTimeMillis();//定义一个结束时间
						if(endTime-startTime>3000){//相减如果超过3秒仍未接收到设备的相应信息，则返回报错
							//System.err.println("超时提醒");
							resultModel.setCode(1);
							resultModel.setMessage(":与设备通信超时!设备编号:"+fingerDrivice.getDriviceID());
							return resultModel;
						}
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			//在数据库中批量修改设备的wifi和服务器信息
			String[] array = mesIDsCanBeBund.toString().split(",");
			Integer[] idArray = new Integer[array.length];
			for (int q = 0; q < array.length; q++) {
				try {
					int t = Integer.parseInt(array[q]);
					if (t > 0) {
						idArray[q] = t;
					}
				} catch (Exception e) {
				}
			}
			
			map.put("array", idArray);//设备id数组
			map.put("wifiID",wifiID);
			map.put("serviceID",severID);
			map.put("modifyID", currentId);
			
			// 在数据库中修改设备服务器ID
			int i = fingerDriviceService.bingNet(map);
			resultModel.setCode(0);
			resultModel.setObj(mesIDsCanBeBund);//这里放的是绑定成功的设备id主键
			resultModel.setMessage("绑定成功");
			operationLog.setOperationContext("绑定网络信息");
			operationLogService.insertOperationLog(operationLog);
			return resultModel;
		}else {
			resultModel.setCode(1);
			resultModel.setMessage(":参数缺失");
			return resultModel;
		}
	}

	/**
	 * 选择可用的设备下拉框
	 * @param response
	 * @param request
	 * @param areaID
	 * @param driviceType
	 * @param currentId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryDriviceListCanBeUsed")
	public List<FingerDrivice> queryDriviceListCanBeUsed(HttpServletResponse response,HttpServletRequest request,Integer deptID,Integer driviceType){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		
		Map<String,Object> map=new HashMap<String,Object>();
		if(deptID!=null){
		map.put("areaID", deptID);
		}
		if(driviceType!=null){
		map.put("driviceType", driviceType);
		}
		map.put("totalNum", 255);
		try{
			return fingerDriviceService.queryDriviceListCanBeUsed(map);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
		
		
	}
	
	
	/**
	 * 所在区域（部门）选择下拉框列表
	 * @param response
	 * @param request
	 * @param mesIDs
	 * @param currentId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("deptList")
	public List<Department> deptList(HttpServletResponse response,HttpServletRequest request,String mesIDs,Integer currentId){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		return fingerDriviceService.deptList();
	}
	
	/**
	 * 查询可用的wifi信息下拉框
	 * @param request
	 * @param response
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryWifiInfoCanBeUsed")
	public List<WiFiDriviceModel> queryWifiInfoCanBeUsed(HttpServletRequest request, HttpServletResponse response){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		return fingerDriviceService.queryWifiInfoCanBeUsed();

		
	}
	/**
	 * 查询可用的服务器列表
	 * @param request
	 * @param response
	 * @return
	 */
	@ResponseBody
	@RequestMapping("querySeverCanBeUsed")
	public List<Server> queryServerCanBeUsed(HttpServletRequest request, HttpServletResponse response){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("UTF-8");
		List<Server> list = fingerDriviceService.queryServerCanBeUsed();
		return list;
		
		
	}

	


}
