package com.jschange.ctr.common;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

@Service
public class SpringTool implements ApplicationContextAware{
	
	private static ApplicationContext applicationContext;
	
	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		if(SpringTool.applicationContext==null){
			SpringTool.applicationContext=applicationContext;
		}
		System.err.println("配置成功!~~~~~~~~");
	}
	
	public static ApplicationContext getApplicationContext() {  
        return applicationContext;  
    }
	
	//通过name获取bean
	public static Object getBean(String name) {  
        return getApplicationContext().getBean(name);  
    } 
	
	//通过class获取bean
	public static<T> T getBean(Class<T> clazz){
		return getApplicationContext().getBean(clazz);
	}
}	
