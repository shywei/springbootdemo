/**
 * 
 */
package com.jschange.ctr.common;

import com.jschange.ctr.common.Pagination;

import java.util.List;

/**
 * 持久化接口实现类
 * 
 * @author
 * 
 */
public class ResultListImpl<T> implements ResultList<T> {

	private static final long serialVersionUID = -4590321979224243763L;

	public ResultListImpl() {

	}

	/** 返回记录列表 */
	private List<T> results;

	/** 返回分页信息 */
	private Pagination page;

	public Pagination getPage() {
		return page;
	}

	public List<T> getResults() {
		return results;
	}

	public void setPage(Pagination page) {
		this.page = page;
	}

	public void setResults(List<T> results) {
		this.results = results;
	}

}
