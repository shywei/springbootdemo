package com.jschange.ctr.model;

import java.io.Serializable;
import java.util.Date;
/**
 * 指静脉设备
 * @author Administrator
 *
 */
public class FingerDrivice implements Serializable{
	private Integer id;//主键id
	private Integer createID;
    private Integer modifyID;
    private Date createDate;
    private Date modifyDate;
    private Integer isDeleted;//是否被删除
    
	private String driviceName;//设备名称
	private String  driviceNo;//设备编码
	private Integer serviceID;//链接的服务器ID
	private Integer wifiID;//链接的wifiID
	private Integer  status;//当前登录状态
	private Integer driviceState;//当前设备状态
	private String memoInfo;//备注信息
	private String driviceID;//设备编号
	private String seriviceIP;//设备连接的服务器IP地址
	private Integer port;//设备连接的服务器的端口号
	private String wifiName;//设备连接的wifi名称
	private String wifiPassWord;//设备连接WiFi的密码

	private Integer driviceType;//设备类型：0固定版1移动版
	private String areaID;//区域(所在部门)ID
	private String areaName;//区域（部门）名称
	private Integer ownerID;//持有人的userid
	private String ownerName;//持有人的姓名
	private String workingStation;//工位编码
	private Integer collectedNum;//已采集的人数
	private Integer occupyNum;//被占用采集的人数
	private Integer remainingNum;//剩余可采集人数（255-collectedNum-occupyNum）
	
	
	public Integer getRemainingNum() {
		if(collectedNum !=null && remainingNum !=null){
			return (255-this.collectedNum-this.occupyNum);
		}
		return remainingNum;
	}

	public void setRemainingNum(Integer remainingNum) {
		this.remainingNum = remainingNum;
	}

	public Integer getOccupyNum() {
		return occupyNum;
	}

	public void setOccupyNum(Integer occupyNum) {
		this.occupyNum = occupyNum;
	}

	public String getWorkingStation() {
		return workingStation;
	}

	public void setWorkingStation(String workingStation) {
		this.workingStation = workingStation;
	}
	
	public Integer getCollectedNum() {
		return collectedNum;
	}

	public void setCollectedNum(Integer collectedNum) {
		this.collectedNum = collectedNum;
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCreateID() {
		return createID;
	}

	public void setCreateID(Integer createID) {
		this.createID = createID;
	}

	public Integer getModifyID() {
		return modifyID;
	}

	public void setModifyID(Integer modifyID) {
		this.modifyID = modifyID;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getDriviceName() {
		return driviceName;
	}

	public void setDriviceName(String driviceName) {
		this.driviceName = driviceName;
	}

	public String getDriviceNo() {
		return driviceNo;
	}

	public void setDriviceNo(String driviceNo) {
		this.driviceNo = driviceNo;
	}

	public Integer getServiceID() {
		return serviceID;
	}

	public void setServiceID(Integer serviceID) {
		this.serviceID = serviceID;
	}
	
	public Integer getPort() {
		return port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}


	public Integer getWifiID() {
		return wifiID;
	}

	public void setWifiID(Integer wifiID) {
		this.wifiID = wifiID;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getDriviceState() {
		return driviceState;
	}

	public void setDriviceState(Integer driviceState) {
		this.driviceState = driviceState;
	}

	public String getMemoInfo() {
		return memoInfo;
	}

	public void setMemoInfo(String memoInfo) {
		this.memoInfo = memoInfo;
	}

	public String getDriviceID() {
		return driviceID;
	}

	public void setDriviceID(String driviceID) {
		this.driviceID = driviceID;
	}

	public String getSeriviceIP() {
		return seriviceIP;
	}

	public void setSeriviceIP(String seriviceIP) {
		this.seriviceIP = seriviceIP;
	}

	public String getWifiName() {
		return wifiName;
	}

	public void setWifiName(String wifiName) {
		this.wifiName = wifiName;
	}
	public String getWifiPassWord() {
		return wifiPassWord;
	}

	public void setWifiPassWord(String wifiPassWord) {
		this.wifiPassWord = wifiPassWord;
	}

	public Integer getDriviceType() {
		return driviceType;
	}

	public void setDriviceType(Integer driviceType) {
		this.driviceType = driviceType;
	}

	public Integer getOwnerID() {
		return ownerID;
	}

	public void setOwnerID(Integer ownerID) {
		this.ownerID = ownerID;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getAreaID() {
		return areaID;
	}

	public void setAreaID(String areaID) {
		this.areaID = areaID;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	
	
	
	
	

	

}
