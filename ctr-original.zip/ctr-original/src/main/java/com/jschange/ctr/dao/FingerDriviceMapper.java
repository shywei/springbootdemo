package com.jschange.ctr.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.Department;
import com.jschange.ctr.model.FingerDrivice;
import com.jschange.ctr.model.Server;
import com.jschange.ctr.model.WiFiDriviceModel;


public interface FingerDriviceMapper {
	public List<FingerDrivice> queryDriviceList(Map<String, Object> map)throws SQLException;//分页查询指静脉设备信息列表
	
	public Integer queryDriviceCount(Map<String, Object> map)throws SQLException;//查询指静脉设备的数量

	public FingerDrivice queryDriviceById(Integer mesID)throws SQLException;//根据指静脉设备id查询设备信息
	
	public Integer updateDrivice(FingerDrivice driviceModel)throws SQLException;//修改指静脉设备信息

	public Integer chenckDriviceID(FingerDrivice driviceModel)throws SQLException;//检查指静脉设备编号是否重复
	
	public Integer deleteDrivice(Integer id)throws SQLException;//删除指静脉设备信息

	public Integer insertDrivice(FingerDrivice fingerDrivice)throws SQLException;//添加指静脉设备信息

	public List<FingerDrivice> queryDriviceListCanBeUsed(Map<String, Object> map)throws SQLException;//查询可用设备，map中可存放查询参数：ownerID：持有人id，areaID：监区id，driviceType:设备类型0固定版1移动版

	public List<Department> deptList()throws SQLException;//查询区域部门信息

	public WiFiDriviceModel queryWifiInfoByWifiID(Integer wifiID)throws SQLException;//根据WiFiID查询wifi信息;

	public Server queryServerInfoByseverID(Integer severID)throws SQLException;//根据服务器ID查询服务器信息;

	public int bingNet(Map<String, Object> map)throws SQLException;//绑定服务器信息和WiFi;

	public List<WiFiDriviceModel> queryWifiInfoCanBeUsed()throws SQLException;//查询可用的WiFi信息列表

	public List<Server> queryServerCanBeUsed()throws SQLException;//查询可用的服务器信息列表
}
