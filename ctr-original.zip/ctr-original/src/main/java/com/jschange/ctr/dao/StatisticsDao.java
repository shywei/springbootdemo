package com.jschange.ctr.dao;

import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.AttendanceDataStatistics;
import com.jschange.ctr.model.DeptInfo;
import com.jschange.ctr.model.Role;

public interface StatisticsDao {

	List<DeptInfo> queryDeptList();

	int deletesum(Map<String, Object> map);

	int inusersum(Map<String, Object> map);

	List<AttendanceDataStatistics> selectSumAttendnum(Map<String, Object> map);

	List<Role> queryRole();

	List<DeptInfo> deptListByRole(Map<String, Object> map);

}
