package com.jschange.ctr.model;

public class ApplicationModel {
	private Integer applicationModel;//应用模式编号
	private String applicationModelName;//应用模式名称 门禁还是考勤
	public Integer getApplicationModel() {
		return applicationModel;
	}
	public void setApplicationModel(Integer applicationModel) {
		this.applicationModel = applicationModel;
	}
	public String getApplicationModelName() {
		return applicationModelName;
	}
	public void setApplicationModelName(String applicationModelName) {
		this.applicationModelName = applicationModelName;
	}
	

}
