package com.jschange.ctr.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.common.ResultListImpl;
import com.jschange.ctr.dao.OperationLogMapper;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.SystemUser;
import com.jschange.ctr.service.OperationLogService;


@Service("operationLogService")
public class OperationLogServiceImpl implements OperationLogService {
	
	@Autowired
	private OperationLogMapper operationLogMapper;
	

	@Override
	public ResultList<OperationLog> getOperationLogList(Map<String, Object> map, Pagination page) {
		try {
			if(null != page){
				int count=operationLogMapper.getOperationLogCount(map);
				page.setTotalCount(count);
				map.put("page",(page.getCurrentPage()-1)*page.getPageSize());
				map.put("rows",page.getPageSize());
			}
			List<OperationLog> list=operationLogMapper.getOperationLogList(map);
			ResultList<OperationLog> rl=new ResultListImpl<>();
			rl.setResults(list);
			rl.setPage(page);
			return rl;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public int insertOperationLog(OperationLog operationLog) {
		if(operationLog.getOperationType()==null){
			operationLog.setOperationType(2);
		}
		return operationLogMapper.insertOperationLog(operationLog);
	}


	@Override
	public String getName(String userid) {
		return operationLogMapper.getName(userid);
	}


	@Override
	public String getState(String stateId) {
		return operationLogMapper.getState(stateId);
	}

	@Override
	public SystemUser queryCurrentUser(String id) {
		return operationLogMapper.queryCurrentUser(id);
	}

	@Override
	public String getNameByID(String id) {
		return operationLogMapper.getNameByID(id);
	}

}
