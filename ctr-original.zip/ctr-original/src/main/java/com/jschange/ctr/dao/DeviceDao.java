package com.jschange.ctr.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.model.ApplicationModel;
import com.jschange.ctr.model.Device;

public interface DeviceDao {

	int queryDeviceCount(Map<String, Object> map)throws SQLException;

	List<Object> queryDeviceByPage(Map<String, Object> map)throws SQLException;
	
	public int insertDevice(Device device)throws SQLException;
	
	public int updateDevice(Device device)throws SQLException;
	
	Integer deleteDeviceByIds(Map<String, Object> map)throws SQLException;

	Device queryDeviceById(Integer id)throws SQLException;
	
	List<ApplicationModel>queryApplicationModel()throws SQLException;
	
	public int check(Device device)throws SQLException;
	
	//查询终端状态列表
	public List<Device>queryDeviceState(Map<String, Object> map)throws SQLException;
	
	//终端状态总数
	public int queryDeviceStateCount(Map<String, Object> map)throws SQLException;

	public void operatorRecord(Map<String, Object> map);
	//根据比对服务器ID查询地址IP
	public String getWebIP(int serverid)throws SQLException;
	//根据终端id查询终端原有信息
	public Device getDevice(long id)throws SQLException;
}
