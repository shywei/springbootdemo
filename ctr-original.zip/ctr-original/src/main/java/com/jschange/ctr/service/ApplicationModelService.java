package com.jschange.ctr.service;

import java.util.List;

import com.jschange.ctr.model.ApplicationModel;

public interface ApplicationModelService {

	//获取应用模式  是门禁还是考勤
	public List<ApplicationModel> applicationModelList();

}
