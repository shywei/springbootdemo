package com.jschange.ctr.service.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.common.ResultListImpl;
import com.jschange.ctr.dao.OperationLogMapper;
import com.jschange.ctr.dao.StatisticsDao;
import com.jschange.ctr.dao.SystemUserMapper;
import com.jschange.ctr.model.DeptInfo;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.Role;
import com.jschange.ctr.model.SystemUser;
import com.jschange.ctr.service.OperationLogService;
import com.jschange.ctr.service.StatisticsService;
import com.jschange.ctr.service.SystemUserServiceI;

import util.ControllerUtil;

@Transactional
@Service("systemUserService")
public class SystemUserServiceImpl implements SystemUserServiceI {

	private static Map<String, Object> map = new HashMap<String, Object>();
	private static Pagination page ;
	private static OperationLog operationLog;

	@Autowired
	private StatisticsDao statisticsDao;
	
	@Autowired
	private SystemUserMapper systemUserMapper;
	
	@Autowired
	private OperationLogMapper operationLogMapper;

	//添加账号
	@Override
	public Integer insertSystemUser(SystemUser systemUser,OperationLog operationLog) {
		Integer result = 0;
		try {
			//根据用户名检查用户是否存在
			Integer checkUser = systemUserMapper.checkUser(systemUser.getLoginName());
			result = 0;
			//如果不存在，添加账号。如果已存在，将原先的账号更新
			if (checkUser == 0) {
				result = systemUserMapper.insertSystemUser(systemUser);
			} else {
				result = systemUserMapper.updateSystemUser(systemUser);
			}
			//查询出刚做操作的账号的编号
			Integer id = systemUserMapper.selectSystemUserId(systemUser);
			//操作内容
			operationLog.setOperationContext("添加了用户编号为"+id+"的账号");
			//调用方法记录操作内容
			operationLogMapper.callOperationPro(operationLog);
			//根据所选择的角色编号查询默认显示的菜单列表
			Integer[] au = systemUserMapper.selectModelRole(systemUser);
			map.put("id", id);
			map.put("au", au);
			//将默认菜单和账号的关联关系添加进表中
			systemUserMapper.insertUserModel(map);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	//删除账号
	@Override
	public Integer deleteSystemUser(String ids,OperationLog operationLog) {
		Integer result = 0;
		try {
			//将前台传来的字符串转为String数组，再遍历String数组全部转型为Integer数组
			String[] idA = ids.split(",");
			Integer[] id = new Integer[idA.length];
			for (int i = 0; i < id.length; i++) {
				id[i] = Integer.parseInt(idA[i]);
				//删除账号操作内容
				operationLog.setOperationContext("删除了用户编号为"+id[i]+"的账号");
				//删除操作的操作日志
				operationLogMapper.callOperationPro(operationLog);
			}
			map.put("id", id);
			//逻辑删除账号
			result = systemUserMapper.deleteSystemUser(map);
			if(result!=0){
				return 1;
			}else{
				return 0;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}

	//分页查询账号列表
	@Override
	public ResultList<Object> querySystemUser(Integer pageSize, Integer pageNo) {
		ResultList<Object> rlist = null;
		try {
			//创建一个ResultListImpl类
			rlist = new ResultListImpl<Object>();
			//创建一个Pagination类用作存放页数信息
			page = new Pagination();
			//页面容量和偏移量
			map.put("offset", pageSize * (pageNo - 1));
			map.put("pageSize", pageSize);
			//查询账号总数
			Integer count = systemUserMapper.querySystemUserCount();
			page.setTotalCount(count);
			page.setPageSize(pageSize);
			page.setStartNum(pageSize * (pageNo - 1));
			page.setEndNum(pageSize * pageNo);
			page.setCurrentPage(pageNo);
			//查询账号列表，通过Map集合传值
			List<Object> rs = systemUserMapper.querySystemUser(map);
			rlist.setResults(rs);
			rlist.setPage(page);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rlist;
	}

	//初始化密码
	@Override
	public Integer resetPassword(Integer id,OperationLog operationLog) {
		Integer it = 0;
		try {
			//根据单个用户编号进行密码初始化
			it = systemUserMapper.resetPassword(id);
			if(it==1){
				//添加操作日志
				operationLogMapper.callOperationPro(operationLog);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return it;
	}
	
	//用户自行修改密码
	@Override
	public Integer updateSystemUserPwd(Integer id, String password,OperationLog operationLog) {
		Integer it=0;
		map.put("id", id);
		map.put("password", password);
		try {
			//根据前台提供的新的密码和用户编号修改密码
			it = systemUserMapper.updateSystemUserPwd(map);
			if(it==1){
				//添加操作日志
				operationLogMapper.callOperationPro(operationLog);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return it;
	}

	//根据登录名查询是否有账号
	@Override
	public Integer checkSystemUser(String loginName) {
		Integer check = 0;
		try {
			check = systemUserMapper.checkSystemUser(loginName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return check;
	}

	//用户登录
	@Override
	public SystemUser loginSystemUser(String password, String loginName,String Ip) {
		map.put("login", loginName);
		map.put("pwd", password);
		SystemUser systemUser = null;
		try {
			//根据登录名和密码查询出用户信息
			systemUser = systemUserMapper.loginSystemUser(map);
			if(systemUser!=null){
				//如果登录成功添加操作日志
				operationLogMapper.callOperationPro(new OperationLog(systemUser.getId(), "系统登录", Ip, 1));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return systemUser;
	}

	//修改密码时检查原密码是否正确
	@Override
	public Integer checkPwd(String password, Integer id) {
		map.put("id", id);
		try {
			//根据用户编号查询出密码
			String checkPwd = systemUserMapper.checkPwd(map);
			//查询的密码与前台传来的密码作比较
			if(password.equals(checkPwd)){
				return 1;
			}else{
				return 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
		
	}

	//查询部门列表
	@Override
	public List<DeptInfo> queryDept() {
		List<DeptInfo> list = statisticsDao.queryDeptList();
		return list;
	}
	
	//查询账号的角色列表
	@Override
	public List<Role> queryRole() {
		List<Role> list = statisticsDao.queryRole();
		return list;
	}
	
}
