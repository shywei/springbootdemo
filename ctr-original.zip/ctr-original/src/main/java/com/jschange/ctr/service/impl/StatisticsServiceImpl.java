package com.jschange.ctr.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jschange.ctr.dao.StatisticsDao;
import com.jschange.ctr.model.AttendanceDataStatistics;
import com.jschange.ctr.model.DeptInfo;
import com.jschange.ctr.model.Drop;
import com.jschange.ctr.model.Role;
import com.jschange.ctr.service.StatisticsService;
import com.jschange.ctr.service.SystemUserServiceI;


@Transactional
@Service("statisticsService")
public class StatisticsServiceImpl implements StatisticsService {
	
	@Autowired
	StatisticsDao statisticsDao;
	
	@Autowired
	SystemUserServiceI systemUserServiceI;
	
	private static Map<String, Object> map = new HashMap<String, Object>();

	@Override
	public List<Drop> selectsumhasdeleted(Map<String, Object> map, Integer depId) {
		List<Drop> dropList= new ArrayList<Drop>();
		map.put("deptid",depId);
		List<DeptInfo> deptList = this.deptListByRole((Integer)map.get("roleid"),depId);
		for(DeptInfo dept:deptList){
			Integer code=dept.getDeptid();
			System.err.println("code"+ code);
			String depName=dept.getDeptName();//大队名称
			map.put("code", code);
		    int deleted = statisticsDao.deletesum(map);//离队人数
			int inuser = statisticsDao.inusersum(map);//在对人数
			Drop drop = new Drop();
			drop.setCode(code);
			drop.setDepName(depName);
			drop.setDeleted(deleted);
			drop.setInuser(inuser);
			dropList.add(drop);
		}
		return dropList;
	}

	@Override
	public List<AttendanceDataStatistics> selectSumAttendnum(Map<String, Object> map) {
		return statisticsDao.selectSumAttendnum(map);
	}

	@Override
	public List<Role> queryRole() {
		// TODO Auto-generated method stub
		return statisticsDao.queryRole();
	}

	@Override
	public List<DeptInfo> deptListByRole(Integer code, Integer deptid) {
		map.put("code", code);
		map.put("deptid", deptid);
		if(code==3){
			return statisticsDao.deptListByRole(map);
		}else if(code == 1||code == 2){
			return systemUserServiceI.queryDept();
		}else{
			return null;
		}
	}
}