package com.jschange.ctr.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.service.UserInfoDeleteService;

import util.CommonWords;
import util.ControllerUtil;
import util.Env;


@Controller
@RequestMapping("userDelete")
public class UserInfoDeleteController extends BaseController {
	
	private static ResultModel result;
	
	@Autowired
	private UserInfoDeleteService userInfoDeleteService;
	
	/**
	 * 删除人员信息
	 * @param request
	 * @param response
	 * @param ids
	 * @param userid
	 * @return
	 */
	@ResponseBody
	@RequestMapping("deleteUserInfo")
	public ResultModel userDelete(HttpServletRequest request,HttpServletResponse response,String ids,Integer userid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		result = new ResultModel();
		Integer res = userInfoDeleteService.deleteUserInfo(ids,userid,new OperationLog(userid, "删除学员", ControllerUtil.getIpAddr(request), 2));
		result.setCode(res!=0?1:0);
		return result;
	}
	
	/**
	 * 恢复人员信息
	 * @param request
	 * @param response
	 * @param id
	 * @param deptid
	 * @param userid
	 * @return
	 */
	@ResponseBody
	@RequestMapping("recoverUserInfo")
	public ResultModel userRecover(HttpServletRequest request,HttpServletResponse response,Integer id,Integer deptid,Integer userid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		result = new ResultModel();
		Integer res = userInfoDeleteService.recoverUserInfo(id,userid,deptid,new OperationLog(userid, "恢复学员", ControllerUtil.getIpAddr(request), 2));
		result.setCode(res);
		switch(res){
			case 0:result.setMessage(CommonWords.recoverSuccess);break;
			case 1:result.setMessage(CommonWords.connectFail);break;
			case 2:result.setMessage(CommonWords.recoverError);break;
			case 6:result.setMessage(CommonWords.connectFail);break;
			case 21:result.setMessage(CommonWords.paramError);break;
			case 22:result.setMessage(CommonWords.USBnotfound);break;
			case 23:result.setMessage(CommonWords.USBerror);break;
			default:result.setMessage("未知错误");
		}
		return result;
	}
}
