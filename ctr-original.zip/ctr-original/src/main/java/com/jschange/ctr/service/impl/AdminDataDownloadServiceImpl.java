package com.jschange.ctr.service.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jschange.ctr.dao.AdminDataDownloadMapper;
import com.jschange.ctr.dao.OpenDoorMapper;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.Device;
import com.jschange.ctr.model.UserInfo;
import com.jschange.ctr.service.AdminDataDownloadService;

import palm.pass.function.TerminalFlowFunction;


@Transactional
@Service(" adminDataDownloadService")
public class AdminDataDownloadServiceImpl implements AdminDataDownloadService {
	
	private TerminalFlowFunction terminal = new TerminalFlowFunction();
	
	@Autowired
	private AdminDataDownloadMapper adminDataDownloadMapper;
	
	
	@Autowired
	OpenDoorMapper openDoorMapper;
	
	//获取登录用户所在部门下所有身份为管理员的人员信息
	@Override
	public List<UserInfo> getUserInfoBydeptID(Integer deptid) throws ServiceException {

		try {
			return adminDataDownloadMapper.getUserInfoBydeptID(deptid);
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return null;
	
	}
	//下发操作
	@Override
	public Integer adminDataDownload(Integer deviceid, Integer userid) throws ServiceException {
		Integer i=-1;
		try {
			
			Device device=openDoorMapper.getDeviceInfo(deviceid);//获取设备信息
			if(device ==null ||device.getDeviceIP() ==null || device.getDevicePort()==null ||device.getDeviceType()==null ||device.getPassword()==null){
				return -1;
			}
			//System.err.println(device.getDeviceIP()+"!!"+device.getDevicePort()+"!!"+device.getDeviceType()+"!!"+device.getPassword());
			
			UserInfo user=adminDataDownloadMapper.getUserInfoByUserID(userid);//获取被选中要下发的管理员的掌静脉信息
			if(user ==null || user.getMetacarpalVein()==null){
				return -1;
			}
			
			//参数转型
			String remoteIP=device.getDeviceIP();
			Integer port=Integer.parseInt(device.getDevicePort());
			long confirmNum=deviceid;
			Integer confirmType=device.getDeviceType();
			Integer confirmModel=0;
			byte[] confirmPasswd=device.getPassword().getBytes();
			Integer totalNum=1;//管理员手掌静脉信息个数，1个，写死
			byte[] adminID=new byte[30];
			adminID[0]=userid.byteValue();
			byte[] openDoorID=new byte [10];
			openDoorID[0]=0;//开门ID,不用做门禁的时候，可忽略，随便放个数字进去即可
			
			byte[] veinData=user.getMetacarpalVein();
			System.err.println(device.getPassword()+","+userid+","+user.getMetacarpalVein());
			System.err.println("各项参数："+remoteIP+","+port+","+confirmNum+","+confirmType+","+confirmModel+","+confirmPasswd+","+totalNum+",管理员ID"+adminID.length+",开门ID"+openDoorID.length+",手掌"+veinData.length);
			i=terminal.adminDownLoad(remoteIP, port, confirmNum, confirmType, confirmModel, confirmPasswd, totalNum, adminID, openDoorID, veinData);
			if(i==0){//0表示下发成功，则修改掌静脉设备表里的相关绑定信息
				Map<String,Object> map=new HashMap<String,Object>();
				map.put("ownerID", userid);
				map.put("deviceid", deviceid);
				Integer j=adminDataDownloadMapper.updateDeviceOwnerID(map);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.err.println("下发结果"+1);
		return i;
	}

}
