package com.jschange.ctr.model;
public class InLeave {
	
	//在队或者离队每月数据
	private int month;
	private int sum;
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getSum() {
		return sum;
	}
	public void setSum(int sum) {
		this.sum = sum;
	}
	public InLeave() {
		
		
	}
	public InLeave(int month, int sum) {
	
		this.month = month;
		this.sum = sum;
	}
	
	

}