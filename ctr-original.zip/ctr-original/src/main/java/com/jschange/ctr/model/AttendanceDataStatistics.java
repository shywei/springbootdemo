package com.jschange.ctr.model;

public class AttendanceDataStatistics {
	
	private int allnum; //总人数
	private int rollcallnum;//应到人数
	private int attendnum;//实到人数
	private int othernum;//其他人数
	private int absensenum;//缺席人数
	private int sickleavenum;//病假人数
	private String deptName;//大队名称
	private String endtime;
	public int getAllnum() {
		return allnum;
	}
	public void setAllnum(int allnum) {
		this.allnum = allnum;
	}
	public int getRollcallnum() {
		return rollcallnum;
	}
	public void setRollcallnum(int rollcallnum) {
		this.rollcallnum = rollcallnum;
	}
	public int getAttendnum() {
		return attendnum;
	}
	public void setAttendnum(int attendnum) {
		this.attendnum = attendnum;
	}
	public int getOthernum() {
		return othernum;
	}
	public void setOthernum(int othernum) {
		this.othernum = othernum;
	}
	public int getAbsensenum() {
		return absensenum;
	}
	public void setAbsensenum(int absensenum) {
		this.absensenum = absensenum;
	}
	public int getSickleavenum() {
		return sickleavenum;
	}
	public void setSickleavenum(int sickleavenum) {
		this.sickleavenum = sickleavenum;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	
	
	
}
