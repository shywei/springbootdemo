package com.jschange.ctr.model;

public class PrpareNum {
	private Integer deptid;
	private Integer allnum;//总人数
	private Integer rollcallnum;//应到人数
	private Integer sickleavenum;//病休人数
	private Integer othernum;//其它人数
	
	public PrpareNum(Integer deptid, Integer allnum, Integer rollcallnum, Integer sickleavenum, Integer othernum) {
		super();
		this.deptid = deptid;
		this.allnum = allnum;
		this.rollcallnum = rollcallnum;
		this.sickleavenum = sickleavenum;
		this.othernum = othernum;
	}
	public Integer getDeptid() {
		return deptid;
	}
	public void setDeptid(Integer deptid) {
		this.deptid = deptid;
	}
	public Integer getAllnum() {
		return allnum;
	}
	public void setAllnum(Integer allnum) {
		this.allnum = allnum;
	}
	public Integer getRollcallnum() {
		return rollcallnum;
	}
	public void setRollcallnum(Integer rollcallnum) {
		this.rollcallnum = rollcallnum;
	}
	public Integer getSickleavenum() {
		return sickleavenum;
	}
	public void setSickleavenum(Integer sickleavenum) {
		this.sickleavenum = sickleavenum;
	}
	public Integer getOthernum() {
		return othernum;
	}
	public void setOthernum(Integer othernum) {
		this.othernum = othernum;
	}
	public PrpareNum(Integer allnum, Integer rollcallnum, Integer sickleavenum, Integer othernum) {
		super();
		this.allnum = allnum;
		this.rollcallnum = rollcallnum;
		this.sickleavenum = sickleavenum;
		this.othernum = othernum;
	}
	public PrpareNum() {
		super();
	}
	
}
