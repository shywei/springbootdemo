package com.jschange.ctr.service;

import com.jschange.ctr.exception.ServiceException;

public interface GetDeviceStateService {
	
	public Integer getDeviceState(Integer confirmNum)throws ServiceException;//获取设备终端状态

}
