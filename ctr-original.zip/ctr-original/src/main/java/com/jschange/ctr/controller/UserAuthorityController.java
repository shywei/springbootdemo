package com.jschange.ctr.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.model.Model;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.service.OperationLogService;
import com.jschange.ctr.service.UserAuthorityService;
@RequestMapping("userAuthorityController")
@Controller
public class UserAuthorityController extends BaseController{
	
	private int count=0;
	private OperationLog operationLog=new OperationLog();
	
	
	@Autowired
	private UserAuthorityService userAuthorityService;
	
	@Autowired 
	private OperationLogService operationLogService;
	
	/**
	 * 获取模块列表和数量
	 * @param resp
	 * @param name     		 模块名称
	 * @param id			 模块id
	 * @param page			 第几页(默认1)
	 * @param rows			 每页显示个数(默认10)
	 * @return
	 */
	@RequestMapping("getModel")
	@ResponseBody
	public ResultModel getModel(HttpServletResponse resp,String name,String id){
		resp.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel=new ResultModel();
		resultModel.setCode(-1);
		Map<String, Object> param=new HashMap<>();
		Pagination page=getPage();
		try {
			if(name!=null && !"".equals(name)){
				param.put("name", name);
			}
			if(id!=null && !"".equals(id)){
				param.put("id", id);
			}
			resultModel.setObj(userAuthorityService.getModel(param, page));
			resultModel.setCode(0);
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 保存模块
	 * @param resp
	 * @param modelid 				模块id(修改时需要)
	 * @param modelName 			模块名称
	 * @param modelUrl 				模块Url
	 * @param menuid 				所属菜单id
	 * @param userName 				帐号名
	 * @param deptid 				部门id
	 * @return
	 */
	@RequestMapping("saveModel")
	@ResponseBody
	public ResultModel saveModel(HttpServletResponse resp,Model model,HttpServletRequest req,String userName,String deptid){
		resp.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel=new ResultModel();
		resultModel.setCode(-1);
		try {
			if(model.getModelName()==null || "".equals(model.getModelName())){
				return resultModel;
			}
			operationLog.setOperationIP(super.getIP(req));
			operationLog.setOperationPersonnel(userName);
			operationLog.setDeptid(deptid);
			if(model.getModelid()!=null && !"".equals(model.getModelid())){
				//修改
				count=userAuthorityService.updateModel(model);
				resultModel.setCode(count);
				//操作日志
				if(count==-2){
					operationLog.setOperationContext("修改模块"+model.getModelName()+"失败");
				}
				else{
					operationLog.setOperationContext("修改模块"+model.getModelName()+"成功");
				}
				operationLogService.insertOperationLog(operationLog);
			}
			else{
				//添加
				count=userAuthorityService.addModelOrMenu(model);
				resultModel.setCode(count);
				//操作日志
				if(model.getMenuid()!=null && !"".equals(model.getMenuid())){
					if(count==1){
						operationLog.setOperationContext("添加模块"+model.getModelName()+"成功");
					}
					else{
						operationLog.setOperationContext("添加模块"+model.getModelName()+"失败");
					}
				}
				else{
					if(count==1){
						operationLog.setOperationContext("添加菜单"+model.getModelName()+"成功");
					}
					else{
						operationLog.setOperationContext("添加菜单"+model.getModelName()+"失败");
					}
				}
				operationLogService.insertOperationLog(operationLog);
			}
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 批量删除模块
	 * @param ids 			要被删除的模块id数组
	 * @param userName		帐号名
	 * @param deptid		部门id
	 * @return
	 */
	@RequestMapping("delModel")
	@ResponseBody
	public ResultModel delModel(String[] ids,HttpServletRequest req,HttpServletResponse resp,String userName,String deptid){
		resp.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel=new ResultModel();
		resultModel.setCode(-1);
		try {
			if(ids!=null && ids.length!=0){
				OperationLog operationLog=new OperationLog();
				operationLog.setOperationIP(super.getIP(req));
				operationLog.setDeptid(deptid);
				operationLog.setOperationPersonnel(userName);
				count=userAuthorityService.delModel(ids,operationLog);
				resultModel.setCode(count);
			}
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 根据账号id查询菜单栏
	 * @param id 			账号id
	 * @param resp
	 * @return
	 */
	@RequestMapping("getMenuById")
	@ResponseBody
	public ResultModel getMenuById(String id,HttpServletResponse resp) {
		resp.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel=new ResultModel();
		resultModel.setCode(-1);
		try {
			if(id!=null && !"".equals(id)){
				resultModel.setObj(userAuthorityService.getMenuById(id));
				resultModel.setCode(0);
			}
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 根据菜单id、账号id查询模块
	 * @param resp
	 * @param id							账号id
	 * @param menuid						菜单id
	 * @return
	 */
	@RequestMapping("getModelByMenuIdAndId")
	@ResponseBody
	public ResultModel getModelByMenuIdAndId(HttpServletResponse resp,String id,String menuid){
		resp.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel=new ResultModel();
		resultModel.setCode(-1);
		try {
			if(id!=null &&!"".equals(id) && menuid!=null && !"".equals(menuid)){
				resultModel.setObj(userAuthorityService.getModelByMenuIdAndId(id, menuid));
				resultModel.setCode(0);
			}
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 查询属于该角色的帐号集合
	 * @param id					角色id
	 * @param resp
	 * @return
	 */
	@RequestMapping("getSystemUserByRoleId")
	@ResponseBody
	public ResultModel getSystemUserByRoleId(String id,HttpServletResponse resp){
		resp.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel=new ResultModel();
		resultModel.setCode(-1);
		try {
			if(id!=null && !"".equals(id)){
				resultModel.setObj(userAuthorityService.getSystemUserByRoleId(id));
				resultModel.setCode(0);
			}
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 菜单下拉框
	 * @param resp
	 * @return
	 */
	@RequestMapping("getMenuList")
	@ResponseBody
	public ResultModel getMenuList(HttpServletResponse resp){
		resp.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel=new ResultModel();
		resultModel.setCode(-1);
		try {
			resultModel.setObj(userAuthorityService.getMenuList());
			resultModel.setCode(0);
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 菜单集合和包含的模块集合(权限分配)
	 * @param resp
	 * @return
	 */
	@RequestMapping("getMenuAndModel")
	@ResponseBody
	public ResultModel getMenuAndModel(HttpServletResponse resp){
		resp.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel=new ResultModel();
		resultModel.setCode(-1);
		try {
			resultModel.setObj(userAuthorityService.getMenuAndModel());
			resultModel.setCode(0);
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 根据角色id查询模块集合(权限分配)
	 * @param resp
	 * @param id			角色id
	 * @return
	 */
	@RequestMapping("getModelByRoleId")
	@ResponseBody
	public ResultModel getModelByRoleId(HttpServletResponse resp,String id){
		resp.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel=new ResultModel();
		resultModel.setCode(-1);
		try {
			if(id!=null && !"".equals(id)){
				resultModel.setObj(userAuthorityService.getModelByRoleId(id));
				resultModel.setCode(0);
			}
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 根据账号id查询模块集合(权限分配)
	 * @param resp
	 * @param id						账号id
	 * @return
	 */
	@RequestMapping("getModelById")
	@ResponseBody
	public ResultModel getModelById(HttpServletResponse resp,String id){
		resp.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel=new ResultModel();
		resultModel.setCode(-1);
		try {
			if(id!=null && !"".equals(id)){
				resultModel.setObj(userAuthorityService.getModelById(id));
				resultModel.setCode(0);
			}
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 修改账号权限
	 * @param ids						模块id数组
	 * @param id						被修改账号id
	 * @param loginName					被修改的帐号名
	 * @param userName					进行修改操作的账号名
	 * @param deptid					部门id
	 * @return
	 */
	@RequestMapping("updateUserAuthority")
	@ResponseBody
	public ResultModel updateUserAuthority(String[] ids,String id,String loginName,HttpServletRequest req,HttpServletResponse resp,String userName,String deptid){
		resp.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel=new ResultModel();
		resultModel.setCode(-1);
		try {
			if(id!=null && !"".equals(id)){
				count=userAuthorityService.updateUserAuthority(ids, id);
				//操作日志
				operationLog.setOperationIP(super.getIP(req));
				operationLog.setDeptid(deptid);
				operationLog.setOperationPersonnel(userName);
				if(count>=0){
					operationLog.setOperationContext("修改帐号"+loginName+"的权限成功");
					resultModel.setCode(0);
				}
				else{
					operationLog.setOperationContext("修改帐号"+loginName+"的权限失败");
				}
				operationLogService.insertOperationLog(operationLog);
			}
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 修改角色权限
	 * @param ids						模块id数组
	 * @param id						被修改角色id
	 * @param roleName					被修改角色名
	 * @param userName					进行修改操作的账号名
	 * @param deptid					部门id
	 * @return
	 */
	@RequestMapping("updateRoleAuthority")
	@ResponseBody
	public ResultModel updateRoleAuthority(String[] ids,String id,String roleName,HttpServletRequest req,HttpServletResponse resp,String userName,String deptid){
		resp.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel=new ResultModel();
		resultModel.setCode(-1);
		try {
			if(id!=null && !"".equals(id)){
				count=userAuthorityService.updateRoleAuthority(ids, id);
				//操作日志
				operationLog.setOperationIP(super.getIP(req));
				operationLog.setDeptid(deptid);
				operationLog.setOperationPersonnel(userName);
				if(count>=0){
					operationLog.setOperationContext("修改角色"+roleName+"的权限成功");
					resultModel.setCode(0);
				}
				else{
					operationLog.setOperationContext("修改角色"+roleName+"的权限失败");
				}
				operationLogService.insertOperationLog(operationLog);
			}
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
}
