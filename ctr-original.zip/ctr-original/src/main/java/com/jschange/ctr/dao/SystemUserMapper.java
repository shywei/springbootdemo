package com.jschange.ctr.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.SystemUser;


public interface SystemUserMapper {

	Integer checkUser(String loginName)throws SQLException;

	Integer insertSystemUser(SystemUser systemUser)throws SQLException;

	Integer updateSystemUser(SystemUser systemUser)throws SQLException;

	Integer deleteSystemUser(Map<String, Object> map)throws SQLException;

	Integer querySystemUserCount()throws SQLException;

	List<Object> querySystemUser(Map<String, Object> map)throws SQLException;

	Integer resetPassword(Integer id)throws SQLException;

	Integer updateSystemUserPwd(Map<String, Object> map)throws SQLException;

	Integer checkSystemUser(String loginName)throws SQLException;

	SystemUser loginSystemUser(Map<String, Object> map)throws SQLException;

	String checkPwd(Map<String, Object> map)throws SQLException;

	Integer selectSystemUserId(SystemUser systemUser);

	Integer[] selectModelRole(SystemUser systemUser);

	Integer insertUserModel(Map<String, Object> map);
     
}