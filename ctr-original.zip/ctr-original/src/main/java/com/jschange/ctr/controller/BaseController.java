package com.jschange.ctr.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.jschange.ctr.common.Pagination;

public class BaseController {
	
	 protected RequestAttributes getRequestAttributes(){
	        return RequestContextHolder.getRequestAttributes(); 
	 }
	
	/**
	 * 获取session
	 * @return
	 */
    protected HttpSession getSession(){
        RequestAttributes requestAttributes = getRequestAttributes();
        if(requestAttributes == null){
            return null;
        }
        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes)requestAttributes;
        HttpSession session = servletRequestAttributes.getRequest().getSession();
        return session;
    }
    
    /**
     * 获取request
     * @return
     */
    protected HttpServletRequest getRequest(){
        RequestAttributes requestAttributes = getRequestAttributes();
        if(requestAttributes == null){
            return null;
        }
        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes)requestAttributes;
        return  servletRequestAttributes.getRequest();
    }
	
    /**
     * 分页
     * @return
     */
    protected Pagination getPage(){
        Pagination page = new Pagination();
        Object pageI =getRequest().getParameter("page");
        Object pageS = getRequest().getParameter("rows");
        Integer pageIndex = 1;
        Integer pageSize = 10;
        if(pageI !=null){
            pageIndex = Integer.parseInt(pageI.toString());
        }
        if(pageS != null){
            pageSize = Integer.parseInt(pageS.toString());
        }
        Integer startNum=(pageIndex-1)*pageSize;
        Integer endNum=pageIndex*pageSize;
        page.setEndNum(endNum);
        page.setStartNum(startNum);
        page.setCurrentPage(pageIndex);
        page.setPageSize(pageSize);
        return page;
    }
	
    /**
     * 获取IP
     * @param request
     * @return
     */
  	public String getIP(HttpServletRequest request){
  		String ip  =  request.getHeader("x-forwarded-for");  
  	    if (ip==null||ip.length()== 0||"unknown" .equalsIgnoreCase(ip))  {  
  	    	ip=request.getHeader("Proxy-Client-IP");  
  	    }   
  	    if (ip==null||ip.length()==0||"unknown" .equalsIgnoreCase(ip))  {  
  	    	ip=request.getHeader("WL-Proxy-Client-IP");  
  	    }   
  	    if (ip==null||ip.length()==0||"unknown".equalsIgnoreCase(ip))  {  
  	    	ip=request.getRemoteAddr();  
  	    }   
  	    return  ip;  
  	 }  
  	

    /**
     *  获取session中的值
     * @param name
     * @return
     */
    protected Object getSessionAttr(String name){
        HttpSession session = getSession();
        if(session == null){
            return null;
        }
        return session.getAttribute(name);
    }
  	

    
}
