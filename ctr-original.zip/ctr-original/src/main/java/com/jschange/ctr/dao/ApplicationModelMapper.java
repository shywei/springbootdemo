package com.jschange.ctr.dao;

import java.util.List;

import com.jschange.ctr.model.ApplicationModel;

public interface ApplicationModelMapper {
	//获取应用模式  是门禁还是考勤
	public List<ApplicationModel> applicationModelList();

}
