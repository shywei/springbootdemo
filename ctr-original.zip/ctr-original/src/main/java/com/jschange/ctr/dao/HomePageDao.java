package com.jschange.ctr.dao;

import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.AbsenceList;
import com.jschange.ctr.model.AttendanceDataStatistics;

public interface HomePageDao {

	List<AttendanceDataStatistics> homeAttence(Map<String, Object> map);

	int yearlyInOrNotTeam(Map<String, Object> map);

	AttendanceDataStatistics proportion(Map<String, Object> map);

	List<AbsenceList> queqinList(String depId);

	List<AbsenceList> otherList(String depId);
	
}
