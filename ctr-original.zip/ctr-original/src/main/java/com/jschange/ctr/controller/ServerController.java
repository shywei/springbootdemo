package com.jschange.ctr.controller;

import java.rmi.ServerException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.Server;
import com.jschange.ctr.model.SystemUser;
import com.jschange.ctr.service.OperationLogService;
import com.jschange.ctr.service.ServerService;

@Controller
@RequestMapping("serverController")
public class ServerController extends BaseController{

	@Autowired
	private ServerService serverService;
	
	@Autowired 
	private OperationLogService logService;
	
	private OperationLog operationLog=new OperationLog();
	
	/**
	 * 注册、修改服务器
	 * @param response
	 * @param server
	 * @return
	 */
	@ResponseBody
	@RequestMapping("saveServer")
	public ResultModel registerServer(HttpServletResponse response,HttpServletRequest request,
			Server server,String currentId){
		response.setHeader("Access-Control-Allow-Origin", "*");		
		response.setCharacterEncoding("utf-8");
		ResultModel rs= new ResultModel();
		try {
			String sysIp=super.getIP(request);//获取登陆IP
			SystemUser user=logService.queryCurrentUser(currentId);
			operationLog.setOperationIP(sysIp);
			operationLog.setOperationPersonnel(user.getUserName());
			operationLog.setDeptid(user.getDeptid().toString());
			Integer serverid=server.getServerid();
			String serverIP=server.getServerIP();
			Integer serverType=server.getServerType();
			if(serverType==1){//注册比对服务器
				int states=serverService.checkContrastServer(server);//比对服务器认证
				if(states!=0){//比对服务器第三方认证失败
					rs.setCode(states);
					operationLog.setOperationContext("注册比对服务器"+server.getServerIP()+"第三方认证失败，失败码为:"+states);
					logService.insertOperationLog(operationLog);
					rs.setMessage("比对服务器第三方认证失败，失败码:"+states);
					return rs;
				}
			}
			if(null == serverIP || "".equals(serverIP)){
				rs.setMessage("服务器IP不可为空！");
				rs.setCode(-1);
				return rs;
			}
			if(null != serverid && 0 != serverid){//服务器id存在，修改
				int i=serverService.updateServer(server);
				if(i>0){
					rs.setCode(500);
					operationLog.setOperationContext("修改服务器"+server.getServerIP()+"成功！");
					logService.insertOperationLog(operationLog);
					rs.setMessage("修改服务器成功！");
				}else{
					rs.setCode(i);
					operationLog.setOperationContext("修改应用服务器"+server.getServerIP()+"失败！");
					logService.insertOperationLog(operationLog);
					rs.setMessage("服务器修改失败！");
				}
				return rs;
			}else{//不存在，增加
				int i=serverService.insertServer(server,operationLog);
				if(i==-2){
					rs.setCode(-2);
				}else{
					rs.setCode(400);
					rs.setMessage("注册服务器成功！");
				}
				return rs;
			}
		} catch (ServerException e) {
			e.printStackTrace();
			rs.setMessage("操作失败！");
		}
		rs.setCode(-5);
		rs.setMessage("操作失败！");
		return rs;
	}
	
	/**
	 * 分页查询服务器列表
	 * @param response
	 * @param serverName
	 * @param serverIP
	 * @param serverType
	 * @param serverStatus
	 * @param s 传值时有分页
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryServerList")
	public ResultModel queryServerList(HttpServletResponse response,Integer serverid,
			String serverName,String serverIP,Integer serverType,Integer serverStatus,
			String s
			){
		response.setHeader("Access-Control-Allow-Origin", "*");		
		response.setCharacterEncoding("utf-8");
		ResultModel rs= new ResultModel();
		Pagination page=getPage();
		Map<String, Object> map=new HashMap<>();
		if(null != serverName && !"".equals(serverName)){
			map.put("serverName", serverName);
		}
		if(null != s && !"".equals(s)){
			map.put("s", s);
		}
		if(null != serverid && !"".equals(serverid)){
			map.put("serverid", serverid);
		}
		if(null != serverIP && !"".equals(serverIP)){
			map.put("serverIP", serverIP);
		}
		if(null != serverType && !"".equals(serverType)){
			map.put("serverType", serverType);
		}
		if(null != serverStatus && !"".equals(serverStatus)){
			map.put("serverStatus", serverStatus);
		}
		try {
			List<Server> list=serverService.queryServerList(map, page).getResults();
			rs.setObj(list);
			rs.setObjExt(page);
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
		}
		rs.setCode(-1);
		return rs;
	}
	
	/**
	 * 删除服务器（单个删除）
	 * @param response
	 * @param serverid
	 * @param serverIP
	 * @return
	 */
	@ResponseBody
	@RequestMapping("delServer")
	public ResultModel delServer(HttpServletResponse response,HttpServletRequest request,
			Integer serverid,String currentId,String serverIP){
		response.setHeader("Access-Control-Allow-Origin", "*");		
		response.setCharacterEncoding("utf-8");
		ResultModel rs= new ResultModel();
		Map<String, Object> map=new HashMap<>();
		String sysIp=super.getIP(request);//获取登陆IP
		SystemUser user=logService.queryCurrentUser(currentId);
		operationLog.setOperationIP(sysIp);
		operationLog.setOperationPersonnel(user.getUserName());
		operationLog.setDeptid(user.getDeptid().toString());
		if(null != serverid && !"".equals(serverid)){
			map.put("serverid", serverid);
		}
		if(null != serverIP && !"".equals(serverIP)){
			map.put("serverIP", serverIP);
		}
		try {
			int t=serverService.delServer(map);
			if(t<0){
				operationLog.setOperationContext("删除服务器"+serverIP+"失败");
				logService.insertOperationLog(operationLog);
			}else{
				operationLog.setOperationContext("删除服务器"+serverIP+"成功");
				logService.insertOperationLog(operationLog);
			}
			rs.setCode(t);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
	
	
}
