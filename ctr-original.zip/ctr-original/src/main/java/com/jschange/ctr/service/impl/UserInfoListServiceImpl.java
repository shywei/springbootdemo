package com.jschange.ctr.service.impl;

import java.awt.print.Pageable;
import java.rmi.ServerException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.common.ResultListImpl;
import com.jschange.ctr.dao.UserInfoListMapper;
import com.jschange.ctr.model.State;
import com.jschange.ctr.model.UserInfo;
import com.jschange.ctr.service.UserInfoListService;

@Service
public class UserInfoListServiceImpl implements UserInfoListService{

	@Autowired
	private UserInfoListMapper userInfoMapper;
	
	@Override
	public ResultList<UserInfo> queryUserInfoList(Map<String, Object> map,Pagination page) throws ServerException {
		try {
			ResultList<UserInfo> list=new ResultListImpl<>();
			if(null != page){
				int allcount=userInfoMapper.counutUserListNum(map);
				page.setTotalCount(allcount);
				map.put("page", (page.getCurrentPage()-1)*page.getPageSize());
				map.put("rows",page.getPageSize());
			}
			List<UserInfo> list1=userInfoMapper.queryUserInfoList(map);
//			for (UserInfo userInfo : list1) {
//				if(userInfo.getGender().equals("男")){
//					userInfo.setGender("1");
//				}else if(userInfo.getGender().equals("女")){
//					userInfo.setGender("0");
//				}
//			}
			list.setResults(list1);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<State> queryStateList() throws ServerException {
		try {
			return userInfoMapper.queryStateList();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public Integer updateUserState(Map<String, Object> map) throws ServerException {
		try {
			return userInfoMapper.updateUserState(map);
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

}
