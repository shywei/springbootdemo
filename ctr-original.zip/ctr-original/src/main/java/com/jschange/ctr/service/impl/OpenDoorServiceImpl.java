package com.jschange.ctr.service.impl;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jschange.ctr.dao.OpenDoorMapper;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.Device;
import com.jschange.ctr.service.OpenDoorService;

import palm.pass.function.TerminalFlowFunction;



@Transactional
@Service("openDoorService")
public class OpenDoorServiceImpl implements OpenDoorService {
	
	
	
	@Autowired
	private OpenDoorMapper openDoorMapper;
	
	private TerminalFlowFunction terminal = new TerminalFlowFunction();

	@Override
	public Integer remoteOpenDoor(Integer id) throws ServiceException {
		try {
			Device device=openDoorMapper.getDeviceInfo(id);
			if(device ==null){
				return -1;//表示查询设备信息失败
			}
			String remoteIP=device.getDeviceIP();
			int port=Integer.parseInt(device.getDevicePort());
			long confirmNum=device.getDeviceid();
			int confirmType=device.getDeviceType();
			int confirmModel=0;//0代表psn900
			byte[] confirmPasswd=device.getPassword().getBytes();
			int j=terminal.RemoteOpenDoor(remoteIP,port,confirmNum,confirmType,confirmModel,confirmPasswd);//远程开门
			return j;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
