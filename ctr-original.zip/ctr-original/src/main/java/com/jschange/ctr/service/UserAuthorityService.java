package com.jschange.ctr.service;

import java.util.Map;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.Menu;
import com.jschange.ctr.model.MenuAndModel;
import com.jschange.ctr.model.Model;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.SystemUser;

public interface UserAuthorityService {
	
	public static final String SERVICE_NAME="com/jschange/ctr/service/UserAuthorityService";
	//查询模块菜单
	public ResultList<Model> getModel(Map<String,Object> param,Pagination page) throws ServiceException;
	//添加模块或菜单
	public int addModelOrMenu(Model model) throws ServiceException;
	//修改模块
	public int updateModel(Model model) throws ServiceException;
	//批量删除模块
	public int delModel(String[] ids,OperationLog operationLog) throws ServiceException;
	//根据账号id查询菜单栏
	public ResultList<Menu> getMenuById(String id) throws ServiceException;
	//根据菜单id、账号id查询模块
	public ResultList<Model> getModelByMenuIdAndId(String id,String menuid) throws ServiceException;
	//查询属于该角色的帐号集合(权限分配)
	public ResultList<SystemUser> getSystemUserByRoleId(String id) throws ServiceException;
	//菜单下拉框
	public ResultList<Menu> getMenuList() throws ServiceException;
	//菜单集合和包含的模块集合(权限分配)
	public ResultList<MenuAndModel> getMenuAndModel() throws ServiceException;
	//根据角色id查询模块集合(权限分配)
	public ResultList<Model> getModelByRoleId(String id) throws ServiceException;
	//根据账号id查询模块集合(权限分配)
	public ResultList<Model> getModelById(String id) throws ServiceException;
	//修改角色权限(权限分配)
	public int updateRoleAuthority(String[] ids,String id) throws ServiceException;
	//修改账号权限(权限分配)
	public int updateUserAuthority(String[] ids,String id) throws ServiceException;
}
