package com.jschange.ctr.model;

public class StartTimeVo {
	private Integer id;
	private String starttime;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getStarttime() {
		return starttime;
	}
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	public StartTimeVo(Integer id, String starttime) {
		super();
		this.id = id;
		this.starttime = starttime;
	}
	public StartTimeVo() {
		super();
	}
	
}
