package com.jschange.ctr.model;


public class OperationLog {
	
	private int id;//编号
	
	private int userid;
	
	private String operationTime;//操作时间
	
	private String operationPersonnel;//操作人
	
	private String operationContext;//操作内容
	
	private String operationIP;//电脑IP地址
	
	private String deptid;//操作人的大队id

	private String deptName;//操作人的大队名称
	
	private Integer operationType;//操作类型

	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOperationTime() {
		return operationTime;
	}

	public void setOperationTime(String operationTime) {
		this.operationTime = operationTime;
	}

	public String getOperationPersonnel() {
		return operationPersonnel;
	}

	public void setOperationPersonnel(String operationPersonnel) {
		this.operationPersonnel = operationPersonnel;
	}

	public String getOperationContext() {
		return operationContext;
	}

	public void setOperationContext(String operationContext) {
		this.operationContext = operationContext;
	}

	public String getOperationIP() {
		return operationIP;
	}

	public void setOperationIP(String operationIP) {
		this.operationIP = operationIP;
	}

	public String getDeptid() {
		return deptid;
	}

	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public Integer getOperationType() {
		return operationType;
	}

	public void setOperationType(Integer operationType) {
		this.operationType = operationType;
	}

	public OperationLog(int id, String operationTime, String operationPersonnel, String operationContext,
			String operationIP, String deptid, String deptName, Integer operationType) {
		super();
		this.id = id;
		this.operationTime = operationTime;
		this.operationPersonnel = operationPersonnel;
		this.operationContext = operationContext;
		this.operationIP = operationIP;
		this.deptid = deptid;
		this.deptName = deptName;
		this.operationType = operationType;
	}
	
	

	public OperationLog(int userid, String operationContext, String operationIP, Integer operationType) {
		super();
		this.userid = userid;
		this.operationContext = operationContext;
		this.operationIP = operationIP;
		this.operationType = operationType;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public OperationLog() {
		super();
	}

	
	

}
