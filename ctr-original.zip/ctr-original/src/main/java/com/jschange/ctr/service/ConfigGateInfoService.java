package com.jschange.ctr.service;

import com.jschange.ctr.exception.ServiceException;


public interface ConfigGateInfoService {
	//设置门禁信息
	public Integer configGateInfo(Integer confirmNum, 
			int doorSignal, int time, int magAlarm, int magAlarmTime, int durAlarm,
			int tamperAlarm, int inputSignal, int alarmTime, int sound, int light, int sleep)throws ServiceException;

}
