package com.jschange.ctr.dao;

import java.sql.SQLException;
import java.util.Map;

public interface UserInfoDeleteDao {

	void deleteSingleUser(String id);

	void recoverUserInfo(String id, String deptId);

	void rollbackRecover(String id);
	
	//根据人员id查询人员persionid用于传给富士通接口 
	//String getPersionId(Map<String, Object> map)throws SQLException;


}
