package com.jschange.ctr.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jschange.ctr.dao.AccessRecordMapper;
import com.jschange.ctr.dao.EventMapper;
import com.jschange.ctr.model.AccessRecord;
import com.jschange.ctr.model.CouldAttendUsr;
import com.jschange.ctr.model.Event;
import com.jschange.ctr.model.StartTimeVo;
import com.jschange.ctr.model.UserInfo;
import com.jschange.ctr.service.AttendPeopleRecordService;



@Service("attendPeopleRecordService")
public class AttendPeopleRecordServiceImpl implements AttendPeopleRecordService {
	@Autowired
	private AccessRecordMapper accessRecordMapper;
	
	@Autowired
	private EventMapper rollCallEventinfoMapper;
	
	private Map<String, Object> m = new HashMap<String, Object>();
	
	//分页查询所有队里需要点名的人员信息
	public List<AccessRecord> selectRecordByPageByTeam(Map<String, Object> map) {
		return accessRecordMapper.selectRecordByPageByTeam(map);
	}
	
	//按条件查询总条数
	public int selectAllRowsByReqire(Map<String, Object> map) {
		return accessRecordMapper.selectAllRowsByReqire(map);
	}
	//按条件查询所有大队记录总数
	public int selectTeamRowsByReqire(Map<String, Object> map) {
		return rollCallEventinfoMapper.selectTeamRowsByReqire(map);
	}
	//按条件查询各大队的信息
	public List<Event> selectTeamRecord(Map<String, Object> map) {
		return rollCallEventinfoMapper.selectTeamRecord(map);
	}
	//获得总人数、应到人数、病休人数、其它人数的方法
	public List<Map> getPrepareNum(Map map) {
		return rollCallEventinfoMapper.getPrepareNum(map);
	}
	//导出Excel表格需要的大队中所有人员信息
	public AccessRecord[] getAllRecordByTeam(Map<String, Object> map) {
		return accessRecordMapper.getAllRecordByTeam(map);
	}
	//导出Excel表格需要的所有大队信息
	public List<Event> getTeamRecord(Map<String, Object> map) {
		return rollCallEventinfoMapper.getTeamRecord(map);
	}
	//开始点名获取大队已经点名的简要信息：图片地址等
	public List<CouldAttendUsr> startRecordInfo(Map<String, Object> map) {
		return accessRecordMapper.startRecordInfo(map);
	}
	//传入id数组进行批量修改
	public int updateRecordByTeam(Map<String, Object> map) {
		return accessRecordMapper.updateRecordByTeam(map);
	}
	//传入id数组进行批量删除
	public int deleteRecordByTeam(Map<String, Object> map) {
		return accessRecordMapper.deleteRecordByTeam(map);
	}
	//结束点名时，向eventinfo表中插入人数信息 
	public int insertEventinfo(Map<String, Object> map) {
		return rollCallEventinfoMapper.insertEventinfo(map);
	}

	public int insertAccessRecord(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return accessRecordMapper.insertAccessRecord(map);
	}
	public int deletePauseRecord(Map<String, Object> map) {
		return accessRecordMapper.deletePauseRecord(map);
	}
	//根据时间将记录状态修改
	public int updateRecordByTime(Integer deptid) {
		// TODO Auto-generated method stub
		return accessRecordMapper.updateRecordByTime(deptid);
		
	}

	public List<CouldAttendUsr> selectNewRecordInfo(Map<String, Object> map) {
		return accessRecordMapper.selectNewRecordInfo(map);
	}

	public List<CouldAttendUsr> selectAbsenseName(Map<String, Object> map) {
		return accessRecordMapper.selectAbsenseName(map);
	}

	public int insertAbsenseRecord(Map<String, Object> map) {
		String[] ids = accessRecordMapper.selectAbesenseId(map);
		//插入缺勤数据
		int res = 0;
		for (int i = 0; i < ids.length; i++) {
			//根据编号查询人员信息
			UserInfo u=accessRecordMapper.getUserInfo(ids[i]);
			Integer result = accessRecordMapper.insertAbsenseRecord(u);
			res += result;
		}
		System.err.println(res);
		map.put("ids1", ids);
		accessRecordMapper.updateCtrEventid(map);
		return res;
	}

	public List<String> selectStartDate(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return accessRecordMapper.selectStartDate(map);
	}

	public List<StartTimeVo> selectStartDateUpdate(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return accessRecordMapper.selectStartDateUpdate(map);
	}

	public int updateCtrEventid(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return accessRecordMapper.updateCtrEventid(map);
	}

}
