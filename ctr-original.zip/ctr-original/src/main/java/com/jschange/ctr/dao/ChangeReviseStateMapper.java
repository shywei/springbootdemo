package com.jschange.ctr.dao;

import java.sql.SQLException;
import java.util.Map;

public interface ChangeReviseStateMapper {
	
	//查询人员当前状态
	public Integer queryRCUserInfoState(String userid)throws SQLException;
	public Integer queryRCUserInfoStateById(String id)throws SQLException;
	//查询该人员调队前部门 
	public String queryOldDept(String id)throws SQLException;
	//修改人员状态和驳回理由
	public Integer updateRCUserInfoState(Map<String, Object> map)throws SQLException;
	//部门调度按钮（将人员状态改为调队中、接收部门改为即将要去的部门）
	public Integer readyChangeDept(Map<String, Object> map)throws SQLException;
	//撤回调队人员
	public Integer recallChangeDeptUser(Map<String, Object> map)throws SQLException;
	
	//查询掌静脉调度的设备状态是否在线
	public Integer checkStatusforfingerdrivice(String userid)throws SQLException;
	//对指静脉实际采集数量和占用数量进行修改
	public Integer updateFingerNum(Map<String, Object> map)throws SQLException;
	//占位指静脉录入人员数量
	public Integer occupyFingerNum(Map<String, Object> map)throws SQLException;
	//将原来设备使用量-1
	public Integer changeCollectedNum(Integer id)throws SQLException;
	//部门调度时选择人员含有指静脉的数量
	public Integer countPersonNum(Map<String, Object> map)throws SQLException;
	//部门调度时判断是不是已经被删除了
	public Integer queryIsDel(String id)throws SQLException;
	
}
