package com.jschange.ctr.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.Server;

public interface ServerMapper {

	//注册服务器
	Integer insertServer(Server server)throws SQLException;
	//检查ip是否重复（数据服务器和比对服务器ip可相同）
	Integer checkIP(Server server)throws SQLException;
	//查询服务器列表
	List<Server> queryServerList(Map<String, Object> map)throws SQLException;
	//查询列表数量
	Integer countServerNum(Map<String, Object> map)throws SQLException;
	//修改服务器
	Integer updateServer(Server server)throws SQLException;
	//删除服务器
	Integer delServer(Map<String, Object> map)throws SQLException;
	//判断该服务器有没有设备正在使用
	Integer checkServerInUse(Map<String, Object> map)throws SQLException;
	
}

