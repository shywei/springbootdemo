package com.jschange.ctr.service;

import java.rmi.ServerException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.Server;

public interface ServerService {

	//注册应用服务器
	Integer insertServer(Server server,OperationLog operationLog)throws ServerException;
	//分页查询服务器
	ResultList<Server> queryServerList(Map<String, Object> map, Pagination page)throws ServerException; 
	//修改服务器
	Integer updateServer(Server server)throws ServerException;
	//删除服务器
	Integer delServer(Map<String, Object> map)throws SQLException;

	//比对服务器认证
	Integer checkContrastServer(Server server)throws ServerException;
	
	
	
	
	
}
