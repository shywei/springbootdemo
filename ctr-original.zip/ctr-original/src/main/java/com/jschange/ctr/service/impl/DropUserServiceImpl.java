package com.jschange.ctr.service.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.common.ResultListImpl;
import com.jschange.ctr.dao.DropUserMapper;
import com.jschange.ctr.model.UserInfo;
import com.jschange.ctr.service.DropUserService;

@Service("dropUserService")
public class DropUserServiceImpl implements DropUserService {
	
	@Autowired
	private DropUserMapper dropUserMapper;

	public ResultList<UserInfo> queryDropUserList(Map<String, Object> map, Pagination page) {
		ResultList<UserInfo> rl=new ResultListImpl<>();
		try {
			if(null != page){
				int count=dropUserMapper.queryDropUserCount(map);
				page.setTotalCount(count);
				map.put("page", (page.getCurrentPage()-1)*page.getPageSize());
				map.put("rows", page.getPageSize());
			}
			List<UserInfo>userList=dropUserMapper.queryDropUserList(map);
			rl.setPage(page);
			rl.setResults(userList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rl;
	}

	@Override
	public ResultList<UserInfo> queryReceiveUserList(Map<String, Object> map, Pagination page) throws SQLException {
		ResultList<UserInfo> rl=new ResultListImpl<>();
		try {
			if(null != page){
				int count=dropUserMapper.countReceiveUserList(map);
				page.setTotalCount(count);
				map.put("page", (page.getCurrentPage()-1)*page.getPageSize());
				map.put("rows", page.getPageSize());
			}
			List<UserInfo>userList=dropUserMapper.queryReceiveUserList(map);
			rl.setPage(page);
			rl.setResults(userList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rl;
	}

	
}
