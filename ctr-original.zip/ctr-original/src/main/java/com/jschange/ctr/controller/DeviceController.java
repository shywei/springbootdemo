package com.jschange.ctr.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.ApplicationModel;
import com.jschange.ctr.model.Area;
import com.jschange.ctr.model.Device;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.service.ApplicationModelService;
import com.jschange.ctr.service.AreaService;
import com.jschange.ctr.service.DeviceService;
import com.jschange.ctr.service.OperationLogService;

import palm.pass.function.TerminalFlowFunction;
import palmpass.client.DeviceMac;
import palmpass.client.GateInfo;
import util.ControllerUtil;
import util.Env;

@Controller
@RequestMapping("device")
public class DeviceController extends BaseController {


	private ResultModel result;

	@Autowired
	private DeviceService deviceService;
	 @Autowired
	private AreaService areaService;
	 @Autowired
	 private ApplicationModelService applicationModelService;
	@Autowired
	private OperationLogService operationLogService;
	
	/**
	 * 获取比对服务器IP
	 */
	String serverIP = Env.getInstance().getProperty("CompareServerIP");
	
	/**
	 * 分页查询终端
	 * @param request
	 * @param response
	 * @param pageSize
	 * @param pageNo
	 * @param deviceName
	 * @param deviceIP
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryDevice")
	public ResultModel queryDeviceByPage(HttpServletRequest request, HttpServletResponse response, Integer pageSize,
			Integer pageNo, String deviceName, String deviceIP) {
		response.setHeader("Access-Control-Allow-Origin", "*");
		Pagination page = this.getPage();
		pageSize=pageSize!=null?pageSize:10;
		page.setPageSize(pageSize);
		pageNo=pageNo!=null?pageNo:1;
		page.setCurrentPage(pageNo);
		page.setStartNum((pageNo - 1) * pageSize);
		page.setEndNum(pageNo * pageSize);
		ResultList<Object> obj = deviceService.queryDeviceByPage(page, deviceName, deviceIP);
		result = new ResultModel();
		result.setCode(1);
		result.setObj(obj);
		result.setMessage(serverIP);
		return result;
	}

	
	/**
	 * 增加终端
	 * <p>Title:saveDevice</p>
	 * <p>Description:</p>
	 * <p>update name: update date:</p>
	 * <p>update Description:</p>
	 * @param @param response
	 * @param @param deviceid
	 * @param @param device
	 * @param @return
	 * @return ResultModel
	 * @throws
	 */
	@ResponseBody
	@RequestMapping("insertDevice")
	public ResultModel insertDevice(HttpServletResponse response,Device device,
			HttpServletRequest request,String operationPersonnel,String deptid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		System.err.println(device.toString());
		 ResultModel resultModel = new ResultModel();
	     resultModel.setCode(-1);
	     try {
	    	request.setCharacterEncoding("utf-8");
	    	int rs = deviceService.check(device);
	    	
	    	 if(rs>0){
	    		 resultModel.setMessage("终端IP已经存在");
	    	 }else {

		    		int i= deviceService.insertDevice(device); 
		    		if (i==0){
		    		resultModel.setCode(0);
				    resultModel.setMessage("添加终端成功");
				    //添加终端成功日志
				    OperationLog operationLog= new OperationLog();
				    operationLog.setOperationPersonnel(operationPersonnel);
				    operationLog.setOperationContext("增加编号为"+device.getDeviceid()+"的终端");
				    operationLog.setOperationIP(ControllerUtil.getIpAddr(request));
				    operationLog.setDeptid(deptid);
				    operationLogService.insertOperationLog(operationLog);	
		    		}else if(i==1){
			    	 resultModel.setCode(-1);
					 resultModel.setMessage("添加终端失败");	
			    	}else if(i==2){
			   		resultModel.setCode(-1);
					resultModel.setMessage("设备编号不匹配");	
		    		}else if(i==3){
			    	resultModel.setCode(-1);
					resultModel.setMessage("设备类型种类不匹配");	
			    	}else if(i==4){
			    	resultModel.setCode(-1);
					resultModel.setMessage("设备密码不匹配");	
				   	}else if(i==5){
				   	resultModel.setCode(-1);
					resultModel.setMessage("无法连接到应用服务器");	
			    	}
			    	 
			}
	    	  
		} catch (Exception e) {
			resultModel.setMessage("添加终端异常");
		}
	     response.setCharacterEncoding("utf-8");
	     return resultModel;    
	}
	/**
	 * 修改终端
	 * <p>Title:updateDevice</p>
	 * <p>Description:</p>
	 * <p>update name: update date:</p>
	 * <p>update Description:</p>
	 * @param @param response
	 * @param @param device
	 * @param @return
	 * @return ResultModel
	 * @throws
	 */
	@ResponseBody
	@RequestMapping("updateDevice")
	public ResultModel updateDevice(HttpServletResponse response,Device device,HttpServletRequest request,
			String operationPersonnel,String deptid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		 ResultModel resultModel = new ResultModel();
	     resultModel.setCode(-1);
	 	System.err.println(device.toString());
	     try {
	    	 request.setCharacterEncoding("utf-8");
	    	 int rs = deviceService.check(device);
	    	 if(rs>0){
	    		 resultModel.setMessage("终端IP已经存在");
	    	 }else {
	    		int i= deviceService.updateDevice(device); 
	    		if(i==0){
	    		 resultModel.setCode(0);
			     resultModel.setMessage("修改终端成功");
			    //修改终端成功日志
				 OperationLog operationLog= new OperationLog();
				 operationLog.setOperationPersonnel(operationPersonnel);
				 operationLog.setOperationContext("修改编号为"+device.getDeviceid()+"的终端信息");
				 operationLog.setOperationIP(ControllerUtil.getIpAddr(request));
				 operationLog.setDeptid(deptid);
				 operationLogService.insertOperationLog(operationLog);	
	    		}else if(i==1){
	    		 resultModel.setCode(-1);
				 resultModel.setMessage("修改终端失败");	
	    		}else if(i==2){
	    		resultModel.setCode(-1);
				resultModel.setMessage("设备编号不匹配");	
	    		}else if(i==3){
		    	resultModel.setCode(-1);
				resultModel.setMessage("设备类型种类不匹配");	
		    	}else if(i==4){
		    	resultModel.setCode(-1);
				resultModel.setMessage("设备密码不匹配");	
		    	}else if(i==5){
		    	resultModel.setCode(-1);
				resultModel.setMessage("无法连接到应用服务器");	
		    	}
		    	
			}
	    	
		} catch (Exception e) {
			resultModel.setMessage("修改终端异常");
		}
	     response.setCharacterEncoding("utf-8");
	     return resultModel;    
	}

	/**
	 * 删除终端
	 * @param request
	 * @param response
	 * @param ids
	 * @param userid
	 * @return
	 */
	@ResponseBody
	@RequestMapping("deleteDevice")
	public ResultModel deleteDeviceByIds(HttpServletRequest request, HttpServletResponse response, String ids,
			Integer userid) {
		response.setHeader("Access-Control-Allow-Origin", "*");
		Integer obj = deviceService.deleteDeviceByIds(ids,new OperationLog(userid, "删除设备", ControllerUtil.getIpAddr(request), 2));
		result = new ResultModel();
		result.setCode(obj!=null?1:0);
		return result;
	}
	
	/**
	 * 查看终端信息
	 * @param request
	 * @param response
	 * @param id
	 * @return
	 */
	@ResponseBody
	@RequestMapping("singleDevice")
	public ResultModel queryDeviceById(HttpServletRequest request, HttpServletResponse response,Integer id){
		response.setHeader("Access-Control-Allow-Origin", "*");
		Device device = deviceService.queryDeviceById(id);
		device.setServerIP(serverIP);
		result = new ResultModel();
		result.setObj(device);
		return result;
	}

	
	/**
	 * 获取应用模式下拉列表
	 * <p>Title:queryApplicationModel</p>
	 * <p>Description:</p>
	 * <p>update name: update date:</p>
	 * <p>update Description:</p>
	 * @param @param response
	 * @param @return
	 * @return ResultModel
	 * @throws
	 */
	@ResponseBody
	@RequestMapping("queryApplicationModel")
	public ResultModel queryApplicationModel(HttpServletResponse response){
		response.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel = new ResultModel();
	     resultModel.setCode(-1);
		try {
			List<ApplicationModel>list=deviceService.queryApplicationModel();
			resultModel.setObj(list);
			resultModel.setCode(0);
		} catch (Exception e) {
			resultModel.setMessage("获取应用模式列表异常");
		}
	     response.setCharacterEncoding("utf-8");
	     return resultModel; 
	}

	
	/**
	 * 远程重启
	 * @param request
	 * @param response
	 * @param id
	 * @return
	 */
	@ResponseBody
	@RequestMapping("restartDevice")
	public ResultModel restartDevice(HttpServletRequest request, HttpServletResponse response,Integer id,Integer userid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		result = new ResultModel();
		Integer obj = deviceService.restartDevice(id,new OperationLog(userid, "远程重启编号为"+id+"的设备", ControllerUtil.getIpAddr(request), 2));
		result.setCode(obj!=null?obj:0);
		return result;
	}
	
	/**
	 * 时间同步
	 * @param request
	 * @param response
	 * @param id
	 * @return
	 */
	@ResponseBody
	@RequestMapping("setDeviceTime")
	public ResultModel setDeviceTime(HttpServletRequest request, HttpServletResponse response,Integer id,Integer userid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		result = new ResultModel();
		Integer obj = deviceService.setDeviceTime(id,new OperationLog(userid, "时间同步编号为"+id+"的设备", ControllerUtil.getIpAddr(request), 2));
		result.setCode(obj!=null?obj:0);
		return result;
	}
	
	/**
	 * 分页查询终端状态列表
	 * <p>Title:quertDeviceStateList</p>
	 * <p>Description:</p>
	 * <p>update name: update date:</p>
	 * <p>update Description:</p>
	 * @param @param deviceName
	 * @param @param deviceIP
	 * @param @param request
	 * @param @param response
	 * @param @return
	 * @return ResultModel
	 * @throws
	 */
	@ResponseBody
	@RequestMapping("quertDeviceStateList")
	public ResultModel quertDeviceStateList(String deviceName,String deviceIP,HttpServletRequest request,
			HttpServletResponse response){
		response.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel = new ResultModel();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("deviceName", deviceName);
		map.put("deviceIP",deviceIP );
		Pagination page = getPage();
		List<Device>deviceList=deviceService.quertDeviceStateList(map, page).getResults();
		resultModel.setObjExt(page);
		resultModel.setObj(deviceList);
		resultModel.setMessage(serverIP);
		response.setCharacterEncoding("utf-8");
		return resultModel;
	}
	/**
	 * 获取区域列表下拉框
	 * <p>Title:areaList</p>
	 * <p>Description:</p>
	 * <p>update name: update date:</p>
	 * <p>update Description:</p>
	 * @param @param response
	 * @param @return
	 * @return List<Area>
	 * @throws
	 */
	@ResponseBody
	@RequestMapping("areaList")
	public List<Area> areaList(HttpServletResponse response){
		response.setHeader("Access-Control-Allow-Origin", "*");
		
		
		return areaService.areaList();
	}
	
	/**
	 * 获取应用模式列表
	 * <p>Title:applicationModelList</p>
	 * <p>Description:</p>
	 * <p>update name: update date:</p>
	 * <p>update Description:</p>
	 * @param @param response
	 * @param @return
	 * @return List<ApplicationModel>
	 * @throws
	 */
	@ResponseBody
	@RequestMapping("applicationModelList")
	public List<ApplicationModel> applicationModelList(HttpServletResponse response){
		response.setHeader("Access-Control-Allow-Origin", "*");
		
		
		return applicationModelService.applicationModelList();
	}
	
	/**
	 * 获取门禁信息
	 * <p>Title:queryGateInfo</p>
	 * <p>Description:</p>
	 * <p>update name: update date:</p>
	 * <p>update Description:</p>
	 * @param @param response
	 * @param @param deviceid
	 * @param @return
	 * @return ResultModel
	 * @throws
	 */
	@ResponseBody
	@RequestMapping("queryGateInfo")
	public ResultModel queryGateInfo(HttpServletResponse response,Integer deviceid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		 ResultModel resultModel = new ResultModel();
	     resultModel.setCode(-1);
	     //获取门禁信息
		GateInfo gate=	deviceService.queryGateInfo(deviceid);
		int i= gate.result;
		gate.light=gate.light/4;
		
		gate.sound=gate.sound/2;
	
		//判断门禁信息结果状态
		if (i==0){
			resultModel.setCode(0);
			resultModel.setObj(gate);
		//	resultModel.setMessage("获取门禁信息成功");				
		}else if(i==1){
			resultModel.setCode(-1);
			resultModel.setMessage("获取门禁信息失败");	
	    }else if(i==2){
	   		resultModel.setCode(-1);
			resultModel.setMessage("设备编号不匹配");	
   		}else if(i==3){
	    	resultModel.setCode(-1);
			resultModel.setMessage("设备类型种类不匹配");	
	    }else if(i==4){
	    	resultModel.setCode(-1);
			resultModel.setMessage("设备密码不匹配");	
		}else if(i==5){
		   	resultModel.setCode(-1);
			resultModel.setMessage("无法连接到应用服务器");	
	    }
		return resultModel;
	}
	/**
	 * 初始化终端
	 * <p>Title:defaultConfig</p>
	 * <p>Description:</p>
	 * <p>update name: update date:</p>
	 * <p>update Description:</p>
	 * @param @param response
	 * @param @param deviceid
	 * @param @return
	 * @return ResultModel
	 * @throws
	 */
	@ResponseBody
	@RequestMapping("defaultConfig")
	public ResultModel defaultConfig(HttpServletResponse response,Integer deviceid,HttpServletRequest request,
			String operationPersonnel,String deptid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		 ResultModel resultModel = new ResultModel();
	     resultModel.setCode(-1);
	     //初始化终端
	     int i=	deviceService.defaultConfig(deviceid);

	
		//判断结果状态
		if (i==0){
			resultModel.setCode(0);
			resultModel.setMessage("初始化成功");
		    //终端初始化日志
			OperationLog operationLog= new OperationLog();
			operationLog.setOperationPersonnel(operationPersonnel);
			operationLog.setOperationContext("初始化了"+deviceid+"的终端信息");
			operationLog.setOperationIP(ControllerUtil.getIpAddr(request));
			operationLog.setDeptid(deptid);
			operationLogService.insertOperationLog(operationLog);
		}else if(i==1){
			resultModel.setCode(-1);
			resultModel.setMessage("初始化失败");	
	    }else if(i==2){
	   		resultModel.setCode(-1);
			resultModel.setMessage("设备编号不匹配");	
   		}else if(i==3){
	    	resultModel.setCode(-1);
			resultModel.setMessage("设备类型种类不匹配");	
	    }else if(i==4){
	    	resultModel.setCode(-1);
			resultModel.setMessage("设备密码不匹配");	
		}else if(i==5){
		   	resultModel.setCode(-1);
			resultModel.setMessage("无法连接到应用服务器");	
	    }
		return resultModel;
	}
	
	/**
	 * 终端系统升级
	 * <p>Title:deviceUpgrade</p>
	 * <p>Description:</p>
	 * <p>update name: update date:</p>
	 * <p>update Description:</p>
	 * @param @param response
	 * @param @param deviceid
	 * @param @return
	 * @return ResultModel
	 * @throws
	 */
	@ResponseBody
	@RequestMapping("deviceUpgrade")
	public ResultModel deviceUpgrade(HttpServletResponse response,Integer deviceid,HttpServletRequest request,
			String operationPersonnel,String deptid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		 ResultModel resultModel = new ResultModel();
	     resultModel.setCode(-1);
	     
	     	try {
	     	//获取上传文件到本地
	     	request.setCharacterEncoding("utf-8");
	     	response.setCharacterEncoding("utf-8");
			MultipartHttpServletRequest multiRequest=(MultipartHttpServletRequest)request;
			Map<String, MultipartFile> files = multiRequest.getFileMap();
			if(files.isEmpty()){
				resultModel.setMessage("上传失败！");
				return resultModel;
			}
			String path=request.getServletContext().getRealPath("/upgrade");
			for(MultipartFile file :files.values()){
				 String name=file.getOriginalFilename();//文件完整名称
				 String fileName=name.substring(0, name.indexOf("."));//文件名
				 String suffix=name.substring(name.lastIndexOf("."));//后缀
				 File dir=new File(path);
				 if(!dir.isDirectory()){//目录不存在则创建
				 	dir.mkdirs();
				 }
				 File newFile=new File(path+"/"+name);
				 file.transferTo(newFile);
				 //保存文件后读取文件长度和文件内容发送到富士通设备升级接口
				 long fileLen=newFile.length();
				 byte[] bytes = new byte[(int)fileLen];
				 InputStream is= new FileInputStream(newFile);
				 int len=0;
				 while((len=is.read(bytes))!=-1){
					 
				 }
				// System.err.println(bytes[(int)fileLen-1]);
			    
				 //升级终端
				 int i=deviceService.deviceUpgrade(deviceid, fileLen, bytes);
			
				//判断结果状态
				if (i==0){
					resultModel.setCode(0);
					resultModel.setMessage("升级成功");
					//终端初始化日志
					OperationLog operationLog= new OperationLog();
					operationLog.setOperationPersonnel(operationPersonnel);
					operationLog.setOperationContext("升级了"+deviceid+"终端");
					operationLog.setOperationIP(ControllerUtil.getIpAddr(request));
					operationLog.setDeptid(deptid);
					operationLogService.insertOperationLog(operationLog);
				}else if(i==1){
					resultModel.setCode(-1);
					resultModel.setMessage("升级失败");	
			    }else if(i==2){
			   		resultModel.setCode(-1);
					resultModel.setMessage("设备编号不匹配");	
		   		}else if(i==3){
			    	resultModel.setCode(-1);
					resultModel.setMessage("设备类型种类不匹配");	
			    }else if(i==4){
			    	resultModel.setCode(-1);
					resultModel.setMessage("设备密码不匹配");	
				}else if(i==5){
				   	resultModel.setCode(-1);
					resultModel.setMessage("无法连接到应用服务器");	
			    }
			   
			 }
	    	} catch (Exception e) {
	    		resultModel.setCode(-1);
				resultModel.setMessage("升级包读取出错");
			}

		return resultModel;
	}
	
	
}
