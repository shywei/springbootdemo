package com.jschange.ctr.model;

public class Flag {
	
	private Integer depid;
	
	private boolean depFlag;

	public Integer getDepid() {
		return depid;
	}

	public void setDepid(Integer depid) {
		this.depid = depid;
	}

	public boolean isDepFlag() {
		return depFlag;
	}

	public void setDepFlag(boolean depFlag) {
		this.depFlag = depFlag;
	}

	public Flag(Integer depid, boolean depFlag) {
		this.depid = depid;
		this.depFlag = depFlag;
	}
	
	public Flag(){
		
		
	}

}
