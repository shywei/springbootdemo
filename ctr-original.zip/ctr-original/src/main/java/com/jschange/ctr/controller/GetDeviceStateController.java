package com.jschange.ctr.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.SystemUser;
import com.jschange.ctr.service.GetDeviceStateService;
import com.jschange.ctr.service.OperationLogService;


/**
 * 获取设备连接状态
 * @author Administrator
 *
 */
@Controller
@RequestMapping("getDeviceStateController")
public class GetDeviceStateController extends BaseController {
	@Autowired
	private OperationLogService operationLogService;
	private OperationLog operationLog=new OperationLog();
	@Autowired
	private GetDeviceStateService getDeviceStateService;
	
	/**
	 * 获取设备在状态
	 * @param response
	 * @param request
	 * @param currentId
	 * @param confirmNum
	 * @return
	 */
	@ResponseBody
	@RequestMapping("getDeviceState")
	public ResultModel getDeviceState(HttpServletResponse response,HttpServletRequest request,Integer currentId,Integer confirmNum){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel resultModel=new ResultModel();
		resultModel.setCode(-1);
		try{
			String sysIp=super.getIP(request);//获取登陆IP
			SystemUser user=operationLogService.queryCurrentUser(currentId+"");//获取当前登录人员信息
			operationLog.setOperationPersonnel(user.getUserName());
			operationLog.setDeptid(user.getDeptid().toString());
			operationLog.setOperationIP(sysIp);
			 
			if(confirmNum ==null){
				resultModel.setMessage("所选设备参数异常");
			}
			Integer i=getDeviceStateService.getDeviceState(confirmNum);
			System.err.println("设备编号="+confirmNum);
			if(i ==-1){
				resultModel.setObj(-1);
				resultModel.setMessage("获取终端信息失败");
			}
			if(i ==0){
				resultModel.setObj(0);
				resultModel.setMessage("终端连接状态正常");
				operationLog.setOperationContext("获取终端状态：终端状态正常");
				operationLogService.insertOperationLog(operationLog);
			}
			if(i ==1){
				resultModel.setObj(0);
				resultModel.setMessage("终端连接状态异常");
				operationLog.setOperationContext("获取终端状态：终端状态异常");
				operationLogService.insertOperationLog(operationLog);
			}
			if(i ==2){
				resultModel.setObj(-1);
				resultModel.setMessage("设备编号不匹配");
			}
			if(i ==3){
				resultModel.setObj(-1);
				resultModel.setMessage("设备类型或种类不匹配");
			}
			if(i ==4){
				resultModel.setObj(-1);
				resultModel.setMessage("连接密码不匹配");
			}
			if(i ==5){
				resultModel.setObj(-1);
				resultModel.setMessage("无法连接 WEB 服务器");
			}

		}catch(Exception e){
			e.printStackTrace();
		}
		return resultModel;
	}

}
