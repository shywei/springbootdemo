package com.jschange.ctr.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jschange.ctr.dao.AreaMapper;
import com.jschange.ctr.model.Area;
import com.jschange.ctr.service.AreaService;

@Service("areaService")
public class AreaServiceImpl implements AreaService {
	
	@Autowired
	private AreaMapper areaMapper;

	@Override
	public List<Area> areaList() {
		// TODO Auto-generated method stub
		return areaMapper.areaList();
	}

}
