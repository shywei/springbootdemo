package com.jschange.ctr.service.impl;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.common.ResultListImpl;
import com.jschange.ctr.dao.DeviceDao;
import com.jschange.ctr.dao.OperationLogMapper;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.ApplicationModel;
import com.jschange.ctr.model.Device;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.service.DeviceService;

import palm.pass.function.TerminalFlowFunction;
import palmpass.client.DeviceMac;
import palmpass.client.GateInfo;
import util.CommonWords;

@Transactional
@Service("deviceService")
public class DeviceServiceImpl implements DeviceService {
	
	private static Map<String, Object> map = new HashMap<String, Object>();
	private static List<Object> rs;	
	private static ResultList<Object> result ;
	Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	DeviceDao deviceDao;

	@Autowired
	private OperationLogMapper operationLogMapper;
	
	//终端对接接口
	private TerminalFlowFunction terminal = new TerminalFlowFunction();
		
	
	@Override
	public ResultList<Object> queryDeviceByPage(Pagination page, String deviceName, String deviceIP) throws ServiceException  {
		try {
			map.put("deviceName", deviceName);
			map.put("deviceIP", deviceIP);
			map.put("offset", page.getStartNum());
			map.put("pageSize", page.getPageSize());
			int count = deviceDao.queryDeviceCount(map);
			page.setTotalCount(count);
			rs = deviceDao.queryDeviceByPage(map);
			result = new ResultListImpl<Object>();
			result.setResults(rs);
			result.setPage(page);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public int insertDevice(Device device) throws ServiceException {
		try {
			//对接添加终端接口
	   		String ip = device.getDeviceIP();//终端IP
	   		int port=Integer.parseInt(device.getDevicePort());//端口
	   		long deviceid = device.getDeviceid();//终端编号
	   		int deviceType=device.getDeviceType();//终端类型 0一体机，1考勤机
	   		//int pattern=Integer.parseInt(device.getPattern());// 模式 0表示1:1模式   1表示1：n模式
	   		byte[] passWord = device.getPassword().getBytes();//密码
	   		String webServiceIP=device.getWebserverIP();//应用服务器IP
			DeviceMac dm=terminal.AddNewTerminal(ip, port,deviceid , deviceType, 0,passWord ,webServiceIP);//0是终端种类psn900
			int i=dm.result;
			if(i==0){
				deviceDao.insertDevice(device);
			}
			return i;
		} catch (SQLException e) {
			logger.error("增加终端异常",e,DeviceService.class);
			
			throw new ServiceException(e);
		}
	}

	@Override
	public int updateDevice(Device device) throws ServiceException {
		try {
			//修改前信息
			long id=device.getId();//终端设备编号
			Device d=deviceDao.getDevice(id); 
			String oldIP=d.getDeviceIP();//终端Ip
			int oldPort=Integer.parseInt(d.getDevicePort());//端口
			int oldType=d.getDeviceType();//终端类型 0一体机，1考勤机
		//	int oldPattern=Integer.parseInt(d.getPattern());//模式 0表示1:1模式   1表示0：n模式
			byte[] oldPassWord=d.getPassword().getBytes();//密码
			//新的终端信息
			long deviceid=device.getDeviceid();//终端编号
			String deviceIP=device.getDeviceIP();//终端IP
			String subnetmask=device.getSubnetmask();//子网掩码
			String gateway=device.getGateway();//网关
			int devicePort=Integer.parseInt(device.getDevicePort());//端口
			byte[] passWord =device.getPassword().getBytes();//密码
	   		String webServiceIP=device.getWebserverIP();//应用服务器IP
			int i=terminal.SetTerminalConfig(oldIP, oldPort, id, oldType,0,
				oldPassWord, deviceid, deviceIP, subnetmask, gateway,
					devicePort, passWord, webServiceIP);
			if(i==0){
				deviceDao.updateDevice(device);
			}
			
			return  i;
		} catch (SQLException e) {
			logger.error("修改终端异常",e,DeviceService.class);

			throw new ServiceException(e);
		}
	}


	@Override
	public Integer deleteDeviceByIds(String ids,OperationLog operationLog) throws ServiceException {
		Integer it = null;
		try {
			String [] idA = ids.split(",");
			Integer [] id = new Integer[idA.length]; 
			for (int i = 0; i < id.length; i++) {
				id[i] = Integer.parseInt(idA[i]);
				operationLog.setOperationContext("删除了编号为"+id[i]+"的设备");
				operationLogMapper.callOperationPro(operationLog);
			}
			map.put("id", id);
			it = deviceDao.deleteDeviceByIds(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return it;
	}

	@Override
	public Device queryDeviceById(Integer id)throws ServiceException {
		Device device = null;
		try {
			device = deviceDao.queryDeviceById(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return device;
	}


	@Override
	public List<ApplicationModel> queryApplicationModel() throws ServiceException {
		try {
			return deviceDao.queryApplicationModel();
		} catch (SQLException e) {
			logger.error("获取应用模式列表异常",e,DeviceService.class);

			throw new ServiceException(e);
		}
	}

	

	@Override
	public Integer restartDevice(Integer id,OperationLog operationLog) {
		Device device = null;
		try {
			device = deviceDao.queryDeviceById(id);
			map.put("id", id);
			map.put("OperatorType", CommonWords.restartDevice);
			if(device!=null){
				//富士通接口处代码
				int res = restartDevice(device);
				if(res == 0){
					map.put("OperatorResult", CommonWords.operatorSuccess);
					operationLogMapper.callOperationPro(operationLog);
					return 1;
				}else{
					map.put("OperatorResult", CommonWords.operatorFail);
					return 0;
				}
			}else{
				map.put("OperatorResult", CommonWords.operatorFail);
				return 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			map.put("OperatorResult", CommonWords.operatorError);
			return 0;
		} finally{
			deviceDao.operatorRecord(map);
		}
		
	}
	
	public int restartDevice(Device device){
		int res = terminal.RemoteReboot(device.getDeviceIP(), Integer.parseInt(device.getDevicePort()),
				(long)device.getDeviceid(), device.getDeviceType(), device.getDeviceType(),
				device.getPassword().getBytes());
		return res;
	}


	@Override
	public Integer setDeviceTime(Integer id,OperationLog operationLog) throws ServiceException {
		Device device;
		try {
			//富士通接口代码
			device = deviceDao.queryDeviceById(id);
			map.put("id", id);
			map.put("OperatorType", CommonWords.timeSynchronization);
			if(device!=null){
				int res = resetTime(device);
				if(res==0){
					map.put("OperatorResult", CommonWords.operatorSuccess);
					operationLogMapper.callOperationPro(operationLog);
					return 1;
				}else{
					return 0;
				}
			}else{
				map.put("OperatorResult", CommonWords.operatorFail);
				return 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			map.put("OperatorResult", CommonWords.operatorError);
			return 0;
		} finally{
			deviceDao.operatorRecord(map);
		}
		
	}

	public int resetTime(Device device){
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMddHHmmss");
		String da = sdf.format(date);
		int res = terminal.SyncTime(device.getDeviceIP(), Integer.parseInt(device.getDevicePort()),
				(long)device.getDeviceid(), device.getDeviceType(), device.getDeviceType(),
				device.getPassword().getBytes(), da.getBytes());
		return res;
	}

	@Override
	public int check(Device device) throws ServiceException {
		try {
			return deviceDao.check(device);
		} catch (SQLException e) {
			logger.error("检查终端ip是否存在异常",e,DeviceService.class);

			throw new ServiceException(e);
		}
	}

	@Override
	public ResultList<Device> quertDeviceStateList(Map<String, Object> map, Pagination page) throws ServiceException {
		int count =0;
		try {
			 if (page != null) {
		        	count = deviceDao.queryDeviceStateCount(map);
	                page.setTotalCount(count);
	                map.put("page", (page.getCurrentPage()-1)*page.getPageSize());
	                map.put("rows", page.getPageSize());
	            }
			 List<Device>list=null;
			 ResultList<Device>res= new ResultListImpl<Device>();
			 list=deviceDao.queryDeviceState(map);
			 res.setPage(page);
	         res.setResults(list);
	         return res;
		} catch (Exception e) {
			logger.error("获取终端状态列表异常",e,DeviceService.class);

			throw new ServiceException(e);
		}
	}
	//门禁信息
	@Override
	public GateInfo queryGateInfo(Integer deviceid) throws ServiceException {
		
		try {
		//根据终端编号查询终端连接信息
		long id = deviceid;
		Device d=	deviceDao.getDevice(id);
		String deviceIP=d.getDeviceIP();
		int port=Integer.parseInt(d.getDevicePort());
		int deviceType=d.getDeviceType();
		byte[]passWord=d.getPassword().getBytes();
		//调用接口获取终端门禁信息
		GateInfo gate=terminal.GetGateInfo(deviceIP, port, id, deviceType, 0, passWord);
	
		return gate;
		} catch (SQLException e) {
			logger.error("获取门禁信息异常",e,DeviceService.class);

			throw new ServiceException(e);
		}
		
		
	}

	@Override
	public int defaultConfig(Integer deviceid) throws ServiceException {
		try {
		//根据终端编号查询终端连接信息
		long id = deviceid;
		Device d=	deviceDao.getDevice(id);
		String deviceIP=d.getDeviceIP();
		int port=Integer.parseInt(d.getDevicePort());
		int deviceType=d.getDeviceType();
		byte[]passWord=d.getPassword().getBytes();
		//调用接口初始化终端
		int i=terminal.SystemInitial(deviceIP, port, id, deviceType, 0, passWord);
		map.put("id", deviceid);
		map.put("OperatorType", "终端初始化");
		if(i==0){
			map.put("OperatorResult", CommonWords.operatorSuccess);
		}else {
			map.put("OperatorResult", CommonWords.operatorFail);
		}
		return i;
		} catch (SQLException e) {
			logger.error("初始化终端异常",e,DeviceService.class);

			throw new ServiceException(e);
		}finally {
			deviceDao.operatorRecord(map);
		}
	}

	@Override
	public int deviceUpgrade(Integer deviceid,long fileLen,byte[]bytes) throws ServiceException {
		try {
			//根据终端编号查询终端连接信息
			long id = deviceid;
			Device d=	deviceDao.getDevice(id);
			String deviceIP=d.getDeviceIP();
			int port=Integer.parseInt(d.getDevicePort());
			int deviceType=d.getDeviceType();
			byte[]passWord=d.getPassword().getBytes();
			//调用接口初始化终端
			int i=terminal.deviceUpgrade(deviceIP, port, id, deviceType, 0, passWord,fileLen,bytes);
			map.put("id", deviceid);
			map.put("OperatorType", "终端升级");
			if(i==0){
				map.put("OperatorResult", "升级成功");
			}else {
				map.put("OperatorResult", "升级失败");
			}
			return i;
			} catch (SQLException e) {
				logger.error("终端升级异常",e,DeviceService.class);

				throw new ServiceException(e);
			}finally {
				deviceDao.operatorRecord(map);
			}
	}
}
