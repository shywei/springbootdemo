package com.jschange.ctr.service;

import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.AttendanceDataStatistics;
import com.jschange.ctr.model.DeptInfo;
import com.jschange.ctr.model.Drop;
import com.jschange.ctr.model.Role;

public interface StatisticsService {

	List<Drop> selectsumhasdeleted(Map<String, Object> map, Integer depId);

	List<AttendanceDataStatistics> selectSumAttendnum(Map<String, Object> map);

	List<Role> queryRole();

	List<DeptInfo> deptListByRole(Integer code, Integer deptid);

}
