package com.jschange.ctr.dao;

import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.Event;


public interface EventMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Event record);

    int insertSelective(Event record);

    Event selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Event record);

    int updateByPrimaryKey(Event record);
    //条件查询总大队点名记录数
	int selectTeamRowsByReqire(Map<String, Object> map);//1
	//按条件查询各大队的信息
	List<Event> selectTeamRecord(Map<String, Object> map);//1
	//获得总人数、应到人数、病休人数、其它人数的方法
	List<Map> getPrepareNum(Map map);//1
	//导出Excel表格需要的所有大队信息
	List<Event> getTeamRecord(Map<String, Object> map);//1
	//结束点名时，向eventinfo表中插入人数信息 
	int insertEventinfo(Map<String,Object> map);//1
}