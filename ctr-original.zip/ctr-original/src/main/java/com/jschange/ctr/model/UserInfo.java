package com.jschange.ctr.model;


public class UserInfo {
    private Integer id;//主键id
    private String userid; //身份编号
    private String userName; //人员姓名
    private Integer gender; //性别
    private String birthday; //出生日期
    private Integer roleid; //角色编号
    private String roleName; //角色名称
    private Integer deptid; //部门编号
    private String deptName; //部门名称
    private Integer isBalckList; //是否黑名单（默认位0 否   1 是）
    private String createtime; //入队时间
    private String deletetime; //离队时间
    private String modifytime; //修改时间
    private Integer hasdeleted; //是否被删除（0未删除 1删除）
    private Integer hasMetacarpalVein; //是否录入掌静脉（0不存在 1存在）
    private byte[] metacarpalVein; //掌静脉信息
    private Integer hasDigitalVein; //是否录入指静脉（0不存在 1存在）
    private byte[] digitalVein; //指静脉信息
    private String photoUrl; //照片地址
    private Integer oldDept; //原部门编号
    private String oldDeptName;
    private Integer stateid; //状态编号
    private String stateName;
    private Integer reviseState; //调度状态
    private String reviseTime; //调度时间
    private String receiveTime; //接收时间
    private Integer receiveDeptid; //接收部门编号
    private String receiveDeptName;
    private String note; //驳回理由
    private Integer areaid; //区域编号
    private String dormitoryNum; //宿舍号
    private String bedNum; //床位
    private String placeOrigin; //籍贯
    private String nationalities; //民族
    private Integer isMarried; //婚否
    private Integer hasChild; //生育情况
    private String politicalStatus; //政治面貌
    private Integer cardType; //证件类型
    private String cardNum; //证件号码
    private String beginEffectiveDate; //证件有效期（起）
    private String endEffectiveDate; //证件有效期（止）
    private String contact; //联系人
    private String contactNum; //联系人电话
    private String residenceAdress; //户口所在地
    private String address; //现居住地
    //private String personid; //人员编号
    //private Integer fingerDeviceid;//指静脉设备id
    //private Integer receivefingerDeviceid;//接收指静脉设备信息ID
    
    
	/*public Integer getReceivefingerDeviceid() {
		return receivefingerDeviceid;
	}
	public void setReceivefingerDeviceid(Integer receivefingerDeviceid) {
		this.receivefingerDeviceid = receivefingerDeviceid;
	}
	public Integer getFingerDeviceid() {
		return fingerDeviceid;
	}
	public void setFingerDeviceid(Integer fingerDeviceid) {
		this.fingerDeviceid = fingerDeviceid;
	}*/
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getGender() {
		return gender;
	}
	public void setGender(Integer gender) {
		this.gender = gender;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public Integer getRoleid() {
		return roleid;
	}
	public void setRoleid(Integer roleid) {
		this.roleid = roleid;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public Integer getDeptid() {
		return deptid;
	}
	public void setDeptid(Integer deptid) {
		this.deptid = deptid;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public Integer getIsBalckList() {
		return isBalckList;
	}
	public void setIsBalckList(Integer isBalckList) {
		this.isBalckList = isBalckList;
	}
	public String getCreatetime() {
		return createtime;
	}
	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}
	public String getDeletetime() {
		return deletetime;
	}
	public void setDeletetime(String deletetime) {
		this.deletetime = deletetime;
	}
	public String getModifytime() {
		return modifytime;
	}
	public void setModifytime(String modifytime) {
		this.modifytime = modifytime;
	}
	public Integer getHasdeleted() {
		return hasdeleted;
	}
	public void setHasdeleted(Integer hasdeleted) {
		this.hasdeleted = hasdeleted;
	}
	public Integer getHasMetacarpalVein() {
		return hasMetacarpalVein;
	}
	public void setHasMetacarpalVein(Integer hasMetacarpalVein) {
		this.hasMetacarpalVein = hasMetacarpalVein;
	}
	public byte[] getMetacarpalVein() {
		return metacarpalVein;
	}
	public void setMetacarpalVein(byte[] metacarpalVein) {
		this.metacarpalVein = metacarpalVein;
	}
	public Integer getHasDigitalVein() {
		return hasDigitalVein;
	}
	public void setHasDigitalVein(Integer hasDigitalVein) {
		this.hasDigitalVein = hasDigitalVein;
	}
	public byte[] getDigitalVein() {
		return digitalVein;
	}
	public void setDigitalVein(byte[] digitalVein) {
		this.digitalVein = digitalVein;
	}
	public String getPhotoUrl() {
		return photoUrl;
	}
	public void setPhotoUrl(String photoUrl) {
		this.photoUrl = photoUrl;
	}
	public Integer getOldDept() {
		return oldDept;
	}
	public void setOldDept(Integer oldDept) {
		this.oldDept = oldDept;
	}
	public String getOldDeptName() {
		return oldDeptName;
	}
	public void setOldDeptName(String oldDeptName) {
		this.oldDeptName = oldDeptName;
	}
	public Integer getStateid() {
		return stateid;
	}
	public void setStateid(Integer stateid) {
		this.stateid = stateid;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public Integer getReviseState() {
		return reviseState;
	}
	public void setReviseState(Integer reviseState) {
		this.reviseState = reviseState;
	}
	public String getReviseTime() {
		return reviseTime;
	}
	public void setReviseTime(String reviseTime) {
		this.reviseTime = reviseTime;
	}
	public String getReceiveTime() {
		return receiveTime;
	}
	public void setReceiveTime(String receiveTime) {
		this.receiveTime = receiveTime;
	}
	public Integer getReceiveDeptid() {
		return receiveDeptid;
	}
	public void setReceiveDeptid(Integer receiveDeptid) {
		this.receiveDeptid = receiveDeptid;
	}
	public String getReceiveDeptName() {
		return receiveDeptName;
	}
	public void setReceiveDeptName(String receiveDeptName) {
		this.receiveDeptName = receiveDeptName;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public Integer getAreaid() {
		return areaid;
	}
	public void setAreaid(Integer areaid) {
		this.areaid = areaid;
	}
	public String getDormitoryNum() {
		return dormitoryNum;
	}
	public void setDormitoryNum(String dormitoryNum) {
		this.dormitoryNum = dormitoryNum;
	}
	public String getBedNum() {
		return bedNum;
	}
	public void setBedNum(String bedNum) {
		this.bedNum = bedNum;
	}
	public String getPlaceOrigin() {
		return placeOrigin;
	}
	public void setPlaceOrigin(String placeOrigin) {
		this.placeOrigin = placeOrigin;
	}
	public String getNationalities() {
		return nationalities;
	}
	public void setNationalities(String nationalities) {
		this.nationalities = nationalities;
	}
	public Integer getIsMarried() {
		return isMarried;
	}
	public void setIsMarried(Integer isMarried) {
		this.isMarried = isMarried;
	}
	public Integer getHasChild() {
		return hasChild;
	}
	public void setHasChild(Integer hasChild) {
		this.hasChild = hasChild;
	}
	public String getPoliticalStatus() {
		return politicalStatus;
	}
	public void setPoliticalStatus(String politicalStatus) {
		this.politicalStatus = politicalStatus;
	}
	public Integer getCardType() {
		return cardType;
	}
	public void setCardType(Integer cardType) {
		this.cardType = cardType;
	}
	public String getCardNum() {
		return cardNum;
	}
	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}
	public String getBeginEffectiveDate() {
		return beginEffectiveDate;
	}
	public void setBeginEffectiveDate(String beginEffectiveDate) {
		this.beginEffectiveDate = beginEffectiveDate;
	}
	public String getEndEffectiveDate() {
		return endEffectiveDate;
	}
	public void setEndEffectiveDate(String endEffectiveDate) {
		this.endEffectiveDate = endEffectiveDate;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getContactNum() {
		return contactNum;
	}
	public void setContactNum(String contactNum) {
		this.contactNum = contactNum;
	}
	public String getResidenceAdress() {
		return residenceAdress;
	}
	public void setResidenceAdress(String residenceAdress) {
		this.residenceAdress = residenceAdress;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	/*public String getPersonid() {
		return personid;
	}
	public void setPersonid(String personid) {
		this.personid = personid;
	}*/
    
    
}
