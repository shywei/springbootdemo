package com.jschange.ctr.model;

import java.io.Serializable;
import java.util.Date;

public class WiFiDriviceModel implements Serializable  {
	private Integer id;//主键ID
	private Integer isDeleted;//是否被删除
	private Integer createId;
	private Integer modifyId;
	private String  wifiNo;//wifi编号
	private String wifiName;//wifi名称
	private String wifiPassWord;//wifi密码
	private Integer status;//wifi状态
	private String memoInfo;//WiFi备注
	
	private Date createDate;//创建日期
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getModifyDate() {
		return modifyDate;
	}
	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}
	private Date modifyDate;//修改日期
	
	
	
	public Integer getModifyId() {
		return modifyId;
	}
	public void setModifyId(Integer modifyId) {
		this.modifyId = modifyId;
	}
	public Integer getCreateId() {
		return createId;
	}
	public void setCreateId(Integer createId) {
		this.createId = createId;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}
	public String getWifiNo() {
		return wifiNo;
	}
	public void setWifiNo(String wifiNo) {
		this.wifiNo = wifiNo;
	}
	public String getWifiName() {
		return wifiName;
	}
	public void setWifiName(String wifiName) {
		this.wifiName = wifiName;
	}
	public String getWifiPassWord() {
		return wifiPassWord;
	}
	public void setWifiPassWord(String wifiPassWord) {
		this.wifiPassWord = wifiPassWord;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getMemoInfo() {
		return memoInfo;
	}
	public void setMemoInfo(String memoInfo) {
		this.memoInfo = memoInfo;
	}
	

}
