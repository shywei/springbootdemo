package com.jschange.ctr.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.alibaba.fastjson.JSON;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.UserInfo;
import com.jschange.ctr.service.OperationLogService;
import com.jschange.ctr.service.UserInfoSaveService;

import palm.pass.function.TerminalFlowFunction;
import palmpass.client.DeviceInfo;
import sun.misc.BASE64Decoder;

import util.Env;

@Controller
@RequestMapping("userInfoSaveController")
public class UserInfoSaveController extends BaseController{
	
	private int count=0;
	private String path = Env.getInstance().getProperty("imgPath");
	
	@Autowired
	private UserInfoSaveService userInfoSaveService;
	
	@Autowired
	private OperationLogService operationLogService;
	
	/**
	 * 人员注册
	 * @param userInfo
	 * @param createid 				进行人员注册操作的账号用户名
	 * @return
	 */
	@RequestMapping("saveUserInfo")
	@ResponseBody
	public ResultModel registerUserInfo(UserInfo userInfo,HttpServletResponse resp,HttpServletRequest req,String userName1,String deptid1,String veinData){
		resp.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel=new ResultModel();
		resultModel.setCode(-1);
		try {
			if(userName1==null || "".equals(userName1) || deptid1==null || "".equals(deptid1)){
				resultModel.setMessage("注册失败！");
				return resultModel;
			}
			if(userInfo.getPhotoUrl()!=null	 && !"".equals(userInfo.getPhotoUrl()) ){
				File file=new File(path+"/"+userInfo.getPhotoUrl());
				if(!file.exists()){
					resultModel.setMessage("请录入照片！");
					return resultModel;
				}
			}
			//判断是否填写必填项
			if(userInfo.getUserid()==null || "".equals(userInfo.getUserid()) || userInfo.getUserName()==null || "".equals(userInfo.getUserName()) 
					|| userInfo.getRoleid()==null || userInfo.getRoleid()==-1 || userInfo.getDeptid() ==null  || userInfo.getDeptid()==-1
					|| userInfo.getPhotoUrl() ==null || "".equals(userInfo.getPhotoUrl())){
				resultModel.setMessage("信息未填写完整！");
				return resultModel;
			}
			else{
				File file=new File(path+"/"+userInfo.getPhotoUrl());
				if(!file.exists()){
					resultModel.setMessage("图片不存在！");
					return resultModel;
				}
				OperationLog operationLog=new OperationLog();
				operationLog.setOperationIP(super.getIP(req));
				operationLog.setOperationPersonnel(userName1);
				operationLog.setDeptid(deptid1);
				//转换掌静脉信息至byte[]
				if(veinData!=null && !"".equals(veinData)){
					byte[] bytes=org.apache.commons.codec.binary.Base64.decodeBase64(veinData.getBytes());
					userInfo.setMetacarpalVein(bytes);
				}
				if(userInfo.getId()==null || "".equals(userInfo.getId())){
					//人员注册
					count=userInfoSaveService.checkRegister(userInfo.getUserid());
					if(count>0){
						resultModel.setMessage("编号已存在！");
						return resultModel;
					}
					SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddHHmmss");
					//userInfo.setPersonid(sdf.format(new Date())+(int)(Math.random()*9000+1000));
					String suffix=userInfo.getPhotoUrl().substring(userInfo.getPhotoUrl().lastIndexOf("."));
					File f1=new File(path+"/"+userInfo.getUserid()+suffix);
					file.renameTo(f1);
					userInfo.setPhotoUrl(f1.getName());
					count=userInfoSaveService.registerUserInfo(userInfo);
					if(count==1){
						resultModel.setCode(0);
						resultModel.setObj(userInfoSaveService.getIdByUserId(userInfo.getUserid()));
						resultModel.setMessage("注册成功！");
						//操作日志
						operationLog.setOperationContext("注册成功！编号"+userInfo.getUserid());
						operationLogService.insertOperationLog(operationLog);
					}
					else{
						resultModel.setMessage("注册失败！");
						//操作日志
						operationLog.setOperationContext("注册失败！编号"+userInfo.getUserid());
						operationLogService.insertOperationLog(operationLog);
					}
				}
				else{
					//人员修改
					if(!userInfo.getUserid().equals(userInfoSaveService.getUserid(userInfo.getId()))){
						resultModel.setMessage("禁止修改人员编号！");
						return resultModel;
					}
					Map<String,Object> param=new HashMap<>();
					param.put("userid", userInfo.getUserid());
					param.put("id", userInfo.getId());
					count=userInfoSaveService.checkUpdate(param);
					if(count>0){
						resultModel.setMessage("编号已存在！");
						return resultModel;
					}
					String suffix=userInfo.getPhotoUrl().substring(userInfo.getPhotoUrl().lastIndexOf("."));
					//判断是否更改照片
					if(!userInfoSaveService.getPhotoUrl(userInfo.getId()).equals(userInfo.getPhotoUrl())){
						//照片不一样
						//删除原来的
						File f=new File(path+"/"+userInfo.getUserid()+suffix);
						f.delete();
						//文件改名
						file.renameTo(f);
						userInfo.setPhotoUrl(f.getName());
					}
					count=userInfoSaveService.updateUserInfo(userInfo);
					resultModel.setCode(0);
					resultModel.setMessage("修改成功！");
					//操作日志
					operationLog.setOperationContext("修改编号"+userInfo.getUserid()+"的信息成功");
					operationLogService.insertOperationLog(operationLog);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 上传图片
	 * @param resp
	 * @param req
	 * @param userid 						账号id
	 * @return
	 */
	@RequestMapping("uploadImg")
	@ResponseBody
	public ResultModel uploadImg(HttpServletResponse resp,HttpServletRequest req,String userid){
		ResultModel resultModel=new ResultModel();
		resp.setHeader("Access-Control-Allow-Origin", "*");
		try {
			if(userid==null || "".equals(userid)){
				resultModel.setMessage("上传失败！");
				return resultModel;
			}
			MultipartHttpServletRequest multiRequest=(MultipartHttpServletRequest)req;
			Map<String, MultipartFile> files = multiRequest.getFileMap();
			if(files.isEmpty()){
				resultModel.setMessage("上传失败！");
				return resultModel;
			}
			for(MultipartFile file :files.values()){
				 String name=file.getOriginalFilename();//文件完整名称
				 String fileName=name.substring(0, name.indexOf("."));//文件名
				 String suffix=name.substring(name.lastIndexOf("."));//后缀
				 if(".JPG".equals(suffix.toUpperCase()) || 
						 ".BMP".equals(suffix.toUpperCase()) || 
						 ".PNG".equals(suffix.toUpperCase())	 ||
						 ".GIF".equals(suffix.toUpperCase()) ||
						 ".JPEG".equals(suffix.toUpperCase())){
					 File dir=new File(path);
					 if(!dir.isDirectory()){//目录不存在则创建
					 	dir.mkdirs();
					 }
					 File newFile=new File(path+"/"+userid+suffix);
					 file.transferTo(newFile);
					 resultModel.setCode(0);
					 resultModel.setObj(newFile.getName());
					 resultModel.setObjExt(req.getScheme()+"://"+req.getServerName()+":"+req.getServerPort()+"/image/"+newFile.getName());
				 }
				 else{
					 resultModel.setMessage("请上传正确的图片！");
				 }
			 }
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 获取大队下拉框
	 * @return
	 */
	@RequestMapping("getDept")
	@ResponseBody
	public ResultModel getDept(HttpServletResponse resp){
		ResultModel resultModel=new ResultModel();
		resp.setHeader("Access-Control-Allow-Origin", "*");
		try {
			resultModel.setObj(userInfoSaveService.getDept());
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 获取角色下拉框
	 * @return
	 */
	@RequestMapping("getRole")
	@ResponseBody
	public ResultModel getRole(HttpServletResponse resp){
		ResultModel resultModel=new ResultModel();
		resp.setHeader("Access-Control-Allow-Origin", "*");
		try {
			resultModel.setObj(userInfoSaveService.getRole());
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 获取证件类型下拉框
	 * @param resp
	 * @return
	 */
	@RequestMapping("getCardType")
	@ResponseBody
	public ResultModel getCardType(HttpServletResponse resp){
		ResultModel resultModel=new ResultModel();
		resp.setHeader("Access-Control-Allow-Origin", "*");
		try {
			resultModel.setObj(userInfoSaveService.getCardType());
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	/**
	 * 人像采集
	 * @param resp
	 * @param userid					操作账号id
	 * @param photo					照片的字节数组字符串
	 * @return
	 */
	@RequestMapping("photograph")
	@ResponseBody
	public ResultModel photograph(HttpServletResponse resp,String userid,String photo,HttpServletRequest req){
		ResultModel resultModel=new ResultModel();
		resp.setHeader("Access-Control-Allow-Origin", "*");
		try {
			if(userid==null || "".equals(userid) || photo==null ||"".equals(photo)){
				resultModel.setMessage("采集失败！");
				return resultModel;
			}
			BASE64Decoder decoder=new BASE64Decoder();
			byte[] b = decoder.decodeBuffer(photo); 
			for(int i=0;i<b.length;++i){  
                if(b[i]<0) {//调整异常数据  
                    b[i]+=256;  
                }  
            }
			//生成jpg图片  
            String imgFilePath = path+"/"+userid+".jpg";//新生成的图片  
            OutputStream out = new FileOutputStream(imgFilePath);      
            out.write(b);  
            out.flush();  
            out.close(); 
            resultModel.setObj(userid+".jpg");
            resultModel.setObjExt(req.getScheme()+"://"+req.getServerName()+":"+req.getServerPort()+"/image/"+userid+".jpg");
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	
	/**
	 * 查看终端信息
	 * @param resp
	 * @param remoteIP			终端IP
	 * @param port				端口号
	 * @param confirmNum		终端编号
	 * @param confirmType		终端类型	
	 * @param confirmModel		终端种类
	 * @param confirmPasswd		终端密码
	 * @return
	 */
	@RequestMapping("getTerminalInfo")
	@ResponseBody
	public ResultModel getTerminalInfo(HttpServletResponse resp,String remoteIP,Integer port,Long confirmNum,Integer confirmType,Integer confirmModel,String confirmPasswd){
		resp.setHeader("Access-Control-Allow-Origin", "*");
		ResultModel resultModel=new ResultModel();
		resultModel.setCode(-1);
		try {
			TerminalFlowFunction t=new TerminalFlowFunction();
			DeviceInfo d=t.GetTerminalInfo(remoteIP, port, confirmNum, confirmType, confirmModel,confirmPasswd.getBytes());
			Map<String,Object> param=new HashMap<>();
			param.put("confirmNum", confirmNum);
			param.put("type", "查看信息");
			if(d.result==0){
				param.put("result","版本号:"+d.version.trim()+",管理员(手):"+d.adminNum);
			}
			else{
				param.put("result","获取失败");
			}
			count=userInfoSaveService.getTerminalInfo(param);
			if(count==1){
				resultModel.setCode(0);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultModel;
	}
}
