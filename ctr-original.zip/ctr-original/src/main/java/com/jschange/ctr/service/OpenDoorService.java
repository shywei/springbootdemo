package com.jschange.ctr.service;

import com.jschange.ctr.exception.ServiceException;

public interface OpenDoorService {
	
	
	public Integer remoteOpenDoor(Integer id)throws ServiceException;//远程开门

}
