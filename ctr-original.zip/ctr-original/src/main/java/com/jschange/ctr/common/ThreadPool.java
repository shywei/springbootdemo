package com.jschange.ctr.common;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


public class ThreadPool {
	private static final int THREADPOOLSIZE = 1;  
	
    public static void treadPool() throws IOException{  
    	
        final ServerSocket server = new ServerSocket(9001);  
        for(int i=0;i<THREADPOOLSIZE;i++){  
            Thread thread = new Thread(){  
                public void run(){  
                    while(true){  
                            try {
								Socket client = server.accept();
								SocketClient socketClient=new SocketClient(client);
								socketClient.handle(client);
							} catch (Exception e) {
								e.printStackTrace();
							}  
                    }   
                }  
            };  
            thread.start(); 
        }  
    } 
}
