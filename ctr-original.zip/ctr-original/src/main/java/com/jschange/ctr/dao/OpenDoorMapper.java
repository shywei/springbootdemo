package com.jschange.ctr.dao;

import java.sql.SQLException;

import com.jschange.ctr.model.Device;

public interface OpenDoorMapper {

	public Device getDeviceInfo(Integer id)throws SQLException;//获取掌静脉设备信息
	
	

}
