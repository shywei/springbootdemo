package com.jschange.ctr.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jschange.ctr.dao.DeptInfoMapper;
import com.jschange.ctr.model.DeptInfo;
import com.jschange.ctr.service.DeptInfoService;



@Service("DeptInfoService")
public class DeptInfoServiceImpl implements DeptInfoService{

	@Autowired
	private DeptInfoMapper deptInfoMapper;

	public int insertDept(DeptInfo sys) {
		// TODO Auto-generated method stub
		return deptInfoMapper.insertDept(sys);
	}

	public List<DeptInfo> selectall(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return deptInfoMapper.selectall(map);
	}




}
