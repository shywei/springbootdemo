package com.jschange.ctr.common;
import java.io.Serializable;

/**
 * 翻页实现类
 * 
 * @author
 * 
 */
public class Pagination implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8925597938748885418L;

	/**
	 * 当前页
	 */
	private int currentPage = 1;

	/**
	 * 每页条数
	 */
	private int pageSize = 10;
	/**
	 * 总条数
	 */
	private int totalCount = 0;

	public int getPageCount() {

		if(totalCount <=0){
			pageCount = 0;
		}else{
		 pageCount =(int)Math.ceil((totalCount*1.0) / (pageSize*1.0) );
		}

		return pageCount;
	}

	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}

	/**
	 *  页数
	 */
	private int pageCount = 0;

	public int getCurrentPage() {

		return currentPage;
	}

	public int getPageSize() {
		if (pageSize < 0) {
			return 0;
		}
		return pageSize;
	}


	public int getTotalCount() {
		if (totalCount < 0) {
			return 0;
		}
		return totalCount;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	String orderBy;

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	private int startNum;//开始条数

	private int endNum;//结束

	public int getStartNum() {
		return startNum;
	}

	public void setStartNum(int startNum) {
		this.startNum = startNum;
	}

	public int getEndNum() {
		return endNum;
	}

	public void setEndNum(int endNum) {
		this.endNum = endNum;
	}
}
