package com.jschange.ctr.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.FingerDrivice;
import com.jschange.ctr.model.UserInfo;

public interface VenaDigitalisMapper {

	FingerDrivice selectDriviceInfoById(Integer mesID) throws SQLException;
	
	List<FingerDrivice> queryDriviceInfo(Integer areaID) throws SQLException;
	
	FingerDrivice selectDriviceInfoByFingerCode(String fingerCode) throws SQLException;
	
	void insertVenaInfo(String fingerCode) throws SQLException;
	
	void updateDriviceState(String fingerCode) throws SQLException;
	
	void updateDriviceStatus(String fingerCode) throws SQLException;
	
	void insertFingerInfo(Map<Object, Object> map) throws SQLException;
	
	Integer queryDriviceID(Integer id) throws SQLException;

	UserInfo queryUserInfo(Integer keyId) throws SQLException;

	void insertRecord(Map<String, Object> map) throws SQLException;

	void insertFingerInfoForUserInfo(Map<Object, Object> map)throws SQLException;

	Integer queryDeptID(String deptName)throws SQLException;
}
