package com.jschange.ctr.model;

import java.util.Date;

public class Server {
	/**
	 *  serverid             int(11) not null auto_increment comment '服务器编号',
   serverIP             varchar(20) comment '服务器IP地址',
   serverName           varchar(30) comment '服务器名称',
   identifyMode         varchar(10) comment '更新认证库的方式，1表示立即更新,0或其他表示重启更新',
   identifyPrecision    varchar(10) comment '识别精度',
   createtime           datetime comment '创建时间',
   modifytime           datetime comment '修改时间',
   serverType           int(11) comment '服务器类型 0 数据服务器 1对比服务器',
   isSpare              int(11) comment '是否备用 0不是 1备用',
   serverStatus         int(11) comment '服务器状态 0启用 1停用',
	 */
	private Integer serverid;
	private String serverIP;
	private String serverName;
	private String identifyMode;//更新认证库的方式，1表示立即更新,0或其他表示重启更新
	private Integer identifyPrecision;//识别精度 0普通 1 高 2最高
	private String createtime;
	private String modifytime;
	private Integer serverType;//服务器类型 0 数据服务器 1对比服务器
	private Integer isSpare;//是否备用 0不是 1备用
	private Integer serverStatus;//服务器状态 0启用 1停用
	public Integer getServerid() {
		return serverid;
	}
	public void setServerid(Integer serverid) {
		this.serverid = serverid;
	}
	public String getServerIP() {
		return serverIP;
	}
	public void setServerIP(String serverIP) {
		this.serverIP = serverIP;
	}
	public String getServerName() {
		return serverName;
	}
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	public String getCreatetime() {
		return createtime;
	}
	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}
	public String getModifytime() {
		return modifytime;
	}
	public void setModifytime(String modifytime) {
		this.modifytime = modifytime;
	}
	public Integer getServerType() {
		return serverType;
	}
	public void setServerType(Integer serverType) {
		this.serverType = serverType;
	}
	public Integer getIsSpare() {
		return isSpare;
	}
	public void setIsSpare(Integer isSpare) {
		this.isSpare = isSpare;
	}
	public Integer getServerStatus() {
		return serverStatus;
	}
	public void setServerStatus(Integer serverStatus) {
		this.serverStatus = serverStatus;
	}
	public String getIdentifyMode() {
		return identifyMode;
	}
	public void setIdentifyMode(String identifyMode) {
		this.identifyMode = identifyMode;
	}
	public Integer getIdentifyPrecision() {
		return identifyPrecision;
	}
	public void setIdentifyPrecision(Integer identifyPrecision) {
		this.identifyPrecision = identifyPrecision;
	}
	
	
	
}
