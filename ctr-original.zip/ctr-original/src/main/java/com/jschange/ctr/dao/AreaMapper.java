package com.jschange.ctr.dao;

import java.util.List;

import com.jschange.ctr.model.Area;

public interface AreaMapper {
	
	public List<Area> areaList();//获取区域列表

}
