package com.jschange.ctr.service;

import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.OperationLog;

public interface UserInfoDeleteService {

	Integer deleteUserInfo(String ids, Integer userid,OperationLog operationLog) throws ServiceException;

	Integer recoverUserInfo(Integer id, Integer userid, Integer deptid,OperationLog operationLog);

}
