package com.jschange.ctr.dao;

import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.SystemUser;


public interface OperationLogMapper {
	
	//查询日志总数
	int getOperationLogCount(Map<String, Object>map) ;
	
	//查询日志列表
	List<OperationLog> getOperationLogList(Map<String, Object>map);
	
	//插入操作日志
	int insertOperationLog(OperationLog operationLog);
	
	//根据人员编号查询人员的姓名
	String getName(String userid);
	String getNameByID(String id);
	
	//根据状态编号查询到状态
	String getState(String stateId);
	 
	//根据登录人当前登陆用自增列ID获取该用户的姓名和大队编号
	SystemUser queryCurrentUser(String id);
	 
	void callOperationPro(OperationLog operationLog);
	
}
