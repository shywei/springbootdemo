package com.jschange.ctr.model;

import java.io.Serializable;
import java.util.Date;

public class RollCallUserInfo implements Serializable{
    private Integer id;

    private Date rollcalluserCreatetime;//登记时间

    private String rollcalluserDept;//code

    private Date rollcalluserDeletetime;//出狱时间

    private Integer rollcalluserHasdeleted;//是否被删除

    private Integer rollcalluserPhoto;//是否有照片0   1

    private String rollcalluserNo;//编号

    private String rollcalluserId;

    private String rollcalluserName;//学员名
    
    private int stateId;//考勤状态
    
    private int teamId;
    private String stataName;//状态名
    private String depName;//现部门名
    
    private int userId;//userInfo表的主键id
    
    private String oldDept;//原部门code
    
    private Date reviseTime;//调队时间
    
    private Date receiveTime;//接收时间
    
    private Integer reviseState;//调队状态 1掉队中 2 已调队 3驳回 （未掉队）
    
    private String reviseDept;//要调入的部门
    
    private String photoUrl;//照片地址
    
    private String note;//备注（用于写部门调动驳回原因）
    
    private String reviseDeptName;//接收部门名称
    
    private String oldDeptName;

	public String getOldDeptName() {
		return oldDeptName;
	}

	public void setOldDeptName(String oldDeptName) {
		this.oldDeptName = oldDeptName;
	}

	public String getReviseDeptName() {
		return reviseDeptName;
	}

	public void setReviseDeptName(String reviseDeptName) {
		this.reviseDeptName = reviseDeptName;
	}

	public String getPhotoUrl() {
		return photoUrl;
	}

	public void setPhotoUrl(String photoUrl) {
		this.photoUrl = photoUrl;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getReviseDept() {
		return reviseDept;
	}

	public void setReviseDept(String reviseDept) {
		this.reviseDept = reviseDept;
	}

	public Date getReviseTime() {
		return reviseTime;
	}

	public void setReviseTime(Date reviseTime) {
		this.reviseTime = reviseTime;
	}

	public Date getReceiveTime() {
		return receiveTime;
	}

	public void setReceiveTime(Date receiveTime) {
		this.receiveTime = receiveTime;
	}

	public Integer getReviseState() {
		return reviseState;
	}

	public void setReviseState(Integer reviseState) {
		this.reviseState = reviseState;
	}

	public String getDepName() {
		return depName;
	}

	public void setDepName(String depName) {
		this.depName = depName;
	}

	public String getStataName() {
		return stataName;
	}

	public void setStataName(String stataName) {
		this.stataName = stataName;
	}

	public int getStateId() {
		return stateId;
	}

	public void setStateId(int stateId) {
		this.stateId = stateId;
	}

	public int getTeamId() {
		return teamId;
	}

	public void setTeamId(int teamId) {
		this.teamId = teamId;
	}


	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getRollcalluserCreatetime() {
        return rollcalluserCreatetime;
    }

    public void setRollcalluserCreatetime(Date rollcalluserCreatetime) {
        this.rollcalluserCreatetime = rollcalluserCreatetime;
    }

    public String getRollcalluserDept() {
        return rollcalluserDept;
    }

    public void setRollcalluserDept(String rollcalluserDept) {
        this.rollcalluserDept = rollcalluserDept == null ? null : rollcalluserDept.trim();
    }

    public Date getRollcalluserDeletetime() {
        return rollcalluserDeletetime;
    }

    public void setRollcalluserDeletetime(Date rollcalluserDeletetime) {
        this.rollcalluserDeletetime = rollcalluserDeletetime;
    }

    public Integer getRollcalluserHasdeleted() {
        return rollcalluserHasdeleted;
    }

    public void setRollcalluserHasdeleted(Integer rollcalluserHasdeleted) {
        this.rollcalluserHasdeleted = rollcalluserHasdeleted;
    }

    public Integer getRollcalluserPhoto() {
        return rollcalluserPhoto;
    }

    public void setRollcalluserPhoto(Integer rollcalluserPhoto) {
        this.rollcalluserPhoto = rollcalluserPhoto;
    }

    public String getRollcalluserNo() {
        return rollcalluserNo;
    }

    public void setRollcalluserNo(String rollcalluserNo) {
        this.rollcalluserNo = rollcalluserNo == null ? null : rollcalluserNo.trim();
    }

    public String getRollcalluserId() {
        return rollcalluserId;
    }

    public void setRollcalluserId(String rollcalluserId) {
        this.rollcalluserId = rollcalluserId == null ? null : rollcalluserId.trim();
    }

    public String getRollcalluserName() {
        return rollcalluserName;
    }

    public void setRollcalluserName(String rollcalluserName) {
        this.rollcalluserName = rollcalluserName == null ? null : rollcalluserName.trim();
    }

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getOldDept() {
		return oldDept;
	}

	public void setOldDept(String oldDept) {
		this.oldDept = oldDept;
	}
    
}