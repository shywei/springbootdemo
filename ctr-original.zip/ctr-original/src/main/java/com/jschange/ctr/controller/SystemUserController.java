package com.jschange.ctr.controller;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.model.DeptInfo;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.Role;
import com.jschange.ctr.model.SystemUser;
import com.jschange.ctr.service.SystemUserServiceI;

import util.ControllerUtil;

@Controller
@RequestMapping("systemUser")
public class SystemUserController extends BaseController {
	
	@Autowired
	private SystemUserServiceI systemUserServiceI;
	
	private static ResultModel result;
	private static final Log log = 
			LogFactory.getLog(SystemUserController.class);
	
	
	/**
	 * 随机生成4位验证码
	 * <p>Title:random</p>
	 * <p>Description:</p>
	 * <p>update name: update date:</p>
	 * <p>update Description:</p>
	 * @param @return
	 * @return Object
	 * @throws
	 */
	@RequestMapping("/random")
	@ResponseBody 
	public ResultModel random(HttpServletResponse response,HttpServletRequest request){
		response.setHeader("Access-Control-Allow-Origin", "*");
		result = new ResultModel();
		String yzm = "";
		yzm += (int)(Math.random()* 9 + 1);
        for ( int i = 0; i < 3; i++ )
        {
        	yzm += (int)(Math.random() * 10);
        }
        result.setObj(yzm);
		return result;
	}
	
	/**
	 * 注册账号
	 * @param request
	 * @param response
	 * @param systemUser
	 * @return
	 */
	@ResponseBody
	@RequestMapping("insertSysetemUser")
	public ResultModel insertSystemUser(HttpServletRequest request,HttpServletResponse response,SystemUser systemUser,Integer userid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		result = new ResultModel();
		Integer res = systemUserServiceI.insertSystemUser(systemUser,new OperationLog(userid, "添加账号", ControllerUtil.getIpAddr(request), 2));
		result.setObj(res);
		return result;
	}
	
	/**
	 * 删除账号
	 * @param request
	 * @param response
	 * @param ids
	 * @return
	 */
	@ResponseBody
	@RequestMapping("deleteSystemUser")
	public ResultModel deleteSystemUser(HttpServletRequest request,HttpServletResponse response,String ids,Integer userid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		result = new ResultModel();
		Integer res = systemUserServiceI.deleteSystemUser(ids,new OperationLog(userid, "删除账号", ControllerUtil.getIpAddr(request), 2));
		result.setCode(res);
		return result;
	}
	
	/**
	 * 分页查询账号信息
	 * @param request
	 * @param response
	 * @param pageSize
	 * @param pageNo
	 * @return
	 */
	@ResponseBody
	@RequestMapping("querySystemUser")
	public ResultModel querySystemUser(HttpServletRequest request,HttpServletResponse response,Integer pageSize,Integer pageNo){
		response.setHeader("Access-Control-Allow-Origin", "*");
		result = new ResultModel();
		ResultList<Object> obj = systemUserServiceI.querySystemUser(pageSize,pageNo);
		result.setObj(obj);
		return result;
	}
	
	/**
	 * 初始化密码
	 * @param request
	 * @param response
	 * @param id
	 * @param userid
	 * @return
	 */
	@ResponseBody
	@RequestMapping("resetPassword")
	public ResultModel resetPassword(HttpServletRequest request,HttpServletResponse response,Integer id,Integer userid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		result = new ResultModel();
		Integer setpwd = systemUserServiceI.resetPassword(id,new OperationLog(userid, "初始化了账号编号为"+id+"的密码", ControllerUtil.getIpAddr(request), 2));
		result.setCode(setpwd);
		return result;
	}
	
	/**
	 * 修改密码
	 * @param request
	 * @param response
	 * @param password
	 * @param id
	 * @param userid
	 * @return
	 */
	@ResponseBody
	@RequestMapping("updateSystemUserPwd")
	public ResultModel updateSystemUserPwd(HttpServletRequest request,HttpServletResponse response,String password,Integer id){
		response.setHeader("Access-Control-Allow-Origin", "*");
		result = new ResultModel();
		Integer ret = systemUserServiceI.updateSystemUserPwd(id,password,new OperationLog(id,"更改密码",ControllerUtil.getIpAddr(request),2));
		result.setCode(ret);
		return result;
	}
	
	/**
	 * 检验用户是否存在
	 * @param request
	 * @param response
	 * @param loginName
	 * @return
	 */
	@ResponseBody
	@RequestMapping("checkSystemUser")
	public ResultModel checkSystemUser(HttpServletRequest request,HttpServletResponse response,String loginName){
		response.setHeader("Access-Control-Allow-Origin", "*");
		result = new ResultModel();
		Integer check = systemUserServiceI.checkSystemUser(loginName);
		result.setCode(check);
		return result;
	}
	
	/**
	 * 用户登录
	 * @param request
	 * @param response
	 * @param password
	 * @param loginName
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@ResponseBody
	@RequestMapping("login")
	public ResultModel loginSystemUser(HttpServletRequest request,HttpServletResponse response,String password,String loginName) throws UnsupportedEncodingException{
		response.setHeader("Access-Control-Allow-Origin", "*");
		request.setCharacterEncoding("utf-8");
		result = new ResultModel();
		SystemUser user = systemUserServiceI.loginSystemUser(password,loginName,ControllerUtil.getIpAddr(request));
		if(user!=null){
			result.setCode(1);
			result.setObj(user);
		}else{
			result.setCode(0);
		}
		return result;
	}
	
	/**
	 * 退出系统
	 * @param request
	 * @param response
	 * @param userid
	 */
	@ResponseBody
	@RequestMapping("exitSystem")
	public void exitSystem(HttpServletRequest request,HttpServletResponse response,Integer userid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		getSession().invalidate();
	}
	
	/**
	 * 修改密码前检查密码
	 * @param request
	 * @param response
	 * @param password
	 * @param id
	 * @return
	 */
	@ResponseBody
	@RequestMapping("checkPwd")
	public ResultModel checkPwd(HttpServletRequest request,HttpServletResponse response,String password,Integer id){
		response.setHeader("Access-Control-Allow-Origin", "*");
		result = new ResultModel();
		Integer res = systemUserServiceI.checkPwd(password,id);
		result.setCode(res);
		return result;
	}
	
	/**
	 * 大队列表
	 * @param request
	 * @param response
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryDept")
	public ResultModel queryDept(HttpServletRequest request,HttpServletResponse response){
		response.setHeader("Access-Control-Allow-Origin", "*");
		result = new ResultModel();
		List<DeptInfo> list = systemUserServiceI.queryDept();
		result.setObj(list);
		return result;
	}
	
}
