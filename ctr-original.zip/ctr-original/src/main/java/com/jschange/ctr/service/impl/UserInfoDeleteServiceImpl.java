package com.jschange.ctr.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jschange.ctr.common.BaseDefine;
import com.jschange.ctr.common.SocketClient;
import com.jschange.ctr.dao.ChangeReviseStateMapper;
import com.jschange.ctr.dao.OperationLogMapper;
import com.jschange.ctr.dao.UserInfoDeleteDao;
import com.jschange.ctr.dao.UserInfoListMapper;
import com.jschange.ctr.dao.UserInfoSaveMapper;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.UserInfo;
import com.jschange.ctr.service.UserInfoDeleteService;
import com.jschange.ctr.service.VenaDigitalisService;
import com.mysql.jdbc.Blob;

import palm.pass.function.ServerFlowFunction;
import util.Env;

@Transactional
@Service("userInfoDeleteService")
public class UserInfoDeleteServiceImpl implements UserInfoDeleteService {
	
	static Logger logger=LoggerFactory.getLogger(UserInfoDeleteServiceImpl.class);
	private static Map<String,Object> map = new HashMap<String, Object>();
	private static String CompareServerIP = Env.getInstance().getProperty("CompareServerIP");
	
	@Autowired
	private UserInfoDeleteDao userInfoDeleteDao;
	
	@Autowired
	private UserInfoSaveMapper userInfoSaveMapper;
	
	@Autowired
	private ChangeReviseStateMapper mapper;
	
	@Autowired
	private OperationLogMapper operationLogMapper;
	
	@Autowired
	private UserInfoListMapper userMapper;
	@Autowired
	private VenaDigitalisService fingerService;
	
	//删除人员
	@Override
	public Integer deleteUserInfo(String ids, Integer userid,OperationLog operationLog) {
		//sorket服务类
		ServerFlowFunction function = new ServerFlowFunction();	
		try {
			//将前台传来的字符串转为String数组，再遍历String数组全部转型为Integer数组
			String[] idStrArray = ids.split(",");
			//Integer[] id = new Integer[idStrArray.length];
			//String usrid = "";
			int identifyServerResult = BaseDefine.IDENTIFY_SUCCESS;
			for (int i = 0; i < idStrArray.length; i++) {
				//id[i] = Integer.parseInt(idA[i]);
				//map.put("uid", id[i]);
				
				//调用存储过程，逻辑删除数据库中的数据
				//改为直接通过组合sql语句删除
				userInfoDeleteDao.deleteSingleUser(idStrArray[i]);
				
				UserInfo userInfo = userInfoSaveMapper.getUserById(idStrArray[i]);
				
				//将返回的人员编号取出用于传给富士通接口id
				//usrid = userInfoDeleteDao.getPersionId(map);
				//通过socket的方式发送给比对服务器将人员数据同时一起删除
				identifyServerResult = function.UserDeleteFunction(CompareServerIP, idStrArray[i]);
				logger.info(identifyServerResult == BaseDefine.IDENTIFY_SUCCESS ? 
						String.format("比对服务用户删除成功（%s）", idStrArray[i]) :
							String.format("比对服务用户删除失败（错误码：%s）", identifyServerResult));
				//删除学员时删除指静脉设备里面的指静脉信息
				//List<UserInfo> list=userMapper.queryUserInfoListByID(id[i]);
				
				/*去除“ 删除学员指静脉信息”的操作
				for(UserInfo user:list){
					//删除设备里面的指静脉
					fingerService.deleteFinger(user.getId());
					//将数据库中的当前设备指静脉使用数量-1
					mapper.changeCollectedNum(user.getFingerDeviceid());
				}
				*/

				if (BaseDefine.IDENTIFY_SUCCESS == identifyServerResult) {
					
					//对比服务器中的人员信息删除成功之后，再调用本地存储过程，逻辑删除数据库中的数据
					//userInfoDeleteDao.deleteSingleUser(map);
					
					//添加操作日志
					operationLog.setOperationContext("删除了人员编号为" + userInfo.getUserid() + "的学员");
					operationLogMapper.callOperationPro(operationLog);
				}
			}
			return identifyServerResult == BaseDefine.IDENTIFY_SUCCESS ? 1 : 0;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
	}
	
	//恢复人员信息
	@Override
	public Integer recoverUserInfo(Integer id, Integer userid,Integer deptid,OperationLog operationLog) {
		ServerFlowFunction function = new ServerFlowFunction();
		//map.put("uid", id);
		//map.put("depid", deptid);
		int identifyServerResult = BaseDefine.IDENTIFY_SUCCESS;
		try {
			//调用存储过程执行恢复操作
			userInfoDeleteDao.recoverUserInfo(id.toString(), deptid.toString());
			//获取返回数据
			//String usrid = userInfoDeleteDao.getPersionId(map);
			//String blob = (String)map.get("palm");
			
			UserInfo userInfo = userInfoSaveMapper.getUserById(id.toString());
			boolean hasVein = userInfo.getHasDigitalVein() == 1 ? true : false;
			//如果没有掌静脉数据则直接恢复而不向比对服务器发送请求
			if (hasVein) {
				//如果掌静脉数据长度不对，则不向比对服务器发送数据
				if (userInfo.getDigitalVein().length == 15000) {
					identifyServerResult = function.UserEnrollFunction(CompareServerIP, id.toString(),
							userInfo.getMetacarpalVein());
					logger.info(identifyServerResult == BaseDefine.IDENTIFY_SUCCESS ? 
							String.format("比对服务用户注册成功（%s）", id) :
								String.format("比对服务用户注册失败（错误码：%s）", identifyServerResult));
				}
			}
			//恢复成功添加操作日志
			if (identifyServerResult == BaseDefine.IDENTIFY_SUCCESS) {
				operationLog.setOperationContext("恢复了人员编号为" + userInfo.getUserid() + "的学员");
				operationLogMapper.callOperationPro(operationLog);
			}
			//恢复失败则回滚数据
			if (identifyServerResult != BaseDefine.IDENTIFY_SUCCESS) {
				//System.err.println(identifyServerResult);
				//map.put("usrid", usrid);
				userInfoDeleteDao.rollbackRecover(id.toString());
				logger.info("因比对服务用户注册失败，撤销恢复人员操作。");
			}
			//System.err.println(identifyServerResult);
			return identifyServerResult;
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
	}

}
