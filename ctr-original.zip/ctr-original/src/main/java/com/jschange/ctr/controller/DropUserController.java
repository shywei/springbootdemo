package com.jschange.ctr.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.UserInfo;
import com.jschange.ctr.service.DropUserService;


@Controller
@RequestMapping("dropUserController")
public class DropUserController extends BaseController{
	
	@Autowired
	private DropUserService dropUserService;
	
	/**
	 * 查询离队人员列表
	 * @param response
	 * @param request
	 * @param deptid 登陆大队id
	 * @param reviseState 查询调队/离队状态
	 * @param userid 查询条件
	 * @param userName 查询条件
	 * @param reviseTime 查询条件
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryDropUserList")
	public ResultModel queryDropUserList(HttpServletResponse response,HttpServletRequest request,
			String deptid,Integer reviseState,Integer roleid,
			String userid,String userName,String reviseTime
			){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel rs=new ResultModel();
		Map<String, Object> map = new HashMap<String, Object>();
		Pagination page = getPage();
		try {
			//windows绝对路径
			String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+"/image/";
			if(null != roleid){
				if(roleid==1 || roleid==2){//管理员身份登录或者所长身份登录
					rs.setMessage("管理员不可进行调队操作！");
					return rs;
				}else {
					if(null!=deptid && !"".equals(deptid)){
			        	map.put("deptid",deptid);
			        }
			        if(null!=reviseState && !"".equals(reviseState)){
			        	map.put("reviseState",reviseState);
			        }
			        if(null!=userid && !"".equals(userid)){
			        	map.put("userid",userid);
			        }
			        if(null!=userName && !"".equals(userName)){
			        	map.put("userName",userName);
			        }
			        if(null!=reviseTime && !"".equals(reviseTime)){
			        	map.put("reviseTime",reviseTime);
			        }
			        List<UserInfo> list= dropUserService.queryDropUserList(map,page).getResults();
				    rs.setMessage(basePath);
				    rs.setObj(list);
				    rs.setObjExt(page);
				    return rs;
				}
				
	        }else {
	        	rs.setMessage("该账户角色不可进行调队操作！");
				return rs;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			return rs;
		}
	}
	
	
	
	/**
	 * 查询接收人员列表
	 * @param response
	 * @param request
	 * @param deptid 登陆大队id
	 * @param reviseState 查询调队/离队状态
	 * @param userid 查询条件
	 * @param userName 查询条件
	 * @param reviseTime 查询条件
	 * @return @RequestParam(defaultValue="1",value="reviseState")	
	 */
	@ResponseBody
	@RequestMapping("queryReceiveUserList")
	public ResultModel queryReceiveUserList(HttpServletResponse response,HttpServletRequest request,
			String deptid,String reviseState,Integer roleid,
			String userid,String userName,String receiveTime
			){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel rs=new ResultModel();
		Map<String, Object> map = new HashMap<String, Object>();
		Pagination page = getPage();
		try {
			//windows绝对路径
			String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+"/image/";
			if(null != roleid){
				if(roleid==1 || roleid==2){//管理员身份登录或者所长身份登录
					rs.setMessage("管理员不可进行调队操作！");
					return rs;
				}else {
					if(null != deptid && !"".equals(deptid)){
			        	map.put("deptid",deptid);
			        }
			        if(null != reviseState && !"".equals(reviseState)){
			        	map.put("reviseState", reviseState);
			        }
			        if(null != userid && !"".equals(userid)){
			        	map.put("userid",userid );
			        }
			        if(null != userName && !"".equals(userName)){
			        	map.put("userName", userName);
			        }
			        if(null != receiveTime && !"".equals(receiveTime)){
			        	map.put("receiveTime",receiveTime );
			        }
			        List<UserInfo> list= dropUserService.queryReceiveUserList(map, page).getResults();
				    rs.setMessage(basePath);
				    rs.setObj(list);
				    rs.setObjExt(page);
				    return rs;
				}
	        }else {
	        	rs.setMessage("该账户不可进行调队操作！");
				return rs;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			return rs;
		}
	}

}
