package com.jschange.ctr.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.UserInfo;

public interface AdminDataDownloadMapper {

	//获取登录用户所在部门下所有身份为管理员的人员信息
	public List<UserInfo> getUserInfoBydeptID(Integer deptid)throws SQLException;
	//根据userid获取user信息（人员表）
	public UserInfo getUserInfoByUserID(Integer userid)throws SQLException;
	//下发成功后修改设备表
	public Integer updateDeviceOwnerID(Map<String, Object> map)throws SQLException;

}
