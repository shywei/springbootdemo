package com.jschange.ctr.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.SystemUser;
import com.jschange.ctr.model.WiFiDriviceModel;
import com.jschange.ctr.service.OperationLogService;
import com.jschange.ctr.service.WifiService;
/**
 * WiFi管理
 * @author Administrator
 *
 */
@Controller
@RequestMapping("WifiController")
public class WifiController extends BaseController {
	@Autowired
	private OperationLogService operationLogService;
	private OperationLog operationLog=new OperationLog();
	
	@Autowired
	private WifiService wifiService;
	/**
	 * 分页查询WiFi信息
	 * @param request
	 * @param response
	 * @param wifi
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryWifiListByPage")
	public ResultModel queryWifiListByPage(HttpServletRequest request,HttpServletResponse response,WiFiDriviceModel wifi){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel resultModel = new ResultModel();
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			if(wifi!=null){
				map.put("wifiName", wifi.getWifiName());

				map.put("status", wifi.getStatus());	

			}
			Pagination page = getPage();
			ResultList<WiFiDriviceModel> list=wifiService.queryWifiListByPage(map, page);
			resultModel.setObj(list);
		} catch (Exception e) {
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}

	/**
	 * 保存WiFi信息
	 * @param request
	 * @param response
	 * @param wifi
	 * @param userid
	 * @return
	 */
	@ResponseBody
	@RequestMapping("saveWifi")
	public ResultModel saveWifi(HttpServletRequest request,HttpServletResponse response,WiFiDriviceModel wifi,Integer userid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel resultModel = new ResultModel();
		try{

			String sysIp=super.getIP(request);//获取登陆IP
			SystemUser user=operationLogService.queryCurrentUser(userid+"");//获取当前登录人员信息
			operationLog.setOperationPersonnel(user.getUserName());
			operationLog.setDeptid(user.getDeptid().toString());
			operationLog.setOperationIP(sysIp);
			
			if(wifi.getId()!=null && wifi.getId()>0){//有id的是修改
				wifi.setModifyId(userid);
				Integer rs = wifiService.updateWifi(wifi);
				resultModel.setCode(0);
				resultModel.setMessage("修改成功");
				operationLog.setOperationContext("修改WiFi信息");
				operationLogService.insertOperationLog(operationLog);
				return resultModel;
			}
			if(wifi.getId()==null||wifi.getId()<=0){//没id或id为0的是添加
				wifi.setCreateId(userid);
				Integer rs = wifiService.insertWifi(wifi);
				resultModel.setCode(0);
				resultModel.setMessage("添加成功");
				operationLog.setOperationContext("添加WiFi信息");
				operationLogService.insertOperationLog(operationLog);
				return resultModel;
			}
			resultModel.setCode(-1);
			resultModel.setMessage("所传参数有误");

		}catch(Exception e){
			e.printStackTrace();
			resultModel.setCode(-1);
			resultModel.setMessage("保存失败");
		}
		return resultModel;
	}
	
	
	/**
	 * 批量删除WiFi信息
	 * @param request
	 * @param response
	 * @param ids
	 * @param userid
	 * @return
	 */
	@ResponseBody
	@RequestMapping("deleteWifi")
	public ResultModel deleteWifi(HttpServletRequest request,HttpServletResponse response,String ids,Integer userid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel resultModel = new ResultModel();
		resultModel.setCode(-1);
		try{
			Integer rs = wifiService.deleteWifi(ids,userid);
			resultModel.setCode(0);
			resultModel.setMessage("删除成功");
			operationLog.setOperationContext("删除WiFi信息");
			operationLogService.insertOperationLog(operationLog);
		}catch(Exception e){
			e.printStackTrace();
			resultModel.setMessage("删除失败");
		}
		
		return resultModel;
		
	}
	/**
	 * 根据WiFi的主键ID查询WiFi信息
	 * @param request
	 * @param response
	 * @param id
	 * @return
	 */
	@ResponseBody
	@RequestMapping("getWiFiInfoByID")
	public ResultModel getWiFiInfoByID(HttpServletRequest request,HttpServletResponse response,Integer id){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel resultModel = new ResultModel();
		try{
			WiFiDriviceModel wifi=wifiService.getWiFiInfoByID(id);
			if(wifi !=null){
				resultModel.setCode(0);
				resultModel.setObj(wifi);
			}
		}catch(Exception e){
			e.printStackTrace();
			resultModel.setCode(-1);
			resultModel.setMessage("获取WiFi信息失败");
		}
		return resultModel;
	}
}
