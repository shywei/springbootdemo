package com.jschange.ctr.service.impl;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jschange.ctr.dao.OpenDoorMapper;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.Device;
import com.jschange.ctr.service.ConfigGateInfoService;

import palm.pass.function.TerminalFlowFunction;

@Transactional
@Service("configGateInfoService")
public class ConfigGateInfoServiceImpl implements ConfigGateInfoService {
	
	private TerminalFlowFunction terminal = new TerminalFlowFunction();
	
	
	@Autowired
	private OpenDoorMapper openDoorMapper;
	
	//设置门禁信息
	@Override
	public Integer configGateInfo(Integer confirmNum,int doorSignal, int time, int magAlarm, int magAlarmTime, int durAlarm,
			int tamperAlarm, int inputSignal, int alarmTime, int sound, int light, int sleep) throws ServiceException {

		Integer i=-1;

		try{
			long confirmNum1=confirmNum;
			Device device=openDoorMapper.getDeviceInfo(confirmNum);//获取掌静脉设备信息
			if(device ==null){
				return -1;
			}
			Integer confirmType=device.getDeviceType();
			Integer confirmModel=0;
			String remoteIP=device.getDeviceIP();
			Integer port=Integer.parseInt(device.getDevicePort());
			byte[] confirmPasswd=device.getPassword().getBytes();
			i=terminal.SetGateInfo(remoteIP, port, confirmNum1, confirmType, confirmModel, confirmPasswd, doorSignal, time, magAlarm, magAlarmTime, durAlarm, tamperAlarm, inputSignal, alarmTime, sound, sleep, light);//设置门禁信息
		}catch(Exception e){
				e.printStackTrace();
			
		}
		return i;
	}

}
