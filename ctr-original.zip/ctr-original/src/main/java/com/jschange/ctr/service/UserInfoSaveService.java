package com.jschange.ctr.service;

import java.util.Map;

import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.DataDictionary;
import com.jschange.ctr.model.DeptInfo;
import com.jschange.ctr.model.Role;
import com.jschange.ctr.model.UserInfo;

public interface UserInfoSaveService {
	
	public static final String SERVICE_NAME="com/jschange/ctr/service/UserInfoSaveService";
	//获取注册/修改时的大队下拉框
	public ResultList<DeptInfo> getDept() throws ServiceException; 
	//获取注册/修改时的角色下拉框
	public ResultList<Role> getRole() throws ServiceException; 
	//获取注册/修改时的证件类型下拉框
	public ResultList<DataDictionary> getCardType() throws ServiceException; 
	//注册时查询人员编号是否存在
	public int checkRegister(String userid) throws ServiceException; 
	//人员注册
	public int registerUserInfo(UserInfo userInfo) throws ServiceException;
	//根据userid查询主键id
	public int getIdByUserId(String id) throws ServiceException;
	//注册成功后，数据导入对接的表
	public int userEnrollFunction(Integer id, byte[] vein) throws ServiceException; 
	//修改时查询人员编号是否存在
	public int checkUpdate(Map<String,Object> param) throws ServiceException; 
	//修改时查询人员编号
	public String getUserid(Integer id) throws ServiceException; 
	//修改时查询照片名称
	public String getPhotoUrl(Integer id) throws ServiceException; 
	//人员修改
	public int updateUserInfo(UserInfo userInfo) throws ServiceException;
	//查看终端信息
	public int getTerminalInfo(Map<String,Object> param) throws ServiceException;
}
