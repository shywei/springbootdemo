package com.jschange.ctr.model;

public class Area {
	
	private Integer areaid;//区域编号
	private String areaName;//区域名称
	public Integer getAreaid() {
		return areaid;
	}
	public void setAreaid(Integer areaid) {
		this.areaid = areaid;
	}
	public String getAreaName() {
		return areaName;
	}
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	

}
