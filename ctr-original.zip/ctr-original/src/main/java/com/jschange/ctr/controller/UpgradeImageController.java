package com.jschange.ctr.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jschange.ctr.model.FingerDrivice;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.service.VenaDigitalisService;

import util.QJCmdSend;
import util.VenaMap;

/*
 * 更新设备里面的图片
 * @gaoxujian
 * */
@Controller
@RequestMapping("upgradeImageController")
public class UpgradeImageController extends BaseController {
	@Autowired
	private VenaDigitalisService venaDigitalisService;
	@RequestMapping("/upgradeImage")
	@ResponseBody
	public Object upgrade(HttpServletResponse response,HttpServletRequest request,Integer mesID,Integer fileName){
		// 解决跨域问题
		response.setHeader("Access-Control-Allow-Origin", "*");
		// 设置字符集编码格式为utf-8
		response.setCharacterEncoding("utf-8");
		//获取需要升级的设备信息
		FingerDrivice driviceInfo = venaDigitalisService.selectDriviceInfoById(mesID);
		//获取设备对应的指纹模块ID
		String key = driviceInfo.getDriviceNo();
		//获取设备对应的socket
		Socket socket=null;
		while(socket==null){
			socket = VenaMap.venaMap.get(key);
		}
		String filepath=request.getSession().getServletContext().getRealPath("/files/upgradefile/"+fileName+".bin");	
		
		InputStream is=null;
		try{
			is=new FileInputStream(filepath);
			//获取文件总字节
			int fileAllBytes=is.available();
			//每个包以1024个字节发送，总包数为packNums
			int packNums=fileAllBytes/1024+1;	
			
			byte[] TxBuf = new byte[7];
			TxBuf[0]=(byte)(0x0+fileName);
			TxBuf[1]=0x13;
			TxBuf[2]=(byte) 0x88;
			TxBuf[3]=0x00;
			TxBuf[4]=(byte)(packNums);
			TxBuf[5]=0x00;
			for(int i=1;i<=packNums;i++){
				TxBuf[6]=(byte)(0x0+i);
				byte[] buff=readStream(is);
				byte[] body=ArrayUtils.addAll(TxBuf, buff);
				//每次发送一个包，之后给2秒延迟，在继续发下一个包（因为发送一条消息，就必须要等设备给应答，如果没有应答就继续发下一条消息，会出错）
				Thread.sleep(2000);
				QJCmdSend.send(socket, 0x8109, body);
				//16进制打印
				String helloHex = DatatypeConverter.printHexBinary(body);
				System.err.println(helloHex);
			}
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(is!=null){
				try {
					is.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		ResultModel resultModel = new ResultModel();
		resultModel.setMessage("更新结束！");
		return resultModel;
	}
	
	public static byte[] readStream(InputStream is) throws Exception {  
		int count = 0;  
	    while (count == 0) {  
	        count = is.available();
	    }  
	    System.err.println("count长度"+count);
	    byte[] b=null;
	    if(count>=1024){
	    	b=new byte[1024];
	    }else{
	    	b = new byte[count]; 
	    }
	    is.read(b);
	    return b;
	}
}
