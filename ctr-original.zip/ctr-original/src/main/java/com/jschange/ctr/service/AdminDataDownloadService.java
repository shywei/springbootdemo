package com.jschange.ctr.service;

import java.util.List;

import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.UserInfo;

public interface AdminDataDownloadService {
	//获取登录用户所在部门下所有身份为管理员的人员信息
	public List<UserInfo> getUserInfoBydeptID(Integer deptid)throws ServiceException;
	//管理员下发操作
	public Integer adminDataDownload(Integer deviceid, Integer userid)throws ServiceException;

}
