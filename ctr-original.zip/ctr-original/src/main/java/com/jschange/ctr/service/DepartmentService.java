package com.jschange.ctr.service;

import java.util.Map;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.Department;


public interface DepartmentService {
	
	ResultList<Department> queryDeptList(Map<String, Object> map,Pagination page,Integer single)throws ServiceException;
	
	Integer updateDept(Department dept)throws ServiceException;
	
	Integer insertDept(Department dept)throws ServiceException;
	
	Integer delDept(Integer deptid)throws ServiceException;
	
}
