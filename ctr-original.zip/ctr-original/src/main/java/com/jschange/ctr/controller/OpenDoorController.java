package com.jschange.ctr.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.SystemUser;
import com.jschange.ctr.service.OpenDoorService;
import com.jschange.ctr.service.OperationLogService;
/**
 * 远程开门
 * @author Administrator
 *
 */
@Controller
@RequestMapping("openDoorController")
public class OpenDoorController extends BaseController{
	@Autowired
	private OperationLogService operationLogService;
	private OperationLog operationLog=new OperationLog();
	@Autowired
	private OpenDoorService openDoorService;
	
	
	@RequestMapping("remoteOpenDoor")
	@ResponseBody
	public ResultModel remoteOpenDoor(HttpServletRequest request, HttpServletResponse response,Integer id,Integer userid) {
		response.setHeader("Access-Control-Allow-Origin", "*");
		 ResultModel resultModel = new ResultModel();
		 resultModel.setCode(-1);
		 try{
			 String sysIp=super.getIP(request);//获取登陆IP
			 System.err.println(userid+"currentId");
			 SystemUser user=operationLogService.queryCurrentUser(userid+"");//获取当前登录人员信息
			 operationLog.setOperationPersonnel(user.getUserName());
			 operationLog.setDeptid(user.getDeptid().toString());
			 operationLog.setOperationIP(sysIp);
			 
			 Integer i= openDoorService.remoteOpenDoor(id);
			 if(i ==null || i==-1){
				 resultModel.setCode(-1);
				 resultModel.setMessage("查询设备信息失败");
			 }
			 if(i==0){
				 resultModel.setCode(0);
				 resultModel.setMessage("远程开门成功");
				 operationLog.setOperationContext("远程开门");
				 operationLogService.insertOperationLog(operationLog);
			 }
			 if(i==1){
				 resultModel.setCode(-1);
				 resultModel.setMessage("远程开门失败");
			 }
			 if(i==2){
				 resultModel.setCode(-1);
				 resultModel.setMessage("设备编号不匹配");
			 }
			 if(i==3){
				 resultModel.setCode(-1);
				 resultModel.setMessage("设备类型或种类不匹配");
			 }
			 if(i==4){
				 resultModel.setCode(-1);
				 resultModel.setMessage("连接密码不匹配");
			 }
			 if(i==5){
				 resultModel.setCode(-1);
				 resultModel.setMessage("无法连接 WEB 服务器");
			 }
			 
			
		 }catch(Exception e) {
				e.printStackTrace();
				resultModel.setMessage(e.getMessage());
		 }
		return resultModel;
		
	}
	

}
