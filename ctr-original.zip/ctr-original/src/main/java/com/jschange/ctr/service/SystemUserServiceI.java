package com.jschange.ctr.service;


import java.util.List;

import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.DeptInfo;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.Role;
import com.jschange.ctr.model.SystemUser;


public interface SystemUserServiceI {
	
	public Integer insertSystemUser(SystemUser systemUser,OperationLog operationLog)throws ServiceException;

	public Integer deleteSystemUser(String ids,OperationLog operationLog)throws ServiceException;

	public ResultList<Object> querySystemUser(Integer pageSize, Integer pageNo)throws ServiceException;

	public Integer resetPassword(Integer id,OperationLog operationLog)throws ServiceException;

	public Integer updateSystemUserPwd(Integer id, String password,OperationLog operationLog)throws ServiceException;

	public Integer checkSystemUser(String loginName)throws ServiceException;

	public SystemUser loginSystemUser(String password, String loginName,String Ip)throws ServiceException;

	public Integer checkPwd(String password, Integer id)throws ServiceException;

	public List<DeptInfo> queryDept();

	public List<Role> queryRole();



    
}
