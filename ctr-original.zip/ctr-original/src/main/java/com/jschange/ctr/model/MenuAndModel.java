package com.jschange.ctr.model;

import java.util.List;

public class MenuAndModel {
	private Integer menuid;//菜单id
	
	private String menuName;//菜单名
	
	private List<Model> modelList;//模块集合

	public Integer getMenuid() {
		return menuid;
	}

	public void setMenuid(Integer menuid) {
		this.menuid = menuid;
	}

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public List<Model> getModelList() {
		return modelList;
	}

	public void setModelList(List<Model> modelList) {
		this.modelList = modelList;
	}
	
	
}
