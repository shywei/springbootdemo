package com.jschange.ctr.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.State;
import com.jschange.ctr.model.SystemUser;
import com.jschange.ctr.model.UserInfo;
import com.jschange.ctr.service.OperationLogService;
import com.jschange.ctr.service.UserInfoListService;

import util.Env;


@Controller
@RequestMapping("userInfoListController")
public class UserInfoListController extends BaseController{

	
	@Autowired
	private UserInfoListService UserInfoListService;
	
	@Autowired
	private OperationLogService operationLogService;
	
	private OperationLog operationLog=new OperationLog();

	/**
	 * 获取照片存放的盘符路径
	 */
	String imagePath = Env.getInstance().getProperty("imgPath");

	/**
	 * 人员状态下拉框
	 * @param response
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryStateList")	 
	public ResultModel queryStateList(HttpServletResponse response){
		response.setHeader("Access-Control-Allow-Origin", "*");		
		response.setCharacterEncoding("utf-8");
		ResultModel model=new ResultModel();
		try {
			List<State> list= UserInfoListService.queryStateList();
			model.setObj(list);
			return model;
		} catch (Exception e) {
			return model;
		}
	}
	
	/**
	 * 修改人员状态
	 * @param response
	 * @param ids
	 * @param stateid
	 * @return
	 */
	@ResponseBody
	@RequestMapping("updateUserState")	 
	public ResultModel updateUserState(HttpServletResponse response,HttpServletRequest request,
			String ids,String userNames,String stateid,String stateName, String currentId){
		response.setHeader("Access-Control-Allow-Origin", "*");		
		response.setCharacterEncoding("utf-8");
		String sysIp=super.getIP(request);//获取登陆IP
		operationLog.setOperationIP(sysIp);
		ResultModel model=new ResultModel();
		Map<String, Object> map= new HashMap<>();
		try {
			if(null != ids && !"".equals(ids) && null != stateid){
				String array[]=ids.split(",");
				int code=0;
				SystemUser user=operationLogService.queryCurrentUser(currentId);
				operationLog.setOperationPersonnel(user.getUserName());
				operationLog.setDeptid(user.getDeptid().toString());
				for(int i=0;i<array.length;i++){
					map.put("userid", array[i]);
					map.put("stateid",stateid);
					UserInfoListService.updateUserState(map);
					String uname=operationLogService.getName(array[i]);
					operationLog.setOperationContext("修改人员编号为："+array[i]+",姓名为："+uname+"的状态为"+stateName);
					operationLogService.insertOperationLog(operationLog);
					code++;
				}
				if(code==array.length){
					model.setCode(code);
					model.setMessage("人员状态修改成功！");
				}                   
				return model;
			}
		} catch (Exception e) {
			return model;
		}
		model.setCode(-5);
		model.setMessage("请选择要修改的人员");
		return model;
	}
	
	/**
	 * 获取人员列表
	 * @param response
	 * @param id 获取人员详细信息
	 * @param userid
	 * @param userName
 	 * @param deptid 
 	 * @param stateid  状态列表
	 * @param states 在队传1  离队传2  全部不传值 
	 * @param createtime
	 * @param deletetime
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryUserInfoList")	 
	public ResultModel queryUserInfoList(HttpServletResponse response,
			Integer id,String userid, HttpServletRequest request,String deptid,
			String userName,String createtime,String deletetime,String states,
			String stateid,Integer roleid
			){
		response.setHeader("Access-Control-Allow-Origin", "*");		
		response.setCharacterEncoding("utf-8");
		ResultModel model=new ResultModel();
		Map<String, Object>map=new HashMap<>();
		Pagination page=getPage();
		try {
			if(null != roleid){
				if(roleid==1 || roleid==2){//管理员身份登录或者所长身份登录
					deptid=null;
				}
	        }
			if(null != id && !"".equals(id)){
				map.put("id", id);
			}
			if(null != stateid && !"".equals(stateid)){
				map.put("stateid", stateid);
			}
			if(null != deptid && !"".equals(deptid)){
				map.put("deptid", deptid);
			}
			if(null != userid && !"".equals(userid)){
				map.put("userid", userid);
			}
			if(null != userName && !"".equals(userName)){
				map.put("userName", userName);
			}
			if(null != createtime && !"".equals(createtime)){
				map.put("createtime", createtime);
				System.err.println("createtime"+createtime);
			}
			if(null != deletetime && !"".equals(deletetime)){
				map.put("deletetime", deletetime);
				System.err.println("deletetime"+deletetime);
			}
			if(null != states && !"".equals(states)){
				map.put("states", states);
			}
			List<UserInfo> list=UserInfoListService.queryUserInfoList(map,page).getResults();
			String basePath = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()+"/image/" ;
			model.setMessage(basePath);
			model.setObj(list);
			model.setObjExt(page);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return model;
	}

	
}
