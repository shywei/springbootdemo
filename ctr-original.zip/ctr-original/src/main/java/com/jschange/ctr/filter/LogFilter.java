package com.jschange.ctr.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jschange.ctr.model.SystemUser;


public class LogFilter implements Filter{

	public void init(FilterConfig filterConfig) throws ServletException {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest req=(HttpServletRequest)request;
		HttpServletResponse resp=(HttpServletResponse) response;
		SystemUser user=(SystemUser)req.getSession().getAttribute("systemuser");
		if(user==null){
			//如果没有登录返回登录的页面
			resp.sendRedirect("login.html");
//			resp.sendRedirect("login.do");
//			req.getRequestDispatcher("login.do").forward(req, resp);
		}
		else{
			chain.doFilter(req, resp);
		}
		String path=req.getRequestURI();
		System.err.println(path);
		if(path.endsWith(".css") || path.endsWith(".js") || path.endsWith(".png") || path.contains("login")){
			chain.doFilter(req, resp);
		}
	}

	public void destroy() {
		
	}

}
