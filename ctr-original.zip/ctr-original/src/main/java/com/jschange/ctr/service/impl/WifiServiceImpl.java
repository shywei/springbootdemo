package com.jschange.ctr.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.common.ResultListImpl;
import com.jschange.ctr.dao.WifiDao;
import com.jschange.ctr.model.FingerDrivice;
import com.jschange.ctr.model.WiFiDriviceModel;
import com.jschange.ctr.service.WifiService;

@Service("wifiService")
public class WifiServiceImpl implements WifiService {
	
	@Autowired
	WifiDao wifiDao;

	@Override
	public ResultList<WiFiDriviceModel> queryWifiListByPage(Map<String, Object> param, Pagination page) {
		Integer totalCount=0;
		if(param==null){
		   param=new HashMap<>();
		}
		if(page!=null){
			totalCount=wifiDao.queryWifiListCount(param);
			page.setTotalCount(totalCount);
			param.put("page", (page.getCurrentPage()-1)*page.getPageSize());
			param.put("rows", page.getPageSize());
		}
		
		List<WiFiDriviceModel> list = wifiDao.queryWifiListByPage(param);
		ResultList<WiFiDriviceModel> re=new ResultListImpl<>();
		re.setResults(list);
		re.setPage(page);
		return re;
	}

	@Override
	public Integer insertWifi(WiFiDriviceModel wifi) {
		Integer rs = wifiDao.insertWifi(wifi);
		return rs;
	}

	@Override
	public Integer updateWifi(WiFiDriviceModel wifi) {
		Integer rs = wifiDao.updateWifi(wifi);
		return rs;
	}

	@Override
	public Integer deleteWifi(String ids, Integer userid) {
		String[] idArray = ids.split(",");
		Integer[] id = new Integer[idArray.length];
		for (int i = 0; i < idArray.length; i++) {
			id[i] = Integer.parseInt(idArray[i]);
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", id);
		Integer rs = wifiDao.deleteWifi(map);
		return rs==0?0:1;
	}

	@Override
	public WiFiDriviceModel getWiFiInfoByID(Integer id) {
		try{
		 return wifiDao.getWiFiInfoByID(id);
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}

}
