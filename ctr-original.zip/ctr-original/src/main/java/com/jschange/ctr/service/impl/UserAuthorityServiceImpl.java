package com.jschange.ctr.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.common.ResultListImpl;
import com.jschange.ctr.dao.OperationLogMapper;
import com.jschange.ctr.dao.UserAuthorityMapper;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.Menu;
import com.jschange.ctr.model.MenuAndModel;
import com.jschange.ctr.model.Model;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.SystemUser;
import com.jschange.ctr.service.UserAuthorityService;
@Service(value=UserAuthorityService.SERVICE_NAME)
@Transactional
public class UserAuthorityServiceImpl implements UserAuthorityService{
	
	int count=0; 
	
	@Autowired
	private UserAuthorityMapper userAuthorityMapper;
	
	@Autowired
	private OperationLogMapper operationLogMapper;
	
	Logger logger=LoggerFactory.getLogger(this.getClass());
	
	//查询模块
	@Override
	public ResultList<Model> getModel(Map<String, Object> param, Pagination page) throws ServiceException {
		try {
			if(page!=null){
				int count=userAuthorityMapper.getModelCount(param);
				page.setTotalCount(count);
                param.put("page", (page.getCurrentPage()-1)*page.getPageSize());
                param.put("rows", page.getPageSize());
			}
			ResultList<Model> resultList=new ResultListImpl<>();
			resultList.setResults(userAuthorityMapper.getModelList(param));
			resultList.setPage(page);
			return resultList;
		} catch (Exception e) {
			logger.error("查询模块异常",e,UserAuthorityServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//添加模块或菜单
	@Override
	public int addModelOrMenu(Model model) throws ServiceException {
		try {
			if(model.getMenuid()!=null && !"".equals(model.getMenuid())){
				//添加模块
				//添加模块前查询模块名称是否存在
				count=userAuthorityMapper.checkAddModel(model);
				if(count>0){
					return -2;
				}
				return userAuthorityMapper.addModel(model);
			}
			else{
				//添加菜单
				//添加菜单前查询菜单名称是否存在
				count=userAuthorityMapper.checkAddMenu(model);
				if(count>0){
					return -2;
				}
				return userAuthorityMapper.addMenu(model);
			}
		} catch (Exception e) {
			logger.error("添加模块或菜单异常",e,UserAuthorityServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//修改模块
	@Override
	public int updateModel(Model model) throws ServiceException {
		try {
			System.err.println("modelName"+model.getModelName());
			System.err.println("menuid"+model.getMenuid());
			System.err.println("modelid"+model.getModelid());
			count=userAuthorityMapper.checkUpdateModel(model);
			System.err.println("我的count"+count);
			if(count>0){
				return -2;
			}
			return userAuthorityMapper.updateModel(model);
		} catch (Exception e) {
			logger.error("修改模块异常",e,UserAuthorityServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//批量删除模块
	@Override
	public int delModel(String[] ids,OperationLog operationLog) throws ServiceException {
		try {
			int i=0;
			for(String id:ids){
				count=userAuthorityMapper.delModel(id);
				if(count==1){
					userAuthorityMapper.delUserModel(id);
					//操作日志
					operationLog.setOperationContext("删除模块"+userAuthorityMapper.getModelNameById(id)+"成功");
					operationLogMapper.insertOperationLog(operationLog);
					i++;
				}
				else{
					//操作日志
					operationLog.setOperationContext("删除模块"+userAuthorityMapper.getModelNameById(id)+"失败");
					operationLogMapper.insertOperationLog(operationLog);
				}
			}
			return i;
		} catch (Exception e) {
			logger.error("批量删除模块异常",e,UserAuthorityServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//根据账号id查询菜单栏
	@Override
	public ResultList<Menu> getMenuById(String id) throws ServiceException {
		try {
			ResultList<Menu> resultList=new ResultListImpl<>();
			resultList.setResults(userAuthorityMapper.getMenuById(id));
			return resultList;
		} catch (Exception e) {
			logger.error("根据账号id查询菜单栏异常",e,UserAuthorityServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//根据菜单id、账号id查询模块
	@Override
	public ResultList<Model> getModelByMenuIdAndId(String id,String menuid) throws ServiceException {
		try {
			ResultList<Model> resultList=new ResultListImpl<>();
			Map<String,Object> param=new HashMap<>();
			param.put("id", id);
			param.put("menuid", menuid);
			resultList.setResults(userAuthorityMapper.getModelByMenuIdAndId(param));
			return resultList;
		} catch (Exception e) {
			logger.error("根据菜单id、账号id查询模块异常",e,UserAuthorityServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//查询菜单集合(权限分配)
	@Override
	public ResultList<Menu> getMenuList() {
		try {
			ResultList<Menu> resultList=new ResultListImpl<>();
			resultList.setResults(userAuthorityMapper.getMenuList());
			return resultList;
		} catch (Exception e) {
			logger.error("查询菜单集合(权限分配)异常",e,UserAuthorityServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//修改账号权限(权限分配)
	@Override
	public int updateUserAuthority(String[] ids,String id) throws ServiceException {
		try {
			count =userAuthorityMapper.delUserAuthority(id);
			Map<String,Object> param=new HashMap<String, Object>();
			param.put("id", id);
			if(ids!=null && ids.length!=0){
				for(String str:ids){
					param.put("modelid", str);
					userAuthorityMapper.addUserAuthority(param);
				}
			}
			return count;
		} catch (Exception e) {
			logger.error("修改账号权限异常",e,UserAuthorityServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//菜单集合和包含的模块集合(权限分配)
	@Override
	public ResultList<MenuAndModel> getMenuAndModel() throws ServiceException {
		try {
			ResultList<MenuAndModel> resultList=new ResultListImpl<>();
			List<MenuAndModel> mamList=new ArrayList<>();
			List<Menu> menuList=userAuthorityMapper.getMenuList();
			for(Menu menu:menuList){
				MenuAndModel mam=new MenuAndModel();
				mam.setMenuid(menu.getMenuid());
				mam.setMenuName(menu.getMenuName());
				mam.setModelList(userAuthorityMapper.getModelByMenuId(menu.getMenuid()));
				mamList.add(mam);
			}
			resultList.setResults(mamList);
			return resultList;
		} catch (Exception e) {
			logger.error("菜单集合和包含的模块集合(权限分配)异常",e,UserAuthorityServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//查询属于该角色的帐号集合(权限分配)
	@Override
	public ResultList<SystemUser> getSystemUserByRoleId(String id) throws ServiceException {
		try {
			ResultList<SystemUser> resultList=new ResultListImpl<>();
			resultList.setResults(userAuthorityMapper.getSystemUserByRoleId(id));
			return resultList;
		} catch (Exception e) {
			logger.error("查询属于该角色的帐号集合(权限分配)异常",e,UserAuthorityServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//根据角色id查询模块集合(权限分配)
	@Override
	public ResultList<Model> getModelByRoleId(String id) throws ServiceException {
		try {
			ResultList<Model> resultList=new ResultListImpl<>();
			resultList.setResults(userAuthorityMapper.getModelByRoleId(id));
			return resultList;
		} catch (Exception e) {
			logger.error("根据角色id查询模块集合(权限分配)异常",e,UserAuthorityServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//根据账号id查询模块集合(权限分配)
	@Override
	public ResultList<Model> getModelById(String id) throws ServiceException {
		try {
			ResultList<Model> resultList=new ResultListImpl<>();
			resultList.setResults(userAuthorityMapper.getModelById(id));
			return resultList;
		} catch (Exception e) {
			logger.error("据账号id查询模块集合(权限分配)异常",e,UserAuthorityServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//修改角色权限(权限分配)
	@Override
	public int updateRoleAuthority(String[] ids, String id) throws ServiceException {
		try {
			//删除该角色下的帐号的公共权限
			userAuthorityMapper.delUserOfRole(id);
			//删除角色原有权限
			count =userAuthorityMapper.delRoleAuthority(id);
			Map<String,Object> param=new HashMap<String, Object>();
			param.put("id", id);
			if(ids!=null && ids.length>0){
				//添加角色新权限
				for(String str:ids){
					param.put("modelid", str);
					userAuthorityMapper.addRoleAuthority(param);
				}
				//获取该角色下的帐号id
				List<String> strList=userAuthorityMapper.getIdByRoleId(id);
				if(strList!=null && strList.size()>0){
					param.clear();
					for(String str:strList){
						param.put("id", str);
						for(String s:ids){
							param.put("modelid", s);
							userAuthorityMapper.addUserAuthority(param);
						}
					}
				}
			}
			return count;
		} catch (Exception e) {
			logger.error("修改角色权限(权限分配)异常",e,UserAuthorityServiceImpl.class);
			throw new ServiceException(e);
		}
	}

}
