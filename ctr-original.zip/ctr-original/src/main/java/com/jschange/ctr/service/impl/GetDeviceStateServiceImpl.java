package com.jschange.ctr.service.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jschange.ctr.dao.GetDeviceStateMapper;
import com.jschange.ctr.dao.OpenDoorMapper;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.Device;
import com.jschange.ctr.service.GetDeviceStateService;

import palm.pass.function.TerminalFlowFunction;

@Transactional
@Service("getDeviceStateService")
public class GetDeviceStateServiceImpl implements GetDeviceStateService {
	
	private TerminalFlowFunction terminal = new TerminalFlowFunction();
	@Autowired
	private OpenDoorMapper openDoorMapper;
	
	@Autowired
	GetDeviceStateMapper getDeviceStateMapper;

	//获取设备终端状态
	@Override
	public Integer getDeviceState(Integer confirmNum) throws ServiceException {
	
		try {
			Device device=openDoorMapper.getDeviceInfo(confirmNum);
			if(device ==null ||device.getDeviceIP() ==null || device.getDevicePort()==null ||device.getDeviceType()==null ||device.getPassword()==null){
				return -1;
			}
			
			//System.err.println(device.getDeviceIP()+"!!"+device.getDevicePort()+"!!"+device.getDeviceType()+"!!"+device.getPassword());
			String remoteIP=device.getDeviceIP();
			Integer port=Integer.parseInt(device.getDevicePort());
			long confirmNum1=confirmNum;
			Integer confirmType=device.getDeviceType();
			Integer confirmModel=0;
			byte[] confirmPasswd=device.getPassword().getBytes();
			
			Integer i=terminal.GetTerminalStatus(remoteIP, port, confirmNum, confirmType, confirmModel, confirmPasswd);
			
			Map<String ,Object> map=new HashMap<String,Object>();
			
			if(i==0){//0代表设备连接正常，之后修改数据库中的设备表里的状态
				map.put("connectionStatus", 0);
				map.put("operatorType", "获取状态");
				map.put("operatorResult", "获取成功");
				map.put("confirmNum", confirmNum);
				Integer j=getDeviceStateMapper.updateDeviceState(map);
				
			}
			if(i==1){//1代表设备连接异常，之后修改数据库中的设备表里的状态
				map.put("connectionStatus", 1);
				map.put("operatorType", "获取状态");
				map.put("operatorResult", "获取成功");
				map.put("confirmNum", confirmNum);
				Integer j=getDeviceStateMapper.updateDeviceState(map);
			}
			if(i>1){//其他情况均属于获取状态失败的情况，
				map.put("operatorType", "获取状态");
				map.put("operatorResult", "获取失败");
				map.put("confirmNum", confirmNum);
				Integer j=getDeviceStateMapper.updateDeviceState(map);
			}
			return i;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return -1;
	}

}
