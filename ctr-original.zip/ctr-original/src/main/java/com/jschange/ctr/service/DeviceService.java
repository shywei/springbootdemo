package com.jschange.ctr.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.ApplicationModel;
import com.jschange.ctr.model.Device;
import com.jschange.ctr.model.OperationLog;

import palmpass.client.GateInfo;

public interface DeviceService {

	ResultList<Object> queryDeviceByPage(Pagination page, String deviceName, String deviceIP) throws ServiceException;
	
	public int insertDevice(Device device)throws ServiceException;
	
	public int updateDevice(Device device)throws ServiceException;
	
	Integer deleteDeviceByIds(String ids,OperationLog operationLog)throws ServiceException;

	Device queryDeviceById(Integer id)throws ServiceException;
	
	List<ApplicationModel>queryApplicationModel()throws ServiceException;

	Integer restartDevice(Integer id,OperationLog operationLog)throws ServiceException;

	Integer setDeviceTime(Integer id,OperationLog operationLog)throws ServiceException;
	
	public int check(Device device)throws ServiceException;
	
	//分页查询终端状态列表
	public ResultList<Device>quertDeviceStateList(Map<String, Object>map,Pagination page) throws ServiceException;
	
	//获取门禁信息
	public GateInfo queryGateInfo(Integer deviceid)throws ServiceException;
	
	//终端初始化
	public int defaultConfig(Integer deviceid)throws ServiceException;
	
	//终端升级
	public int deviceUpgrade(Integer deviceid,long fileLen,byte[]bytes)throws ServiceException;
}
