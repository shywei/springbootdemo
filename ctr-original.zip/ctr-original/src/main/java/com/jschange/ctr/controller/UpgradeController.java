package com.jschange.ctr.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.FingerDrivice;
import com.jschange.ctr.service.VenaDigitalisService;


import util.QJCmdSend;
import util.VenaMap;
/*
 * 升级终端软件
 * @gaoxujian 2017/8/24
 * */
@Controller
@RequestMapping("upgradeController")
public class UpgradeController {
	@Autowired
	private VenaDigitalisService venaDigitalisService;
	@RequestMapping("/upgrade")
	@ResponseBody
	public Object upgrade(HttpServletResponse response,HttpServletRequest request,Integer mesID){
		// 解决跨域问题
		response.setHeader("Access-Control-Allow-Origin", "*");
		// 设置字符集编码格式为utf-8
		response.setCharacterEncoding("utf-8");
		//获取需要升级的设备信息
		FingerDrivice driviceInfo = venaDigitalisService.selectDriviceInfoById(mesID);
		//获取设备对应的指纹模块ID
		String key = driviceInfo.getDriviceNo();
		//获取设备对应的socket
		Socket socket=null;
		while(socket==null){
			socket = VenaMap.venaMap.get(key);
		}
		//将升级的软件发送到设备，获取文件路径
		String filepath=request.getSession().getServletContext().getRealPath("/files/upgradefile/qj.bin");
	
		InputStream is=null;
		try {
			is=new FileInputStream(filepath);
			//获取文件总字节
			int fileAllBytes=is.available();
			//每个包以1024个字节发送，总包数为packNums
			int packNums=fileAllBytes/1024+1;	
			//将文件转换成byte数组，然后将数组中的所有数字按双字节相加，得到求和校验码
			byte[] filebyte=getBytes(filepath);
			int sum=0;
			for(int i=0;i<filebyte.length;i++){
				sum+=filebyte[i];
			}
			System.err.println("文件总和相加："+sum);

			//TxBuf里面是消息体前两个字节，代表总包数和分包号
			byte[] TxBuf = new byte[4];
			TxBuf[0] = 0x00;
			TxBuf[1] = (byte)(packNums);
			TxBuf[2] = 0x00;
			//最后一个包中需要加上check里面的校验码，校验码是文件中所有数字相加，取最后两个字节
			byte[] check=new byte[2];
			check[0]=(byte) 0xE1;
			check[1]=(byte) 0x90;
			for(int i=1;i<=packNums;i++){
				TxBuf[3]=(byte)(0x0+i);
				byte[] buff=readStream(is);
				byte[] body=ArrayUtils.addAll(TxBuf, buff);
				//每次发送一个包，之后给2秒延迟，在继续发下一个包（因为发送一条消息，就必须要等设备给应答，如果没有应答就继续发下一条消息，会出错）
				Thread.sleep(2000);
				//发送最后一个包时，加上验证码
				if(i==packNums){
					byte[] body2=ArrayUtils.addAll(body, check);
					if(socket!=null){
						QJCmdSend.send(socket, 0x8110, body2);
					}
					//16进制打印
					String helloHex = DatatypeConverter.printHexBinary(body2);
					System.err.println(helloHex);
				}else{
					if(socket!=null){
						QJCmdSend.send(socket, 0x8110, body);
					}
					//16进制打印
					String a = DatatypeConverter.printHexBinary(body);
					System.err.println(a);
				}
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e){
			e.printStackTrace();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(is!=null){
				try {
					is.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		ResultModel resultModel = new ResultModel();
		resultModel.setMessage("升级结束！");
		return resultModel;
	}
	public static byte[] readStream(InputStream is) throws Exception {  
		int count = 0;  
	    while (count == 0) {  
	        count = is.available();
	    }  
	    System.err.println("count长度"+count);
	    byte[] b=null;
	    if(count>=1024){
	    	b=new byte[1024];
	    }else{
	    	b = new byte[count]; 
	    }
	    is.read(b);
	    return b;
	}
	/** 
     * 获得指定文件的byte数组 
     */  
    private static byte[] getBytes(String filePath){  
        byte[] buffer = null;  
        try {  
            File file = new File(filePath);  
            FileInputStream fis = new FileInputStream(file);  
            ByteArrayOutputStream bos = new ByteArrayOutputStream(1000);  
            byte[] b = new byte[1000];  
            int n;  
            while ((n = fis.read(b)) != -1) {  
                bos.write(b, 0, n);  
            }  
            fis.close();  
            bos.close();  
            buffer = bos.toByteArray();  
        } catch (FileNotFoundException e) {  
            e.printStackTrace();  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
        return buffer;  
    }
}
