package com.jschange.ctr.service;

import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.AccessRecord;
import com.jschange.ctr.model.CouldAttendUsr;
import com.jschange.ctr.model.Event;
import com.jschange.ctr.model.StartTimeVo;



public interface AttendPeopleRecordService {
	//分页查询所有队里需要点名的人员信息
	public List<AccessRecord> selectRecordByPageByTeam(Map<String, Object> map);
	//按条件查询人员记录总条数
	public int selectAllRowsByReqire(Map<String, Object> map);
	//按条件查询所有大队记录总数
	public int selectTeamRowsByReqire(Map<String, Object> map);
	//按条件查询各大队的信息
	public List<Event> selectTeamRecord(Map<String, Object> map);
	//获得总人数、应到人数、病休人数、其它人数的方法
	public List<Map> getPrepareNum(Map map);
	//导出Excel表格需要的大队中所有人员信息
	public AccessRecord[] getAllRecordByTeam(Map<String, Object> map);
	//导出Excel表格需要的所有大队信息
	public List<Event> getTeamRecord(Map<String, Object> map);
	//开始点名获取大队已经点名的简要信息：图片地址等
	public List<CouldAttendUsr> startRecordInfo(Map<String, Object> map);
	//传入id数组进行批量修改
	public int updateRecordByTeam(Map<String, Object> map);
	//传入id数组进行批量删除
	public int deleteRecordByTeam(Map<String, Object> map);
	//结束点名时，向eventinfo表中插入人数信息 
	public int insertEventinfo(Map<String, Object> map);
	//插入一条状态
	public int insertAccessRecord(Map<String, Object> map);
	//暂停点名
	public int deletePauseRecord(Map<String, Object> map);
	//根据时间将记录状态修改
	public int updateRecordByTime(Integer deptid);
	//查询新记录
	public List<CouldAttendUsr> selectNewRecordInfo(Map<String, Object> map);
	//结束点名时，将未到人员信息显示出来
	public List<CouldAttendUsr> selectAbsenseName(Map<String, Object> map);
	//结束点名时，向记录表中插入缺勤数据
	public int insertAbsenseRecord(Map<String, Object> map);
	//查询所有点名开始时间
	public List<String> selectStartDate(Map<String, Object> map);
	//查询所有点名开始时间方法2
	public List<StartTimeVo> selectStartDateUpdate(Map<String, Object> map);
	//结束点名时，修改记录表中eventid字段
	public int updateCtrEventid(Map<String, Object> map);
}
