package com.jschange.ctr.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.UserInfo;
import com.jschange.ctr.service.AdminDataDownloadService;

/**
 * 管理员下发
 * @author Administrator
 *
 */
@Controller
@RequestMapping("adminDataDownloadController")
public class AdminDataDownloadController extends BaseController {
	
	@Autowired
	private AdminDataDownloadService adminDataDownloadService;
	
	/**
	 * 获取登录用户所在部门下所有身份为管理员的的信息
	 * @param request
	 * @param response
	 * @param deptid
	 * @return
	 */
	@RequestMapping("getUserInfoBydeptID")
	@ResponseBody
	public List<UserInfo> getUserInfoBydeptID(HttpServletRequest request, HttpServletResponse response,Integer deptid ){
		response.setHeader("Access-Control-Allow-Origin", "*");

		List<UserInfo> userInfoList=adminDataDownloadService.getUserInfoBydeptID(deptid);
		return userInfoList;
	}
	
	/**
	 * 管理员下发操作
	 * @param request
	 * @param response
	 * @param deviceid
	 * @param userid
	 * @return
	 */
	@RequestMapping("adminDataDownload")
	@ResponseBody
	public ResultModel  adminDataDownload(HttpServletRequest request, HttpServletResponse response,Integer currentId,Integer deviceid,Integer userid ) {
		response.setHeader("Access-Control-Allow-Origin", "*");
		 ResultModel resultModel = new ResultModel();
		 resultModel.setCode(-1);
		try{
			if(deviceid ==null ||userid==null){
				resultModel.setCode(-1);
				resultModel.setMessage("信息参数缺失");
			}
			Integer i=adminDataDownloadService.adminDataDownload(deviceid,userid);
			if(i==-1){
				resultModel.setCode(-1);
				resultModel.setMessage("查询设备或管理员信息异常");
			}
			if(i==0){
				resultModel.setCode(0);
				resultModel.setMessage("下发成功");
			}
			if(i==1){
				resultModel.setCode(-1);
				resultModel.setMessage("下发失败");
			}
			if(i==2){
				resultModel.setCode(-1);
				resultModel.setMessage("设备编号不匹配");
			}
			if(i==3){
				resultModel.setCode(-1);
				resultModel.setMessage("连接密码不匹配");
			}
			if(i==4){
				resultModel.setCode(-1);
				resultModel.setMessage("无法连接 WEB 服务器");
			}
		}catch(Exception e){
			e.printStackTrace();
			resultModel.setMessage(e.getMessage());
		}
		return resultModel;
	}
	
	
	

}
