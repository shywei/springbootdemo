package com.jschange.ctr.service;

import java.rmi.ServerException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.UserInfo;

public interface ChangeReviseStateService {
	
	//驳回或接收人员调队
	public Object updateRCUserInfoState(Map<String, Object> map,OperationLog operationLog) throws ServiceException;

	//部门调度按钮（将人员状态改为调队中、接收部门改为即将要去的部门）
	public Integer readyChangeDept(Map<String, Object> map,OperationLog operationLog)throws ServiceException;
	
	//撤回调队人员
	public Integer recallChangeDeptUser(Map<String, Object> map,OperationLog operationLog)throws ServiceException;

	//查询人员当前状态
	public Integer queryRCUserInfoStateById(String id)throws ServiceException;
	
	//部门调度时判断是不是已经被删除了
	public Integer queryIsDel(String id)throws ServiceException;
	
}
