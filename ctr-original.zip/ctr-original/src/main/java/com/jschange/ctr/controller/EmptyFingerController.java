package com.jschange.ctr.controller;

import java.io.IOException;
import java.net.Socket;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.FingerDrivice;
import com.jschange.ctr.service.VenaDigitalisService;
import util.QJCmdSend;
import util.ResolveMsg;
import util.SocketMap;
import util.VenaMap;
/*
 * 清空设备里面所有指纹数据
 * 
 * @gaoxujian 2017/8/28
 * */
@Controller
@RequestMapping("emptyFingerController")
public class EmptyFingerController extends BaseController {
	@Autowired
	private VenaDigitalisService venaDigitalisService;
	@RequestMapping("/emptyFinger")
	@ResponseBody
	public Object emptyFinger(HttpServletResponse response,Integer mesID){
		// 解决跨域问题
		response.setHeader("Access-Control-Allow-Origin", "*");
		// 设置字符集编码格式为utf-8
		response.setCharacterEncoding("utf-8");
		//获取需要升级的设备信息
		FingerDrivice driviceInfo =null;
		if(mesID!=null){
			driviceInfo = venaDigitalisService.selectDriviceInfoById(mesID);
		}else{
			System.err.println("未获取页面的mesID");
		}
		//获取设备对应的指纹模块ID
		String key = driviceInfo.getDriviceNo();
		//获取设备对应的socket
		Socket socket = VenaMap.venaMap.get(key);
		byte[] body=new byte[0];
		try {
			QJCmdSend.send(socket, 0x8108, body);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String res=null;
		while(res==null){
			res = SocketMap.socketMap.get(socket);
		}
		SocketMap.socketMap.remove(socket);
		ResultModel resultModel = new ResultModel();
		resultModel.setMessage(res);
		return resultModel;
	}
}
