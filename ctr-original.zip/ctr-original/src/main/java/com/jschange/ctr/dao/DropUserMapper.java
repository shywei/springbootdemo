package com.jschange.ctr.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.UserInfo;


public interface DropUserMapper {
	//查询人员调队-离队人员 列表
	List<UserInfo>queryDropUserList(Map<String, Object>map)throws SQLException;
	
	//查询人员调队-离队人员总数 
	 int queryDropUserCount(Map<String, Object>map)throws SQLException;
	 
	//查询人员调队-离队人员 列表
	List<UserInfo>queryReceiveUserList(Map<String, Object>map)throws SQLException;
	
	//查询人员调队-离队人员总数 
	 Integer countReceiveUserList(Map<String, Object>map)throws SQLException;


}
