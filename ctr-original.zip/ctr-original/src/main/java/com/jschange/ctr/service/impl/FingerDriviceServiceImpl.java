package com.jschange.ctr.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.common.ResultListImpl;
import com.jschange.ctr.dao.FingerDriviceMapper;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.Area;
import com.jschange.ctr.model.Department;
import com.jschange.ctr.model.FingerDrivice;
import com.jschange.ctr.model.Server;
import com.jschange.ctr.model.WiFiDriviceModel;
import com.jschange.ctr.service.FingerDriviceService;

@Transactional
@Service("FingerDriviceService")
public class FingerDriviceServiceImpl implements FingerDriviceService {
	
	@Autowired
	private FingerDriviceMapper fingerDriviceMapper;
	
	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Override
	public ResultList<FingerDrivice> queryDriviceList(Map<String, Object> param,Pagination page) throws ServiceException {
		try {
			Integer totalCount=0;
			if(param==null){
			   param=new HashMap<>();
			}
			if(page!=null){
				totalCount=fingerDriviceMapper.queryDriviceCount(param);
				System.err.println(totalCount+"总数量");
				page.setTotalCount(totalCount);
				param.put("page", (page.getCurrentPage()-1)*page.getPageSize());
				param.put("rows", page.getPageSize());
				System.err.println(page.getCurrentPage()+"!!!"+page.getPageSize()+"page"+(page.getCurrentPage()-1)*page.getPageSize()+"rows"+page.getPageSize());
			}
			List<FingerDrivice> list=fingerDriviceMapper.queryDriviceList(param);
			System.err.println(list.size()+"长度");
			ResultList<FingerDrivice> re=new ResultListImpl<>();
			re.setResults(list);
			re.setPage(page);
			return re;
		} catch (Exception e) {
			logger.error("获取指静脉设备信息列表异常",e,FingerDriviceServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//根据设备id查询设备信息
	@Override
	public FingerDrivice queryDriviceById(Integer mesID) throws ServiceException {
		try{
			return fingerDriviceMapper.queryDriviceById(mesID);
		}catch(Exception e){
			logger.error("根据设备id查询指静脉设备信息异常",e,FingerDriviceServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//修改设备信息
	@Transactional
	public Integer updateDrivice(FingerDrivice driviceModel) throws ServiceException {
		try{
			return fingerDriviceMapper.updateDrivice(driviceModel);
			
		}catch(Exception e){
			logger.error("修改设备信息异常",e,FingerDriviceServiceImpl.class);
			throw new ServiceException(e);
			
		}
	}
	
	//检查设备编号是否重复
	@Override
	public Integer chenckDriviceID(FingerDrivice fingerDrivice) throws ServiceException {
		try{
			return fingerDriviceMapper.chenckDriviceID(fingerDrivice);
			
		}catch(Exception e){
			logger.error("检查设备编号是否重复异常",e,FingerDriviceServiceImpl.class);
			throw new ServiceException(e);
			
		}
	}
	//添加设备信息
	@Override
	public Integer insertDrivice(FingerDrivice fingerDrivice) throws ServiceException {
		try{
			return fingerDriviceMapper.insertDrivice(fingerDrivice);
			
		}catch(Exception e){
			logger.error("检查设备编号是否重复异常",e,FingerDriviceServiceImpl.class);
			throw new ServiceException(e);
			
		}
	}
	//删除设备信息
	@Override
	public int deleteDrivice(Integer id) throws ServiceException {
		try{
			return fingerDriviceMapper.deleteDrivice(id);
			
		}catch(Exception e){
			logger.error("删除设备异常",e,FingerDriviceServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	//查询可用设备，map中可存放查询参数：ownerID：持有人id，areaID：监区id，driviceType:设备类型0固定版1移动版
	@Override
	public List<FingerDrivice> queryDriviceListCanBeUsed(Map<String, Object> map) throws ServiceException {
		try{
			return fingerDriviceMapper.queryDriviceListCanBeUsed(map);
			
		}catch(Exception e){
			logger.error("查询可用设备异常",e,FingerDriviceServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	//查询部门信息下拉框
	@Override
	public List<Department> deptList() throws ServiceException {
		try{
			return fingerDriviceMapper.deptList();
			
		}catch(Exception e){
			logger.error("查询区域部门信息异常",e,FingerDriviceServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	//查询wifi信息
	@Override
	public WiFiDriviceModel queryWifiInfoByWifiID(Integer wifiID) throws ServiceException {
		try{
			return fingerDriviceMapper.queryWifiInfoByWifiID(wifiID);
			
		}catch(Exception e){
			logger.error("查询wifi信息异常",e,FingerDriviceServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	//查询服务器信息
	@Override
	public Server queryServerInfoByseverID(Integer severID) throws ServiceException {
		try{
			return fingerDriviceMapper.queryServerInfoByseverID(severID);
			
		}catch(Exception e){
			logger.error("查询wifi信息异常",e,FingerDriviceServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	//绑定wifi信息和服务器信息
	@Override
	public int bingNet(Map<String, Object> map) throws ServiceException {
		try{
			return fingerDriviceMapper.bingNet(map);
			
		}catch(Exception e){
			logger.error("绑定WiFi和服务器信息异常",e,FingerDriviceServiceImpl.class);
			throw new ServiceException(e);
		}
	}

	//查询可用的WiFi信息列表
	@Override
	public List<WiFiDriviceModel> queryWifiInfoCanBeUsed() throws ServiceException {
		try{
			return fingerDriviceMapper.queryWifiInfoCanBeUsed();
			
		}catch(Exception e){
			logger.error("查询可用的wifi信息列表异常",e,FingerDriviceServiceImpl.class);
			throw new ServiceException(e);
		}
	}

	//查询可用的服务器信息列表
	@Override
	public List<Server> queryServerCanBeUsed() throws ServiceException {
		try{
			return fingerDriviceMapper.queryServerCanBeUsed();
			
		}catch(Exception e){
			logger.error("查询可用的服务器信息列表异常",e,FingerDriviceServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
}
