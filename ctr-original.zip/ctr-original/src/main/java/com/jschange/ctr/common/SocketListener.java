package com.jschange.ctr.common;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;


public class SocketListener implements ServletContextListener{
	
	private ThreadPool threadPool;
	
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		try {
			threadPool.treadPool();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
