package com.jschange.ctr.common;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.jschange.ctr.dao.UserInfoSaveMapper;
import com.jschange.ctr.model.UserInfo;

import palm.pass.function.ServerFlowFunction;
import palmpass.server.IdentifyResult;
import util.Env;

public class SocketClient implements Runnable{
	
	private Socket socket;
	private InputStream is;
	private BufferedOutputStream os;
	private String compareServerIP = Env.getInstance().getProperty("CompareServerIP");
	static Logger logger=LoggerFactory.getLogger(SocketClient.class);
	
	public SocketClient(Socket socket){
		this.socket=socket;
	}
	
	public void handle(Socket socket) throws Exception{
		
		try {
			is=socket.getInputStream();
		    os = new BufferedOutputStream(socket.getOutputStream());
		    int len=0;
		    int sum=0;
		    byte[] a=new byte[8228];
		    while((len=is.read(a,sum,8227-sum))!=-1){
		    	sum+=len;
		    	if(sum==8227){
		    		break;
		    	}
		    }
		    byte[] b = new byte[8192];
		    System.arraycopy(a, 31, b, 0, 8192);
		    ServerFlowFunction sff=new ServerFlowFunction();
		    IdentifyResult result=sff.IdentifyRequestFunction(compareServerIP,b);
		    String id = result.ID;
		    int res = result.result;
		    logger.info(result.result == 0 ? String.format("掌静脉认证成功（%s）", result.ID) :
		    	String.format("掌静脉认证失败（%s）", result.result));
		    String str="***:2114/  138/mc/ "+res+"/                    /          /                              /                                                  :***";
		    String check=String.format("%2x", MyUtil.checkSum(str.getBytes(), 18, 138-4-18));
	    	str=str.replace("mc", check);
		    if (res == 0) {
		    	//根据编号查询人员信息
			    ApplicationContext app=SpringTool.getApplicationContext();
		    	UserInfoSaveMapper userInfoSaveMapper=(UserInfoSaveMapper)app.getBean(UserInfoSaveMapper.class);
			    UserInfo user=userInfoSaveMapper.getUserById(id);
			    String uid=user.getUserid();
			    String name=user.getUserName();
			    String dept=user.getDeptName();
			    Integer deptid=user.getDeptid();
			    //拼接人员信息
			    StringBuffer sb=new StringBuffer("***:2114/  138/mc/ 0/");
			    sb.append(uid);
			    for(int i=0;i<20-uid.getBytes().length;i++){
			    	sb.append(" ");
			    }
			    sb.append("/"+"1234567890/"+name);
			    for(int i=0;i<30-name.getBytes().length;i++){
			    	sb.append(" ");
			    }
			    sb.append("/"+dept);
			    for(int i=0;i<50-dept.getBytes().length;i++){
			    	sb.append(" ");
			    }
			    sb.append(":***");
			    str=sb.toString();
			    check=String.format("%2x", MyUtil.checkSum(str.getBytes(), 18, 138-4-18));
			    str=str.replace("mc", check);
			    //获取设备编号
			    byte[] c=new byte[6];
			    c[0]=a[24];
			    c[1]=a[25];
			    c[2]=a[26];
			    c[3]=a[27];
			    c[4]=a[28];
			    c[5]=a[29];
			    String deviceid=new String(c).trim();
			    //插入识别认证记录表
			    Map<String,Object> param=new HashMap<>();
			    param.put("userid", uid);
			    param.put("name", name);
			    param.put("deptid", deptid);
			    param.put("deviceid", deviceid);
			    userInfoSaveMapper.insertRecord(param);
		    }
		    os.write(str.getBytes());
		    os.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				if (os != null) {
					os.close();
				}
				if (is != null) {
					is.close();
				}
				if (socket != null) {
					socket.close();
				}
			}catch(IOException e){
				e.printStackTrace();
			}
		}	
	}
	
	@Override
	public void run() {
		try {
			handle(socket);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
