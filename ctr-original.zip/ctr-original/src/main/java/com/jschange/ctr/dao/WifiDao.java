package com.jschange.ctr.dao;

import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.WiFiDriviceModel;

public interface WifiDao {

	int queryWifiListCount(Map<String, Object> map);

	List<WiFiDriviceModel> queryWifiListByPage(Map<String, Object> map);

	Integer insertWifi(WiFiDriviceModel wifi);

	Integer updateWifi(WiFiDriviceModel wifi);

	Integer deleteWifi(Map<String, Object> map);
	
	WiFiDriviceModel getWiFiInfoByID(Integer id);

}
