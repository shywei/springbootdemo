package com.jschange.ctr.controller;

import java.io.IOException;
import java.net.Socket;
import java.security.DigestInputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.FingerDrivice;
import com.jschange.ctr.service.VenaDigitalisService;
import util.QJCmdSend;
import util.SocketMap;
import util.VenaFingerMap;
import util.VenaMap;

/*
 * 指静脉采集和删除
 * @gaoxujian 2017/8/4 
 * */
@Controller
@RequestMapping("collectFingerController")
public class CollectFingerController extends BaseController{
	@Autowired
	private VenaDigitalisService venaDigitalisService;
	
	
	@RequestMapping("/firstCollectFinger")
	@ResponseBody
	//第一次采集指静脉请求
	public Object firstCollectFinger(HttpServletRequest request, HttpServletResponse response, String userId, Integer mesID,
			String userName,String deptName) {
		// 解决跨域问题
		response.setHeader("Access-Control-Allow-Origin", "*");
		// 设置字符集编码格式为utf-8
		response.setCharacterEncoding("utf-8");
		// 页面会不断的请求，判断是否是第一次请求，如果是则向终端发送录入指纹指令
			try {
				// 获取所选机器的机器信息
				FingerDrivice driviceInfo=null;
				if(mesID!=null){
					driviceInfo = venaDigitalisService.selectDriviceInfoById(mesID);
				}else{
					System.err.println("页面传来的mesID为null");
				}
				// 将机器信息的ID赋值给key
				Socket socket=null;
				if(driviceInfo!=null){
					String fingerCode = driviceInfo.getDriviceNo();
					// 通过获取的key获取map集合中的特定socket	
					socket = VenaMap.venaMap.get(fingerCode);
					ServletContext application = request.getSession().getServletContext();
					application.setAttribute("drvicesocket", socket);
				}else{
					System.err.println("设备信息不存在");
				}
				// 获取页面传来的用户ID
				Integer userID=null;
				if(userId!=null){
					userID = Integer.valueOf(userId);
				}else{
					System.out.println("页面传过来的userId为null");
				}
				//发送用户名和部门名   将TxBuf替换成body
				// 新建发送消息的body数组
				byte[] TxBuf = new byte[4];
				// 将用户ID按高八位在前第八位在后的方式转化成byte数组
				TxBuf[0] = 0x00;
				TxBuf[1] = 0x01;
				TxBuf[2] = (byte) ((userID >> 8) & 0xff);
				TxBuf[3] = (byte) (userID & 0xff);
				byte[] uName=null;
				if(userName!=null){
					uName=userName.getBytes("GBK");
				}else{
					System.err.println("页面传过来的userName为null");
				}
				byte[] dName=null;
				if(deptName!=null){
					dName=deptName.getBytes("GBK");
				}else{
					System.err.println("页面传过来的deptName为null");
				}
				byte[] utemp=new byte[20];
				for (int j=0;j<uName.length;j++) {
					utemp[j]=uName[j];
				}
				byte[] dtemp=new byte[64];
				for (int j = 0; j < dName.length; j++) {
					dtemp[j]=dName[j];
				}
				byte[] TEMP=ArrayUtils.addAll(utemp, dtemp);
				byte[] body=ArrayUtils.addAll(TxBuf, TEMP);
				if(socket!=null){
					QJCmdSend.send(socket, 0x8101, body);
				}else{
					System.err.println("socket不存在");
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		return null; 
	}
	//之后的请求,获取返回值
	@RequestMapping("/nextCollectFinger")
	@ResponseBody
	public Object nextCollectFinger(HttpServletRequest request, HttpServletResponse response){
		ResultModel resultModel = new ResultModel();
		// 解决跨域问题
		response.setHeader("Access-Control-Allow-Origin", "*");
		// 设置字符集编码格式为utf-8
		response.setCharacterEncoding("utf-8");

		ServletContext application = request.getSession().getServletContext();
		Socket socket=(Socket)application .getAttribute("drvicesocket");
		String	res=SocketMap.socketMap.get(socket);	
		if(res==null){
			res="-1";
		}
		System.err.println("返回值:"+res);
		SocketMap.socketMap.remove(socket);
		resultModel.setMessage(res);
		return resultModel;
	}
	
	//查询设备信息
	@RequestMapping("/queryDriviceInfo")
	@ResponseBody
	public Object queryDriviceInfo(HttpServletRequest request, HttpServletResponse response,String deptName){
		ResultModel resultModel = new ResultModel();
		// 解决跨域问题
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");	
		Integer areaID=venaDigitalisService.queryDeptID(deptName);
		List<FingerDrivice> driviceModelList=venaDigitalisService.queryDriviceInfo(areaID);
		if(resultModel!=null){
			resultModel.setObj(driviceModelList);
		}else{
			System.err.println("未获得设备信息");
		}
		return resultModel;
	}
	
	//采集信息是否保存
	@RequestMapping("/isSave")
	@ResponseBody
	public Object isSave(HttpServletRequest request, HttpServletResponse response, String userId, Integer mesID, Integer isSave) {
		
		response.setHeader("Access-Control-Allow-Origin", "*");
		// 设置字符集编码格式为utf-8
		response.setCharacterEncoding("utf-8");
		ServletContext application = request.getSession().getServletContext();
		Socket socket=(Socket)application .getAttribute("drvicesocket");
		// 判断是否点击保存按钮，如果isSave==1则为保存
		if (isSave != null) {
			if (isSave == 1) {
				ResultModel resultModel=new ResultModel();
				Map<Object,Object> map=new HashMap<Object,Object>();
				Integer userID=Integer.valueOf(userId);
				byte[] finger=VenaFingerMap.fingerMap.get(userID);
				map.put("userID", userID);
				map.put("mesID", mesID);
				map.put("finger", finger);
				venaDigitalisService.insertFingerInfoForUserInfo(map);
				System.out.println("保存指纹信息成功");
				return resultModel;
			}
			//点击取消isSave值为0，发送删除指静脉报文，不保存数据到数据库
			if(isSave == 0){
				try {
					ResultModel resultModel = new ResultModel();
					byte[] body=new byte[0];
					QJCmdSend.send(socket, 0x8107, body);
					SocketMap.socketMap.remove(socket);
					resultModel.setMessage("取消成功");
					System.err.println("取消指纹录入");
					return resultModel;
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}else{
			System.err.println("isSave="+isSave);
		}
		return null;
	}
}
