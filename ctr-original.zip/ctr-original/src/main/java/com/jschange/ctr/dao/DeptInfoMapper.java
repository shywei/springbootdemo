package com.jschange.ctr.dao;

import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.DeptInfo;

public interface DeptInfoMapper {
    
	 //增加大队
    public int insertDept(DeptInfo sys);

    public List<DeptInfo> selectall(Map<String, Object> map);
    
}