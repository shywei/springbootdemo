package com.jschange.ctr.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.model.Department;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.SystemUser;
import com.jschange.ctr.service.DepartmentService;
import com.jschange.ctr.service.OperationLogService;

@Controller
@RequestMapping("departmentController")
public class DepartmentController extends BaseController{
	
	
	@Autowired
	private DepartmentService deptService;
	
	@Autowired
	private OperationLogService operationLogService;
	
	private OperationLog operationLog=new OperationLog();
	
	/**
	 * 查询所有部门
	 * @param response
	 * @param deptid
	 * @param deptName
	 * @param superDeptName
	 * @return
	 */
	@ResponseBody
	@RequestMapping("queryDeptList")
	public ResultModel queryDeptList(HttpServletResponse response,String deptid,
			String deptName,String superDeptName,Integer single
			){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel model= new ResultModel();
		Pagination page=getPage();
		try {
			Map<String, Object> map=new HashMap<>();
			if(deptid!=null && !"".equals(deptid)){
				map.put("deptid", deptid);
			}
			if(deptName!=null && !"".equals(deptName)){
				map.put("deptName", deptName);
			}
			if(superDeptName!=null && !"".equals(superDeptName)){
				map.put("superDeptName", superDeptName);
			}
			List<Department> list=deptService.queryDeptList(map, page,single).getResults();
			model.setObjExt(page);
			model.setObj(list);
			return model;
		} catch (Exception e) {
			
		}
		return model;
	}
	/**
	 * 增加/修改部门信息
	 * @param response
	 * @param request
	 * @param dept
	 * @param currentId
	 * @return
	 */
	@ResponseBody
	@RequestMapping("saveDept")
	public ResultModel saveDept(HttpServletResponse response,HttpServletRequest request,
			Department dept,String currentId){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel model= new ResultModel();
		try {
			//插入操作日志
			String sysIp=super.getIP(request);//获取登陆IP
			SystemUser user=operationLogService.queryCurrentUser(currentId);//获取当前登录人员信息
			operationLog.setOperationPersonnel(user.getUserName());
			operationLog.setDeptid(user.getDeptid().toString());
			operationLog.setOperationIP(sysIp);
			if(dept.getDeptName()==null){
				model.setCode(-1);
				model.setMessage("部门名称不可为空");
				return model;
			}
			if(dept.getDeptid()!=null){//修改
				int i=deptService.updateDept(dept);
				if(i>0){
					model.setCode(1);
					model.setMessage("修改部门信息成功");
					//插入操作日志
					operationLog.setOperationContext("修改"+dept.getDeptName()+"部门信息");
					operationLogService.insertOperationLog(operationLog);
					return model;
				}else if(i==-3){
					model.setCode(-1);
					model.setMessage("部门名称不可重复！");
					return model;
				}else{
					model.setCode(-1);
					model.setMessage("修改部门信息失败");
					return model;
				}
			}else{//保存
				int i=deptService.insertDept(dept);
				if(i>0){
					model.setCode(1);
					model.setMessage("增加部门信息成功");
					//插入操作日志
					operationLog.setOperationContext("增加部门"+dept.getDeptName());
					operationLogService.insertOperationLog(operationLog);
					return model;
				}else if(i==-3){
					model.setCode(-1);
					model.setMessage("部门名称不可重复！");
					return model;
				}else{
					model.setCode(-1);
					model.setMessage("增加部门信息失败");
					return model;
				}
			}
		} catch (Exception e) {
			model.setMessage("操作异常");
			return model;
		}
		
	}
	
	
	/**
	 * 删除部门，只支持单个删除（部门中有队员或者是其他部门的上级部门时，无法删除）
	 * @param response
	 * @param request
	 * @param currentId
	 * @param deptid
	 * @param deptName
	 * @return
	 */
	@ResponseBody
	@RequestMapping("delDept")
	public ResultModel delDept(HttpServletResponse response,HttpServletRequest request,
			String currentId,String deptid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel model= new ResultModel();
		try {
			//插入操作日志
			String sysIp=super.getIP(request);//获取登陆IP
			SystemUser user=operationLogService.queryCurrentUser(currentId);//获取当前登录人员信息
			operationLog.setOperationPersonnel(user.getUserName());
			operationLog.setDeptid(user.getDeptid().toString());
			operationLog.setOperationIP(sysIp);
			if(null != deptid){
				Map<String, Object> map= new HashMap<>();
				map.put("deptid", deptid);
				List<Department> list=deptService.queryDeptList(map, null, null).getResults();
				String deptName=null;
				for(Department dept:list){
					deptName=dept.getDeptName();
				}
				int i=deptService.delDept(Integer.parseInt(deptid));
				if(i>0){
					model.setCode(1);
					model.setMessage("成功删除！");
					//插入操作日志
					operationLog.setOperationContext("成功删除部门"+deptName);
					operationLogService.insertOperationLog(operationLog);
					return model;
				}else if(i==-3){
					model.setCode(-1);
					model.setMessage("该部门被占用，无法删除！");
					return model;
				}
			}
		} catch (Exception e) {
			model.setCode(-1);
			model.setMessage("异常信息，无法操作");
			return model;
		}
		return model;
	}
}
