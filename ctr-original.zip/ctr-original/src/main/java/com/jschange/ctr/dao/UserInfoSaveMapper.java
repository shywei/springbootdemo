package com.jschange.ctr.dao;

import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.DataDictionary;
import com.jschange.ctr.model.DeptInfo;
import com.jschange.ctr.model.Role;
import com.jschange.ctr.model.UserInfo;

public interface UserInfoSaveMapper {
	
	//注册时查询人员编号是否存在
	public int checkRegister(String userid);
	//获取注册/修改时的大队下拉框
	public List<DeptInfo> getDept();
	//获取注册/修改时的角色下拉框
	public List<Role> getRole();
	//获取注册/修改时的证件类型下拉框
	public List<DataDictionary> getCardType();
	//人员注册
	public int registerUserInfo(UserInfo userInfo);
	//根据userid查询主键id
	public int getIdByUserId(String id);
	//注册指静脉信息
	public int registerFingerVein(UserInfo userInfo);
	//注册成功后，数据导入对接的表
	public int userEnrollFunction(Map<String,Object> param);
	//修改时查询人员编号是否存在
	public int checkUpdate(Map<String,Object> param);
	//修改时查询人员编号
	public String getUserid(Integer id);
	//修改时查询照片名称
	public String getPhotoUrl(Integer id);
	//人员修改
	public int updateUserInfo(UserInfo userInfo);
	//根据id获取personid
	//public String getPersonId(Integer id);
	//修改对接表数据之删除旧数据，成功后调用userEnrollFunction()
	public int userDeleteFunction(String id);
	//查看终端信息
	public int getTerminalInfo(Map<String,Object> param);
	//认证比对时根据编号查询人员信息
	//public UserInfo getUserByPersonid(String userid);
	// 认证比对时根据编号查询人员信息
	public UserInfo getUserById(String id);
	//插入识别认证记录表
	public int insertRecord(Map<String,Object> param);
}
