package com.jschange.ctr.palmpass;

import palmpass.server.IdentifyResult;

public interface ServerFlowFunction {

	/*
	 * 获取比对服务器状态
	 * 
	 * @parameter:	IP : remote server IP address 
	 * 	
	 * @return 
	 * 		0 = server running
	 * 		1 = server state abnormal
	 * 		6 = connect server error , check socket or server 
	 * 		22 = not plug in key
	 * 		23 = error key
	 * 
	 * */
	public int GetServerStateFunction(String ip);
	
	/*
	 * 通知比对服务器重新读取数据库
	 * 
	 * @parameter:	IP : remote server IP address 
	 * 	
	 * @return 
	 * 		0 = server will reload dataBase
	 * 		1 = server reload database error
	 * 		6 = connect server error , check socket or server 
	 * 		22 = not plug in key
	 * 		23 = error key
	 *  
	 * 
	 * */
	public int ReloadDataFunction(String ip);
	
	/*
	 * 比对服务器定时重启属性配置
	 * @parameter:	IP : remote server IP address 
	 * 				flag: indicate reboot open or close
	 * 				hour: indicate reboot time
	 * 				min:  indicate reboot time
	 * @return 
	 * 		0 = server set success
	 * 		1 = server set failure
	 * 		6 = connect server error , check socket or server 
	 *  	21 = parameters error : flag :[0,1] , hour:[0-23] , minute:[0-59]
	 * 		22 = not plug in key
	 * 		23 = error key
	 * 
	 * */
	public int AutoRebootConfigFunction(String ip, int flag, int hour, int min);
	
	/*
	 * 用户注册通知消息
	 * 
	 * @parameter:	IP : remote server IP address 
	 * 				id: user ID
	 * 				enrollData: enroll user Vein Data
	 * 				
	 * @return 
	 * 		0 = user enroll success 
	 * 		1 = user enroll failure
	 * 		6 = connect server error , check socket or server  
	 * 		21 = parameters error : id length more than 20 ; enrollData length is not equal 15000
	 * 		22 = not plug in key
	 * 		23 = error key
	 *  
	 * */
	public int UserEnrollFunction(String ip, String id, byte[] enrollData);
	
	/*
	 * 用户更新通知消息
	 * @parameter:	IP : remote server IP address 
	 * 				id: user ID
	 * 				enrollData: enroll user Vein Data
	 * 				
	 * @return 
	 * 		0 = user update success 
	 * 		1 = user update failure
	 * 		6 = connect server error , check socket or server  
	 * 		21 = parameters error : id length more than 20 ; enrollData length is not equal 15000
	 * 		22 = not plug in key
	 * 		23 = error key
	 *  
	 * 
	 * */
	public int UserUpdateFunction(String ip, String id, byte[] enrollData);
	
	/*
	 * 用户删除通知消息
	 * @parameter:	IP : remote server IP address 
	 * 				id: user ID
	 * 				
	 * 				
	 * @return 
	 * 		0 = user delete success 
	 * 		1 = user delete failure
	 * 		6 = connect server error , check socket or server  
	 * 		16 = can not find this ID
	 * 		21 = parameters error : id length more than 20 
	 * 		22 = not plug in key
	 * 		23 = error key
	 * 
	 * 
	 * */
	public int UserDeleteFunction(String ip, String id);
	
	/*
	 * 配置比对服务器
	 * @parameter:	IP : remote server IP address 
	 * 				precision: identify precision
	 * 				
	 * 				
	 * @return 
	 * 		0 = user delete success 
	 * 		1 = user delete failure
	 * 		6 = connect server error , check socket or server  
	 * 		21 = parameters error : precision is not [1-3]  
	 * 		22 = not plug in key
	 * 		23 = error key
	 *  
	 * */
	public int ConfigServerFunction(String ip , int precision);
	
	/*
	 * 1:N识别请求消息
	 * @parameter:	IP : remote server IP address 
	 * 				captureData:  capture vein data for identify
	 * 				
	 * 				
	 * @return IdentifyResult.result [int]
	 * 		0 = identify success 
	 * 		1 = identify failure
	 * 		6 = connect server error , check socket or server  
	 * 		21 = parameters error : captureData length is not equal 8192 
	 * 		22 = not plug in key
	 * 		23 = error key
	 * 
	 *  
	 * 		IdentifyResult.ID [string]
	 * 			null = identify fail
	 * 			other = user id
	 * */
	public IdentifyResult IdentifyRequestFunction(String ip, byte[] captureData);
	
	/*
	 * 1:1识别请求消息
	 * 
	  * @parameter:	IP : remote server IP address 
	 * 				captureData:  capture vein data for verify
	 * 				
	 * 				
	 * @return 
	 * 		0 = identify success 
	 * 		1 = identify failure
	 * 		6 = connect server error , check socket or server  
	 * 		21 = parameters error : captureData length is not equal 8192 
	 * 		22 = not plug in key
	 * 		23 = error key
	 *  
	 * 
	 * */
	public int VerifyRequestFunction(String ip ,String id, byte[] captureData);
}
