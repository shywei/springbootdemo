package com.jschange.ctr.model;

import java.util.Date;

public class Event {
	
	private Integer eventid;//点名概况编号
	private Integer deptid;//部门编号
	private String deptName;//部门名称
	private String starttime;//开始时间
	private String endtime;//结束时间
	private String state;//状态
	private Integer allnum;//总人数
	private Integer rollcallnum;//应到人数
	private Integer sickleavenum;//病休人数
	private Integer othernum;//其它人数
	private Integer attendnum;//实到人数
	private Integer absensenum;//缺勤人数
    
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public Integer getEventid() {
		return eventid;
	}
	public void setEventid(Integer eventid) {
		this.eventid = eventid;
	}
	public Integer getDeptid() {
		return deptid;
	}
	public void setDeptid(Integer deptid) {
		this.deptid = deptid;
	}
	public String getStarttime() {
		return starttime;
	}
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Integer getAllnum() {
		return allnum;
	}
	public void setAllnum(Integer allnum) {
		this.allnum = allnum;
	}
	public Integer getRollcallnum() {
		return rollcallnum;
	}
	public void setRollcallnum(Integer rollcallnum) {
		this.rollcallnum = rollcallnum;
	}
	public Integer getSickleavenum() {
		return sickleavenum;
	}
	public void setSickleavenum(Integer sickleavenum) {
		this.sickleavenum = sickleavenum;
	}
	public Integer getOthernum() {
		return othernum;
	}
	public void setOthernum(Integer othernum) {
		this.othernum = othernum;
	}
	public Integer getAttendnum() {
		return attendnum;
	}
	public void setAttendnum(Integer attendnum) {
		this.attendnum = attendnum;
	}
	public Integer getAbsensenum() {
		return absensenum;
	}
	public void setAbsensenum(Integer absensenum) {
		this.absensenum = absensenum;
	}

	

}
