package com.jschange.ctr.service;

import java.util.List;
import java.util.Map;

import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.FingerDrivice;
import com.jschange.ctr.model.UserInfo;
/*
 * 设备相关操作service层接口
 * @gaoxujian
 * */
public interface VenaDigitalisService {
	//根据设备ID查询设备信息
	FingerDrivice selectDriviceInfoById(Integer mesID) throws ServiceException;
	//查询所有设备信息
	List<FingerDrivice> queryDriviceInfo(Integer areaID) throws ServiceException;
	//如果设备指纹编码存在，根据编码，查询设备对应信息
	FingerDrivice selectDriviceInfoByFingerCode(String fingerCode) throws ServiceException;
	//如果设备指纹编码不存在，插入新设备编码信息
	void insertVenaInfo(String fingerCode) throws ServiceException;
	//设备离线时，根据指纹编码，改变设备状态
	void updateDriviceState(String fingerCode) throws ServiceException;
	//设备登录时，更具指纹编码，改变设备状态（非首次登陆）
	void updateDriviceStatus(String fingerCode) throws ServiceException;
	//采集的时候，保存指纹信息到数据库
	void insertFingerInfo(Map<Object, Object> map) throws ServiceException;
	//根据用户ID,查询采集时对应的设备ID
	Integer queryDriviceID(Integer userID) throws ServiceException;
	//通过设备中读取的ID，查询人员相关信息
	UserInfo queryUserInfo(Integer keyId) throws ServiceException;
	//向点名表中插入人员信息
	void insertRecord(Map<String, Object> map) throws ServiceException;
	//指静脉数据下发,返回值：1为下发成功，0为下发失败
	Integer IssuedFinger(Integer mesID,Integer userID,String userName,String deptName,byte[] finger)throws ServiceException;
	//向人员表中插入指纹信息
	void insertFingerInfoForUserInfo(Map<Object, Object> map)throws ServiceException;
	//根据人员主键ID,删除设备中人员信息
	Integer deleteFinger(Integer id)throws ServiceException;
	//根据部门名称查询部门ID
	Integer queryDeptID(String deptName)throws ServiceException;
	//修改有线连接信息（服务器IP，端口号，本地IP）
	Integer changeWiredInfo(String serviceIP,String localIP,Integer mesID,String port)throws ServiceException;
}
