package com.jschange.ctr.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.jschange.ctr.model.AccessRecord;
import com.jschange.ctr.model.CouldAttendUsr;
import com.jschange.ctr.model.Event;
import com.jschange.ctr.model.Flag;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.StartTimeVo;
import com.jschange.ctr.service.AttendPeopleRecordService;
import com.jschange.ctr.service.OperationLogService;

import redis.clients.jedis.Jedis;
import util.ControllerUtil;
import util.Env;
import util.SerializeUtil;


/**
 * 点名管理
 * @author tanty
 *
 */
@Controller
@RequestMapping("/AttendPeopleRecordController")
public class AttendPeopleRecordController {

	@Autowired
	private AttendPeopleRecordService attendPeopleRecordService;
	@Autowired
	private OperationLogService operationLogService;
	
	private Jedis jedis=null;

	String redisIP = Env.getInstance().getProperty("redisIP");
	String redisPassWord = Env.getInstance().getProperty("redisPassWord");
	
	//表示是否可以使用点名（跳到点名页面）
//	List<Flag>flagList=new ArrayList<Flag>();
	Flag flag=null;
	
	/**
	 * 显示列表，根据不同的角色，查询不同的信息
	 * 
	 * @param request
	 * @param response
	 * @param recordTeamId
	 *            大队编号
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping("/ShowRecord")
	@ResponseBody
	public Object accessRecordShowInfo(@RequestParam(value = "roleid", required = false) String roleid,
			@RequestParam(value = "recordDeptId", required = false) Integer recordDeptId,
			@RequestParam(value = "recordDate", required = false) String recordDate,
			@RequestParam(value = "recordUsername",required =false) String recordUsername,
			@RequestParam(value = "recordUserId", required = false) String recordUserId,
			@RequestParam(value = "page", required = false) String page,
			@RequestParam(value = "rows", required = false) String rows,
			String startDate,
			Integer startid,
			String stateid,//状态
			HttpServletRequest request,
			HttpServletResponse response) throws ParseException {
		// 解决跨域问题
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		// 将前台数据放入Map集合中
		Map<String, Object> map = new HashMap<String, Object>();
		// 分页的条件格式转换
		int pageNo = isNotNull(page) ? Integer.parseInt(page) : 1;
		int pageSize = isNotNull(rows) ? Integer.parseInt(rows) : 10;
		int offset = (pageNo - 1) * pageSize;// 偏移量
		map.put("pageSize", pageSize);
		map.put("offset", offset);
		// 接受队伍编号
		map.put("deptid", recordDeptId);
		// 如果存在查询时间条件,进行格式转换
		if(isNotNull(recordDate)){
			recordDate = recordDate.substring(0, 10);
			map.put("recordDate", recordDate);
		}
		if(isNotNull(recordUsername)){
			map.put("rollcallname", recordUsername);
		}
		if(isNotNull(stateid)){
			map.put("stateid", stateid);
		}
		if(isNotNull(recordUserId)){
			map.put("recordUserId", recordUserId);
		}
//		System.err.println(stateid);
		int total = 0;
		List<AccessRecord> alist = null;
		//存放病休学工信息的临时集合
		List<AccessRecord> tlist = null;
		List<Event> rlist = null;
		List<StartTimeVo> dlist = null;
//		dlist = attendPeopleRecordService.selectStartDate(map);
		dlist = attendPeopleRecordService.selectStartDateUpdate(map);
//		for (String string : dlist) {
//			string = string.substring(0, 19);
//		}
//		if(isNotNull(startDate)){
		if(dlist==null||dlist.size()==0){
			dlist.add(new StartTimeVo(0,"暂无数据"));
		}
		if(startid!=null&&startid!=0){
			map.put("startDate", startDate);
			map.put("startid", startid);
		}else{
			map.put("startid",dlist.get(0).getId());
		}
		
		
		map.put("dlist", dlist);
		// 队长的角色ID为3，进入不同方法
		if ("3".equals(roleid)) {
			if(recordDeptId==null||recordDeptId==0){
				map.put("msg", "没有相应的大队编号！");
				Object json = JSON.toJSON(map);
				return json;
			}
			// 条件查询总记录数
			total = attendPeopleRecordService.selectAllRowsByReqire(map);
			// 进入查询队伍中人员信息或进入查询所信息
			alist = attendPeopleRecordService.selectRecordByPageByTeam(map);

			map.put("total", total);
			map.put("result", alist);
		} else if ("2".equals(roleid) || "1".equals(roleid)) {
			// 条件查询总大队点名记录数
			total = attendPeopleRecordService.selectTeamRowsByReqire(map);
			// 条件查询各大队的点名记录
			rlist = attendPeopleRecordService.selectTeamRecord(map);
			map.put("total", total);
			map.put("result", rlist);
		}
		//计算总页数
		int count = total%pageSize==0?total/pageSize:total/pageSize+1;
		map.put("count", count);
		map.put("page", pageNo);
		// 调用业务层分页查询方法
		Object json = JSON.toJSON(map);
		return json;
	}

	/**
	 * 点名前准备，点击开始点名传入几个参数
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/clearRecord")
	@ResponseBody
	public Object clearRecord(@RequestParam(value = "recordDeptId", required = true) String recordDeptId,
			HttpServletRequest request, HttpServletResponse response) {
		// 解决跨域问题
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		// 大队编号转型
		Integer deptid = isNotNull(recordDeptId) ? Integer.parseInt(recordDeptId) : null;
		//根据时间将记录状态修改
		int code = attendPeopleRecordService.updateRecordByTime(deptid);
		//入参 返回值Map集合
		Map<String, Object> map = new HashMap<String, Object>();
		// 返回值
		Object object = null;
		if (deptid == null) {
			map.put("msg", "开始点名失败！");
			object = JSON.toJSON(map);
			return object;
		}
		// 获得总人数、应到人数、病休人数、其它人数的方法
		map.put("deptid", deptid);
		attendPeopleRecordService.getPrepareNum(map);
		//开始点名获取大队已经点名的简要信息：图片地址等
		List<CouldAttendUsr> clist = attendPeopleRecordService.startRecordInfo(map); 
		//windows绝对路径
		String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+"/image/";
		System.err.println("图片地址："+basePath);
		for (CouldAttendUsr c : clist) {
			c.setPhotoUrl(basePath+c.getPhotoUrl());
		}
		map.put("result", clist);
		map.put("code", code);

//		if(flagList.size()>0){
//			for (int i = 0; i < flagList.size(); i++) {
//				Flag flag=	flagList.get(i);
//				if(flag.getDepid().equals(deptid)){
//					
//				}
//				
//			}
//		}else{
//		Flag flag=new Flag(deptid,true);
//		flagList.add(flag);
//		}
		
	
		
 	
 		//连接redis数据库用于存放已点名人员编号
 	    jedis= new Jedis( redisIP,6379);
	    jedis.auth(redisPassWord);
	  //读取redis中已经录入的信息
	  	byte[] value=jedis.get(("dept"+deptid).getBytes());
	  	Object obj = SerializeUtil. unserialize(value);
		//把对应的大队点名开关放入集合中
		if(flag==null){
			 flag=new Flag(deptid,true);
		}else if(flag !=null && !flag.getDepid().equals(deptid)&&obj==null){
			 flag=new Flag(deptid,true);
		}
		map.put("flag", flag);
	    Set<String>list=new HashSet<String>();
	    list.add("0");
	    jedis.del(("dept"+deptid).getBytes());
	    jedis.set(("dept"+deptid).getBytes(), SerializeUtil. serialize(list));
		object = JSON.toJSON(map);
		return object;
	}
	
	/**
	 * 点名前准备，点击开始点名传入几个参数
	 * 5
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/prepareRecord")
	@ResponseBody
	public Object prepareRecord(@RequestParam(value = "recordDeptId", required = true) String recordDeptId,
			
			HttpServletRequest request, HttpServletResponse response) {
		// 解决跨域问题
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		// 大队编号转型
		Integer deptid = isNotNull(recordDeptId) ? Integer.parseInt(recordDeptId) : null;
//		//根据时间将记录状态修改
//		attendPeopleRecordService.updateRecordByTime(deptid);
		//入参 返回值Map集合
		Map<String, Object> map = new HashMap<String, Object>();
		// 返回值
		Object object = null;
		if (deptid == null) {
			map.put("msg", "开始点名失败！");
			object = JSON.toJSON(map);
			return object;
		}
		List<CouldAttendUsr> nlist = null;

		// 获得总人数、应到人数、病休人数、其它人数的方法
		map.put("deptid", deptid);
		attendPeopleRecordService.getPrepareNum(map);
		//开始点名获取大队已经点名的简要信息：图片地址等
		//List<CouldAttendUsr> clist = attendPeopleRecordService.startRecordInfo(map); 

		//将对应正在点名的大队开关设置为false
//		for (Flag flag : flagList) {
			if(deptid.equals(flag.getDepid())){
				flag.setDepFlag(true);
			}
//		}
		
		//读取redis中已经录入的信息并返回下一个人员信息并在增加到redis中
		byte[] value=jedis.get(("dept"+deptid).getBytes());
		Object obj = SerializeUtil. unserialize(value);
		if(obj!=null){
			Set<String>ids=(Set<String>)obj;
			System.err.println("缓存长度"+ids.size());
			map.put("ids1", ids);
			nlist = attendPeopleRecordService.selectNewRecordInfo(map);
			//已经显示考勤的人员放入缓存
			for (CouldAttendUsr user : nlist) {
			String userid=	user.getUserid().toString();
			ids.add(userid);
			jedis.set(("dept"+deptid).getBytes(),  SerializeUtil. serialize(ids));
			}
		}
		//windows绝对路径
		String basePath = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+"/image/";
		if(nlist!=null){
			for (CouldAttendUsr c : nlist) {
				if(c.getPhotoUrl()!=null){
					c.setPhotoUrl(basePath+c.getPhotoUrl());
				}
			}
		}
		map.put("result", nlist);
 		object = JSON.toJSON(map);
 		System.err.println("结束"+object);
		return object;
	}
	
	/**
	 * 导出EXCEL表格需要的信息
	 * @param roleid
	 * @param recordDeptId
	 * @param recordDate
	 * @param recordUserId
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/outputExcl")
	@ResponseBody
	public Object outputExcl(@RequestParam(value = "roleid", required = true) String roleid,
			@RequestParam(value = "recordDeptId", required = false) String recordDeptId,
			@RequestParam(value = "recordDate", required = false) String recordDate,
			String stateid,
			HttpServletRequest request,
			HttpServletResponse response) {
		// 解决跨域问题
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		// 将前台数据放入Map集合中
		Map<String, Object> map = new HashMap<String, Object>();
		Object json = null;
		// 接受队伍编号
		Integer deptid = isNotNull(recordDeptId) ? Integer.parseInt(recordDeptId) : null;
		map.put("deptid", deptid);
		// 如果存在查询时间条件,进行格式转换
		if(isNotNull(recordDate)){
			recordDate = recordDate.substring(0, 10);
			map.put("recordDate", recordDate);
		}
		List<Event> rlist = null;
		ArrayList result = new ArrayList();
		// 队长的角色ID为3，进入不同方法
		if ("3".equals(roleid)) {
			if(deptid==null||deptid==0){
				map.put("msg", "没有相应的大队编号！");
				json = JSON.toJSON(map);
				return json;
			}
			List<StartTimeVo> list = attendPeopleRecordService.selectStartDateUpdate(map);
			map.put("dlist", list);
			int i = 0;
			for (StartTimeVo startTimeVo : list) {
				map.put("eventid", startTimeVo.getId());
				AccessRecord [] arlist = attendPeopleRecordService.getAllRecordByTeam(map);
				if(arlist.length==0){
					result.add(arlist);
				}else{
					result.add(arlist);
				}
				i++;
			}
			map.put("dlist", list);
			map.put("result", result);
			//导出Excel表格需要的大队中所有人员信息
//			alist = attendPeopleRecordService.getAllRecordByTeam(map);
//			map.put("result", alist);
			json = JSON.toJSON(map);
		} else if ("2".equals(roleid) || "1".equals(roleid)) {
			//导出Excel表格需要的所有大队信息
			rlist = attendPeopleRecordService.getTeamRecord(map);
			json = JSON.toJSON(rlist);
		}
		return json;
	}
	
	/**
	 * 完成点名
	 * 修改前台传来的参数对应的数据库数据
	 * @param ids 拼接的id字符串5
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/commitRecord")
	@ResponseBody
	public Object commitRecord(
			@RequestParam(value="recordDeptId",required=true)String recordDeptId,

			@RequestParam(value="absenseNum",required=true)String absenseNum,
			@RequestParam(value="startDatetime",required=true) String startDatetime,
			String endDatetime,String operationPersonnel,String operationIP,String depCode,
			HttpServletRequest request,HttpServletResponse response){
		// 解决跨域问题
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		Map<String, Object> map = new HashMap<String, Object>();
		Object object = null;
		Date date = new Date();
		SimpleDateFormat sbf = new SimpleDateFormat("yyyy-MM-dd");
		startDatetime = sbf.format(date)+" "+startDatetime;
		endDatetime = sbf.format(date)+" "+endDatetime;
		// 大队编号转型
		Integer deptid = isNotNull(recordDeptId) ? Integer.parseInt(recordDeptId) : null;

		if (deptid == null) {
			map.put("msg", "开始点名失败！");
			object = JSON.toJSON(map);
			return object;
		}
		// 获得总人数、应到人数、病休人数、其它人数的方法
		map.put("deptid", deptid);
		attendPeopleRecordService.getPrepareNum(map);
		int attendnum=0;
		//读取redis中已经录入的信息
		byte[] value=jedis.get(("dept"+deptid).getBytes());
		Object obj = SerializeUtil. unserialize(value);
		if(obj!=null){
			Set<String>ids=(Set<String>)obj;
			map.put("ids1", ids);

			 attendnum=ids.size()-1;//获取已点名人数
			map.put("attendnum",attendnum );
		}
//		Integer attendnum = isNotNull(attendNum)?Integer.parseInt(attendNum):null;
		Integer absensenum = isNotNull(absenseNum)?Integer.parseInt(absenseNum):null;
		
		map.put("absensenum", absensenum);
		map.put("starttime", startDatetime);
		map.put("endtime", endDatetime);
		//传入id数组进行批量修改
		int updateNum = attendPeopleRecordService.updateRecordByTeam(map);
		if(isNotNull(startDatetime)){
			map.put("startDatetime", startDatetime);
		}
		//结束点名时，将未到人员信息显示出来
		List<CouldAttendUsr> nlist = attendPeopleRecordService.selectAbsenseName(map);
		//结束点名时，向eventinfo表中插入人数信息 
		int result = attendPeopleRecordService.insertEventinfo(map);
		//结束点名时，向记录表中插入缺勤数据
		int  a = attendPeopleRecordService.insertAbsenseRecord(map);
		//结束点名时，修改记录表中eventid字段
		int i =  attendPeopleRecordService.updateCtrEventid(map);
		map.put("result", nlist);
		map.put("msg", "实到人数为"+attendnum+"人");//影响行数
		object = JSON.toJSON(map);
		//结束点名后插入点名日志
    	OperationLog operationLog= new OperationLog();
    	operationLog.setOperationPersonnel(operationPersonnel);
    	operationLog.setOperationContext("进行点名操作");
    	operationLog.setOperationIP(ControllerUtil.getIpAddr(request));
    	operationLog.setDeptid(depCode);
    	operationLogService.insertOperationLog(operationLog);
    	
		//完成点名将开关设置为true
//		for (Flag flag : flagList) {
			if(deptid.equals(flag.getDepid())){
				flag.setDepFlag(true);
			}
//		}
		return object;
	}
	
	/**
	 * 暂停点名后的恢复点名方法
	 * @param pauseDatetime
	 * @param recordDeptId
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/pauseRecord")
	@ResponseBody
	public Object pauseRecord(@RequestParam(value="pauseDatetime",required=true )String pauseDatetime,
			@RequestParam(value="recordDeptId",required=true )String recordDeptId,
			HttpServletRequest request,HttpServletResponse response){
		// 解决跨域问题
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		Map<String, Object> map = new HashMap<String, Object>();
		Object object = null;
		int deptid=0;
		if (isNotNull(pauseDatetime)) {
			Date date = new Date();
			SimpleDateFormat sbf = new SimpleDateFormat("yyyy-MM-dd");
			pauseDatetime = sbf.format(date)+" "+pauseDatetime;
			map.put("pauseDatetime", pauseDatetime);
		}
		if(isNotNull(recordDeptId)){
			 deptid = Integer.parseInt(recordDeptId);
			map.put("deptid", deptid);
		}
		//读取redis中已经录入的信息
		byte[] value=jedis.get(("dept"+deptid).getBytes());
		Object obj = SerializeUtil. unserialize(value);
		if(obj!=null){
			Set<String>ids=(Set<String>)obj;
			map.put("ids1", ids);
		}
		//暂停点名时，将未到人员信息显示出来
		List<CouldAttendUsr> nlist = attendPeopleRecordService.selectAbsenseName(map);
		//根据暂停时间和恢复时间删除数据
		int code = this.attendPeopleRecordService.deletePauseRecord(map);
//		Map<String, Object> map2 = new HashMap<String, Object>();
//		map2.put("code", code);
		
		
		object = JSON.toJSON(nlist);
		return object;
	}
	
	/**
	 * 终止点名时，删除相对应的数据
	 * @param ids 5
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/shutdownRecord")
	@ResponseBody
	public Object rollbackRecord(
			HttpServletRequest request,HttpServletResponse response,@RequestParam(value="recordDeptId",required=true )String recordDeptId){
		// 解决跨域问题
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");

		Map<String, Object> map = new HashMap<String, Object>();
		Object json = null;
//		if(idArray1==null||idArray1.length==0){
//			map.put("msg", "未传入学工编号！");
//			json = JSON.toJSON(map);
//			return json;
//		}
		/*
		if(ids1==null||ids1.length==0){
			map.put("msg", "未传入学工编号！");
			json = JSON.toJSON(map);
			return json;
		}
		//传入id数组进行批量删除
		Map<String, Object>map1 = new HashMap<String, Object>();

		map1.put("ids1", ids1);
		map1.put("ids2", ids2);
		map1.put("ids3", ids3);
		map1.put("ids4", ids4);
		map1.put("ids5", ids5);
		*/
		// 大队编号转型
		Integer deptid = isNotNull(recordDeptId) ? Integer.parseInt(recordDeptId) : null;
		//传入id数组进行批量删除
		Map<String, Object>map1 = new HashMap<String, Object>();
		//读取redis中已经录入的信息
		byte[] value=jedis.get(("dept"+deptid).getBytes());
		Object obj = SerializeUtil. unserialize(value);
		if(obj!=null){
			Set<String>ids=(Set<String>)obj;
			System.err.println(ids.size());
			map1.put("ids1", ids);
			
		}
		int deleteNum = attendPeopleRecordService.deleteRecordByTeam(map1);
		if(deleteNum>0){
			map.put("msg", "已终止点名，请重新开始点名！");
		}else{
			map.put("msg", "服务器繁忙");
		}
		json=JSON.toJSON(map);
		
    	
		//终止点名将开关设置为true
//		for (Flag flag : flagList) {
			if(deptid.equals(flag.getDepid())){
				flag.setDepFlag(true);
			}
//		}
//			 jedis.del(("dept"+deptid).getBytes());
		return json;
	}
	
	/**
	 * 判断字符串是否为空，解决前台传递条件的问题
	 * 
	 * @param str
	 * @return
	 */
	public boolean isNotNull(String str) {
		return str != null && !"".equals(str) && !"undefined".equals(str);
	}
}
