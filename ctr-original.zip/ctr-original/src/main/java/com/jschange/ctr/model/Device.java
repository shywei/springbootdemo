package com.jschange.ctr.model;

public class Device {
	private Integer id;//用于修改时传到后台的设备编号（修改前）
	private Integer deviceid;//设备编号
	private String deviceName;//设备名称
	private Integer deviceType;//设备类型 0一体机，1考勤机
	private String pattern;//模式 0表示1:1模式   1表示0：n模式
	private String deviceIP;//设备IP
	private String devicePort;//端口号
	private String subnetmask;//子网掩码
	private String gateway;//网关
	private String password;//连接密码
	private Integer serverid;//比对服务器编号
	private String serverIP;//比对服务器
	private Integer zoneid;//时段编号
	private String standbyServerIP;//备用服务器IP
	private String webserverIP;//应用服务器IP
	private String createtime;//创建时间
	private String modifytime;//修改时间
	private String areaName;//区域名称
	private Integer areaid;//区域编号
	private Integer applicationModel;//应用模式  是用于点名还是门禁
	private String applicationModelName;//应用模式名称
	private String functionDescription;//功能描述
	private String operatorType;//操作类型
	private String operatorResult;//操作结果
	private Integer connectionStatus;//设备连接状态 0连接正常  1 连接丢失
	
	
	public String getOperatorType() {
		return operatorType;
	}
	public void setOperatorType(String operatorType) {
		this.operatorType = operatorType;
	}
	public String getOperatorResult() {
		return operatorResult;
	}
	public void setOperatorResult(String operatorResult) {
		this.operatorResult = operatorResult;
	}
	public Integer getConnectionStatus() {
		return connectionStatus;
	}
	public void setConnectionStatus(Integer connectionStatus) {
		this.connectionStatus = connectionStatus;
	}
	public Integer getAreaid() {
		return areaid;
	}
	public void setAreaid(Integer areaid) {
		this.areaid = areaid;
	}
	public String getApplicationModelName() {
		return applicationModelName;
	}
	public void setApplicationModelName(String applicationModelName) {
		this.applicationModelName = applicationModelName;
	}
	public Integer getServerid() {
		return serverid;
	}
	public void setServerid(Integer serverid) {
		this.serverid = serverid;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getDeviceid() {
		return deviceid;
	}
	public void setDeviceid(Integer deviceid) {
		this.deviceid = deviceid;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public Integer getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(Integer deviceType) {
		this.deviceType = deviceType;
	}
	public String getDeviceIP() {
		return deviceIP;
	}
	public void setDeviceIP(String deviceIP) {
		this.deviceIP = deviceIP;
	}
	public String getDevicePort() {
		return devicePort;
	}
	public void setDevicePort(String devicePort) {
		this.devicePort = devicePort;
	}
	public String getSubnetmask() {
		return subnetmask;
	}
	public void setSubnetmask(String subnetmask) {
		this.subnetmask = subnetmask;
	}
	public String getGateway() {
		return gateway;
	}
	public void setGateway(String gateway) {
		this.gateway = gateway;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getServerIP() {
		return serverIP;
	}
	public void setServerIP(String serverIP) {
		this.serverIP = serverIP;
	}
	public Integer getZoneid() {
		return zoneid;
	}
	public void setZoneid(Integer zoneid) {
		this.zoneid = zoneid;
	}
	public String getStandbyServerIP() {
		return standbyServerIP;
	}
	public void setStandbyServerIP(String standbyServerIP) {
		this.standbyServerIP = standbyServerIP;
	}
	public String getWebserverIP() {
		return webserverIP;
	}
	public void setWebserverIP(String webserverIP) {
		this.webserverIP = webserverIP;
	}
	public String getCreatetime() {
		return createtime;
	}
	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}
	public String getModifytime() {
		return modifytime;
	}
	public void setModifytime(String modifytime) {
		this.modifytime = modifytime;
	}
	public String getAreaName() {
		return areaName;
	}
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	public Integer getApplicationModel() {
		return applicationModel;
	}
	public void setApplicationModel(Integer applicationModel) {
		this.applicationModel = applicationModel;
	}
	public String getFunctionDescription() {
		return functionDescription;
	}
	public void setFunctionDescription(String functionDescription) {
		this.functionDescription = functionDescription;
	}
	public String getPattern() {
		return pattern;
	}
	public void setPattern(String pattern) {
		this.pattern = pattern;
	}
	@Override
	public String toString() {
		return "Device [id=" + id + ", deviceid=" + deviceid + ", deviceName=" + deviceName + ", deviceType="
				+ deviceType + ", pattern=" + pattern + ", deviceIP=" + deviceIP + ", devicePort=" + devicePort
				+ ", subnetmask=" + subnetmask + ", gateway=" + gateway + ", password=" + password + ", serverid="
				+ serverid + ", serverIP=" + serverIP + ", zoneid=" + zoneid + ", standbyServerIP=" + standbyServerIP
				+ ", webserverIP=" + webserverIP + ", createtime=" + createtime + ", modifytime=" + modifytime
				+ ", areaName=" + areaName + ", areaid=" + areaid + ", applicationModel=" + applicationModel
				+ ", applicationModelName=" + applicationModelName + ", functionDescription=" + functionDescription
				+ ", operatorType=" + operatorType + ", operatorResult=" + operatorResult + ", connectionStatus="
				+ connectionStatus + "]";
	}
	
}	
