package com.jschange.ctr.common;




import com.jschange.ctr.common.Pagination;

import java.io.Serializable;
import java.util.List;

/**
 * 持久化接口
 * @author
 *
 */
public interface ResultList<T> extends Serializable {
	
	/**
	 * 获取结果集
	 * @return
	 */
	public List<T> getResults() ;

	/**
	 * 设置结果集
	 * @param reuslts
	 * @return
	 */
	public void setResults(List<T> reuslts) ;

	/**
	 * 获取总页数
	 * @return
	 */
	public Pagination getPage() ;

	/**
	 * 设置总页数
	 * @param page
	 * @return
	 */
	public void setPage(Pagination page) ;
	
}
