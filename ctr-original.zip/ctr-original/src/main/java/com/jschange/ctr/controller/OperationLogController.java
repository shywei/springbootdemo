package com.jschange.ctr.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.service.OperationLogService;


@Controller
@RequestMapping("operationLogController")
public class OperationLogController extends BaseController {
	
	@Autowired
	private OperationLogService operationLogService;
	
	/**
	 * 分页条件查询操作日志
	 * <p>Title:getOperationLogList</p>
	 * <p>Description:</p>
	 * <p>update name: update date:</p>
	 * <p>update Description:</p>
	 * @param @param response
	 * @param @param request
	 * @param @param operationTime
	 * @param @param operationPersonnel
	 * @param @param operationIP
	 * @param @return
	 * @return Object
	 * @throws
	 */
	@ResponseBody
	@RequestMapping("getOperationLogList")
	public ResultModel getOperationLogList(HttpServletResponse response,HttpServletRequest request,
			String operationTime,String operationPersonnel,String operationIP,String roleid,
			String deptCode,String operationType
			){
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("utf-8");
		ResultModel rs= new ResultModel();
		Pagination page=getPage();
		if("1".equals(roleid)||"2".equals(roleid)){//1 系统管理员   2 管理员（所长）
			roleid=null;
			deptCode=null;
		}
		try {
	        Map<String, Object> map = new HashMap<String, Object>();
	        if(null !=operationTime && !"".equals(operationTime)){
	        	map.put("operationTime", operationTime);
	        }
	        if(null !=operationType && !"".equals(operationType)){
	        	map.put("operationType", operationType);
	        }
	        if(null !=operationPersonnel && !"".equals(operationPersonnel)){
	        	map.put("operationPersonnel", operationPersonnel);
	        }
	        if(null !=operationIP && !"".equals(operationIP)){
	        	map.put("operationIP", operationIP);
	        }
	        if(null !=deptCode && !"".equals(deptCode)){
	        	map.put("deptid", deptCode);
	        }
	        //获取日志列表和数量
	        List<OperationLog>operationLogList=operationLogService.getOperationLogList(map,page).getResults();
	        rs.setObjExt(page);
	        rs.setObj(operationLogList);
	        return rs;
		} catch (Exception e) {
			return rs;
		}
		
	}
	
	

}
