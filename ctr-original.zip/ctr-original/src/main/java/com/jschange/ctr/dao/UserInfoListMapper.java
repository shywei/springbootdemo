package com.jschange.ctr.dao;

import java.rmi.ServerException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.State;
import com.jschange.ctr.model.UserInfo;

public interface UserInfoListMapper {
	
	//查询人员列表
	List<UserInfo> queryUserInfoList(Map<String, Object> map)throws SQLException;
	
	//查询人员列表数量
	Integer counutUserListNum(Map<String, Object> map)throws SQLException;

	//人员状态下拉框
	List<State> queryStateList()throws SQLException;
	
	//人员状态更改
	Integer updateUserState(Map<String, Object> map)throws SQLException;
	//根据主键ID查询人员信息
	List<UserInfo> queryUserInfoListByID(Integer integer)throws SQLException;
	
	
}
