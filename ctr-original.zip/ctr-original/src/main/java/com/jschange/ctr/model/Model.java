package com.jschange.ctr.model;

public class Model {
	private Integer modelid;//模块编号
	private String modelName;//模块名称
	private String modelUrl;//模块链接
	private Integer createid;//创建者id
	private String loginName;//创建账号
	private String createtime;//创建时间
	private Integer hasdeleted;//是否被删除(0存在1删除)
	private Integer menuid;//菜单编号
	private String menuName;//菜单名
	private Integer sortid;//排序号
	
	public Integer getSortid() {
		return sortid;
	}
	public void setSortid(Integer sortid) {
		this.sortid = sortid;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public Integer getModelid() {
		return modelid;
	}
	public void setModelid(Integer modelid) {
		this.modelid = modelid;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getModelUrl() {
		return modelUrl;
	}
	public void setModelUrl(String modelUrl) {
		this.modelUrl = modelUrl;
	}
	public Integer getCreateid() {
		return createid;
	}
	public void setCreateid(Integer createid) {
		this.createid = createid;
	}
	public String getCreatetime() {
		return createtime;
	}
	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}
	public Integer getHasdeleted() {
		return hasdeleted;
	}
	public void setHasdeleted(Integer hasdeleted) {
		this.hasdeleted = hasdeleted;
	}
	public Integer getMenuid() {
		return menuid;
	}
	public void setMenuid(Integer menuid) {
		this.menuid = menuid;
	}
	
}
