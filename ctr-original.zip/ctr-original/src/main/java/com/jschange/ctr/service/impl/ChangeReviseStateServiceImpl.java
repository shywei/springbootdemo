package com.jschange.ctr.service.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jschange.ctr.dao.ChangeReviseStateMapper;
import com.jschange.ctr.dao.OperationLogMapper;
import com.jschange.ctr.dao.UserInfoListMapper;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.OperationLog;
import com.jschange.ctr.model.UserInfo;
import com.jschange.ctr.service.ChangeReviseStateService;
import com.jschange.ctr.service.OperationLogService;
import com.jschange.ctr.service.VenaDigitalisService;


@Service("ChangeReviseStateService")
public class ChangeReviseStateServiceImpl implements ChangeReviseStateService{

	@Autowired
	private ChangeReviseStateMapper mapper;
	
	@Autowired
	private VenaDigitalisService fingerService;
	
	@Autowired
	private OperationLogService operationLogService;
	
	@Autowired
	private UserInfoListMapper userMapper;
	
	@Autowired
	private OperationLogMapper logMapper;
	
	//部门调度按钮（将人员状态改为调队中、接收部门改为即将要去的部门）
	@Override
	public Integer readyChangeDept(Map<String, Object> map,OperationLog operationLog) {
		try {
			String[] array=(String []) map.get("array");
			if(null != array){
				mapper.readyChangeDept(map);
				//查询该人员中含有指静脉数据的有多少人
				Integer count=mapper.countPersonNum(map);
				if(count!=0){
					map.put("count", count);
					mapper.occupyFingerNum(map);
				}
				for(int i=0;i<array.length;i++){
					//获取人员姓名拼接用于操作日志
					String userName=operationLogService.getNameByID(array[i]);
					//插入操作日志
					operationLog.setOperationContext("将人员:"+userName+"调入"+map.get("logUserDept")+",目前处于调队中");
					operationLogService.insertOperationLog(operationLog);
				}
			 return 1;	
			}else{
				return -3;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			return -3;
		}
	}
	
	
	//修改人员状态（驳回/接收）
	public Object updateRCUserInfoState(Map<String, Object> map,OperationLog operationLog) {
		try {
			if(map.containsKey("ids")){
				String ids=(String) map.get("ids"); 
				String[]arrayList=ids.split(",");
				String failID="";//人员状态不处于调队中，不可进行操作的集合
				String reviseState=(String) map.get("reviseState");//判断指令为接收或者驳回
				int state=0;//判断人员状态是否处于调队中
				if(reviseState.equals("2")){//接收人员
					for(int i=0;i<arrayList.length;i++){
						String userid=arrayList[i];
						//判断当前人员状态是否处于调队中state=1 调队中
						state=mapper.queryRCUserInfoState(userid);
						if(state==1){//调队中（调队中的数据才可以进行操作）
							Map<String, Object> map1=new HashMap<>();//用于对指静脉设备里面的存储量进行操作时传入参数的集合
							map1.put("id",userid);
							List<UserInfo> list=userMapper.queryUserInfoList(map1);
							for(UserInfo user:list){
								//1.判断当前人员是否存在指静脉信息
								if(user.getDigitalVein()!=null){//存在人员指静脉信息，调用设备下发接口
									//1）判断即将调入的设备状态是否处于在线状态
									Integer	statusFinger=mapper.checkStatusforfingerdrivice(userid);
									if(statusFinger!=0){//设备不处于在线状态，不可进行接收操作，将失败操作加入到失败的数据中
//										failID=userid+","+failID;
										//测试时直接return
										return -10;
									}else{//设备正常，可以进行接收操作
										//调用指静脉下发接口（从一台设备转移到另一台设备）返回0失败 1成功
										/*
										try {
											Integer q=fingerService.IssuedFinger(user.getReceivefingerDeviceid(), user.getId(), user.getUserName(), user.getDeptName(), user.getDigitalVein());
											if(q!=null){
												if(q!=1){//指静脉设备下发失败！
//													failID=userid+","+failID;
													//测试时直接return
													return -8;
												}else{//将原来设备上的指静脉数据删除，原来设备在数据库中的存储量-1
													fingerService.deleteFinger(user.getId());
													mapper.changeCollectedNum(user.getFingerDeviceid());
												}
											}
										} catch (Exception e) {
//											failID=userid+","+failID;
											e.printStackTrace();
											return -9;
										}*/
									}
								}
								map.put("userid", userid);
								String name=logMapper.getName(userid);
								String oldDept=mapper.queryOldDept(userid);
								map.put("reviseState", 2);
								map.put("oldDept", oldDept);
								
								/*
								if(user.getDigitalVein()!=null){
									map.put("fingerDeviceid", user.getReceivefingerDeviceid());
									map1.put("fingerDeviceidNo",user.getReceivefingerDeviceid());
									map1.put("reviseState", 2);
									//对指静脉设备占用数量操作（在人员进行调队时，会将要选择调去的指静脉设备的录取数量进行占位处理；当接收时需要将占用的数量减1，实际录入的数量加1（数据库里面会操作））
									mapper.updateFingerNum(map1);
								}*/
								//调用接收接口
								mapper.updateRCUserInfoState(map);
								//插入操作日志
								operationLog.setOperationContext(operationLog.getDeptName()+"接收人员编号为："+userid+",姓名为："+name+"的学员");
							}
						}else{
							failID=userid+","+failID;
						}
					}
				}else if(reviseState.equals("3")){//驳回
					for(int i=0;i<arrayList.length;i++){
						String userid=arrayList[i];
						state=mapper.queryRCUserInfoState(userid);
						if(state==1){
							map.put("userid", userid);
							String name=logMapper.getName(userid);
							String oldDept=mapper.queryOldDept(userid);
							map.put("reviseState", 3);
							mapper.updateRCUserInfoState(map);
							Map<String, Object> map2=new HashMap<>();
							//当驳回时需要将占用的数量减1，实际录入的数量加1（数据库里面会操作））
							map2.put("id",userid);
							List<UserInfo> list=userMapper.queryUserInfoList(map2);
							/*
							for(UserInfo user:list){
								if(user.getDigitalVein()!=null){
									map2.put("fingerDeviceidNo", user.getReceivefingerDeviceid());
									mapper.updateFingerNum(map2);
								}
							}*/
							operationLog.setOperationContext(operationLog.getDeptName()+"驳回人员编号为："+userid+",姓名为："+name+"的学员");
						}else{
							failID=userid+","+failID;
						}
					}
				}
				if(failID!=null && !"".equals(failID)){
					return failID+"操作失败";
				}else{
					return "success";
				}
			} 
		} catch (Exception e) {
			return -2;
		}
		return -3;
	}
	
	//撤回调队人员
	@Override
	public Integer recallChangeDeptUser(Map<String, Object> map,OperationLog operationLog) throws ServiceException {
		try {
			String ids=(String) map.get("ids"); 
			String[] array=ids.split(",");
			for(int i=0;i<array.length;i++){
				String id=array[i];
				Map<String,Object> map1=new HashMap<>();
				map1.put("userid",id);
				List<UserInfo> list=userMapper.queryUserInfoList(map1);
				for(UserInfo user:list){
					/*
					if(user.getDigitalVein()!=null){
						map1.put("fingerDeviceidNo", user.getReceivefingerDeviceid());
						mapper.updateFingerNum(map1);
					}*/
				}
				map.put("id", array[i]);
				String userName=logMapper.getName(array[i]);
				mapper.recallChangeDeptUser(map);
				operationLog.setOperationContext("撤回编号为"+array[i]+",姓名为"+userName+"的人员");
				logMapper.insertOperationLog(operationLog);
			}
			return mapper.recallChangeDeptUser(map);
		} catch (Exception e) {
			e.printStackTrace();
			return -3;
		}
		
	}

	//查询人员当前状态
	@Override
	public Integer queryRCUserInfoStateById(String id) throws ServiceException {
		try {
			return mapper.queryRCUserInfoState(id);
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
		
	}


	@Override
	public Integer queryIsDel(String id) throws ServiceException {
		try {
			return mapper.queryIsDel(id);
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
	}

	

}
