package com.jschange.ctr.dao;

import java.sql.SQLException;
import java.util.Map;

public interface GetDeviceStateMapper {
	
	public Integer updateDeviceState(Map<String,Object> map)throws SQLException;//修改终端设备状态

}
