package com.jschange.ctr.model;

public class DataDictionary {
	private Integer id;//主键id
	private String isDeleted;//是否删除(0存在1删除)
	private String DataKey;//显示的中文名
	private String DataValue;//保存到数据库的
	private String DataType;//类型
	private String TypeTitle;//类型的名称
	private String IsSysData;//是否是系统数据系统数据不可删除(1是0不是)
	private String Note;//备注
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}
	public String getDataKey() {
		return DataKey;
	}
	public void setDataKey(String dataKey) {
		DataKey = dataKey;
	}
	public String getDataValue() {
		return DataValue;
	}
	public void setDataValue(String dataValue) {
		DataValue = dataValue;
	}
	public String getDataType() {
		return DataType;
	}
	public void setDataType(String dataType) {
		DataType = dataType;
	}
	public String getTypeTitle() {
		return TypeTitle;
	}
	public void setTypeTitle(String typeTitle) {
		TypeTitle = typeTitle;
	}
	public String getIsSysData() {
		return IsSysData;
	}
	public void setIsSysData(String isSysData) {
		IsSysData = isSysData;
	}
	public String getNote() {
		return Note;
	}
	public void setNote(String note) {
		Note = note;
	}
	
}
