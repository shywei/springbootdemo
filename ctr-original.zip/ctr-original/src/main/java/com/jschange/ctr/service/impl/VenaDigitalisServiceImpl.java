package com.jschange.ctr.service.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jschange.ctr.dao.VenaDigitalisMapper;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.FingerDrivice;
import com.jschange.ctr.model.ResultModel;
import com.jschange.ctr.model.UserInfo;
import com.jschange.ctr.service.VenaDigitalisService;

import util.QJCmdSend;
import util.SocketMap;
import util.VenaMap;

@Service("venaDigitalisService")
public class VenaDigitalisServiceImpl implements VenaDigitalisService {
	@Autowired
	private VenaDigitalisMapper venaDigitalisMapper;
	@Override
	public FingerDrivice selectDriviceInfoById(Integer mesID) throws ServiceException {
		// TODO Auto-generated method stub
		FingerDrivice driviceModel=null;
		try {
			driviceModel=venaDigitalisMapper.selectDriviceInfoById(mesID);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return driviceModel;
	}

	@Override
	public List<FingerDrivice> queryDriviceInfo(Integer areaID) throws ServiceException {
		// TODO Auto-generated method stub
		List<FingerDrivice> driviceModelList=null;
		try {
			driviceModelList=venaDigitalisMapper.queryDriviceInfo(areaID);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return driviceModelList;
	}

	@Override
	public FingerDrivice selectDriviceInfoByFingerCode(String fingerCode) throws ServiceException {
		// TODO Auto-generated method stub
		FingerDrivice driviceModel=null;
		try {
			driviceModel=venaDigitalisMapper.selectDriviceInfoByFingerCode(fingerCode);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return driviceModel;
	}

	@Override
	public void insertVenaInfo(String fingerCode) throws ServiceException {
		// TODO Auto-generated method stub
		try {
			venaDigitalisMapper.insertVenaInfo(fingerCode);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void updateDriviceState(String fingerCode) throws ServiceException {
		// TODO Auto-generated method stub
		try {
			venaDigitalisMapper.updateDriviceState(fingerCode);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void updateDriviceStatus(String fingerCode) throws ServiceException {
		// TODO Auto-generated method stub
		try {
			venaDigitalisMapper.updateDriviceStatus(fingerCode);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void insertFingerInfo(Map<Object, Object> map) throws ServiceException {
		// TODO Auto-generated method stub
		try {
			venaDigitalisMapper.insertFingerInfo(map);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Integer queryDriviceID(Integer userID) throws ServiceException{
		// TODO Auto-generated method stub
		Integer driviceID=null;
		try {
			driviceID=venaDigitalisMapper.queryDriviceID(userID);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return driviceID;
	}

	@Override
	public UserInfo queryUserInfo(Integer keyId) throws ServiceException{
		// TODO Auto-generated method stub
		UserInfo user=null;
		try {
			user=venaDigitalisMapper.queryUserInfo(keyId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
		
	}

	@Override
	public void insertRecord(Map<String, Object> map) throws ServiceException {
		// TODO Auto-generated method stub
		try {
			venaDigitalisMapper.insertRecord(map);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 人员下发
	 * mesID 设备主键ID
	 * userID 用户ID
	 * userName 
	 * deptName
	 * finger
	 */
	@Override
	public Integer IssuedFinger(Integer mesID,Integer userID, String userName, String deptName, byte[] finger)
			throws ServiceException {
		// TODO Auto-generated method stub
		byte[] uID = new byte[4];
		String res=null;
		// 将用户ID按高八位在前第八位在后的方式转化成byte数组
		uID[0] = 0x00;
		uID[1] = 0x01;
		uID[2] = (byte) ((userID >> 8) & 0xff);
		uID[3] = (byte) (userID & 0xff);
		
		try {
			byte[] uName=userName.getBytes("GBK");
			byte[] dName = deptName.getBytes("GBK");
			byte[] utemp=new byte[20];
			for (int j=0;j<uName.length;j++) {
				utemp[j]=uName[j];
			}
			byte[] dtemp=new byte[64];
			for (int j = 0; j < dName.length; j++) {
				dtemp[j]=dName[j];
			}
			//将人员ID,姓名，部门,指纹数据合成一个数组TEMP3
			byte[] TEMP=ArrayUtils.addAll(utemp, dtemp);
			byte[] TEMP2=ArrayUtils.addAll(uID, TEMP);
			byte[] TEMP3=ArrayUtils.addAll(TEMP2, finger);
			//算求和校验码和异或校验码
			int total=0;
			int total2=0;
			byte[] a=new byte[4];
	
			for(int i=0;i<1072;){
				a[0]=finger[i];
				a[1]=finger[i+1];
				a[2]=finger[i+2];
				a[3]=finger[i+3];
				total+=byteArrayToInt(a);
				total2^=byteArrayToInt(a);
				i+=4;
			}
			//将求和，异或转成byte数组,并且合并
			byte[] sums=intToByteArray(total);
			byte[] xors=intToByteArray(total2);
			byte[] TEMP4=ArrayUtils.addAll(sums, xors);
			//将所有数组合并成body
			byte[] body=ArrayUtils.addAll(TEMP3, TEMP4);
			//根据设备ID,查询设备信息
			FingerDrivice fingerDrivice=venaDigitalisMapper.selectDriviceInfoById(mesID);
			Socket socket=null;
			if(fingerDrivice!=null){
				String fingerCode=fingerDrivice.getDriviceNo();
				socket = VenaMap.venaMap.get(fingerCode);
				QJCmdSend.send(socket, 0x8103, body);
			}
			if(socket!=null){
				while(res==null){
					res=SocketMap.socketMap.get(socket);
				}
				SocketMap.socketMap.remove(socket);
			}else{
				System.err.println("socket不存在！");
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}catch (SQLException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
		Integer it = Integer.valueOf(res);
		return it;
	}

	@Override
	public void insertFingerInfoForUserInfo(Map<Object, Object> map)throws ServiceException {
		// TODO Auto-generated method stub
		try {
			venaDigitalisMapper.insertFingerInfoForUserInfo(map);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//将byte数组转成int
	public static int byteArrayToInt(byte[] b) {  
        return   b[3] & 0xFF |  
                (b[2] & 0xFF) << 8 |  
                (b[1] & 0xFF) << 16 |  
                (b[0] & 0xFF) << 24;  
    } 
	//将int转成byte数组
	public static byte[] intToByteArray(int a) {  
	    return new byte[] {  
	        (byte) ((a >> 24) & 0xFF),  
	        (byte) ((a >> 16) & 0xFF),     
	        (byte) ((a >> 8) & 0xFF),     
	        (byte) (a & 0xFF)  
	    };  
	}
	
	//根据人员主键ID,删除设备中人员信息
	@Override
	public Integer deleteFinger(Integer id) throws ServiceException {
		// TODO Auto-generated method stub
		byte[] body=new byte[4];
		body[0] = 0x00;
		body[1] = 0x01;
		body[2] = (byte) ((id >> 8) & 0xff);
		body[3] = (byte) (id & 0xff);
		//通过用户ID,查询到当时采集时对应的设备ID
		Integer mesID=null;
		try {
			mesID = venaDigitalisMapper.queryDriviceID(id);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//获取对应ID的设备信息
		FingerDrivice driviceInfo =null;
		if(mesID!=null){
			try {
				driviceInfo = venaDigitalisMapper.selectDriviceInfoById(mesID);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			System.err.println("查询的设备mesID为null");
		}
		//获取设备对应的指纹模块ID
		String fingerCode = driviceInfo.getDriviceNo();
		//获取设备对应的socket
		Socket socket = null;
		if(fingerCode!=null){
			socket = VenaMap.venaMap.get(fingerCode);
		}
		String res=null;
		
		if(socket!=null){
			try {
				QJCmdSend.send(socket, 0x8102, body);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			while(res==null){
				res=SocketMap.socketMap.get(socket);
			}
		}
		Integer it = Integer.valueOf(res);
		return it;
	}

	@Override
	public Integer queryDeptID(String deptName) throws ServiceException{
		// TODO Auto-generated method stub
		Integer deptID=null;
		try {
			deptID=venaDigitalisMapper.queryDeptID(deptName);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return deptID;
	}
	
	/**
	 * 修改设备有线信息
	 * mesID 设备主键ID
	 * serviceIP 服务器IP
	 * localIP 设备本地IP
	 * port 端口号
	 */
	@Override
	public Integer changeWiredInfo(String serviceIP, String localIP,Integer mesID,String port) throws ServiceException {
		// TODO Auto-generated method stub
		String res=null;
		String[] serIP=serviceIP.split("\\.");
		String[] locIP=localIP.split("\\.");
		int por=Integer.parseInt(port);
		byte[] sIP=new byte[4];
		byte[] lIP=new byte[4];
		byte[] p=new byte[]{(byte)((por >> 8) & 0xFF),(byte) (por & 0xFF)};
		for(int i=0;i<serIP.length;i++){
			sIP[i]=(byte)(Integer.parseInt(serIP[i]) & 0xff);
		}
		for(int i=0;i<locIP.length;i++){
			lIP[i]=(byte)(Integer.parseInt(locIP[i]) & 0xff);
		}
		byte[] temp=ArrayUtils.addAll(sIP, p);
		byte[] body=ArrayUtils.addAll(temp, lIP);
		
		//根据设备ID,查询设备信息
		try {
			FingerDrivice fingerDrivice=venaDigitalisMapper.selectDriviceInfoById(mesID);
			if(fingerDrivice!=null){
				String fingerCode=fingerDrivice.getDriviceNo();
				if(fingerCode!=null){
					Socket socket = VenaMap.venaMap.get(fingerCode);
					if(socket!=null){
						QJCmdSend.send(socket, 0x8105, body);
					}
					if(res==null){
						res=SocketMap.socketMap.get(socket);
					}
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Integer it = Integer.valueOf(res);
		return it;
	}  
}
