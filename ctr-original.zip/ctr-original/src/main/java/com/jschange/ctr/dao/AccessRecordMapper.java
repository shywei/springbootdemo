package com.jschange.ctr.dao;

import java.util.List;
import java.util.Map;

import com.jschange.ctr.model.AccessRecord;
import com.jschange.ctr.model.CouldAttendUsr;
import com.jschange.ctr.model.StartTimeVo;
import com.jschange.ctr.model.UserInfo;
public interface AccessRecordMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(AccessRecord record);

    int insertSelective(AccessRecord record);

    AccessRecord selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(AccessRecord record);

    int updateByPrimaryKey(AccessRecord record);
    
    //改变正常状态时需要向记录表插入异常状态信息
    int insertAccessRecord(Map<String,Object> map);
    
    //分页查询所有队里需要点名的人员信息
	List<AccessRecord> selectRecordByPageByTeam(Map<String, Object> map);//1
	
	//按条件查询人员记录总条数
	int selectAllRowsByReqire(Map<String, Object> map);//1
	
	//导出Excel表格需要的大队中所有人员信息
	AccessRecord[] getAllRecordByTeam(Map<String, Object> map);//1
	
	//开始点名获取大队已经点名的简要信息：图片地址等
	List<CouldAttendUsr> startRecordInfo(Map<String, Object> map);//1

	//传入id数组进行批量修改
	int updateRecordByTeam(Map<String, Object> map);//1
	
	//传入id数组进行批量删除
	int deleteRecordByTeam(Map<String, Object> map);//1
	//暂停点名
	int deletePauseRecord(Map<String, Object> map);//1
	//根据时间将记录状态修改
	int updateRecordByTime(Integer deptid);//1

	List<CouldAttendUsr> selectNewRecordInfo(Map<String, Object> map);//1

	List<CouldAttendUsr> selectAbsenseName(Map<String, Object> map);//1
	//查询缺勤人员的ID
	String[] selectAbesenseId(Map<String, Object> map);//1

	Integer insertAbsenseRecord(UserInfo user);//1

	List<String> selectStartDate(Map<String, Object> map);

	List<StartTimeVo> selectStartDateUpdate(Map<String, Object> map);//1

	int updateCtrEventid(Map<String, Object> map);//1
	UserInfo  getUserInfo(String userid);

}