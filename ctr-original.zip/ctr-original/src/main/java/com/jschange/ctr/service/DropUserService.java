package com.jschange.ctr.service;

import java.rmi.ServerException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.model.UserInfo;


public interface DropUserService {
	
	//查询人员调队-离队人员 列表
	ResultList<UserInfo> queryDropUserList(Map<String, Object>map,Pagination page)throws ServerException;
	//查询人员调队-离队人员 列表
	ResultList<UserInfo> queryReceiveUserList(Map<String, Object>map,Pagination page)throws SQLException;


}
