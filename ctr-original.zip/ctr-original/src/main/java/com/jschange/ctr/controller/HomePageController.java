package com.jschange.ctr.controller;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.jschange.ctr.model.AbsenceList;
import com.jschange.ctr.model.AttendanceDataStatistics;
import com.jschange.ctr.model.InLeave;
import com.jschange.ctr.service.HomePageService;



@Controller
@RequestMapping("homePageController")
public class HomePageController {
	@Autowired
	HomePageService homePageService;
	
	/**
	 * 首页柱状图考勤数据 code=9 是所长看到的数据
	 * <p>Title:homeAttence</p>
	 * <p>Description:</p>
	 * <p>update name: update date:</p>
	 * <p>update Description:</p>
	 * @param @param response
	 * @param @param code
	 * @param @return
	 * @return Object
	 * @throws
	 */
	@ResponseBody
	@RequestMapping("homeAttence")
	public Object homeAttence(HttpServletResponse response,String code,Integer deptid){
		
		response.setHeader("Access-Control-Allow-Origin", "*");
		Map<String, Object> map= new HashMap<String, Object>();
		if("1".equals(code)){
			code="9";
		}
		map.put("code", code);
		map.put("deptid",deptid);
		List<AttendanceDataStatistics>list=homePageService.homeAttence(map);
		return JSON.toJSON(list);
		
	}
	
	/**
	 * 首页在队离队的全年折线数据code=9 是所长看到的数据 isDelected=0 在队
	 * <p>Title:yearlyInOrNotTeam</p>
	 * <p>Description:</p>
	 * <p>update name: update date:</p>
	 * <p>update Description:</p>
	 * @param @param response
	 * @param @param code
	 * @param @param isDelected
	 * @param @return
	 * @return Object
	 * @throws
	 */
	@ResponseBody
	@RequestMapping("yearlyInOrNotTeam")
	public Object yearlyInOrNotTeam(HttpServletResponse response,String code,String isDelected,Integer deptid){
		response.setHeader("Access-Control-Allow-Origin", "*");
		Map<String, Object>map= new HashMap<String, Object>();
		if("1".equals(code)){
			code="9";
		}
		map.put("code", code);
		map.put("isDelected", isDelected);
		map.put("deptid",deptid);
		SimpleDateFormat sdf= new SimpleDateFormat("yyyy");
		//获取当月日期并截取到月份用来循环
		SimpleDateFormat sdf1= new SimpleDateFormat("yyyy-MM");
		String nowTime=sdf1.format(new Date());
		//截取到月份
		nowTime=nowTime.substring(5,7);
		int k= Integer.parseInt(nowTime);
		List<InLeave>list= new ArrayList<InLeave>();
		//之循环到当月数据
		for(int i =1;i<=k;i++){
		String time=sdf.format(new Date());
			if (i<10) {
			time=time+"-0"+i;	
			}else{
				time=time+"-"+i;
			}
			map.put("time", time);
		int value=	homePageService.yearlyInOrNotTeam(map);
		InLeave inleave= new InLeave(i, value);
		list.add(inleave);
		}
//		System.err.println(JSON.toJSON(list));
		return JSON.toJSON(list);
		
	}
	/**
	 * 首页饼状图比例数据code=9 是所长看到的数据 
	 * <p>Title:proportion</p>
	 * <p>Description:</p>
	 * <p>update name: update date:</p>
	 * <p>update Description:</p>
	 * @param @param response
	 * @param @param code
	 * @param @return
	 * @return Object
	 * @throws
	 */
	@ResponseBody
	@RequestMapping("proportion")
	public Object proportion(HttpServletResponse response,String code,Integer deptid){
		
		response.setHeader("Access-Control-Allow-Origin", "*");
		Map<String, Object> map= new HashMap<String, Object>();
		if("1".equals(code)){
			code="9";
		}
		map.put("code", code);
		map.put("deptid",deptid);
		List<AttendanceDataStatistics>list=homePageService.homeAttence(map);
		AttendanceDataStatistics attend=homePageService.proportion(map);
		Map<String, Object>map1= new HashMap<String, Object>();
		try {
			 double total=attend.getAllnum()+0.0; //总人数
			 int rollcallNum=attend.getRollcallnum();//应到人数
			 int attendNum=attend.getAttendnum();//实到人数
			 int otherNum=attend.getOthernum();//其他人数
			 int absentNum=attend.getAbsensenum();//缺席人数
			 int sickNum=attend.getSickleavenum();//病假人数
			 
			 map1.put("attend", attend);//考勤数据
			 map1.put("depSum", list.size());//大队总数
			 map1.put("attendNum", String.format("%.1f", (attendNum*100)/total));//实到人数比例
			 map1.put("otherNum", String.format("%.1f", (otherNum*100)/total));//其他人数比例
			 map1.put("absentNum", String.format("%.1f", (absentNum*100)/total));//缺席人数比例
			 map1.put("sickNum", String.format("%.1f", (sickNum*100)/total));//病假人数比例
			
		} catch (Exception e) {
			
		}
		
		
		
		return JSON.toJSON(map1);
	}
	
	/**
	 * 缺勤人员名单
	 * <p>Title:queqinList</p>
	 * <p>Description:</p>
	 * <p>update name: update date:</p>
	 * <p>update Description:</p>
	 * @param @param response
	 * @param @param depId大队的code
	 * @param @return
	 * @return Object
	 * @throws
	 */
	@ResponseBody
	@RequestMapping("queqinList")
	public Object queqinList(HttpServletResponse response,String depId){
		response.setHeader("Access-Control-Allow-Origin", "*");
		System.err.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~depId缺勤"+depId);
		//获取点名缺勤人员名单
		List<AbsenceList> list=homePageService.queqinList(depId);
		response.setCharacterEncoding("utf-8");
		return JSON.toJSON(list);
		}
	}

