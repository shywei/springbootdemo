package com.jschange.ctr.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jschange.ctr.dao.ApplicationModelMapper;
import com.jschange.ctr.model.ApplicationModel;
import com.jschange.ctr.service.ApplicationModelService;

@Service("applicationModelService")
public class ApplicationModelServiceImpl implements ApplicationModelService {
	@Autowired
	private ApplicationModelMapper applicationModelMapper;
	@Override
	public List<ApplicationModel> applicationModelList() {
		// TODO Auto-generated method stub
		return applicationModelMapper.applicationModelList();
	}

}
