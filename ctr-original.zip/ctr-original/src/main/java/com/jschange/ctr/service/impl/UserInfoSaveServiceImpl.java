package com.jschange.ctr.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.common.ResultListImpl;
import com.jschange.ctr.dao.UserInfoSaveMapper;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.DataDictionary;
import com.jschange.ctr.model.DeptInfo;
import com.jschange.ctr.model.Role;
import com.jschange.ctr.model.UserInfo;
import com.jschange.ctr.service.UserInfoSaveService;

import palm.pass.function.ServerFlowFunction;
import util.Env;
@Service(value=UserInfoSaveService.SERVICE_NAME)
@Transactional
public class UserInfoSaveServiceImpl implements UserInfoSaveService{
	
	private int count=0;
	
	private String compareServerIP = Env.getInstance().getProperty("CompareServerIP");
	
	@Autowired
	private UserInfoSaveMapper userInfoSaveMapper;
	
	
	Logger logger=LoggerFactory.getLogger(this.getClass());
	
	//人员注册
	@Override
	public int registerUserInfo(UserInfo userInfo) throws ServiceException {
		try {
				//将下拉框的"请选择"筛选掉
				if(userInfo.getIsBalckList()==-1){
					userInfo.setIsBalckList(2);
				}
				if(userInfo.getGender()==-1){
					userInfo.setGender(null);
				}
				if(userInfo.getIsMarried()==-1){
					userInfo.setIsMarried(null);
				}
				if(userInfo.getHasChild()==-1){
					userInfo.setHasChild(null);
				}
				if(userInfo.getCardType()==-1){
					userInfo.setCardType(null);
				}
				//日期set null
				if("".equals(userInfo.getBirthday())){
					userInfo.setBirthday(null);
				}
				if("".equals(userInfo.getCreatetime())){
					userInfo.setCreatetime(null);
				}
				if("".equals(userInfo.getDeletetime())){
					userInfo.setDeletetime(null);
				}
				if("".equals(userInfo.getBeginEffectiveDate())){
					userInfo.setBeginEffectiveDate(null);
				}
				if("".equals(userInfo.getEndEffectiveDate())){
					userInfo.setEndEffectiveDate(null);
				}
				count=userInfoSaveMapper.registerUserInfo(userInfo);
				if(count==1){
					//本地注册成功，开始同步数据至对接表
					if(userInfo.getMetacarpalVein()!=null && userInfo.getMetacarpalVein().length==15000){
						/* 调用已有的接口方法，在对接表中重新插入认证数据
						Map<String,Object> param = new HashMap<>();
						param.put("id", userInfo.getId());
						param.put("userid", userInfo.getPersonid());
						param.put("vein", userInfo.getMetacarpalVein());
						userInfoSaveMapper.userEnrollFunction(param);*/
						userEnrollFunction(userInfo.getId(), userInfo.getMetacarpalVein());
						//调用同步方法
						ServerFlowFunction sff=new ServerFlowFunction();
						sff.UserEnrollFunction(compareServerIP, userInfo.getId().toString(),
								userInfo.getMetacarpalVein());
					}
				}
				return count;
		} catch (Exception e) {
			logger.error("人员注册异常",e, UserInfoSaveServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//人员修改
	@Override
	public int updateUserInfo(UserInfo userInfo) throws ServiceException {
		try {
			//将下拉框的"请选择"筛选掉
			if(userInfo.getIsBalckList()==-1){
				userInfo.setIsBalckList(2);
			}
			if(userInfo.getGender()==-1){
				userInfo.setGender(null);
			}
			if(userInfo.getIsMarried()==-1){
				userInfo.setIsMarried(null);
			}
			if(userInfo.getHasChild()==-1){
				userInfo.setHasChild(null);
			}
			if(userInfo.getCardType()==-1){
				userInfo.setCardType(null);
			}
			//日期set null
			if("".equals(userInfo.getBirthday())){
				userInfo.setBirthday(null);
			}
			if("".equals(userInfo.getCreatetime())){
				userInfo.setCreatetime(null);
			}
			if("".equals(userInfo.getDeletetime())){
				userInfo.setDeletetime(null);
			}
			if("".equals(userInfo.getBeginEffectiveDate())){
				userInfo.setBeginEffectiveDate(null);
			}
			if("".equals(userInfo.getEndEffectiveDate())){
				userInfo.setEndEffectiveDate(null);
			}
			//判断人员编号是否已存在
			Map<String,Object> param=new HashMap<>();
			param.put("userid", userInfo.getUserid());
			param.put("id", userInfo.getId());
			count=userInfoSaveMapper.checkUpdate(param);
			if(count==0){
				//人员编号不存在
				if(userInfo.getMetacarpalVein()!=null){
					userInfo.setHasMetacarpalVein(1);
				}
				if(userInfo.getDigitalVein()!=null){
					userInfo.setHasDigitalVein(1);
				}
				count=userInfoSaveMapper.updateUserInfo(userInfo);
				if(userInfo.getMetacarpalVein()!=null){
					//更新对接表里数据
					//根据id获取personid
					//String userid=userInfoSaveMapper.getPersonId(userInfo.getId());
					count=userInfoSaveMapper.userDeleteFunction(userInfo.getId().toString());
					/* 调用已有的接口方法，在对接表中重新插入认证数据
					param.put("id", userInfo.getId());
					param.put("userid", userid);
					param.put("vein", userInfo.getMetacarpalVein());
					userInfoSaveMapper.userEnrollFunction(param);*/
					userEnrollFunction(userInfo.getId(), userInfo.getMetacarpalVein());
					//调用同步方法
					ServerFlowFunction sff=new ServerFlowFunction();
					if(count==1){
						//已有，则更新
						sff.UserUpdateFunction(compareServerIP, userInfo.getId().toString(),
								userInfo.getMetacarpalVein());
					}
					else{
						sff.UserEnrollFunction(compareServerIP, userInfo.getId().toString(),
								userInfo.getMetacarpalVein());
					}
				}
				return count;
			}
			return count-2;
		} catch (Exception e) {
			logger.error("人员修改异常",e, UserInfoSaveServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//获取注册/修改时的大队下拉框
	@Override
	public ResultList<DeptInfo> getDept() throws ServiceException {
		try {
			ResultList<DeptInfo> deptList=new ResultListImpl<>();
			deptList.setResults(userInfoSaveMapper.getDept());
			return deptList;
		} catch (Exception e) {
			logger.error("获取注册/修改时的大队下拉框异常",e, UserInfoSaveServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//获取注册/修改时的角色下拉框
	@Override
	public ResultList<Role> getRole() throws ServiceException {
		try {
			ResultList<Role> roleList=new ResultListImpl<>();
			roleList.setResults(userInfoSaveMapper.getRole());
			return roleList;
		} catch (Exception e) {
			logger.error("获取注册/修改时的角色下拉框异常",e, UserInfoSaveServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//修改时查询人员编号
	@Override
	public String getUserid(Integer id) throws ServiceException {
		try {
			return userInfoSaveMapper.getUserid(id);
		} catch (Exception e) {
			logger.error("修改时查询人员编号异常",e, UserInfoSaveServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//修改时查询照片名称
	@Override
	public String getPhotoUrl(Integer id) throws ServiceException {
		try {
			return userInfoSaveMapper.getPhotoUrl(id);
		} catch (Exception e) {
			logger.error("修改时查询照片名称异常",e, UserInfoSaveServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//获取注册/修改时的证件类型下拉框
	@Override
	public ResultList<DataDictionary> getCardType() throws ServiceException {
		try {
			ResultList<DataDictionary> resultList=new ResultListImpl<>();
			resultList.setResults(userInfoSaveMapper.getCardType());
			return resultList;
		} catch (Exception e) {
			logger.error("获取注册/修改时的证件类型下拉框异常",e, UserInfoSaveServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//注册时查询人员编号是否存在
	@Override
	public int checkRegister(String userid) throws ServiceException {
		try {
			count=userInfoSaveMapper.checkRegister(userid);
			return count;
		} catch (Exception e) {
			logger.error("注册时查询人员编号是否存在异常",e, UserInfoSaveServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//修改时查询人员编号是否存在
	@Override
	public int checkUpdate(Map<String, Object> param) throws ServiceException {
		try {
			count=userInfoSaveMapper.checkUpdate(param);
			return count;
		} catch (Exception e) {
			logger.error("修改时查询人员编号是否存在异常",e, UserInfoSaveServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//注册成功后，数据导入对接的表
	@Override
	public int userEnrollFunction(Integer id, byte[] vein) throws ServiceException {
		try {
			Map<String,Object> param=new HashMap<>();
			param.put("id", id);
			param.put("vein", vein);
			count=userInfoSaveMapper.userEnrollFunction(param);
			return count;
		} catch (Exception e) {
			logger.error("数据导入对接的表异常",e, UserInfoSaveServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//根据userid查询主键id
	@Override
	public int getIdByUserId(String id) throws ServiceException {
		try {
			return userInfoSaveMapper.getIdByUserId(id);
		} catch (Exception e) {
			logger.error("根据userid查询主键id异常",e, UserInfoSaveServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	
	//查看终端信息
	@Override
	public int getTerminalInfo(Map<String, Object> param) throws ServiceException {
		try {
			return userInfoSaveMapper.getTerminalInfo(param);
		} catch (Exception e) {
			logger.error("查看终端信息异常",e, UserInfoSaveServiceImpl.class);
			throw new ServiceException(e);
		}
	}
	

}
