package com.jschange.ctr.model;

import java.io.Serializable;

public class SystemUser implements Serializable{
    private Integer id;

    private String loginName;//登录名

    private String userName;//用户名称

    private String password;//密码

    private Integer deptid;//部门编号

    private Integer hasdeleted;//是否被删除

    private String deletetime;//删除时间

    private String createtime;//创建时间
    
    private String modifytime;//修改时间

    private Integer roleid;//角色编号
    
    private String deptName;//部门名称
    
    private String userIP;//登录IP

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getDeptid() {
		return deptid;
	}

	public void setDeptid(Integer deptid) {
		this.deptid = deptid;
	}

	public Integer getHasdeleted() {
		return hasdeleted;
	}

	public void setHasdeleted(Integer hasdeleted) {
		this.hasdeleted = hasdeleted;
	}


	public String getDeletetime() {
		return deletetime;
	}

	public void setDeletetime(String deletetime) {
		this.deletetime = deletetime;
	}

	public String getCreatetime() {
		return createtime;
	}

	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}

	public String getModifytime() {
		return modifytime;
	}

	public void setModifytime(String modifytime) {
		this.modifytime = modifytime;
	}

	public Integer getRoleid() {
		return roleid;
	}

	public void setRoleid(Integer roleid) {
		this.roleid = roleid;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getUserIP() {
		return userIP;
	}

	public void setUserIP(String userIP) {
		this.userIP = userIP;
	}

	
  
    
}