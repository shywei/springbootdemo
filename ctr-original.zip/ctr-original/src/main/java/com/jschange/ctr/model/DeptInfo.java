package com.jschange.ctr.model;

import java.io.Serializable;
import java.util.Date;

public class DeptInfo implements Serializable{
    private Integer deptid;//部门编号

    private String deptName;//部门名称

    private Integer superid;//上级编号

    private String createtime;//创建时间

    private String modifytime;//修改时间


	public Integer getDeptid() {
		return deptid;
	}

	public void setDeptid(Integer deptid) {
		this.deptid = deptid;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public Integer getSuperid() {
		return superid;
	}

	public void setSuperid(Integer superid) {
		this.superid = superid;
	}

	public String getCreatetime() {
		return createtime;
	}

	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}

	public String getModifytime() {
		return modifytime;
	}

	public void setModifytime(String modifytime) {
		this.modifytime = modifytime;
	}

	
    
 
}