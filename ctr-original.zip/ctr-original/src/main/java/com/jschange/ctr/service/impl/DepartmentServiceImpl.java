package com.jschange.ctr.service.impl;

import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.common.ResultListImpl;
import com.jschange.ctr.dao.DepartmentMapper;
import com.jschange.ctr.exception.ServiceException;
import com.jschange.ctr.model.Department;
import com.jschange.ctr.service.DepartmentService;
@Service
public class DepartmentServiceImpl implements DepartmentService{
	
	
	@Autowired
	private DepartmentMapper deptMapper;
	
	//查询所有部门
	@Override
	public ResultList<Department> queryDeptList(Map<String, Object> map, Pagination page,Integer single) throws ServiceException {
		try {
			ResultList<Department> rl=new ResultListImpl<>();
			if(single!=null){
				if(single==-1){
					if(page != null ){
						int totalCount=deptMapper.queryDeptNum(map);
						page.setTotalCount(totalCount);
						map.put("page", (page.getCurrentPage()-1)*page.getPageSize());
						map.put("rows",page.getPageSize());
					}
				}
			}
			List<Department> list=deptMapper.queryDeptList(map);
			rl.setPage(page);
			rl.setResults(list);
			return rl;
		} catch (Exception e) {
			return null;
		}
	}

	//修改部门信息
	@Override
	public Integer updateDept(Department dept) throws ServiceException {
		try {
			//判断部门名称是否重复
			int i=deptMapper.checkDeptName(dept);
			if(i>0){
				return -3;
			}
			return deptMapper.updateDept(dept);
		} catch (Exception e) {
			return -1;
		}
		
	}
	//增加部门信息
	@Override
	public Integer insertDept(Department dept) throws ServiceException {
		try {
			//判断部门名称是否重复
			int i=deptMapper.checkDeptName(dept);
			if(i>0){
				return -3;
			}
			return deptMapper.insertDept(dept);
		} catch (Exception e) {
			return -1;
		}
	}

	//根据部门id删除部门（只支持单个删除）
	@Override
	public Integer delDept(Integer deptid) throws ServiceException {
		try {
			//判断该部门是否有成员
			Integer i=deptMapper.queryDeptInUseForUser(deptid);
			//判断该删除的部门是否为其他部门的上级部门
			Integer j=deptMapper.queryDeptInUse(deptid);
			//判断该删除的部门是否有系统用户
			Integer h=deptMapper.queryDeptInUseForSystemUser(deptid);
			if(i>0 || j>0 ||h>0){
				return -3;
			}else{
				return deptMapper.delDept(deptid);
			}
		} catch (Exception e) {
			return -1;
		}
	}

}
