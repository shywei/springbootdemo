package com.jschange.ctr.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.model.Department;

public interface DepartmentMapper {
	
	//查询部门，可根据ID查询
	List<Department> queryDeptList(Map<String, Object> map)throws SQLException;
	//查询部门数量
	Integer queryDeptNum(Map<String, Object> map)throws SQLException;
	//修改部门信息
	Integer updateDept(Department dept)throws SQLException;
	//增加部门
	Integer insertDept(Department dept)throws SQLException;
	//根据部门ID删除部门
	Integer delDept(Integer deptid)throws SQLException;
	//判断该部门是否为其他部门的上级部门
	Integer queryDeptInUse(Integer deptid)throws SQLException;
	//判断该部门是否有学员
	Integer queryDeptInUseForUser(Integer deptid)throws SQLException;
	//判断该部门下是否有系统用户
	Integer queryDeptInUseForSystemUser(Integer deptid)throws SQLException;
	//判断部门名称是否重复
	Integer checkDeptName(Department dept)throws SQLException;
	
	
	
	
	


}
