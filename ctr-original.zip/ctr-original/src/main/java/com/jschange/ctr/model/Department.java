package com.jschange.ctr.model;

public class Department {

	private Integer deptid;
	private String deptName;
	private Integer superid;
	private String superDeptName;
	private String createtime;
	private String modifytime;
	public Integer getDeptid() {
		return deptid;
	}
	public void setDeptid(Integer deptid) {
		this.deptid = deptid;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public Integer getSuperid() {
		return superid;
	}
	public void setSuperid(Integer superid) {
		this.superid = superid;
	}
	public String getCreatetime() {
		return createtime;
	}
	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}
	public String getModifytime() {
		return modifytime;
	}
	public void setModifytime(String modifytime) {
		this.modifytime = modifytime;
	}
	public String getSuperDeptName() {
		return superDeptName;
	}
	public void setSuperDeptName(String superDeptName) {
		this.superDeptName = superDeptName;
	}

}
