package com.jschange.ctr.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jschange.ctr.dao.HomePageDao;
import com.jschange.ctr.model.AbsenceList;
import com.jschange.ctr.model.AttendanceDataStatistics;
import com.jschange.ctr.service.HomePageService;


@Transactional
@Service("homePageService")
public class HomePageServiceImpl implements HomePageService {
	
	@Autowired
	HomePageDao homePageDao;
	
	@Override
	public List<AttendanceDataStatistics> homeAttence(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return homePageDao.homeAttence(map);
	}

	@Override
	public int yearlyInOrNotTeam(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return homePageDao.yearlyInOrNotTeam(map);
	}

	@Override
	public AttendanceDataStatistics proportion(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return homePageDao.proportion(map);
	}

	@Override
	public List<AbsenceList> queqinList(String depId) {
		List<AbsenceList>list1= homePageDao.queqinList(depId);//缺席的
		List<AbsenceList>list2=homePageDao.otherList(depId);//其他的
		//循环将缺勤人员列表状态改为缺席并加到list2集合中
		for (AbsenceList absenceList : list1) {
			absenceList.setStateName("缺席");
			list2.add(absenceList);
		}
		return list2;
	}

}
