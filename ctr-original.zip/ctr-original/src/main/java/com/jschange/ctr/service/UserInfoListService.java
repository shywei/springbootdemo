package com.jschange.ctr.service;

import java.rmi.ServerException;
import java.util.List;
import java.util.Map;

import com.jschange.ctr.common.Pagination;
import com.jschange.ctr.common.ResultList;
import com.jschange.ctr.model.State;
import com.jschange.ctr.model.UserInfo;

public interface UserInfoListService {

	//查询人员列表
	ResultList<UserInfo> queryUserInfoList(Map<String, Object> map,Pagination page)throws ServerException;
	
	//人员状态下拉框
	List<State> queryStateList()throws ServerException;
	
	//修改人员状态
	Integer updateUserState(Map<String, Object> map)throws ServerException;
	
}


