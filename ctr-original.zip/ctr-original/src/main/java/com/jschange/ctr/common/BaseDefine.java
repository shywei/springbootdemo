package com.jschange.ctr.common;

public class BaseDefine {
	
	// 比对服务返回值定义
	public final static int IDENTIFY_SUCCESS = 0;

	// 比对服务器访问端口
	public final static int IDENTIFY_SOCKET_PORT = 9999;
}
